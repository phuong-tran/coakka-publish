# CoAkka HTTP for Go

Local package candidate, not a published Go module or release approval.
The Go connector uses host-inlined handlers and the packaged CoAkka HTTP Core.
It does not extract or download libraries at runtime.

## Package contents

- `go/`: Go module `github.com/phuong-tran/coakka-http-runtime-go`, including
  documented source and the cgo bridge.
- `native/`: matching Core shared library, public headers and license material.
- `SHA256SUMS`: exact payload checksums. Keep the Go module and matching native
  SDK together; do not substitute an older local SDK.

Requires Go 1.23 or newer, cgo, and a C11 compiler. The language floor is not
a recommendation to deploy an unsupported toolchain. No downloaded Go modules
are required by this connector. Select the bundle for the application's process
architecture, which may differ from the machine architecture under emulation.
The native SDK targets macOS ARM64, Linux ARM64/x86-64 and Windows ARM64/x86-64.
Per-platform test qualification is recorded separately from archive availability.

## Local module use

No public tag is assigned in this candidate. From an application module, set an
absolute path to the extracted bundle and use a local module replacement:

```sh
export COAKKA_HTTP_PACKAGE=/absolute/path/to/extracted-bundle
go mod edit -require=github.com/phuong-tran/coakka-http-runtime-go@v0.0.0
go mod edit -replace=github.com/phuong-tran/coakka-http-runtime-go="$COAKKA_HTTP_PACKAGE/go"
export CGO_ENABLED=1
export CGO_CFLAGS="-I$COAKKA_HTTP_PACKAGE/native/include"
export CGO_LDFLAGS="-L$COAKKA_HTTP_PACKAGE/native/lib -Wl,-rpath,$COAKKA_HTTP_PACKAGE/native/lib"
go build -trimpath .
```

The commands above cover macOS/Linux. The explicit loader path is also needed
by Go1.23 test executables on macOS. For deployment, choose an application-owned
library directory or a relative loader path; do not bake a developer directory
into a shipped application. Copy the library's versioned aliases along with it.

On Windows, use a cgo-capable C compiler for the selected architecture (MSVC is
not a cgo compiler). Set `CGO_CFLAGS` to `-I<bundle>/native/include` and
`CGO_LDFLAGS` to `-L<bundle>/native/lib`. Add `<bundle>\native\bin` to the
process `PATH`, or deploy its DLL adjacent to the application executable.
Set `GOARCH=arm64` or `amd64` to match both the compiler target and Core.
No global PATH or system installation is required.

## Quick start

```go
package main

import (
    "context"
    "log"
    "os"
    "os/signal"

    coakkahttp "github.com/phuong-tran/coakka-http-runtime-go"
)

func main() {
    ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
    defer stop()
    service, err := coakkahttp.NewBuilder().
        Get("/hello/{name}", func(request *coakkahttp.Request) (coakkahttp.Response, error) {
            return coakkahttp.Text(200, "hello "+request.PathParameters[0].EncodedValue)
        }).Start()
    if err != nil { log.Fatal(err) }
    port, err := service.Port()
    if err != nil { log.Fatal(err) }
    log.Printf("listening on http://127.0.0.1:%d", port)
    <-ctx.Done()
    if err := service.Close(); err != nil { log.Fatal(err) }
}
```

Run `go doc github.com/phuong-tran/coakka-http-runtime-go` for the API and each
field's documented contract. Handlers return ordinary Go values; request data
is Go-owned after the native lease is released. Preserve normal Go ownership
when sharing mutable values across goroutines.

## Configuration and lifecycle

Omitted options delegate to Core. `RuntimeInfo()` reports accepted limits,
CPU selection, execution state, backend and notification settings; input values
are not effective runtime facts. `CPUAuto` is the default, `CPUSingle` requests
one CPU. Placement is not a process-wide quota; Go does not change `GOMAXPROCS`.
CPU budget, HTTP loops and handler concurrency are distinct concepts. HTTP-loop
tuning is fixed by the connector and is not an application setting. Inspect
`RuntimeInfo().Execution.Selection` for Core's accepted construction decision
and `Execution` for observed loop activity; neither is CPU utilization. The
selection is meaningful only when `Execution.Observed` is true. Core validates
the complete configuration and never disables a feature to admit a profile.
Startup settings require graceful close and a new service, not restart of a
stopped owner. Transport, handler, write and shutdown deadlines remain bounded.

The API includes TLS/mTLS, HTTP/2/3, WebSockets, SSE, request/response streaming,
static files, gzip, outbound requests, monitoring and generation-checked route
changes. Core owns protocols, validation, defaults, timeout and failure truth.
Monitoring is disabled by default. io_uring is opt-in; Core probes eligibility
and reports effective fallback. The connector never selects a fallback itself.

Host-inlined compression is optional: configure
`builder.Compression(&coakkahttp.Compression{Mode: coakkahttp.CompressionGZIP, MinimumBodyBytes: 1, GZIPLevel: 6})`
before `Start`. The builder copies the value; later caller mutation cannot
change it. `Compression(nil)` removes an earlier override, and
`CompressionDisabled` explicitly disables compression. Core owns numeric bounds,
workspace, eligibility and `Accept-Encoding` negotiation. The handler returns
an ordinary response; do not precompress it or add a second compression layer.
Unknown Go mode values fail at the enum-to-boolean boundary instead of silently
becoming disabled. This option is startup-only and adds no handler-path lookup.

GZIP transforms eligible buffered responses only. Response streams and SSE
remain uncompressed; enabling GZIP does not collect them into a buffer.
When this coding policy is enabled and a client explicitly refuses identity,
an unencoded response stream is rejected with HTTP406 before it starts.
Application-supplied content encoding remains the application's responsibility.

`Service.Routes()` (also `Runtime.Routes()`) returns `(RouteSnapshot, error)`:
one coherent Core-issued structural generation, binding-change sequence and
complete bounded route/binding list. The returned slice belongs to the caller;
editing it does not change routing. Monitoring need not be enabled. A refused
or unresolved query returns no partial snapshot. This unreleased candidate
replaces the former local-declaration getter; use Core generation/revision
guards when applying changes, not a handler-registry copy.

`ClientTerminal` keeps a typed `OutboundReason`, `OutboundPhase`, `OutboundRetry`
and `OutboundCertainty` together with the copied response and diagnostic.
`OutboundResponse` includes HTTP404/500; cancellation and deadline expiry are
distinct causes. Switch on named constants, not numeric tables or diagnostic
text. Unknown enum numbers remain representable; `Reason.String()` derives a
symbolic code or `UNKNOWN(number)`. Retry disposition is not permission to
replay business work: the application owns idempotency and retry budgets.
Do not automatically expose operator diagnostics to an HTTP client.

`Service.Close` closes admission, waits for Core's drain outcome and joins Go
work before destroying Core. Application handlers must return. A refusal may
retain ownership: inspect `*CloseError.RuntimeRetained`, retain the service and
retry cleanup. `*DrainError` preserves forced expiry or abort even after cleanup.
Never report an expired drain as graceful success. Low-level `Runtime.Close`
is forced cleanup; low-level graceful use requires `Drain`, progressing readers
and handlers, and `WaitDrained` first. A timed wait is not native quiescence.

## Licensing and status

The file-scoped terms are in `LICENSE`, `NATIVE-LICENSE.md`, `PACKAGE-LICENSE.md`
and `NOTICE`. Go connector source is supplied for normal Go module compilation;
Core remains a closed shared library. Source packaging is not binary obfuscation
or a claim that native binaries cannot be inspected. This candidate does not
authorize publication, assign registry coordinates or establish an ABI freeze.
