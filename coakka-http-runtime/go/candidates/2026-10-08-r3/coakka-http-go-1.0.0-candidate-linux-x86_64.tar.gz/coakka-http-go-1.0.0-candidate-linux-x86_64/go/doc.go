// Package coakkahttp is the typed Go connector for CoAkka HTTP Runtime.
//
// Runtime owns every listener, socket, file, TLS context, client connection, and
// protocol state machine. The Go package supplies copied configuration values,
// pulls copied events, and submits commands; it never hosts an HTTP stack.
package coakkahttp
