# Go Connector Architecture

## Boundary

The connector binds only the public declarations from `include/coakka/http/http.h`
projected in `internal/native_api.h`. `bridge.c` resolves the complete ABI8
table before configuration allocation. A missing symbol or an ABI revision
other than 7
fails closed. No private runtime header, protobuf schema, callback, Go HTTP
server, socket, file descriptor, TLS engine, or client transport crosses this
boundary.

Core is the sole owner of listeners, connections, protocol state, filesystem
access, TLS material, WebSocket sessions, and outbound calls. Inputs are
ordinary Go values projected into temporary C allocations. Every configuration
and command API copies those inputs before a successful return; the temporary
arena is then released.

## Layers

- `config.go` and `outbound_config.go` model every construction-time ABI8
  option, including static/SPA mounts, application file authorities, TLS/mTLS,
  gzip, inspection, monitor reservation, and outbound topology.
- `native_config.go` is the only configuration projection owner. It creates
  the opaque native configuration, applies copied declarations, creates Core,
  destroys the temporary configuration, and transfers the library handle to
  `nativeCore`.
- `core.go` is the public lifecycle and concurrency boundary. It counts active
  native calls, enforces one reader per pull lane, and prevents destroy from
  overlapping a call.
- `native_protocol.go`, `native_extended.go`, and `native_monitor.go` project
  request, stream, SSE, WebSocket, outbound, health, rebind, and monitor values.
- `service.go` is an optional bounded request/reply facade. One event pump feeds a
  fixed worker set through a bounded channel; it is implemented entirely over
  public `Core` methods. Startup obtains one Core plan before allocating the
  runtime, and the service retains the pointer-free plan as observable
  effective configuration. A construction-time monitor reservation and all six
  monitor controls delegate to the same Core owner. Its single listener is
  copied as a complete protocol/security declaration; Core alone opens file
  credentials and owns the TLS context and handshake lifecycle.
  Static mount and file-authority declarations are copied during that same
  construction transaction. Static-only startup uses an empty handler registry
  rather than a synthetic route. A file response transfers only the bounded
  response head, authority ID and encoded path; Core owns confinement, open,
  metadata validation, `sendfile` selection, fallback I/O and descriptor
  release.
  `service_response_stream.go` owns the per-exchange response-writability state.
  The same event pump demultiplexes writable, cancellation and terminal events;
  its capacity-one notification cannot grow with duplicate readiness. One fixed
  worker owns each producer and retries only an exact queue-full chunk.
  `service_request_stream.go` owns one sole-reader queue per active streamed
  request. The event pump is its only producer; copied DATA/trailer items are
  bounded at construction and must have a continuous Core sequence. Terminal
  state uses no queue slot, so cancel, close and Core terminal events always
  wake a blocked handler read.
  `service_sse.go` owns the callback-scoped typed SSE writer.
  `service_websocket.go` owns the construction-bounded pending/session maps and
  the sole WebSocket reader. Native event bytes are copied under the low-level
  lease law before the ordered callback runs; callback failure closes only the
  affected session with code 1011.

## Lease Law

Each successful native `take_event`, `take_websocket`, or `take_outbound`
returns exactly one Core-owned lease. The matching native projection method:

1. initializes the public ABI output struct;
2. takes one item;
3. installs the matching release in a defer immediately;
4. copies every byte range and pointer-free field into Go storage;
5. joins a release failure into the returned error.

The public `Event`, `SocketEvent`, and `ClientTerminal` therefore never contain
native pointers and cannot outlive a lease accidentally. Even validation or
allocation failure follows the same release path.

## Lifecycle Law

`Core.acquire` rejects new operations after close begins and counts calls that
already crossed the boundary. `Close` marks the Core closing, invokes the two
ABI-defined reader interrupts, waits for the active count to reach zero, then
drains/stops a started Core, destroys it, and finally unloads the dynamic
library. WebSocket, outbound, liveness, rebind, and monitor waits are capped at
30 seconds, so non-interruptible joins remain finite.

After stop has joined native producers, `Core.Close` nonblockingly copies and
releases the remaining bounded terminal queue before destroy. ABI8 keeps queued
terminal observations readable after stop specifically for this ownership
handoff. A retained destroy keeps the native owner and a later close retries
without repeating completed connector shutdown stages.

`Service.Close` first marks connector admission closed and asks Core to drain.
Core interrupts wake any sole outbound or monitor waiter before close waits for active
native calls, so no service mutex is held across the blocking wait.
The sole event pump remains alive: requests that crossed the Core boundary are
either delivered to an already admitted worker or completed with the bounded
503 overload response, and every resulting terminal observation is released. One
empty timed read with no tracked exchange is the pump quiescence barrier. Close
also marks every response-stream state terminal so a pressure wait cannot pin a
worker. Stable completion channels cover the pump, fixed workers and optional
WebSocket reader; no retry creates a detached waiter goroutine. Each `Close`
uses one monotonic connector deadline, closes the work channel only after the
pump exits, joins the workers, then stops the WebSocket reader and delegates
native destruction to `Core.Close`. A timeout retains the reachable Core and
resumes those stages on a later `Close`. A `Handler` must return and must not
call `Service.Close`; Go cannot forcibly cancel arbitrary application code.

## Artifact Law

The selected payload is embedded by exact Go target, bounded to 64 MiB,
verified by SHA-256, extracted once into an owner-only process directory, and
loaded with local symbol visibility. `COAKKA_HTTP_CORE_PATH` is a development
override and accepts only a bounded regular non-symlink file. It does not relax
the ABI8 or complete-symbol-table check.
