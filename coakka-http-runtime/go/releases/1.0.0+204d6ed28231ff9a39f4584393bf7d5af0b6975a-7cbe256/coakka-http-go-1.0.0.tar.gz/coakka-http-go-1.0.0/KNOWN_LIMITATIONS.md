# Known Limitations

- Runtime info reports the loaded image and current host at query time.
  Production may fall back from requested `IOUring`; consumers needing an
  exact backend must check the per-Core effective value after start.

Release `1.0.0` is distributed as a GitHub source artifact. A tagged public Go
module remains a separate publication gate.

## Artifact Evidence

- The current private source embeds exact full-profile ABI8 Core
  `204d6ed28231ff9a39f4584393bf7d5af0b6975a` images for all five release
  targets. Embedded tests, vet and 20 repetitions pass on the recorded hosts;
  Linux images require GLIBC 2.28.
- Windows arm64 has matching-host functional evidence. Windows x86-64 executes
  under Windows 11 ARM64's x64 emulation layer, so that result is matching-OS
  functional evidence rather than physical-x86-64 or performance evidence.
- Cross-compilation remains build evidence only and never substitutes for the
  recorded matching-host executions.

## API Constraints

- Direct native waits accept durations from zero through 30 seconds. Longer
  application waits must poll and observe their own context or cancellation.
- `Builder`/`Service` supports buffered inline-body and sole-reader streamed requests, and buffered or
  incremental responses with final trailers
  with one complete Core-owned listener, including protocol and TLS/mTLS
  declaration and copied request trailers. Typed SSE and WebSocket callbacks
  are also high-level Service capabilities. Static/index/SPA trees and
  authority-confined application file responses are available directly on the
  same high-level Service; Core owns file I/O and automatic `sendfile`
  fallback. Logical outbound target declaration, submit, cancel and copied
  terminal take are available on the same high-level Service. Inspection and
  advanced protocol control remain available through the complete low-level
  `Config`/`Core` API.
  Monitoring, handler-only rebind and complete structural route publication
  are exposed on the facade through the same Core owner.
- All five embedded ABI8 candidates execute real HTTP/2 TLS and HTTP/3
  QUIC/TLS request/reply through `Builder`/`Service` without an override.
- `Service.Close` waits only to `Limits.ShutdownTimeoutMillis` for admitted
  application work and connector readers. A timeout keeps the Core owner
  reachable and permits retry after the handler returns; Core may already have
  completed the HTTP exchange with its bounded `503 runtime stopped` terminal.
  Handlers must not call `Close` on their own Service. The low-level `Core` API
  is the appropriate boundary for applications requiring cancellable worker
  supervision.
- The extracted embedded file and owner-only directory are retained for the
  process lifetime so repeated Core creation cannot create an unbounded number
  of temporary files. Automatic process-exit directory deletion is not provided;
  short-lived tools should use a task-scoped `TMPDIR` and remove it afterward.

## Verification

The admitted ABI8 images expose exactly 176 public symbols. From this
module directory on the qualified hosts, the following commands pass with
the exact embedded images (not a Core override):

```sh
go test ./...
go vet ./...
go test -race ./...
go test -count=20 ./...
```

The tests exercise the exact embedded bytes, callback-free pull dispatch,
automatic event lease release, buffered Service concurrency and close,
incremental request-body delivery before upload completion,
health/liveness, the complete Service monitor plane, ABI surface completeness,
bounded overload, timeout-retained close retry, GoDoc coverage, and payload
digest verification.

Go's race runtime cannot start on the Pi kernel's 47-bit VMA layout; its
diagnostic is preserved as blocked, not a test failure or pass. The complete
Go race suite passes on a separate native ARM64 VM. Go itself does not support
`-race` on Windows ARM64; Windows x86-64 race passes under the declared
emulation environment. None of these Go checks instruments native Core. See
the repository's September 28 five-target record for exact identities.
