# CoAkka HTTP for Go

Release `1.0.0` source is available as a GitHub artifact. A tagged public Go
module is a separate publication gate and has not been opened.

## Runtime baseline

The consumer baseline is Go 1.23 with cgo and a C11 compiler. The `go 1.23`
module directive is the owning minimum, and the connector test and vet gates run
with an actual Go 1.23 toolchain in addition to the development toolchain. A
newer locally installed Go version does not raise this minimum.

The current source candidate binds the public callback-free Core ABI8. The native Core is the
sole owner of listeners, sockets, TLS state, files, HTTP protocol engines,
WebSockets, and outbound client connections. Go supplies copied configuration
and commands and pulls copied events; the connector does not host HTTP.

`Config` and `Core` expose the complete low-level surface: listener protocols
and TLS/mTLS, route body policy, resource limits, gzip, static/SPA mounts,
application file authorities, outbound topology and credentials, request and
response streams, trailers, SSE, WebSockets, route rebind, health, inspection,
and monitoring. `Builder` and `Service` provide the single-listener
request/reply path, including buffered and incrementally read requests, incremental responses with
final trailers, protocol and TLS/mTLS declaration, the complete monitor control
plane, generation-checked handler-only publication, and copied request trailers
in `Request.Trailers`.

```go
service, err := coakkahttp.NewBuilder().
    Post("/echo", func(request *coakkahttp.Request) (coakkahttp.Response, error) {
        return coakkahttp.Bytes(200, request.Bytes())
    }).
    Start()
if err != nil {
    return err
}
defer service.Close()

plan := service.Plan() // immutable Core decision captured before listen
runtimeInfo, err := service.RuntimeInfo()
health, err := service.Health()
probed, err := service.ProbeLiveness(time.Second)
monitorConfig, err := service.MonitorConfig()
monitorPage, err := service.ReadMonitorEvents(0, 8)
replacement := func(request *coakkahttp.Request) (coakkahttp.Response, error) {
    return coakkahttp.Bytes(201, request.Bytes())
}
err = service.PrepareHandler(2, replacement)
outcome, err := service.RebindHandler(coakkahttp.RebindRequest{
    ActivationID: 1, ExpectedRouteGeneration: 1, RouteID: 1,
    ExpectedBindingRevision: 1, NewHandlerBindingID: 2,
}, 2*time.Second)
```

`Builder.Start` always asks Core to plan the complete declaration before it
allocates or publishes a listener. The current Go transport provider is
Runtime Core, and `Service.Plan()` exposes that immutable effective decision;
there is no execution-provider setter.
`Builder.Listener` replaces the complete single-listener declaration. Core
copies its bind/protocol/security values, opens the certificate, key and
optional mutual-TLS trust file, and owns the resulting TLS resources. The
service plan includes the matching HTTP/2, HTTP/3, TLS or mutual-TLS capability
before Core allocation; invalid or unsupported declarations fail before
request admission.
The five-target package gates send real HTTP/2 TLS and HTTP/3 QUIC/TLS
requests through this same `Service`; protocol values are not
configuration-only placeholders.
`Builder.StaticMount` publishes an immutable Core-owned static tree, including
optional index and SPA fallback policy; a static-only service needs no dummy
Go route or worker callback. `Builder.FileAuthority` plus `ServeFile` selects
an encoded path under one configured authority without opening or reading the
file in Go. Core chooses its supported `sendfile` path when legal and otherwise
uses its bounded fallback; the connector exposes no transport-specific switch.
The buffered service gate also sends a raw chunked HTTP/1.1 request and requires
both its body and announced trailer to reach the handler.
`PostStream` and the other `*Stream` route helpers deliver the body through the
sole-consumer `Request.Body` reader. The event pump copies DATA and trailers
into a construction-bounded per-exchange queue; EOF makes `Request.Trailers`
visible, while cancellation, terminal completion and close wake a blocked read.
`NewStreamingResponse` adds response streaming to the same service. Its producer
runs on one fixed worker, writes through a callback-scoped
`ResponseStreamWriter`, and returns final `Headers`. The sole event reader
routes writable, cancellation and terminal events to a bounded per-exchange
state. A write retries the exact chunk only after Core reports queue pressure;
disconnect and close wake the producer within `Limits.ResponseWriteTimeoutMillis`.
`NewSSEResponse` writes typed `SSEEvent` values through that same bounded writer
law. `Builder.WebSocket` and `NewWebSocketResponse` declare a Core-owned upgrade
and one ordered Go callback. A sole reader copies and exact-releases each native
event before invoking the callback; pending upgrades and sessions are each
capped by `Limits.MaxActiveRequests`. A callback error or panic is retained in
the bounded diagnostic queue and closes the session with code 1011. Service
close rejects new upgrades, joins the reader, marks every Go session closed,
and then delegates native destruction to Core.
`Service.RuntimeInfo()`, `Service.Health()` and `Service.ProbeLiveness()` expose
the same copied Core snapshots and bounded active probe as the low-level owner;
the connector does not create its own sampler or platform probe.
`Builder.Monitor` reserves monitor resources before start. `Service` then
forwards config, aggregate snapshot, generation-checked policy apply, bounded
event read, sole-waiter wait, and interrupt to that same Core. Close interrupts
the waiter before draining active calls.
`Builder.OutboundTarget` adds one immutable logical target generation before
planning. `Service.OutboundSubmit` copies a buffered request,
`Service.OutboundCancel` requests sticky cancellation, and
`Service.TakeOutbound` returns one Go-owned terminal or `nil` only on timeout.
Exactly one terminal reader may run; `Close` interrupts it and waits for the
active call gate before Core destruction.
The handler queue is fixed by `Limits.RequestQueueCapacity`; host dispatch
pressure receives `503 service unavailable`, while earlier Core admission
pressure may receive `503 runtime busy`. `Close` gives the pump, workers and
optional WebSocket reader one monotonic connector deadline. If application
code remains live at expiry, the native owner is retained and a later `Close`
continues shutdown after that code converges.
`Limits.MaxHandlerBindings` fixes the total lifetime number of startup,
prepared, active and retired handler IDs. `PrepareHandler` registers a
single-assignment ID; `RebindHandler` publishes it through Core's generation
checks. Admitted requests retain their captured handler. Retry a delivery-
ambiguous result only with the exact same request and prepared ID. Inspect the
typed `outcome.Code` (for example, `RebindApplied`) for the publication result.
`PublishRoutes` submits one complete structural generation whose handler IDs
were already prepared. The service updates `Routes()` only after Core returns
`RoutePublicationApplied`; exact replay returns the retained digest and stale
generation rejection preserves both dispatch and the previous snapshot. If an
exact retry after timeout or wakeup ambiguity returns
`RoutePublicationActivationExpired`, close and recreate the service before
publishing again; the Go facade does not guess from its local snapshot.

For lower-level protocol control, create `Config`, call
`Open`, start the returned `Core`, and run exactly one reader for each required
pull lane:

```go
core, err := coakkahttp.Open(coakkahttp.Config{
    Listeners: []coakkahttp.Listener{{
        ID: 1, BindAddress: "127.0.0.1",
        Protocol: coakkahttp.ProtocolHTTP11,
        Security: coakkahttp.SecurityPlaintext,
    }},
    Routes: []coakkahttp.Route{{
        ID: 1, HandlerBindingID: 1, Method: "GET", Pattern: "/events",
        BodyDelivery: coakkahttp.BodyStream,
    }},
})
if err != nil {
    return err
}
defer core.Close()
if err = core.Start(); err != nil {
    return err
}
event, err := core.TakeEvent(250 * time.Millisecond)
```

`InspectRuntime()` reports whether the loaded Core and current host support
Core's exact `io_uring` poller contract. `Core.RuntimeInfo()` adds
requested/effective backend and fallback truth. `IOUring` is a production
preference: Core may fall back to `IOPlatformDefault` when it is rejected or
unavailable. A benchmark claiming `io_uring` must reject unsupported or
fallback snapshots; Go must not inspect `/proc` or probe the syscall itself.

`PlanService(required, host)` asks Core to normalize dependencies and choose
one provider for a complete service declaration. The host mask is an audited
connector implementation fact, not an OS probe. Unsupported plans retain both
missing masks so a higher-level Go facade can reject startup without removing
the requested capability from its API.

`TakeEvent`, `TakeWebSocket`, and `TakeOutbound` copy all borrowed data and
release the native lease exactly once before returning, including copy-error
paths. Pull waits are capped at 30 seconds so `Close` has a finite connector
join bound; longer application waits should poll and observe their own context.
`Close` interrupts the inbound, outbound and monitor waiters, waits for active native
calls, then destroys Core before unloading its library.

`COAKKA_HTTP_CORE_PATH` may select a matching ABI8 binary for development. The
override must resolve to a bounded regular non-symlink file. Packaged operation
extracts the build-tag-selected embedded payload once per process, verifies its
SHA-256 digest, and loads it locally. A package is releasable only when exact
Core payloads for `darwin/arm64`, `linux/amd64`, `linux/arm64`,
`windows/amd64`, and `windows/arm64` have matching-host dependency closure,
export, architecture, and runtime evidence.

Release payload state:

| Go target | Current pre-registry payload |
| --- | --- |
| `darwin/arm64` | qualified private full-profile ABI8 payload |
| `linux/amd64` | qualified private full-profile ABI8 payload, GLIBC 2.28 |
| `linux/arm64` | qualified private full-profile ABI8 payload, GLIBC 2.28 |
| `windows/amd64` | qualified private full-profile ABI8 payload |
| `windows/arm64` | qualified private full-profile ABI8 payload |

All five payloads consume Core source
`204d6ed28231ff9a39f4584393bf7d5af0b6975a` and pass embedded test, vet and
20 bounded repetitions without a development override. Race passes on macOS,
Linux x86-64, a native Linux ARM64 VM and Windows x86-64. Go does not support
`-race` on Windows ARM64; the Pi's 47-bit VMA layout prevents that race runtime
from starting. Those tool limits are not reported as passes. Public module
publication and production signing remain separate gates.
