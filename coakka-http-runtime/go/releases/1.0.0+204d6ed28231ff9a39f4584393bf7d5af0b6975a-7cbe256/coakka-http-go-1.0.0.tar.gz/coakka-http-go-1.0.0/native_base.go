package coakkahttp

/*
#cgo CFLAGS: -std=c11 -Wall -Wextra -Wpedantic -Wconversion -Wsign-conversion -Werror
// Go 1.23's generated _cgo_main.c uses an old-style main declaration. AppleClang
// 17 and LLVM-MinGW Clang 23 diagnose that generated declaration; owned bridge
// code keeps full C11 gates.
#cgo darwin CFLAGS: -Wno-strict-prototypes
#cgo windows CFLAGS: -Wno-strict-prototypes
#cgo linux LDFLAGS: -ldl
#include "bridge.h"
#include <stdlib.h>
*/
import "C"

import (
	"crypto/sha256"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
	"unsafe"
)

const (
	maximumBridgeBytes     = 64 << 20
	maximumProjectionItems = 1 << 20
	maximumNativeWait      = 30 * time.Second
)

var (
	corePathOnce sync.Once
	corePath     string
	corePathErr  error
)

type nativeCore struct {
	api          *C.coakka_http_go_api_t
	core         *C.coakka_http_core_t
	capabilities Capabilities
}

type nativeArena struct {
	allocations []unsafe.Pointer
}

func (arena *nativeArena) close() {
	for index := len(arena.allocations) - 1; index >= 0; index-- {
		C.free(arena.allocations[index])
	}
	arena.allocations = nil
}

func (arena *nativeArena) allocate(size uintptr) (unsafe.Pointer, error) {
	if size == 0 {
		return nil, nil
	}
	pointer := C.calloc(1, C.size_t(size))
	if pointer == nil {
		return nil, errors.New("native projection allocation failed")
	}
	arena.allocations = append(arena.allocations, pointer)
	return pointer, nil
}

func (arena *nativeArena) bytes(value []byte) (C.coakka_http_bytes_t, error) {
	if len(value) == 0 {
		return C.coakka_http_bytes_t{}, nil
	}
	if len(value) > maximumBridgeBytes {
		return C.coakka_http_bytes_t{}, errors.New("native byte projection exceeds the Go bound")
	}
	pointer := C.CBytes(value)
	if pointer == nil {
		return C.coakka_http_bytes_t{}, errors.New("native byte projection allocation failed")
	}
	arena.allocations = append(arena.allocations, pointer)
	return C.coakka_http_bytes_t{data: (*C.uint8_t)(pointer), size: C.uint64_t(len(value))}, nil
}

func (arena *nativeArena) text(value string) (C.coakka_http_bytes_t, error) {
	return arena.bytes([]byte(value))
}

func boolByte(value bool) C.uint8_t {
	if value {
		return 1
	}
	return 0
}

func nativeDuration(timeout time.Duration) (C.uint64_t, error) {
	if timeout < 0 {
		return 0, errors.New("timeout must not be negative")
	}
	if timeout > maximumNativeWait {
		return 0, fmt.Errorf("timeout exceeds the bounded maximum %s", maximumNativeWait)
	}
	if timeout == 0 {
		return 0, nil
	}
	milliseconds := (timeout + time.Millisecond - 1) / time.Millisecond
	return C.uint64_t(milliseconds), nil
}

func resultError(result C.coakka_http_result_t) error {
	if ResultCode(result.code) == ResultOK {
		return nil
	}
	detail := C.GoString((*C.char)(unsafe.Pointer(&result.detail[0])))
	return &Error{
		Code:   ResultCode(result.code),
		Actual: uint64(result.actual),
		Limit:  uint64(result.limit),
		Detail: detail,
	}
}

func nativePlanService(api *C.coakka_http_go_api_t, required, host Capabilities) (ServicePlan, error) {
	var request C.coakka_http_service_plan_request_t
	var plan C.coakka_http_service_plan_t
	C.coakka_http_go_service_plan_request_init(api, &request)
	C.coakka_http_go_service_plan_init(api, &plan)
	request.required_capabilities = C.coakka_http_capabilities_t(required)
	request.host_capabilities = C.coakka_http_capabilities_t(host)
	request.runtime_capabilities = C.coakka_http_go_features(api)
	outcome := C.coakka_http_go_plan_service(api, &request, &plan)
	code := ResultCode(outcome.code)
	if code != ResultOK && code != ResultUnsupported {
		return ServicePlan{}, resultError(outcome)
	}
	return ServicePlan{
		Provider:                   Provider(plan.provider),
		Supported:                  code == ResultOK,
		RequiredCapabilities:       Capabilities(plan.required_capabilities),
		HostCapabilities:           Capabilities(plan.host_capabilities),
		RuntimeCapabilities:        Capabilities(plan.runtime_capabilities),
		MissingHostCapabilities:    Capabilities(plan.missing_host_capabilities),
		MissingRuntimeCapabilities: Capabilities(plan.missing_runtime_capabilities),
	}, nil
}

func nativeBytes(value C.coakka_http_bytes_t) ([]byte, error) {
	if value.size == 0 {
		return nil, nil
	}
	if value.data == nil || uint64(value.size) > maximumBridgeBytes {
		return nil, errors.New("native byte range is outside the Go bound")
	}
	return C.GoBytes(unsafe.Pointer(value.data), C.int(value.size)), nil
}

func nativeText(value C.coakka_http_bytes_t) (string, error) {
	data, err := nativeBytes(value)
	return string(data), err
}

func resolveCorePath() (string, error) {
	if override := os.Getenv("COAKKA_HTTP_CORE_PATH"); override != "" {
		input, err := os.Lstat(override)
		if err != nil || input.Mode()&os.ModeSymlink != 0 {
			return "", errors.New("native Core override must be a regular non-symlink file")
		}
		resolved, err := filepath.EvalSymlinks(override)
		if err != nil {
			return "", err
		}
		details, err := os.Stat(resolved)
		if err != nil || !details.Mode().IsRegular() || details.Size() <= 0 || details.Size() > maximumBridgeBytes {
			return "", errors.New("native Core override is outside the package bound")
		}
		return resolved, nil
	}
	corePathOnce.Do(func() {
		if len(packagedCore) == 0 || len(packagedCore) > maximumBridgeBytes {
			corePathErr = errors.New("no verified native Core payload exists for this target")
			return
		}
		actual := fmt.Sprintf("%x", sha256.Sum256(packagedCore))
		if actual != packagedCoreSHA256 {
			corePathErr = errors.New("packaged native Core failed integrity validation")
			return
		}
		directory, err := os.MkdirTemp("", "coakka-http-")
		if err != nil {
			corePathErr = err
			return
		}
		if err = os.Chmod(directory, 0o700); err != nil {
			corePathErr = err
			return
		}
		corePath = filepath.Join(directory, packagedCoreName)
		if err = os.WriteFile(corePath, packagedCore, 0o500); err != nil {
			corePathErr = err
		}
	})
	return corePath, corePathErr
}

func openNativeAPI() (*C.coakka_http_go_api_t, error) {
	path, err := resolveCorePath()
	if err != nil {
		return nil, err
	}
	nativePath := C.CString(path)
	if nativePath == nil {
		return nil, errors.New("native Core path allocation failed")
	}
	defer C.free(unsafe.Pointer(nativePath))
	var api *C.coakka_http_go_api_t
	if err := resultError(C.coakka_http_go_open(nativePath, &api)); err != nil {
		return nil, err
	}
	if api == nil {
		return nil, errors.New("native Core returned an empty ABI table")
	}
	return api, nil
}

func nativeFeatures(api *C.coakka_http_go_api_t) Capabilities {
	return Capabilities(C.coakka_http_go_features(api))
}

func projectRuntimeInfo(value C.coakka_http_runtime_info_t) RuntimeInfo {
	return RuntimeInfo{
		ABIVersion:         uint32(value.abi_version),
		Features:           Capabilities(value.features),
		IOUringCompiled:    value.io_uring_compiled != 0,
		IOUringSupported:   value.io_uring_supported != 0,
		IOUringProbeError:  int32(value.io_uring_probe_error),
		RequestedIOBackend: IOBackend(value.requested_io_backend),
		EffectiveIOBackend: IOBackend(value.effective_io_backend),
		FallbackReason:     IOBackendFallbackReason(value.fallback_reason),
		CoreStarted:        value.core_started != 0,
	}
}

func nativeRuntimeInfo(api *C.coakka_http_go_api_t) (RuntimeInfo, error) {
	var value C.coakka_http_runtime_info_t
	C.coakka_http_go_runtime_info_init(api, &value)
	if err := resultError(C.coakka_http_go_runtime_get_info(api, &value)); err != nil {
		return RuntimeInfo{}, err
	}
	return projectRuntimeInfo(value), nil
}

func (native *nativeCore) runtimeInfo() (RuntimeInfo, error) {
	var value C.coakka_http_runtime_info_t
	C.coakka_http_go_runtime_info_init(native.api, &value)
	if err := resultError(C.coakka_http_go_core_get_runtime_info(native.api, native.core, &value)); err != nil {
		return RuntimeInfo{}, err
	}
	return projectRuntimeInfo(value), nil
}

func closeNativeAPI(api **C.coakka_http_go_api_t) {
	C.coakka_http_go_close(api)
}

func (native *nativeCore) destroy() error {
	if native == nil {
		return nil
	}
	var err error
	if native.core != nil {
		err = resultError(C.coakka_http_go_core_destroy(native.api, &native.core))
	}
	if native.core == nil {
		C.coakka_http_go_close(&native.api)
	}
	return err
}
