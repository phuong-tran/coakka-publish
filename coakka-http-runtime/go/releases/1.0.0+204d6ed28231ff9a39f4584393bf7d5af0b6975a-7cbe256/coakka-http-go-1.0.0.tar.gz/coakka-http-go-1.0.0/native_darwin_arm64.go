//go:build darwin && arm64

package coakkahttp

import _ "embed"

//go:embed native/darwin-arm64/libcoakka_http_runtime.1.0.0.dylib
var packagedCore []byte

const packagedCoreName = "libcoakka_http_runtime.1.0.0.dylib"
const packagedCoreSHA256 = "027bcabeb06bd7b2810b33a015853c205600466f998816860ebc08115ed4331e"
