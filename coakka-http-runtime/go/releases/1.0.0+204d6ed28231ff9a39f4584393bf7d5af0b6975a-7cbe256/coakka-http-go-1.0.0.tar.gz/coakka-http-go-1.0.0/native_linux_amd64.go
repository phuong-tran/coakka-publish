//go:build linux && amd64

package coakkahttp

import _ "embed"

//go:embed native/linux-amd64/libcoakka_http_runtime.so.1.0.0
var packagedCore []byte

const packagedCoreName = "libcoakka_http_runtime.so.1.0.0"
const packagedCoreSHA256 = "0f5208841f331c62dc10cb55e776a161093ead8e01aaa7a3ef0c353bf3a77f79"
