//go:build linux && arm64

package coakkahttp

import _ "embed"

//go:embed native/linux-arm64/libcoakka_http_runtime.so.1.0.0
var packagedCore []byte

const packagedCoreName = "libcoakka_http_runtime.so.1.0.0"
const packagedCoreSHA256 = "22a7bfe646699c5770ca1b83407efa65df4222bbd758dd9bbe00a462108a35f2"
