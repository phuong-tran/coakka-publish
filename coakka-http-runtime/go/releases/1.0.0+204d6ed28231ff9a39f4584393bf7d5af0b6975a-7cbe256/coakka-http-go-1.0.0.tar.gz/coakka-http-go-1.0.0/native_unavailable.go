//go:build !(darwin && arm64) && !(linux && arm64) && !(linux && amd64) && !(windows && arm64) && !(windows && amd64)

package coakkahttp

// A target stays unavailable until its ABI8 matching-host dependency, export,
// architecture, stress, and race gates pass. Pre-registry payloads are removed
// rather than retained as a compatibility path.
var packagedCore []byte

const packagedCoreName = "unavailable"
const packagedCoreSHA256 = ""
