//go:build windows && amd64

package coakkahttp

import _ "embed"

//go:embed native/windows-amd64/coakka_http_runtime.dll
var packagedCore []byte

const packagedCoreName = "coakka_http_runtime.dll"
const packagedCoreSHA256 = "94d9ef20d45eadba479dfecf50cdcb773b1aa764524c7d901299b0d9aabba0bc"
