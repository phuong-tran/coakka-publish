//go:build windows && arm64

package coakkahttp

import _ "embed"

//go:embed native/windows-arm64/coakka_http_runtime.dll
var packagedCore []byte

const packagedCoreName = "coakka_http_runtime.dll"
const packagedCoreSHA256 = "9bc1f29ee84baa23e713258da2f922f9a7334bfd1f2a049901841078288b6990"
