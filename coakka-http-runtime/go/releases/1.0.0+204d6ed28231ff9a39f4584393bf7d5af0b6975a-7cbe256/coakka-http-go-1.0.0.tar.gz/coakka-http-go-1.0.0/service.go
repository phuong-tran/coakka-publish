package coakkahttp

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"strings"
	"sync"
	"time"
)

const (
	maximumRoutes          = 1024
	maximumHandlerBindings = 16384
	maximumStaticMounts    = 16
	maximumFileAuthorities = 16
	maximumOutboundTargets = 32
	maximumOutboundTrusts  = 16
	maximumOutboundIDs     = 16
	servicePollInterval    = 100 * time.Millisecond
)

var serviceMethods = map[string]struct{}{
	"DELETE": {},
	"GET":    {},
	"PATCH":  {},
	"POST":   {},
	"PUT":    {},
}

// Limits contains the buffered Service's principal Core and pump bounds.
type Limits struct {
	// MaxConnections bounds accepted connections retained by Core.
	MaxConnections uint32
	// MaxActiveRequests bounds concurrent exchanges retained by Core.
	MaxActiveRequests uint32
	// RequestQueueCapacity bounds requests waiting for a Go worker.
	RequestQueueCapacity uint32
	// ResponseQueueCapacity bounds native response completions.
	ResponseQueueCapacity uint32
	// MaxRequestBodyBytes bounds one inline request body.
	MaxRequestBodyBytes uint64
	// MaxResponseBodyBytes bounds one buffered response body.
	MaxResponseBodyBytes uint64
	// RequestTimeoutMillis bounds application response latency in Core.
	RequestTimeoutMillis uint32
	// ShutdownTimeoutMillis bounds connector quiescence plus native drain and stop.
	ShutdownTimeoutMillis uint32
	// ResponseWriteTimeoutMillis bounds each wait for response stream credit.
	ResponseWriteTimeoutMillis uint32
	// RequestStreamMaxRetainedItems bounds copied body events waiting per streamed request.
	RequestStreamMaxRetainedItems uint32
	// MaxHandlerBindings bounds startup, prepared, active, and retired binding IDs.
	MaxHandlerBindings uint32
}

// DefaultLimits returns conservative finite bounds for a small service.
func DefaultLimits() Limits {
	return Limits{
		MaxConnections:                128,
		MaxActiveRequests:             64,
		RequestQueueCapacity:          64,
		ResponseQueueCapacity:         64,
		MaxRequestBodyBytes:           1 << 20,
		MaxResponseBodyBytes:          4 << 20,
		RequestTimeoutMillis:          30_000,
		ShutdownTimeoutMillis:         5_000,
		ResponseWriteTimeoutMillis:    5_000,
		RequestStreamMaxRetainedItems: 4,
		MaxHandlerBindings:            1_088,
	}
}

// Validate rejects zero, excessive, or inconsistent Service limits.
func (limits Limits) Validate() error {
	if limits.MaxConnections == 0 || limits.MaxConnections > 65_536 ||
		limits.MaxActiveRequests == 0 || limits.MaxActiveRequests > limits.MaxConnections ||
		limits.RequestQueueCapacity == 0 || limits.RequestQueueCapacity > limits.MaxActiveRequests ||
		limits.ResponseQueueCapacity == 0 || limits.ResponseQueueCapacity > limits.MaxActiveRequests ||
		limits.MaxRequestBodyBytes == 0 || limits.MaxRequestBodyBytes > maximumBridgeBytes ||
		limits.MaxResponseBodyBytes == 0 || limits.MaxResponseBodyBytes > maximumBridgeBytes ||
		limits.RequestTimeoutMillis == 0 || limits.ShutdownTimeoutMillis == 0 ||
		limits.ResponseWriteTimeoutMillis == 0 ||
		limits.RequestStreamMaxRetainedItems == 0 || limits.RequestStreamMaxRetainedItems > 1024 ||
		limits.MaxHandlerBindings == 0 || limits.MaxHandlerBindings > maximumHandlerBindings {
		return errors.New("CoAkka HTTP service limits are invalid")
	}
	return nil
}

type routeDeclaration struct {
	route     Route
	handler   Handler
	webSocket bool
}

// Builder collects one buffered inline-body Service declaration. Configure it
// from one goroutine and call Start once. Advanced and streaming applications
// should construct Config directly and use Open.
type Builder struct {
	listener        Listener
	workers         uint32
	limits          Limits
	monitor         *MonitorOptions
	staticMounts    []StaticMount
	fileAuthorities []FileAuthority
	outbound        *OutboundOptions
	outboundTargets []OutboundTarget
	outboundTrusts  []OutboundTrust
	outboundIDs     []OutboundIdentity
	routes          []routeDeclaration
	started         bool
	deferred        error
}

// StaticMount adds one Core-owned static tree with optional index and SPA policy.
func (builder *Builder) StaticMount(mount StaticMount) *Builder {
	if builder.mutable() {
		if len(builder.staticMounts) >= maximumStaticMounts {
			builder.deferred = errors.New("static mount count exceeds the Core bound")
			return builder
		}
		builder.staticMounts = append(builder.staticMounts, mount)
	}
	return builder
}

// FileAuthority adds one bounded root for application-selected file responses.
func (builder *Builder) FileAuthority(authority FileAuthority) *Builder {
	if builder.mutable() {
		if len(builder.fileAuthorities) >= maximumFileAuthorities {
			builder.deferred = errors.New("file authority count exceeds the Core bound")
			return builder
		}
		builder.fileAuthorities = append(builder.fileAuthorities, authority)
	}
	return builder
}

// Outbound replaces the bounded native client reservations. Targets must be
// declared separately with OutboundTarget.
func (builder *Builder) Outbound(options OutboundOptions) *Builder {
	if builder.mutable() {
		copy := options
		builder.outbound = &copy
	}
	return builder
}

// OutboundTarget adds one immutable logical target generation copied by Core.
func (builder *Builder) OutboundTarget(target OutboundTarget) *Builder {
	if builder.mutable() {
		if len(builder.outboundTargets) >= maximumOutboundTargets {
			builder.deferred = errors.New("outbound target count exceeds the Core bound")
			return builder
		}
		copy := target
		copy.Endpoints = append([]OutboundEndpoint(nil), target.Endpoints...)
		for index := range copy.Endpoints {
			if copy.Endpoints[index].ConnectionStrategyGeneration == 0 {
				copy.Endpoints[index].ConnectionStrategyGeneration = 1
			}
		}
		builder.outboundTargets = append(builder.outboundTargets, copy)
	}
	return builder
}

// OutboundTrust adds one generation-keyed CA bundle copied by Core.
func (builder *Builder) OutboundTrust(trust OutboundTrust) *Builder {
	if builder.mutable() {
		if len(builder.outboundTrusts) >= maximumOutboundTrusts {
			builder.deferred = errors.New("outbound trust count exceeds the Core bound")
			return builder
		}
		copy := trust
		copy.CAPEM = append([]byte(nil), trust.CAPEM...)
		builder.outboundTrusts = append(builder.outboundTrusts, copy)
	}
	return builder
}

// OutboundIdentity adds one generation-keyed mutual-TLS identity copied by Core.
func (builder *Builder) OutboundIdentity(identity OutboundIdentity) *Builder {
	if builder.mutable() {
		if len(builder.outboundIDs) >= maximumOutboundIDs {
			builder.deferred = errors.New("outbound identity count exceeds the Core bound")
			return builder
		}
		copy := identity
		copy.CertificateChainPEM = append([]byte(nil), identity.CertificateChainPEM...)
		copy.PrivateKeyPEM = append([]byte(nil), identity.PrivateKeyPEM...)
		builder.outboundIDs = append(builder.outboundIDs, copy)
	}
	return builder
}

// NewBuilder returns a loopback builder with conservative finite defaults.
func NewBuilder() *Builder {
	return &Builder{
		listener: Listener{ID: 1, Protocol: ProtocolHTTP11, BindAddress: "127.0.0.1", Security: SecurityPlaintext},
		workers:  1,
		limits:   DefaultLimits(),
	}
}

// Listen selects the bind host and port. Port zero requests an available port.
func (builder *Builder) Listen(host string, port uint16) *Builder {
	if !builder.mutable() {
		return builder
	}
	if strings.TrimSpace(host) == "" || strings.ContainsRune(host, '\x00') {
		builder.deferred = errors.New("listener host is invalid")
		return builder
	}
	builder.listener.BindAddress, builder.listener.Port = host, port
	return builder
}

// Listener replaces the complete single-listener protocol and TLS declaration.
func (builder *Builder) Listener(listener Listener) *Builder {
	if !builder.mutable() {
		return builder
	}
	if listener.ID == 0 {
		listener.ID = 1
	}
	if listener.Protocol == 0 {
		listener.Protocol = ProtocolHTTP11
	}
	if listener.Security == 0 {
		listener.Security = SecurityPlaintext
	}
	if strings.TrimSpace(listener.BindAddress) == "" {
		listener.BindAddress = "127.0.0.1"
	}
	builder.listener = listener
	return builder
}

// Concurrency selects the fixed number of Go handler workers.
func (builder *Builder) Concurrency(workers uint32) *Builder {
	if !builder.mutable() {
		return builder
	}
	if workers == 0 || workers > 1024 {
		builder.deferred = errors.New("handler worker count is invalid")
		return builder
	}
	builder.workers = workers
	return builder
}

// Limits replaces every principal Service resource ceiling.
func (builder *Builder) Limits(limits Limits) *Builder {
	if !builder.mutable() {
		return builder
	}
	if err := limits.Validate(); err != nil {
		builder.deferred = err
		return builder
	}
	builder.limits = limits
	return builder
}

// Monitor reserves bounded Core monitoring resources for this Service.
func (builder *Builder) Monitor(options MonitorOptions) *Builder {
	if !builder.mutable() {
		return builder
	}
	copy := options
	builder.monitor = &copy
	return builder
}

// Handle registers a buffered inline-body handler for one method and pattern.
func (builder *Builder) Handle(method, pattern string, handler Handler) *Builder {
	return builder.handle(method, pattern, BodyInline, handler)
}

// HandleStream registers a handler whose request body is read incrementally.
func (builder *Builder) HandleStream(method, pattern string, handler Handler) *Builder {
	return builder.handle(method, pattern, BodyStream, handler)
}

// HandleWebSocket registers a route whose handler must select a WebSocket
// response. The declaration reserves the Core WebSocket lane before bind.
func (builder *Builder) HandleWebSocket(method, pattern string, handler Handler) *Builder {
	before := len(builder.routes)
	builder.handle(method, pattern, BodyInline, handler)
	if len(builder.routes) == before+1 {
		builder.routes[before].webSocket = true
	}
	return builder
}

// WebSocket registers one GET WebSocket upgrade route.
func (builder *Builder) WebSocket(pattern string, handler Handler) *Builder {
	return builder.HandleWebSocket("GET", pattern, handler)
}

func (builder *Builder) handle(method, pattern string, delivery BodyDelivery, handler Handler) *Builder {
	if !builder.mutable() {
		return builder
	}
	normalized := strings.ToUpper(strings.TrimSpace(method))
	_, supported := serviceMethods[normalized]
	if !supported || !strings.HasPrefix(pattern, "/") || handler == nil {
		builder.deferred = errors.New("route declaration is invalid")
		return builder
	}
	if len(builder.routes) >= maximumRoutes {
		builder.deferred = errors.New("route count exceeds the Service bound")
		return builder
	}
	id := uint64(len(builder.routes) + 1)
	builder.routes = append(builder.routes, routeDeclaration{
		route: Route{
			ID:               id,
			HandlerBindingID: id,
			Method:           normalized,
			Pattern:          pattern,
			BodyDelivery:     delivery,
			BodyPolicy: BodyPolicy{
				Enabled:      true,
				AcceptAbsent: true,
				AcceptOther:  true,
				MaxBodyBytes: builder.limits.MaxRequestBodyBytes,
			},
		},
		handler: handler,
	})
	return builder
}

// Get registers a GET handler.
func (builder *Builder) Get(pattern string, handler Handler) *Builder {
	return builder.Handle("GET", pattern, handler)
}

// Post registers a POST handler.
func (builder *Builder) Post(pattern string, handler Handler) *Builder {
	return builder.Handle("POST", pattern, handler)
}

// Put registers a PUT handler.
func (builder *Builder) Put(pattern string, handler Handler) *Builder {
	return builder.Handle("PUT", pattern, handler)
}

// Patch registers a PATCH handler.
func (builder *Builder) Patch(pattern string, handler Handler) *Builder {
	return builder.Handle("PATCH", pattern, handler)
}

// Delete registers a DELETE handler.
func (builder *Builder) Delete(pattern string, handler Handler) *Builder {
	return builder.Handle("DELETE", pattern, handler)
}

// GetStream registers a streamed GET request body handler.
func (builder *Builder) GetStream(pattern string, handler Handler) *Builder {
	return builder.HandleStream("GET", pattern, handler)
}

// PostStream registers a streamed POST request body handler.
func (builder *Builder) PostStream(pattern string, handler Handler) *Builder {
	return builder.HandleStream("POST", pattern, handler)
}

// PutStream registers a streamed PUT request body handler.
func (builder *Builder) PutStream(pattern string, handler Handler) *Builder {
	return builder.HandleStream("PUT", pattern, handler)
}

// PatchStream registers a streamed PATCH request body handler.
func (builder *Builder) PatchStream(pattern string, handler Handler) *Builder {
	return builder.HandleStream("PATCH", pattern, handler)
}

// DeleteStream registers a streamed DELETE request body handler.
func (builder *Builder) DeleteStream(pattern string, handler Handler) *Builder {
	return builder.HandleStream("DELETE", pattern, handler)
}

func (builder *Builder) mutable() bool {
	if builder == nil {
		return false
	}
	if builder.started {
		builder.deferred = errors.New("builder can only be started once")
		return false
	}
	return true
}

// Start creates Core, starts listeners, and launches one bounded event pump
// plus the configured fixed worker set.
func (builder *Builder) Start() (*Service, error) {
	if builder == nil {
		return nil, errors.New("builder is nil")
	}
	if builder.started {
		return nil, errors.New("builder can only be started once")
	}
	builder.started = true
	if builder.deferred != nil {
		return nil, builder.deferred
	}
	if len(builder.routes) == 0 && len(builder.staticMounts) == 0 && len(builder.outboundTargets) == 0 {
		return nil, errors.New("at least one route, static mount, or outbound target is required")
	}
	if len(builder.outboundTargets) == 0 &&
		(builder.outbound != nil || len(builder.outboundTrusts) != 0 || len(builder.outboundIDs) != 0) {
		return nil, errors.New("outbound options and credentials require a logical target")
	}
	if err := builder.limits.Validate(); err != nil {
		return nil, err
	}
	if uint32(len(builder.routes)) > builder.limits.MaxHandlerBindings {
		return nil, errors.New("route count exceeds the handler binding capacity")
	}
	requiredCapabilities := Capabilities(CapabilityInbound | CapabilityRouteRebind |
		CapabilityRouteManifestPublication | CapabilityHealth |
		CapabilityResponseStream | CapabilityResponseTrailers | CapabilityResponseWriteTimeout |
		CapabilityServerSentEvents)
	usesWebSocket := false
	for _, declaration := range builder.routes {
		if declaration.route.BodyDelivery == BodyStream {
			requiredCapabilities |= CapabilityRequestStream
		}
		usesWebSocket = usesWebSocket || declaration.webSocket
	}
	if usesWebSocket {
		requiredCapabilities |= CapabilityWebSocket
	}
	if builder.listener.Protocol == ProtocolHTTP2 {
		requiredCapabilities |= CapabilityHTTP2
	} else if builder.listener.Protocol == ProtocolHTTP3 {
		requiredCapabilities |= CapabilityHTTP3
	}
	if builder.listener.Security == SecurityTLS {
		requiredCapabilities |= CapabilityTLS
	} else if builder.listener.Security == SecurityMutualTLS {
		requiredCapabilities |= CapabilityMutualTLS
	}
	if builder.monitor != nil {
		requiredCapabilities |= CapabilityMonitor
	}
	if len(builder.staticMounts) != 0 {
		requiredCapabilities |= CapabilityStaticFiles | CapabilityStaticFrontend
	}
	if len(builder.fileAuthorities) != 0 {
		requiredCapabilities |= CapabilityApplicationFiles
	}
	if len(builder.outboundTargets) != 0 {
		requiredCapabilities |= CapabilityOutbound | CapabilityOutboundLogicalTarget
	}
	plan, err := PlanService(requiredCapabilities, 0)
	if err != nil {
		return nil, err
	}
	if !plan.Supported || plan.Provider != ProviderRuntime {
		return nil, fmt.Errorf(
			"Core cannot provide the declared service: provider=%d missing_runtime=%#x",
			plan.Provider,
			uint64(plan.MissingRuntimeCapabilities),
		)
	}
	limits := builder.limits
	routes := make([]Route, len(builder.routes))
	handlers := make(map[uint64]Handler, len(builder.routes))
	for index, declaration := range builder.routes {
		route := declaration.route
		route.BodyPolicy.MaxBodyBytes = limits.MaxRequestBodyBytes
		routes[index] = route
		handlers[route.HandlerBindingID] = declaration.handler
	}
	core, err := Open(Config{
		Limits: &CoreLimits{
			EventLoopThreads:              1,
			MaxListeners:                  1,
			MaxConnections:                limits.MaxConnections,
			MaxActiveExchanges:            limits.MaxActiveRequests,
			RequestQueueDepth:             limits.RequestQueueCapacity,
			CompletionQueueDepth:          limits.ResponseQueueCapacity,
			ConnectionTimeoutBatchSize:    limits.MaxConnections,
			RequestStreamMaxRetainedItems: limits.RequestStreamMaxRetainedItems,
			TerminalObservationQueueDepth: limits.MaxActiveRequests,
			MaxRequestBodyBytes:           limits.MaxRequestBodyBytes,
			MaxResponseBodyBytes:          limits.MaxResponseBodyBytes,
			MaxSerializedResponseBytes:    limits.MaxResponseBodyBytes + (1 << 20),
			AppHostTimeoutMillis:          uint64(limits.RequestTimeoutMillis),
			DrainTimeoutMillis:            uint64(limits.ShutdownTimeoutMillis),
			StopTimeoutMillis:             uint64(limits.ShutdownTimeoutMillis),
			ResponseWriteTimeoutMillis:    uint64(limits.ResponseWriteTimeoutMillis),
		},
		Listeners:       []Listener{builder.listener},
		Routes:          routes,
		StaticMounts:    append([]StaticMount(nil), builder.staticMounts...),
		FileAuthorities: append([]FileAuthority(nil), builder.fileAuthorities...),
		Monitor:         builder.monitor,
		Outbound:        builder.outbound,
		OutboundEnabled: len(builder.outboundTargets) != 0 && builder.outbound == nil,
		OutboundTargets: append([]OutboundTarget(nil), builder.outboundTargets...),
		OutboundTrust:   append([]OutboundTrust(nil), builder.outboundTrusts...),
		OutboundIdentities: append(
			[]OutboundIdentity(nil), builder.outboundIDs...,
		),
	})
	if err != nil {
		return nil, err
	}
	if err = core.Start(); err != nil {
		_ = core.Close()
		return nil, err
	}
	service := &Service{
		core:                  core,
		plan:                  plan,
		routes:                routes,
		handlers:              handlers,
		maxHandlerBindings:    limits.MaxHandlerBindings,
		jobs:                  make(chan *Request, limits.RequestQueueCapacity),
		pending:               make(map[ExchangeID]struct{}, limits.MaxActiveRequests),
		requestStreams:        make(map[ExchangeID]*requestBodyStream, limits.MaxActiveRequests),
		requestStreamCapacity: limits.RequestStreamMaxRetainedItems,
		responseStreams:       make(map[ExchangeID]*responseStreamState, limits.MaxActiveRequests),
		responseWriteTimeout:  time.Duration(limits.ResponseWriteTimeoutMillis) * time.Millisecond,
		shutdownTimeout:       time.Duration(limits.ShutdownTimeoutMillis) * time.Millisecond,
		pumpDone:              make(chan struct{}),
		remainingWorkers:      builder.workers,
		workersDone:           make(chan struct{}),
	}
	if usesWebSocket {
		service.webSockets = newWebSocketDispatcher(service, limits.MaxActiveRequests)
		service.webSocketReaderDone = make(chan struct{})
	}
	for worker := uint32(0); worker < builder.workers; worker++ {
		go service.runWorker()
	}
	go service.runPump()
	if service.webSockets != nil {
		go service.runWebSocketReader()
	}
	return service, nil
}

type diagnosticQueue struct {
	mu     sync.Mutex
	values []error
}

func (queue *diagnosticQueue) add(err error) {
	if err == nil {
		return
	}
	queue.mu.Lock()
	defer queue.mu.Unlock()
	if len(queue.values) == 64 {
		copy(queue.values, queue.values[1:])
		queue.values = queue.values[:63]
	}
	queue.values = append(queue.values, err)
}

func (queue *diagnosticQueue) take() error {
	queue.mu.Lock()
	defer queue.mu.Unlock()
	if len(queue.values) == 0 {
		return nil
	}
	err := queue.values[0]
	copy(queue.values, queue.values[1:])
	queue.values = queue.values[:len(queue.values)-1]
	return err
}

// Service is a buffered Handler facade over the callback-free Core API.
// Close waits for admitted handlers; handlers must therefore return and must
// not call Close on their own Service.
type Service struct {
	closeMu               sync.Mutex
	closed                bool
	shutdownStarted       bool
	shutdownErr           error
	shutdownTimeout       time.Duration
	jobsClosed            bool
	stateMu               sync.Mutex
	closing               bool
	pending               map[ExchangeID]struct{}
	requestStreams        map[ExchangeID]*requestBodyStream
	requestStreamCapacity uint32
	responseStreams       map[ExchangeID]*responseStreamState
	responseWriteTimeout  time.Duration
	core                  *Core
	plan                  ServicePlan
	routes                []Route
	routesMu              sync.RWMutex
	handlers              map[uint64]Handler
	handlersMu            sync.RWMutex
	maxHandlerBindings    uint32
	jobs                  chan *Request
	pumpDone              chan struct{}
	workersMu             sync.Mutex
	remainingWorkers      uint32
	workersDone           chan struct{}
	errors                diagnosticQueue
	webSockets            *webSocketDispatcher
	webSocketReaderDone   chan struct{}
}

// Plan returns Core's immutable whole-service provider decision made before
// listener publication. The current Go provider delegates transport to Core.
func (service *Service) Plan() ServicePlan {
	if service == nil {
		return ServicePlan{}
	}
	return service.plan
}

// RuntimeInfo returns capability and effective backend truth copied from Core.
func (service *Service) RuntimeInfo() (RuntimeInfo, error) {
	if service == nil || service.core == nil {
		return RuntimeInfo{}, errors.New("service is closed")
	}
	return service.core.RuntimeInfo()
}

// Health returns a non-blocking copied Core health snapshot.
func (service *Service) Health() (Health, error) {
	if service == nil || service.core == nil {
		return Health{}, errors.New("service is closed")
	}
	return service.core.Health()
}

// ProbeLiveness waits for fresh Core progress evidence within timeout.
func (service *Service) ProbeLiveness(timeout time.Duration) (Health, error) {
	if service == nil || service.core == nil {
		return Health{}, errors.New("service is closed")
	}
	return service.core.ProbeLiveness(timeout)
}

// SubmitOutbound starts one buffered call to a startup-declared logical target.
func (service *Service) SubmitOutbound(request ClientRequest) (OutboundID, error) {
	if service == nil || service.core == nil {
		return OutboundID{}, errors.New("service is closed")
	}
	return service.core.SubmitOutbound(request)
}

// CancelOutbound requests cancellation of an admitted outbound call.
func (service *Service) CancelOutbound(call OutboundID) error {
	if service == nil || service.core == nil {
		return errors.New("service is closed")
	}
	return service.core.CancelOutbound(call)
}

// TakeOutbound waits for and copies one terminal, or returns nil on timeout.
// Exactly one goroutine may call TakeOutbound for a Service at a time.
func (service *Service) TakeOutbound(timeout time.Duration) (*ClientTerminal, error) {
	if service == nil || service.core == nil {
		return nil, errors.New("service is closed")
	}
	return service.core.TakeOutbound(timeout)
}

// MonitorConfig returns the copied effective monitoring configuration.
func (service *Service) MonitorConfig() (MonitorConfig, error) {
	if service == nil || service.core == nil {
		return MonitorConfig{}, errors.New("service is closed")
	}
	return service.core.MonitorConfig()
}

// MonitorSnapshot returns copied bounded aggregates and co-observed health.
func (service *Service) MonitorSnapshot() (MonitorSnapshot, error) {
	if service == nil || service.core == nil {
		return MonitorSnapshot{}, errors.New("service is closed")
	}
	return service.core.MonitorSnapshot()
}

// ApplyMonitorPolicy performs an optimistic live monitor policy update.
func (service *Service) ApplyMonitorPolicy(expectedGeneration uint64, policy MonitorPolicy) (MonitorApplyOutcome, error) {
	if service == nil || service.core == nil {
		return MonitorApplyOutcome{}, errors.New("service is closed")
	}
	return service.core.ApplyMonitorPolicy(expectedGeneration, policy)
}

// ReadMonitorEvents reads one bounded cursor page of copied monitor events.
func (service *Service) ReadMonitorEvents(afterSequence uint64, maximumEvents uint32) (MonitorEventPage, error) {
	if service == nil || service.core == nil {
		return MonitorEventPage{}, errors.New("service is closed")
	}
	return service.core.ReadMonitorEvents(afterSequence, maximumEvents)
}

// WaitMonitor waits until newer monitoring truth may be available.
func (service *Service) WaitMonitor(timeout time.Duration) error {
	if service == nil || service.core == nil {
		return errors.New("service is closed")
	}
	return service.core.WaitMonitor(timeout)
}

// InterruptMonitor wakes the sole monitor waiter without fabricating data.
func (service *Service) InterruptMonitor() error {
	if service == nil || service.core == nil {
		return errors.New("service is closed")
	}
	return service.core.InterruptMonitor()
}

// PrepareHandler registers one new single-assignment binding identity. It is
// not dispatchable until RebindHandler publishes it through Core.
func (service *Service) PrepareHandler(bindingID uint64, handler Handler) error {
	if service == nil || bindingID == 0 || handler == nil {
		return errors.New("handler binding is invalid")
	}
	service.closeMu.Lock()
	defer service.closeMu.Unlock()
	if service.closed || service.shutdownStarted {
		return errors.New("service is closing or closed")
	}
	service.handlersMu.Lock()
	defer service.handlersMu.Unlock()
	if _, exists := service.handlers[bindingID]; exists {
		return errors.New("handler binding identity was already used")
	}
	if uint32(len(service.handlers)) >= service.maxHandlerBindings {
		return errors.New("handler binding capacity is exhausted")
	}
	service.handlers[bindingID] = handler
	return nil
}

// RebindHandler publishes one previously prepared binding under Core's route
// generation and binding revision checks. Ambiguous outcomes can be retried
// with the exact same request because prepared bindings remain registered.
func (service *Service) RebindHandler(request RebindRequest, timeout time.Duration) (RebindOutcome, error) {
	if service == nil || service.core == nil {
		return RebindOutcome{}, errors.New("service is closed")
	}
	service.closeMu.Lock()
	defer service.closeMu.Unlock()
	if service.closed || service.shutdownStarted {
		return RebindOutcome{}, errors.New("service is closing or closed")
	}
	service.handlersMu.RLock()
	_, prepared := service.handlers[request.NewHandlerBindingID]
	service.handlersMu.RUnlock()
	if !prepared {
		return RebindOutcome{}, errors.New("handler binding was not prepared")
	}
	return service.core.Rebind(request, timeout)
}

// PublishRoutes atomically replaces the complete structural route generation.
// Every referenced binding must have been registered through PrepareHandler.
// Delivery-ambiguous outcomes can be resolved by retrying the exact request.
func (service *Service) PublishRoutes(request RoutePublication, timeout time.Duration) (RoutePublicationOutcome, error) {
	if service == nil || service.core == nil {
		return RoutePublicationOutcome{}, errors.New("service is closed")
	}
	if len(request.Routes) > maximumHandlerBindings {
		return RoutePublicationOutcome{}, errors.New("route generation exceeds the service bound")
	}
	routes := append([]Route(nil), request.Routes...)
	service.closeMu.Lock()
	defer service.closeMu.Unlock()
	if service.closed || service.shutdownStarted {
		return RoutePublicationOutcome{}, errors.New("service is closing or closed")
	}
	service.handlersMu.RLock()
	for _, route := range routes {
		if route.HandlerBindingID == 0 || service.handlers[route.HandlerBindingID] == nil {
			service.handlersMu.RUnlock()
			return RoutePublicationOutcome{}, errors.New("route references an unprepared handler binding")
		}
	}
	service.handlersMu.RUnlock()
	request.Routes = routes
	outcome, err := service.core.PublishRoutes(request, timeout)
	if err != nil {
		return RoutePublicationOutcome{}, err
	}
	if outcome.Code == RoutePublicationApplied {
		service.routesMu.Lock()
		service.routes = routes
		service.routesMu.Unlock()
	}
	return outcome, nil
}

// Port returns the selected port of the Service listener.
func (service *Service) Port() (uint16, error) {
	if service == nil {
		return 0, errors.New("service is closed")
	}
	return service.core.BoundPort()
}

// Routes returns a defensive copy of the Service route declarations.
func (service *Service) Routes() []Route {
	if service == nil {
		return nil
	}
	service.routesMu.RLock()
	defer service.routesMu.RUnlock()
	return append([]Route(nil), service.routes...)
}

// PollError removes and returns the oldest bounded pump or handler diagnostic.
func (service *Service) PollError() error {
	if service == nil {
		return nil
	}
	return service.errors.take()
}

func (service *Service) runPump() {
	defer close(service.pumpDone)
	for {
		event, err := service.core.TakeEvent(servicePollInterval)
		if err != nil {
			var coreErr *Error
			if errors.As(err, &coreErr) && (coreErr.Code == ResultTimeout || coreErr.Code == ResultClosed || coreErr.Code == ResultCancelled) {
				if service.pumpMayStop() {
					return
				}
				continue
			}
			if errors.Is(err, errCoreClosed) {
				return
			}
			service.errors.add(err)
			continue
		}
		if event.Kind == EventResponseWritable {
			service.signalResponseStreamWritable(event.Exchange)
			continue
		}
		if event.Kind == EventRequestCancelled {
			service.finishRequestStream(event.Exchange, errRequestBodyCancelled)
			service.signalResponseStreamTerminal(event.Exchange, errors.New("response stream request was cancelled"))
			continue
		}
		if event.Kind == EventTerminal {
			service.observeTerminal(event.Exchange)
			continue
		}
		if event.Kind == EventRequestData || event.Kind == EventRequestTrailers || event.Kind == EventRequestEnd {
			service.routeRequestStreamEvent(event)
			continue
		}
		if event.Kind != EventRequest || event.Request == nil {
			continue
		}
		if service.trackRequest(event.Exchange) {
			if responseErr := service.core.Respond(event.Exchange, internalResponse()); responseErr != nil {
				service.errors.add(responseErr)
			}
			continue
		}
		if event.Request.BodyDelivery == BodyStream {
			stream := newRequestBodyStream(
				event.Request,
				service.requestStreamCapacity,
				event.Sequence,
			)
			service.stateMu.Lock()
			service.requestStreams[event.Exchange] = stream
			service.stateMu.Unlock()
			event.Request.Body = stream
		} else {
			event.Request.Body = io.NopCloser(bytes.NewReader(event.Request.body))
		}
		select {
		case service.jobs <- event.Request:
		default:
			service.errors.add(errors.New("Go handler queue is full"))
			_ = service.core.Respond(event.Exchange, overloadedResponse())
		}
	}
}

// trackRequest records every request event before it can be dispatched. Once
// shutdown begins, the pump still completes already-admitted Core exchanges
// with a bounded failure instead of abandoning their terminal observations.
func (service *Service) trackRequest(exchange ExchangeID) bool {
	service.stateMu.Lock()
	defer service.stateMu.Unlock()
	service.pending[exchange] = struct{}{}
	return service.closing
}

func (service *Service) observeTerminal(exchange ExchangeID) {
	service.stateMu.Lock()
	stream := service.responseStreams[exchange]
	requestStream := service.requestStreams[exchange]
	delete(service.responseStreams, exchange)
	delete(service.requestStreams, exchange)
	delete(service.pending, exchange)
	service.stateMu.Unlock()
	if stream != nil {
		stream.terminate(errors.New("response stream reached terminal state"))
	}
	if requestStream != nil {
		requestStream.finish(errRequestBodyTerminated)
	}
}

func (service *Service) beginShutdown() {
	service.stateMu.Lock()
	service.closing = true
	service.stateMu.Unlock()
}

// A timed-out read is the quiescence barrier: the sole reader has observed no
// queued event after shutdown began, and every request it saw reached terminal.
func (service *Service) pumpMayStop() bool {
	service.stateMu.Lock()
	defer service.stateMu.Unlock()
	return service.closing && len(service.pending) == 0
}

func (service *Service) runWorker() {
	defer service.workerStopped()
	for request := range service.jobs {
		service.handle(request)
	}
}

func (service *Service) workerStopped() {
	service.workersMu.Lock()
	defer service.workersMu.Unlock()
	if service.remainingWorkers == 0 {
		return
	}
	service.remainingWorkers--
	if service.remainingWorkers == 0 {
		close(service.workersDone)
	}
}

func (service *Service) handle(request *Request) {
	response := internalResponse()
	if request.Body != nil {
		defer func() { _ = request.Body.Close() }()
	}
	service.handlersMu.RLock()
	handler := service.handlers[request.HandlerBindingID]
	service.handlersMu.RUnlock()
	if handler == nil {
		service.errors.add(errors.New("request has no registered Go handler"))
		_ = service.core.Respond(request.Exchange, response)
		return
	}
	func() {
		defer func() {
			if recovered := recover(); recovered != nil {
				service.errors.add(fmt.Errorf("handler panic: %v", recovered))
				response = internalResponse()
			}
		}()
		value, err := handler(request)
		if err != nil {
			service.errors.add(err)
			return
		}
		response = value
	}()
	if response.sse != nil {
		service.handleSSEResponse(request.Exchange, response)
		return
	}
	if response.file != nil {
		if err := service.core.RespondFile(request.Exchange, *response.file); err != nil {
			service.errors.add(err)
		}
		return
	}
	if response.webSocket != nil {
		if service.webSockets == nil {
			service.errors.add(errors.New("handler returned an undeclared WebSocket response"))
			_ = service.core.Respond(request.Exchange, internalResponse())
			return
		}
		if err := service.webSockets.accept(request.Exchange, response.webSocket); err != nil {
			service.errors.add(err)
			_ = service.core.Respond(request.Exchange, internalResponse())
		}
		return
	}
	if response.producer != nil {
		service.handleStreamingResponse(request.Exchange, response)
		return
	}
	if err := service.core.Respond(request.Exchange, response); err != nil {
		service.errors.add(err)
		fallback := internalResponse()
		if response.Status != fallback.Status || string(response.body) != string(fallback.body) {
			if fallbackErr := service.core.Respond(request.Exchange, fallback); fallbackErr != nil {
				service.errors.add(fallbackErr)
			}
		}
	}
}

func internalResponse() Response {
	response, err := Text(500, "internal server error")
	if err != nil {
		panic("static internal response is invalid")
	}
	return response
}

func overloadedResponse() Response {
	response, err := Text(503, "service unavailable")
	if err != nil {
		panic("static overloaded response is invalid")
	}
	return response
}

func waitForServiceStage(done <-chan struct{}, deadline time.Time, stage string) error {
	select {
	case <-done:
		return nil
	default:
	}
	remaining := time.Until(deadline)
	if remaining <= 0 {
		return fmt.Errorf("service shutdown timed out waiting for %s", stage)
	}
	timer := time.NewTimer(remaining)
	defer timer.Stop()
	select {
	case <-done:
		return nil
	case <-timer.C:
		return fmt.Errorf("service shutdown timed out waiting for %s", stage)
	}
}

// Close stops admission, drains admitted handlers, stops the event pump, and
// releases Core. It is idempotent and serialized for concurrent callers. A
// timeout retains the live owner so a later call can resume shutdown.
func (service *Service) Close() error {
	if service == nil {
		return nil
	}
	service.closeMu.Lock()
	defer service.closeMu.Unlock()
	if service.closed {
		return nil
	}
	deadline := time.Now().Add(service.shutdownTimeout)
	if !service.shutdownStarted {
		service.shutdownStarted = true
		service.beginShutdown()
		service.shutdownErr = service.core.Drain()
	}
	if err := waitForServiceStage(service.pumpDone, deadline, "the event pump"); err != nil {
		return errors.Join(service.shutdownErr, err)
	}
	if !service.jobsClosed {
		close(service.jobs)
		service.jobsClosed = true
	}
	if err := waitForServiceStage(service.workersDone, deadline, "handler workers"); err != nil {
		return errors.Join(service.shutdownErr, err)
	}
	if service.webSockets != nil {
		service.webSockets.stopReader()
		if err := waitForServiceStage(service.webSocketReaderDone, deadline, "the WebSocket reader"); err != nil {
			return errors.Join(service.shutdownErr, err)
		}
	}
	closeErr := service.core.Close()
	if service.webSockets != nil {
		service.webSockets.shutdown()
	}
	service.closed = closeErr == nil
	return errors.Join(service.shutdownErr, closeErr)
}
