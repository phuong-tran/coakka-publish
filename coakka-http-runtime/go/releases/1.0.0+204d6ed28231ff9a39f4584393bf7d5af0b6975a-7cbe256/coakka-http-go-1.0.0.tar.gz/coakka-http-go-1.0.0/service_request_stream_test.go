package coakkahttp

import (
	"errors"
	"io"
	"testing"
	"time"
)

func TestRequestBodyStreamCloseWakesBlockedRead(t *testing.T) {
	stream := newRequestBodyStream(&Request{}, 1, 1)
	result := make(chan error, 1)
	go func() {
		buffer := make([]byte, 1)
		_, err := stream.Read(buffer)
		result <- err
	}()

	if err := stream.Close(); err != nil {
		t.Fatal(err)
	}
	select {
	case err := <-result:
		if !errors.Is(err, io.ErrClosedPipe) {
			t.Fatalf("blocked read returned %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("blocked request-body read was not woken")
	}
}

func TestRequestBodyStreamOverflowFailsClosed(t *testing.T) {
	stream := newRequestBodyStream(&Request{}, 1, 1)
	if !stream.offer(requestBodyEvent{kind: EventRequestData, sequence: 2, data: []byte("first")}) {
		t.Fatal("first request-body item was rejected")
	}
	if stream.offer(requestBodyEvent{kind: EventRequestData, sequence: 3, data: []byte("second")}) {
		t.Fatal("overflowing request-body item was accepted")
	}

	buffer := make([]byte, 8)
	count, err := stream.Read(buffer)
	if err != nil || string(buffer[:count]) != "first" {
		t.Fatalf("retained prefix differs: count=%d body=%q err=%v", count, buffer[:count], err)
	}
	if _, err = stream.Read(buffer); !errors.Is(err, errRequestBodyOverflow) {
		t.Fatalf("overflow terminal differs: %v", err)
	}
}

func TestRequestBodyStreamRejectsSequenceGap(t *testing.T) {
	stream := newRequestBodyStream(&Request{}, 1, 7)
	if stream.offer(requestBodyEvent{kind: EventRequestData, sequence: 9, data: []byte("gap")}) {
		t.Fatal("discontinuous request-body item was accepted")
	}
	if _, err := stream.Read(make([]byte, 1)); !errors.Is(err, errRequestBodySequence) {
		t.Fatalf("sequence terminal differs: %v", err)
	}
}
