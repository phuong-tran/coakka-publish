package coakkahttp

import (
	"errors"
	"fmt"
	"sync"
	"time"
)

// ResponseStreamProducer writes a response incrementally and returns optional
// response trailers. The Service invokes it on one fixed handler worker. The
// producer and writer must not escape the callback or be used concurrently.
type ResponseStreamProducer func(*ResponseStreamWriter) (Headers, error)

type responseStreamState struct {
	mu       sync.Mutex
	notify   chan struct{}
	writable bool
	terminal error
}

func newResponseStreamState() *responseStreamState {
	return &responseStreamState{notify: make(chan struct{}, 1)}
}

func (state *responseStreamState) wake() {
	select {
	case state.notify <- struct{}{}:
	default:
	}
}

func (state *responseStreamState) grantWritable() {
	state.mu.Lock()
	if state.terminal == nil {
		state.writable = true
	}
	state.mu.Unlock()
	state.wake()
}

func (state *responseStreamState) terminate(err error) {
	state.mu.Lock()
	if state.terminal == nil {
		state.terminal = err
	}
	state.mu.Unlock()
	state.wake()
}

func (state *responseStreamState) awaitWritable(timeout time.Duration) error {
	timer := time.NewTimer(timeout)
	defer timer.Stop()
	for {
		state.mu.Lock()
		if state.terminal != nil {
			err := state.terminal
			state.mu.Unlock()
			return err
		}
		if state.writable {
			state.writable = false
			state.mu.Unlock()
			return nil
		}
		state.mu.Unlock()

		select {
		case <-state.notify:
		case <-timer.C:
			return errors.New("response stream writable-credit wait timed out")
		}
	}
}

// ResponseStreamWriter writes copied chunks after Core's initial writability
// hint and waits again only after queue pressure. A writer is valid only while
// its producer callback runs.
type ResponseStreamWriter struct {
	service  *Service
	exchange ExchangeID
	state    *responseStreamState
	timeout  time.Duration
	mu       sync.Mutex
	closed   bool
	started  bool
}

// Write waits for initial credit, retries exact queue pressure only after a
// recovery credit, and copies the accepted chunk into Core.
func (writer *ResponseStreamWriter) Write(data []byte) (int, error) {
	if writer == nil || writer.service == nil || writer.state == nil {
		return 0, errors.New("response stream writer is invalid")
	}
	if len(data) == 0 {
		return 0, nil
	}
	writer.mu.Lock()
	defer writer.mu.Unlock()
	if writer.closed {
		return 0, errors.New("response stream writer is closed")
	}
	if !writer.started {
		if err := writer.state.awaitWritable(writer.timeout); err != nil {
			return 0, err
		}
		writer.started = true
	}
	for {
		err := writer.service.core.WriteResponseStream(writer.exchange, data)
		if err == nil {
			return len(data), nil
		}
		var coreErr *Error
		if !errors.As(err, &coreErr) || coreErr.Code != ResultQueueFull {
			return 0, err
		}
		if err = writer.state.awaitWritable(writer.timeout); err != nil {
			return 0, err
		}
	}
}

func (writer *ResponseStreamWriter) close() {
	writer.mu.Lock()
	writer.closed = true
	writer.mu.Unlock()
}

func (service *Service) registerResponseStream(exchange ExchangeID, state *responseStreamState) error {
	service.stateMu.Lock()
	defer service.stateMu.Unlock()
	if _, exists := service.responseStreams[exchange]; exists {
		return errors.New("response stream is already registered")
	}
	service.responseStreams[exchange] = state
	return nil
}

func (service *Service) unregisterResponseStream(exchange ExchangeID, state *responseStreamState) {
	service.stateMu.Lock()
	if service.responseStreams[exchange] == state {
		delete(service.responseStreams, exchange)
	}
	service.stateMu.Unlock()
}

func (service *Service) signalResponseStreamWritable(exchange ExchangeID) {
	service.stateMu.Lock()
	state := service.responseStreams[exchange]
	service.stateMu.Unlock()
	if state != nil {
		state.grantWritable()
	}
}

func (service *Service) signalResponseStreamTerminal(exchange ExchangeID, err error) {
	service.stateMu.Lock()
	state := service.responseStreams[exchange]
	service.stateMu.Unlock()
	if state != nil {
		state.terminate(err)
	}
}

func (service *Service) handleStreamingResponse(exchange ExchangeID, response Response) {
	state := newResponseStreamState()
	if err := service.registerResponseStream(exchange, state); err != nil {
		service.errors.add(err)
		_ = service.core.Respond(exchange, internalResponse())
		return
	}
	defer service.unregisterResponseStream(exchange, state)

	head := response
	head.producer = nil
	if err := service.core.StartResponseStream(exchange, head); err != nil {
		service.errors.add(err)
		_ = service.core.Respond(exchange, internalResponse())
		return
	}

	writer := &ResponseStreamWriter{
		service:  service,
		exchange: exchange,
		state:    state,
		timeout:  service.responseWriteTimeout,
	}
	trailers, producerErr := invokeResponseStreamProducer(response.producer, writer)
	writer.close()
	if producerErr != nil {
		service.errors.add(producerErr)
		trailers = Headers{}
	}
	if err := service.core.FinishResponseStream(exchange, trailers); err != nil {
		service.errors.add(err)
	}
}

func invokeResponseStreamProducer(producer ResponseStreamProducer, writer *ResponseStreamWriter) (trailers Headers, err error) {
	defer func() {
		if recovered := recover(); recovered != nil {
			trailers = Headers{}
			err = fmt.Errorf("response stream producer panic: %v", recovered)
		}
	}()
	return producer(writer)
}
