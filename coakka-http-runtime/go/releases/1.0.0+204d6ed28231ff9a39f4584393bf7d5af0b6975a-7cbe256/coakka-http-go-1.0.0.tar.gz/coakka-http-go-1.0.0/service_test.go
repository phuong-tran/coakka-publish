package coakkahttp_test

import (
	"bufio"
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	coakkahttp "github.com/phuong-tran/coakka-http-runtime-go"
)

func readWebSocketFrame(reader *bufio.Reader) (byte, []byte, error) {
	header := make([]byte, 2)
	if _, err := io.ReadFull(reader, header); err != nil {
		return 0, nil, err
	}
	length := uint64(header[1] & 0x7f)
	if header[1]&0x80 != 0 {
		return 0, nil, errors.New("server WebSocket frame was masked")
	}
	switch length {
	case 126:
		extended := make([]byte, 2)
		if _, err := io.ReadFull(reader, extended); err != nil {
			return 0, nil, err
		}
		length = uint64(extended[0])<<8 | uint64(extended[1])
	case 127:
		return 0, nil, errors.New("test client rejects oversized WebSocket frames")
	}
	if length > 64<<10 {
		return 0, nil, errors.New("test client frame exceeds its bound")
	}
	payload := make([]byte, int(length))
	if _, err := io.ReadFull(reader, payload); err != nil {
		return 0, nil, err
	}
	return header[0] & 0x0f, payload, nil
}

func writeMaskedWebSocketFrame(conn net.Conn, opcode byte, payload []byte) error {
	if len(payload) > 125 {
		return errors.New("test client frame exceeds its single-byte bound")
	}
	mask := [4]byte{1, 2, 3, 4}
	frame := make([]byte, 6+len(payload))
	frame[0] = 0x80 | opcode
	frame[1] = 0x80 | byte(len(payload))
	copy(frame[2:6], mask[:])
	for index, value := range payload {
		frame[6+index] = value ^ mask[index%len(mask)]
	}
	_, err := conn.Write(frame)
	return err
}

func TestRequestResponseAndIdempotentClose(t *testing.T) {
	header, err := coakkahttp.NewHeader("x-reply", "two")
	if err != nil {
		t.Fatal(err)
	}
	headers, err := coakkahttp.NewHeaders(header)
	if err != nil {
		t.Fatal(err)
	}
	service, err := coakkahttp.NewBuilder().Concurrency(2).Post(
		"/echo",
		func(request *coakkahttp.Request) (coakkahttp.Response, error) {
			if request.Method != http.MethodPost || request.Target != "/echo?value=1" {
				return coakkahttp.Response{}, errors.New("request projection differs")
			}
			value, ok := request.Headers.Get("x-test")
			if !ok || value != "one" {
				return coakkahttp.Response{}, errors.New("request header differs")
			}
			return coakkahttp.NewResponse(201, headers, request.Bytes())
		},
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	plan := service.Plan()
	if !plan.Supported || plan.Provider != coakkahttp.ProviderRuntime ||
		!plan.RequiredCapabilities.Has(coakkahttp.CapabilityInbound) {
		t.Fatalf("unexpected service plan: %+v", plan)
	}
	runtimeInfo, err := service.RuntimeInfo()
	if err != nil || !runtimeInfo.CoreStarted {
		t.Fatalf("unexpected service runtime info: info=%+v err=%v", runtimeInfo, err)
	}
	health, err := service.Health()
	if err != nil || health.FailedComponents != 0 || !health.AdmissionOpen {
		t.Fatalf("unexpected service health: health=%+v err=%v", health, err)
	}
	probed, err := service.ProbeLiveness(time.Second)
	if err != nil || probed.AcknowledgedProbeSequence == 0 || probed.FailedComponents != 0 {
		t.Fatalf("unexpected service liveness: health=%+v err=%v", probed, err)
	}
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}
	request, err := http.NewRequest(http.MethodPost, fmt.Sprintf("http://127.0.0.1:%d/echo?value=1", port), bytes.NewReader([]byte("payload")))
	if err != nil {
		t.Fatal(err)
	}
	request.Header.Set("x-test", "one")
	response, err := http.DefaultClient.Do(request)
	if err != nil {
		t.Fatal(err)
	}
	body, err := io.ReadAll(response.Body)
	_ = response.Body.Close()
	if err != nil || response.StatusCode != 201 || response.Header.Get("x-reply") != "two" || string(body) != "payload" {
		t.Fatalf("response differs: status=%d header=%q body=%q err=%v", response.StatusCode, response.Header.Get("x-reply"), body, err)
	}
	if err = service.Close(); err != nil {
		t.Fatal(err)
	}
	if err = service.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestServiceOwnsLogicalOutboundCallsAndInterruptsWaiter(t *testing.T) {
	responseHeader, err := coakkahttp.NewHeader("x-outbound", "yes")
	if err != nil {
		t.Fatal(err)
	}
	responseHeaders, err := coakkahttp.NewHeaders(responseHeader)
	if err != nil {
		t.Fatal(err)
	}
	upstream, err := coakkahttp.NewBuilder().Get(
		"/upstream",
		func(*coakkahttp.Request) (coakkahttp.Response, error) {
			return coakkahttp.NewResponse(201, responseHeaders, []byte("outbound-ready"))
		},
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if closeErr := upstream.Close(); closeErr != nil {
			t.Error(closeErr)
		}
	}()
	port, err := upstream.Port()
	if err != nil {
		t.Fatal(err)
	}
	caller, err := coakkahttp.NewBuilder().OutboundTarget(coakkahttp.OutboundTarget{
		Name:       "loopback.service",
		Generation: 1,
		Strategy:   coakkahttp.OutboundSingleOwner,
		Endpoints: []coakkahttp.OutboundEndpoint{{
			NodeID:        "loopback-node",
			ConnectHost:   "127.0.0.1",
			ConnectPort:   port,
			HTTPAuthority: fmt.Sprintf("127.0.0.1:%d", port),
		}},
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if closeErr := caller.Close(); closeErr != nil {
			t.Error(closeErr)
		}
	}()
	plan := caller.Plan()
	if !plan.RequiredCapabilities.Has(coakkahttp.CapabilityOutbound) ||
		!plan.RequiredCapabilities.Has(coakkahttp.CapabilityOutboundLogicalTarget) {
		t.Fatalf("outbound capabilities are absent from plan: %+v", plan)
	}
	requestHeader, err := coakkahttp.NewHeader("x-request", "copied")
	if err != nil {
		t.Fatal(err)
	}
	requestHeaders, err := coakkahttp.NewHeaders(requestHeader)
	if err != nil {
		t.Fatal(err)
	}
	call, err := caller.SubmitOutbound(coakkahttp.ClientRequest{
		TimeoutMillis: 3_000,
		LogicalTarget: "loopback.service",
		Method:        http.MethodGet,
		Target:        "/upstream",
		Headers:       requestHeaders,
	})
	if err != nil || call.Generation == 0 {
		t.Fatalf("outbound submit failed: call=%+v err=%v", call, err)
	}
	terminal, err := caller.TakeOutbound(5 * time.Second)
	if err != nil || terminal == nil {
		t.Fatalf("outbound terminal failed: terminal=%+v err=%v", terminal, err)
	}
	value, found := terminal.ResponseHeaders.Get("x-outbound")
	if terminal.Reason != 1 || terminal.Call != call ||
		terminal.LogicalTarget != "loopback.service" || terminal.TargetGeneration != 1 ||
		terminal.SelectedNodeID != "loopback-node" || terminal.ResponseStatus != 201 ||
		!found || value != "yes" || string(terminal.ResponseBody) != "outbound-ready" {
		t.Fatalf("outbound terminal differs: %+v header=%q found=%v", terminal, value, found)
	}
	terminal, err = caller.TakeOutbound(0)
	if err != nil || terminal != nil {
		t.Fatalf("empty outbound take differs: terminal=%+v err=%v", terminal, err)
	}

	entered := make(chan struct{})
	finished := make(chan error, 1)
	go func() {
		close(entered)
		_, waitErr := caller.TakeOutbound(30 * time.Second)
		finished <- waitErr
	}()
	<-entered
	time.Sleep(20 * time.Millisecond)
	started := time.Now()
	if err = caller.Close(); err != nil {
		t.Fatal(err)
	}
	if elapsed := time.Since(started); elapsed >= time.Second {
		t.Fatalf("outbound waiter close exceeded its bound: %s", elapsed)
	}
	select {
	case waitErr := <-finished:
		var nativeErr *coakkahttp.Error
		if !errors.As(waitErr, &nativeErr) || nativeErr.Code != coakkahttp.ResultClosed {
			t.Fatalf("outbound waiter returned %v", waitErr)
		}
	case <-time.After(time.Second):
		t.Fatal("outbound waiter remained blocked after close")
	}
}

func TestServiceProjectsBufferedRequestTrailers(t *testing.T) {
	service, err := coakkahttp.NewBuilder().Post(
		"/trailers",
		func(request *coakkahttp.Request) (coakkahttp.Response, error) {
			checksum, ok := request.Trailers.Get("x-checksum")
			if string(request.Bytes()) != "payload" || !ok || checksum != "ok" {
				return coakkahttp.Response{}, errors.New("buffered body or trailers differ")
			}
			return coakkahttp.Text(200, "trailers-ready")
		},
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if closeErr := service.Close(); closeErr != nil {
			t.Error(closeErr)
		}
	}()
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}
	connection, err := net.DialTimeout("tcp", fmt.Sprintf("127.0.0.1:%d", port), 5*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer connection.Close()
	if err = connection.SetDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatal(err)
	}
	request := "POST /trailers HTTP/1.1\r\n" +
		"Host: 127.0.0.1\r\n" +
		"Transfer-Encoding: chunked\r\n" +
		"Trailer: X-Checksum\r\n" +
		"Connection: close\r\n\r\n" +
		"7\r\npayload\r\n0\r\nX-Checksum: ok\r\n\r\n"
	if _, err = io.WriteString(connection, request); err != nil {
		t.Fatal(err)
	}
	wire, err := io.ReadAll(connection)
	if err != nil || !bytes.Contains(wire, []byte("HTTP/1.1 200")) ||
		!bytes.Contains(wire, []byte("trailers-ready")) {
		t.Fatalf("trailer response differs: wire=%q err=%v", wire, err)
	}
	if err = service.PollError(); err != nil {
		t.Fatal(err)
	}
}

func TestServiceStreamsRequestBeforeUploadCompletes(t *testing.T) {
	firstRead := make(chan error, 1)
	service, err := coakkahttp.NewBuilder().PostStream(
		"/request-stream",
		func(request *coakkahttp.Request) (coakkahttp.Response, error) {
			first := make([]byte, len("first-"))
			_, readErr := io.ReadFull(request.Body, first)
			if readErr == nil && string(first) != "first-" {
				readErr = fmt.Errorf("first streamed chunk differs: %q", first)
			}
			firstRead <- readErr
			if readErr != nil {
				return coakkahttp.Response{}, readErr
			}
			rest, readErr := io.ReadAll(request.Body)
			if readErr != nil {
				return coakkahttp.Response{}, readErr
			}
			checksum, ok := request.Trailers.Get("x-checksum")
			if string(rest) != "second" || !ok || checksum != "stream-ok" {
				return coakkahttp.Response{}, fmt.Errorf(
					"stream tail differs: body=%q checksum=%q present=%t", rest, checksum, ok,
				)
			}
			return coakkahttp.Text(200, string(first)+string(rest))
		},
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	if !service.Plan().RequiredCapabilities.Has(coakkahttp.CapabilityRequestStream) {
		t.Fatalf("request-stream capability is absent: %+v", service.Plan())
	}
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}
	connection, err := net.DialTimeout("tcp", fmt.Sprintf("127.0.0.1:%d", port), 5*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer connection.Close()
	if err = connection.SetDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatal(err)
	}
	requestHeadAndFirstChunk := "POST /request-stream HTTP/1.1\r\n" +
		"Host: 127.0.0.1\r\n" +
		"Transfer-Encoding: chunked\r\n" +
		"Trailer: X-Checksum\r\n" +
		"Connection: close\r\n\r\n" +
		"6\r\nfirst-\r\n"
	if _, err = io.WriteString(connection, requestHeadAndFirstChunk); err != nil {
		t.Fatal(err)
	}
	select {
	case readErr := <-firstRead:
		if readErr != nil {
			t.Fatal(readErr)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("handler did not receive the first chunk before upload completion")
	}
	if _, err = io.WriteString(connection, "6\r\nsecond\r\n0\r\nX-Checksum: stream-ok\r\n\r\n"); err != nil {
		t.Fatal(err)
	}
	wire, err := io.ReadAll(connection)
	if err != nil || !bytes.Contains(wire, []byte("HTTP/1.1 200")) ||
		!bytes.Contains(wire, []byte("first-second")) {
		t.Fatalf("stream response differs: wire=%q err=%v", wire, err)
	}
	if err = service.PollError(); err != nil {
		t.Fatal(err)
	}
}

func TestServiceStreamsResponseWithCreditAndTrailers(t *testing.T) {
	contentType, err := coakkahttp.NewHeader("content-type", "text/plain")
	if err != nil {
		t.Fatal(err)
	}
	headers, err := coakkahttp.NewHeaders(contentType)
	if err != nil {
		t.Fatal(err)
	}
	trailer, err := coakkahttp.NewHeader("x-stream-end", "done")
	if err != nil {
		t.Fatal(err)
	}
	trailers, err := coakkahttp.NewHeaders(trailer)
	if err != nil {
		t.Fatal(err)
	}
	streamed, err := coakkahttp.NewStreamingResponse(
		200,
		headers,
		func(writer *coakkahttp.ResponseStreamWriter) (coakkahttp.Headers, error) {
			if _, writeErr := writer.Write([]byte("stream-")); writeErr != nil {
				return coakkahttp.Headers{}, writeErr
			}
			if _, writeErr := writer.Write([]byte("body")); writeErr != nil {
				return coakkahttp.Headers{}, writeErr
			}
			return trailers, nil
		},
	)
	if err != nil {
		t.Fatal(err)
	}
	service, err := coakkahttp.NewBuilder().Get(
		"/stream",
		func(*coakkahttp.Request) (coakkahttp.Response, error) {
			return streamed, nil
		},
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	if !service.Plan().RequiredCapabilities.Has(coakkahttp.CapabilityResponseStream) ||
		!service.Plan().RequiredCapabilities.Has(coakkahttp.CapabilityResponseTrailers) ||
		!service.Plan().RequiredCapabilities.Has(coakkahttp.CapabilityResponseWriteTimeout) {
		t.Fatalf("stream service plan is incomplete: %+v", service.Plan())
	}
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}
	response, err := http.Get(fmt.Sprintf("http://127.0.0.1:%d/stream", port))
	if err != nil {
		t.Fatal(err)
	}
	body, readErr := io.ReadAll(response.Body)
	_ = response.Body.Close()
	if readErr != nil || response.StatusCode != 200 || string(body) != "stream-body" ||
		response.Trailer.Get("x-stream-end") != "done" {
		t.Fatalf("stream response differs: status=%d body=%q trailer=%q err=%v",
			response.StatusCode, body, response.Trailer.Get("x-stream-end"), readErr)
	}
	if err = service.PollError(); err != nil {
		t.Fatal(err)
	}
}

func TestServiceWritesTypedServerSentEvents(t *testing.T) {
	header, err := coakkahttp.NewHeader("x-events", "ordered")
	if err != nil {
		t.Fatal(err)
	}
	headers, err := coakkahttp.NewHeaders(header)
	if err != nil {
		t.Fatal(err)
	}
	response, err := coakkahttp.NewSSEResponse(headers, func(writer *coakkahttp.SSEWriter) error {
		if writeErr := writer.Write(coakkahttp.SSEEvent{
			Data: []byte("ready"), EventType: "state", ID: "1", RetryMillis: 1500,
			HasEventType: true, HasID: true, HasRetry: true,
		}); writeErr != nil {
			return writeErr
		}
		return writer.Write(coakkahttp.SSEEvent{Data: []byte("done")})
	})
	if err != nil {
		t.Fatal(err)
	}
	service, err := coakkahttp.NewBuilder().Get(
		"/events",
		func(*coakkahttp.Request) (coakkahttp.Response, error) { return response, nil },
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	if !service.Plan().RequiredCapabilities.Has(coakkahttp.CapabilityServerSentEvents) {
		t.Fatalf("SSE capability is absent: %+v", service.Plan())
	}
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}
	wire, err := http.Get(fmt.Sprintf("http://127.0.0.1:%d/events", port))
	if err != nil {
		t.Fatal(err)
	}
	body, readErr := io.ReadAll(wire.Body)
	_ = wire.Body.Close()
	expected := "id: 1\nevent: state\nretry: 1500\ndata: ready\n\ndata: done\n\n"
	if readErr != nil || wire.StatusCode != 200 ||
		wire.Header.Get("content-type") != "text/event-stream" ||
		wire.Header.Get("x-events") != "ordered" || string(body) != expected {
		t.Fatalf("SSE response differs: status=%d headers=%v body=%q err=%v",
			wire.StatusCode, wire.Header, body, readErr)
	}
	if err = service.PollError(); err != nil {
		t.Fatal(err)
	}
}

func TestServiceServesStaticSPAAndApplicationFiles(t *testing.T) {
	root := t.TempDir()
	if err := os.WriteFile(filepath.Join(root, "asset.txt"), []byte("core-owned-file"), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(root, "index.html"), []byte("spa-fallback"), 0o600); err != nil {
		t.Fatal(err)
	}
	staticService, err := coakkahttp.NewBuilder().
		StaticMount(coakkahttp.StaticMount{
			ID: 81, URLPrefix: "/app", RootPath: root, IndexFile: "index.html",
			SPAFallbackFile: "index.html", HasIndexFile: true, HasSPAFallbackFile: true,
		}).Start()
	if err != nil {
		t.Fatal(err)
	}
	staticPort, err := staticService.Port()
	if err != nil {
		t.Fatal(err)
	}
	fetch := func(port uint16, path string, acceptHTML bool) string {
		request, requestErr := http.NewRequest(http.MethodGet, fmt.Sprintf("http://127.0.0.1:%d%s", port, path), nil)
		if requestErr != nil {
			t.Fatal(requestErr)
		}
		if acceptHTML {
			request.Header.Set("Accept", "text/html")
		}
		response, requestErr := http.DefaultClient.Do(request)
		if requestErr != nil {
			t.Fatal(requestErr)
		}
		defer response.Body.Close()
		body, readErr := io.ReadAll(response.Body)
		if readErr != nil {
			t.Fatal(readErr)
		}
		if response.StatusCode != http.StatusOK {
			t.Fatalf("GET %s returned %d: %s", path, response.StatusCode, body)
		}
		return string(body)
	}
	if actual := fetch(staticPort, "/app/asset.txt", false); actual != "core-owned-file" {
		t.Fatalf("unexpected static body %q", actual)
	}
	if actual := fetch(staticPort, "/app/client/route", true); actual != "spa-fallback" {
		t.Fatalf("unexpected SPA body %q", actual)
	}
	if err = staticService.Close(); err != nil {
		t.Fatal(err)
	}

	var calls atomic.Int32
	fileService, err := coakkahttp.NewBuilder().
		FileAuthority(coakkahttp.FileAuthority{
			ID: 82, RootPath: root, MaxActiveFiles: 2, MaxFileBytes: 1024,
		}).
		Get("/download", func(*coakkahttp.Request) (coakkahttp.Response, error) {
			calls.Add(1)
			return coakkahttp.ServeFile(200, coakkahttp.Headers{}, 82, "/asset.txt")
		}).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if closeErr := fileService.Close(); closeErr != nil {
			t.Errorf("close service: %v", closeErr)
		}
	}()
	filePort, err := fileService.Port()
	if err != nil {
		t.Fatal(err)
	}
	if actual := fetch(filePort, "/download", false); actual != "core-owned-file" || calls.Load() != 1 {
		t.Fatalf("unexpected file response body=%q calls=%d", actual, calls.Load())
	}
}

func TestServiceOwnsWebSocketUpgradeAndOrderedCallbacks(t *testing.T) {
	events := make(chan string, 4)
	response, err := coakkahttp.NewWebSocketResponse(
		"coakka.test",
		func(session *coakkahttp.WebSocketSession, event coakkahttp.SocketEvent) error {
			switch event.Kind {
			case coakkahttp.WebSocketOpen:
				events <- "open:" + session.Subprotocol()
				return session.SendText("welcome")
			case coakkahttp.WebSocketText:
				events <- "text:" + string(event.Data)
				return session.SendText(string(event.Data))
			case coakkahttp.WebSocketClose:
				events <- fmt.Sprintf("close:%d:%s", event.CloseCode, event.Data)
			}
			return nil
		},
	)
	if err != nil {
		t.Fatal(err)
	}
	service, err := coakkahttp.NewBuilder().WebSocket(
		"/socket",
		func(*coakkahttp.Request) (coakkahttp.Response, error) { return response, nil },
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	if !service.Plan().RequiredCapabilities.Has(coakkahttp.CapabilityWebSocket) {
		t.Fatalf("WebSocket capability is absent: %+v", service.Plan())
	}
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}
	connection, err := net.DialTimeout("tcp", fmt.Sprintf("127.0.0.1:%d", port), 5*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = connection.Close() }()
	if err = connection.SetDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatal(err)
	}
	_, err = io.WriteString(connection,
		"GET /socket HTTP/1.1\r\n"+
			"Host: 127.0.0.1\r\n"+
			"Upgrade: websocket\r\n"+
			"Connection: Upgrade\r\n"+
			"Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n"+
			"Sec-WebSocket-Version: 13\r\n"+
			"Sec-WebSocket-Protocol: coakka.test\r\n\r\n")
	if err != nil {
		t.Fatal(err)
	}
	reader := bufio.NewReader(connection)
	status, err := reader.ReadString('\n')
	if err != nil || !strings.Contains(status, " 101 ") {
		t.Fatalf("WebSocket upgrade failed: status=%q err=%v", status, err)
	}
	selectedProtocol := false
	for {
		line, readErr := reader.ReadString('\n')
		if readErr != nil {
			t.Fatal(readErr)
		}
		if strings.EqualFold(strings.TrimSpace(line), "sec-websocket-protocol: coakka.test") {
			selectedProtocol = true
		}
		if line == "\r\n" {
			break
		}
	}
	if !selectedProtocol {
		t.Fatal("WebSocket upgrade omitted the selected subprotocol")
	}
	opcode, payload, err := readWebSocketFrame(reader)
	if err != nil || opcode != 1 || string(payload) != "welcome" {
		t.Fatalf("WebSocket welcome differs: opcode=%d payload=%q err=%v", opcode, payload, err)
	}
	if err = writeMaskedWebSocketFrame(connection, 1, []byte("alpha")); err != nil {
		t.Fatal(err)
	}
	opcode, payload, err = readWebSocketFrame(reader)
	if err != nil || opcode != 1 || string(payload) != "alpha" {
		t.Fatalf("WebSocket echo differs: opcode=%d payload=%q err=%v", opcode, payload, err)
	}
	if err = writeMaskedWebSocketFrame(connection, 8, []byte{0x03, 0xe8, 'd', 'o', 'n', 'e'}); err != nil {
		t.Fatal(err)
	}
	opcode, payload, err = readWebSocketFrame(reader)
	if err != nil || opcode != 8 || !bytes.Equal(payload, []byte{0x03, 0xe8, 'd', 'o', 'n', 'e'}) {
		t.Fatalf("WebSocket close differs: opcode=%d payload=%v err=%v", opcode, payload, err)
	}
	for _, expected := range []string{"open:coakka.test", "text:alpha", "close:1000:done"} {
		select {
		case actual := <-events:
			if actual != expected {
				t.Fatalf("WebSocket callback order differs: got=%q want=%q", actual, expected)
			}
		case <-time.After(5 * time.Second):
			t.Fatalf("WebSocket callback did not arrive: %s", expected)
		}
	}
	if err = service.PollError(); err != nil {
		t.Fatal(err)
	}
}

func TestServiceResponseStreamDisconnectWakesWriter(t *testing.T) {
	limits := coakkahttp.DefaultLimits()
	limits.ResponseWriteTimeoutMillis = 1_000
	started := make(chan struct{})
	proceed := make(chan struct{})
	producerDone := make(chan error, 1)
	streamed, err := coakkahttp.NewStreamingResponse(
		200,
		coakkahttp.Headers{},
		func(writer *coakkahttp.ResponseStreamWriter) (coakkahttp.Headers, error) {
			close(started)
			<-proceed
			chunk := bytes.Repeat([]byte("x"), 64<<10)
			for attempt := 0; attempt < 1_024; attempt++ {
				if _, writeErr := writer.Write(chunk); writeErr != nil {
					producerDone <- writeErr
					return coakkahttp.Headers{}, writeErr
				}
			}
			err := errors.New("disconnected stream accepted every bounded write")
			producerDone <- err
			return coakkahttp.Headers{}, err
		},
	)
	if err != nil {
		t.Fatal(err)
	}
	service, err := coakkahttp.NewBuilder().Limits(limits).Get(
		"/disconnect",
		func(*coakkahttp.Request) (coakkahttp.Response, error) {
			return streamed, nil
		},
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}
	connection, err := net.DialTimeout("tcp", fmt.Sprintf("127.0.0.1:%d", port), 5*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = io.WriteString(connection, "GET /disconnect HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n"); err != nil {
		t.Fatal(err)
	}
	select {
	case <-started:
	case <-time.After(5 * time.Second):
		t.Fatal("stream producer did not start")
	}
	_ = connection.Close()
	close(proceed)
	select {
	case writeErr := <-producerDone:
		if writeErr == nil {
			t.Fatal("disconnected stream writer returned no error")
		}
	case <-time.After(5 * time.Second):
		t.Fatal("disconnected stream writer did not reach a bounded terminal")
	}
}

func TestServiceProjectsCompleteMonitorControlPlane(t *testing.T) {
	monitor := coakkahttp.MonitorOptions{
		Collection:          coakkahttp.MonitorAggregatesAndEvents,
		EventCapacity:       16,
		MaxEventsPerRead:    4,
		AggregateCategories: uint64(coakkahttp.MonitorCategoryLifecycle),
		EventCategories:     uint64(coakkahttp.MonitorCategoryLifecycle),
		SignalReserved:      true,
	}
	service, err := coakkahttp.NewBuilder().Monitor(monitor).Get(
		"/", func(*coakkahttp.Request) (coakkahttp.Response, error) {
			return coakkahttp.Empty(204)
		},
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()

	config, err := service.MonitorConfig()
	if err != nil || config.Generation == 0 || config.Policy.Collection != coakkahttp.MonitorAggregatesAndEvents {
		t.Fatalf("unexpected monitor config: config=%+v err=%v", config, err)
	}
	if _, err = service.MonitorSnapshot(); err != nil {
		t.Fatal(err)
	}
	if _, err = service.ReadMonitorEvents(0, 4); err != nil {
		t.Fatal(err)
	}
	policy := config.Policy
	policy.Collection = coakkahttp.MonitorAggregates
	policy.Notification = coakkahttp.MonitorNotifyPoll
	policy.EventCategories = 0
	policy.ActiveEventCapacity = 0
	outcome, err := service.ApplyMonitorPolicy(config.Generation, policy)
	if err != nil || outcome.Reason != coakkahttp.MonitorApplyApplied {
		t.Fatalf("unexpected monitor apply: outcome=%+v err=%v", outcome, err)
	}
	if err = service.WaitMonitor(0); err != nil {
		var coreErr *coakkahttp.Error
		if !errors.As(err, &coreErr) || coreErr.Code != coakkahttp.ResultTimeout {
			t.Fatal(err)
		}
	}
	if err = service.InterruptMonitor(); err != nil {
		t.Fatal(err)
	}
}

func TestServiceOwnsTLSAndMutualTLSListenerResources(t *testing.T) {
	fixture := func(name string) string {
		path, err := filepath.Abs(filepath.Join("test-fixtures", "tls", name))
		if err != nil {
			t.Fatal(err)
		}
		return path
	}
	listener := func(security coakkahttp.TransportSecurity, generation uint64) coakkahttp.Listener {
		value := coakkahttp.Listener{
			ID:                   1,
			Protocol:             coakkahttp.ProtocolHTTP11,
			BindAddress:          "127.0.0.1",
			Security:             security,
			CredentialGeneration: generation,
			CredentialID:         "go-server",
			CertificateChainFile: fixture("server.pem"),
			PrivateKeyFile:       fixture("server.key"),
		}
		if security == coakkahttp.SecurityMutualTLS {
			value.TrustRootsFile = fixture("ca.pem")
		}
		return value
	}
	client := func(withIdentity bool) *http.Client {
		ca, err := os.ReadFile(fixture("ca.pem"))
		if err != nil {
			t.Fatal(err)
		}
		roots := x509.NewCertPool()
		if !roots.AppendCertsFromPEM(ca) {
			t.Fatal("TLS fixture CA was not parsed")
		}
		configuration := &tls.Config{RootCAs: roots, MinVersion: tls.VersionTLS12}
		if withIdentity {
			identity, loadErr := tls.LoadX509KeyPair(fixture("client.pem"), fixture("client.key"))
			if loadErr != nil {
				t.Fatal(loadErr)
			}
			configuration.Certificates = []tls.Certificate{identity}
		}
		return &http.Client{
			Transport: &http.Transport{TLSClientConfig: configuration},
			Timeout:   5 * time.Second,
		}
	}
	get := func(client *http.Client, port uint16) (int, string, error) {
		response, err := client.Get(fmt.Sprintf("https://localhost:%d/secure", port))
		if err != nil {
			return 0, "", err
		}
		defer func() { _ = response.Body.Close() }()
		body, err := io.ReadAll(response.Body)
		return response.StatusCode, string(body), err
	}
	port := func(service *coakkahttp.Service) uint16 {
		value, err := service.Port()
		if err != nil {
			t.Fatal(err)
		}
		return value
	}

	tlsService, err := coakkahttp.NewBuilder().Listener(
		listener(coakkahttp.SecurityTLS, 7),
	).Get("/secure", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Text(200, "tls-ready")
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	if !tlsService.Plan().RequiredCapabilities.Has(coakkahttp.CapabilityTLS) ||
		!tlsService.Plan().RequiredCapabilities.Has(coakkahttp.CapabilityHealth) {
		t.Fatalf("TLS service plan is incomplete: %+v", tlsService.Plan())
	}
	tlsClient := client(false)
	status, body, err := get(tlsClient, port(tlsService))
	tlsClient.CloseIdleConnections()
	if err != nil || status != 200 || body != "tls-ready" {
		t.Fatalf("TLS request differs: status=%d body=%q err=%v", status, body, err)
	}
	if err = tlsService.Close(); err != nil {
		t.Fatal(err)
	}

	mutualService, err := coakkahttp.NewBuilder().Listener(
		listener(coakkahttp.SecurityMutualTLS, 9),
	).Get("/secure", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Text(200, "mtls-ready")
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = mutualService.Close() }()
	if !mutualService.Plan().RequiredCapabilities.Has(coakkahttp.CapabilityMutualTLS) {
		t.Fatalf("mutual-TLS service plan is incomplete: %+v", mutualService.Plan())
	}
	unauthenticated := client(false)
	_, _, unauthenticatedErr := get(unauthenticated, port(mutualService))
	unauthenticated.CloseIdleConnections()
	if unauthenticatedErr == nil {
		t.Fatal("mutual-TLS listener accepted a client without an identity")
	}
	authenticated := client(true)
	status, body, err = get(authenticated, port(mutualService))
	authenticated.CloseIdleConnections()
	if err != nil || status != 200 || body != "mtls-ready" {
		t.Fatalf("mutual-TLS request differs: status=%d body=%q err=%v", status, body, err)
	}
}

func TestServiceOwnsHTTP2AndHTTP3WireProtocols(t *testing.T) {
	clients := []struct {
		name        string
		environment string
		protocol    coakkahttp.ListenerProtocol
		capability  coakkahttp.Capabilities
	}{
		{"http2", "COAKKA_HTTP_TEST_HTTP2_CLIENT", coakkahttp.ProtocolHTTP2, coakkahttp.CapabilityHTTP2},
		{"http3", "COAKKA_HTTP_TEST_HTTP3_CLIENT", coakkahttp.ProtocolHTTP3, coakkahttp.CapabilityHTTP3},
	}
	fixtures, err := filepath.Abs(filepath.Join("test-fixtures", "tls"))
	if err != nil {
		t.Fatal(err)
	}
	for _, test := range clients {
		t.Run(test.name, func(t *testing.T) {
			client := os.Getenv(test.environment)
			if client == "" {
				t.Skipf("%s is not configured", test.environment)
			}
			service, startErr := coakkahttp.NewBuilder().Listener(coakkahttp.Listener{
				ID:                   1,
				Protocol:             test.protocol,
				BindAddress:          "127.0.0.1",
				Security:             coakkahttp.SecurityTLS,
				CredentialGeneration: 1,
				CredentialID:         "go-protocol-server",
				CertificateChainFile: filepath.Join(fixtures, "server.pem"),
				PrivateKeyFile:       filepath.Join(fixtures, "server.key"),
			}).Get("/protocol", func(*coakkahttp.Request) (coakkahttp.Response, error) {
				return coakkahttp.Text(200, "protocol-ready")
			}).Start()
			if startErr != nil {
				t.Fatal(startErr)
			}
			defer func() { _ = service.Close() }()
			if !service.Plan().RequiredCapabilities.Has(test.capability) {
				t.Fatalf("%s service plan is incomplete: %+v", test.name, service.Plan())
			}
			port, portErr := service.Port()
			if portErr != nil {
				t.Fatal(portErr)
			}
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			defer cancel()
			output, runErr := exec.CommandContext(
				ctx, client, fmt.Sprint(port), "/protocol", "protocol-ready",
			).CombinedOutput()
			if runErr != nil {
				t.Fatalf("%s wire client failed: %v\n%s", test.name, runErr, output)
			}
		})
	}
}

func TestServiceHandlerRebindPreservesCapturedWork(t *testing.T) {
	entered := make(chan struct{})
	release := make(chan struct{})
	var releaseOnce sync.Once
	releaseOld := func() { releaseOnce.Do(func() { close(release) }) }
	defer releaseOld()

	limits := coakkahttp.DefaultLimits()
	limits.MaxHandlerBindings = 3
	service, err := coakkahttp.NewBuilder().Limits(limits).Concurrency(2).Get(
		"/value",
		func(*coakkahttp.Request) (coakkahttp.Response, error) {
			close(entered)
			<-release
			return coakkahttp.Text(200, "old")
		},
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}

	type httpResult struct {
		status int
		body   string
		err    error
	}
	request := func() httpResult {
		response, requestErr := http.Get(fmt.Sprintf("http://127.0.0.1:%d/value", port))
		if requestErr != nil {
			return httpResult{err: requestErr}
		}
		body, readErr := io.ReadAll(response.Body)
		_ = response.Body.Close()
		return httpResult{status: response.StatusCode, body: string(body), err: readErr}
	}
	oldResult := make(chan httpResult, 1)
	go func() { oldResult <- request() }()
	select {
	case <-entered:
	case <-time.After(5 * time.Second):
		t.Fatal("old handler was not admitted")
	}

	if err = service.PrepareHandler(2, func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Text(201, "new")
	}); err != nil {
		t.Fatal(err)
	}
	rebind := coakkahttp.RebindRequest{
		ActivationID:            1,
		ExpectedRouteGeneration: 1,
		RouteID:                 1,
		ExpectedBindingRevision: 1,
		NewHandlerBindingID:     2,
	}
	applied, err := service.RebindHandler(rebind, 2*time.Second)
	if err != nil || applied.Code != coakkahttp.RebindApplied || !applied.Changed || applied.EffectiveHandlerBindingID != 2 {
		t.Fatalf("unexpected rebind outcome: outcome=%+v err=%v", applied, err)
	}
	replayed, err := service.RebindHandler(rebind, 2*time.Second)
	if err != nil || !replayed.Replayed {
		t.Fatalf("exact rebind was not replayed: outcome=%+v err=%v", replayed, err)
	}
	current := request()
	if current.err != nil || current.status != 201 || current.body != "new" {
		t.Fatalf("new request did not use replacement: %+v", current)
	}

	if err = service.PrepareHandler(3, func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Text(202, "stale")
	}); err != nil {
		t.Fatal(err)
	}
	staleRequest := rebind
	staleRequest.ActivationID = 2
	staleRequest.NewHandlerBindingID = 3
	stale, err := service.RebindHandler(staleRequest, 2*time.Second)
	if err != nil || stale.Code != coakkahttp.RebindBindingRevisionMismatch || stale.EffectiveHandlerBindingID != 2 {
		t.Fatalf("stale rebind changed effective state: outcome=%+v err=%v", stale, err)
	}
	if err = service.PrepareHandler(2, func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Empty(204)
	}); err == nil {
		t.Fatal("duplicate handler binding was accepted")
	}

	releaseOld()
	select {
	case old := <-oldResult:
		if old.err != nil || old.status != 200 || old.body != "old" {
			t.Fatalf("captured request did not retain old handler: %+v", old)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("captured request did not complete")
	}
	if err = service.Close(); err != nil {
		t.Fatal(err)
	}
	if err = service.PrepareHandler(4, func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Empty(204)
	}); err == nil {
		t.Fatal("handler preparation succeeded after close")
	}
	if _, err = service.RebindHandler(rebind, time.Second); err == nil {
		t.Fatal("rebind succeeded after close")
	}
}

func TestServicePublishesCompleteRouteGenerationAndPreservesCapturedWork(t *testing.T) {
	entered := make(chan struct{})
	release := make(chan struct{})
	var releaseOnce sync.Once
	releaseOld := func() { releaseOnce.Do(func() { close(release) }) }
	defer releaseOld()

	limits := coakkahttp.DefaultLimits()
	limits.MaxHandlerBindings = 3
	service, err := coakkahttp.NewBuilder().Limits(limits).Concurrency(2).Get(
		"/old",
		func(*coakkahttp.Request) (coakkahttp.Response, error) {
			close(entered)
			<-release
			return coakkahttp.Text(200, "old-generation")
		},
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}

	type httpResult struct {
		status int
		body   string
		err    error
	}
	request := func(path string) httpResult {
		response, requestErr := http.Get(fmt.Sprintf("http://127.0.0.1:%d%s", port, path))
		if requestErr != nil {
			return httpResult{err: requestErr}
		}
		body, readErr := io.ReadAll(response.Body)
		_ = response.Body.Close()
		return httpResult{status: response.StatusCode, body: string(body), err: readErr}
	}
	oldResult := make(chan httpResult, 1)
	go func() { oldResult <- request("/old") }()
	select {
	case <-entered:
	case <-time.After(5 * time.Second):
		t.Fatal("old handler was not admitted")
	}

	if err = service.PrepareHandler(2, func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Text(201, "new-generation")
	}); err != nil {
		t.Fatal(err)
	}
	publication := coakkahttp.RoutePublication{
		ActivationID:                  1,
		ExpectedRouteGeneration:       1,
		ExpectedMetadataGeneration:    1,
		ExpectedBindingChangeSequence: 1,
		Routes: []coakkahttp.Route{{
			ID:               2,
			HandlerBindingID: 2,
			Method:           http.MethodGet,
			Pattern:          "/new",
			BodyDelivery:     coakkahttp.BodyInline,
			BodyPolicy: coakkahttp.BodyPolicy{
				Enabled:      true,
				AcceptAbsent: true,
				AcceptOther:  true,
				MaxBodyBytes: limits.MaxRequestBodyBytes,
			},
		}},
	}
	applied, err := service.PublishRoutes(publication, 2*time.Second)
	if err != nil || applied.Code != coakkahttp.RoutePublicationApplied ||
		!applied.Changed || applied.EffectiveRouteGeneration != 2 {
		t.Fatalf("unexpected route publication: outcome=%+v err=%v", applied, err)
	}
	replayed, err := service.PublishRoutes(publication, 2*time.Second)
	if err != nil || !replayed.Replayed || replayed.OperationDigest != applied.OperationDigest {
		t.Fatalf("exact publication was not replayed: outcome=%+v err=%v", replayed, err)
	}
	stale := publication
	stale.ActivationID = 2
	rejected, err := service.PublishRoutes(stale, 2*time.Second)
	if err != nil || rejected.Code != coakkahttp.RoutePublicationGenerationMismatch ||
		rejected.EffectiveRouteGeneration != 2 {
		t.Fatalf("stale publication changed effective state: outcome=%+v err=%v", rejected, err)
	}
	current := request("/new")
	if current.err != nil || current.status != 201 || current.body != "new-generation" {
		t.Fatalf("new route did not use prepared handler: %+v", current)
	}
	removed := request("/old")
	if removed.err != nil || removed.status != http.StatusNotFound {
		t.Fatalf("removed route remained dispatchable: %+v", removed)
	}
	if routes := service.Routes(); len(routes) != 1 || routes[0].ID != 2 {
		t.Fatalf("service route snapshot differs: %+v", routes)
	}

	releaseOld()
	select {
	case old := <-oldResult:
		if old.err != nil || old.status != 200 || old.body != "old-generation" {
			t.Fatalf("captured request did not retain old handler: %+v", old)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("captured request did not complete")
	}
}

func TestHandlerFailureReturnsBoundedResponse(t *testing.T) {
	service, err := coakkahttp.NewBuilder().Get("/fail", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Response{}, errors.New("failure from handler")
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	port, _ := service.Port()
	response, err := http.Get(fmt.Sprintf("http://127.0.0.1:%d/fail", port))
	if err != nil {
		t.Fatal(err)
	}
	body, _ := io.ReadAll(response.Body)
	_ = response.Body.Close()
	if response.StatusCode != 500 || string(body) != "internal server error" {
		t.Fatalf("failure response differs: status=%d body=%q", response.StatusCode, body)
	}
	if err := service.PollError(); err == nil || err.Error() != "failure from handler" {
		t.Fatalf("handler diagnostic differs: %v", err)
	}
}

func TestDispatchPressureFailsClosed(t *testing.T) {
	limits := coakkahttp.DefaultLimits()
	limits.RequestQueueCapacity = 1
	entered := make(chan struct{})
	release := make(chan struct{})
	var enteredOnce sync.Once
	var releaseOnce sync.Once
	service, err := coakkahttp.NewBuilder().Limits(limits).Get("/pressure", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		enteredOnce.Do(func() { close(entered) })
		<-release
		return coakkahttp.Text(200, "ok")
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		releaseOnce.Do(func() { close(release) })
		if closeErr := service.Close(); closeErr != nil {
			t.Error(closeErr)
		}
	}()
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}
	type requestResult struct {
		status int
		body   string
		err    error
	}
	results := make(chan requestResult, 9)
	request := func() {
		response, requestErr := http.Get(fmt.Sprintf("http://127.0.0.1:%d/pressure", port))
		if requestErr != nil {
			results <- requestResult{err: requestErr}
			return
		}
		body, readErr := io.ReadAll(response.Body)
		_ = response.Body.Close()
		results <- requestResult{status: response.StatusCode, body: string(body), err: readErr}
	}
	go request()
	select {
	case <-entered:
	case <-time.After(5 * time.Second):
		t.Fatal("first pressured handler did not start")
	}
	for index := 0; index < 8; index++ {
		go request()
	}
	received := make([]requestResult, 0, 9)
	pressureTimer := time.NewTimer(5 * time.Second)
	pressureObserved := false
	for !pressureObserved && len(received) < 9 {
		select {
		case result := <-results:
			received = append(received, result)
			pressureObserved = result.err == nil && result.status == http.StatusServiceUnavailable
		case <-pressureTimer.C:
			t.Fatal("bounded dispatch pressure did not produce a 503 response")
		}
	}
	if !pressureTimer.Stop() {
		select {
		case <-pressureTimer.C:
		default:
		}
	}
	if !pressureObserved {
		t.Fatal("bounded dispatch pressure did not produce a 503 response")
	}
	releaseOnce.Do(func() { close(release) })
	overloaded := 0
	for len(received) < 9 {
		select {
		case result := <-results:
			received = append(received, result)
		case <-time.After(5 * time.Second):
			t.Fatal("pressured requests did not converge")
		}
	}
	for _, result := range received {
		if result.err != nil {
			t.Errorf("pressured request failed: %v", result.err)
			continue
		}
		switch result.status {
		case 200:
			if result.body != "ok" {
				t.Errorf("successful pressure response body differs: %q", result.body)
			}
		case 503:
			overloaded++
			if result.body != "service unavailable" && result.body != "runtime busy\n" {
				t.Errorf("overload response body differs: %q", result.body)
			}
		default:
			t.Errorf("unexpected pressure response: status=%d body=%q", result.status, result.body)
		}
	}
	if overloaded == 0 {
		t.Fatal("dispatch pressure did not produce a 503 response")
	}
}

func TestCloseTimeoutRetainsOwnerForRetry(t *testing.T) {
	limits := coakkahttp.DefaultLimits()
	limits.ShutdownTimeoutMillis = 250
	entered := make(chan struct{})
	release := make(chan struct{})
	var releaseOnce sync.Once
	service, err := coakkahttp.NewBuilder().Limits(limits).Get("/blocked", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		close(entered)
		<-release
		return coakkahttp.Text(200, "released")
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		releaseOnce.Do(func() { close(release) })
		_ = service.Close()
	}()
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}
	type requestResult struct {
		status int
		body   string
		err    error
	}
	result := make(chan requestResult, 1)
	go func() {
		response, requestErr := http.Get(fmt.Sprintf("http://127.0.0.1:%d/blocked", port))
		if requestErr != nil {
			result <- requestResult{err: requestErr}
			return
		}
		body, readErr := io.ReadAll(response.Body)
		_ = response.Body.Close()
		result <- requestResult{status: response.StatusCode, body: string(body), err: readErr}
	}()
	select {
	case <-entered:
	case <-time.After(5 * time.Second):
		t.Fatal("blocked handler did not start")
	}
	started := time.Now()
	closeErr := service.Close()
	if closeErr == nil || !strings.Contains(closeErr.Error(), "service shutdown timed out") {
		t.Fatalf("first close did not report its shutdown bound: %v", closeErr)
	}
	if elapsed := time.Since(started); elapsed > 2*time.Second {
		t.Fatalf("first close exceeded its bounded envelope: %s", elapsed)
	}
	if _, healthErr := service.Health(); healthErr != nil {
		t.Fatalf("timed-out close released the live Core owner: %v", healthErr)
	}
	releaseOnce.Do(func() { close(release) })
	select {
	case response := <-result:
		completed := response.err == nil && response.status == 200 && response.body == "released"
		cancelled := response.err == nil && response.status == 503 && response.body == "runtime stopped\n"
		if !completed && !cancelled {
			t.Fatalf("admitted request did not reach a bounded terminal: %+v", response)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("admitted request did not complete after release")
	}
	if err = service.Close(); err != nil {
		t.Fatalf("close retry did not release the converged owner: %v", err)
	}
}

func TestConcurrentRequestsRemainIsolated(t *testing.T) {
	service, err := coakkahttp.NewBuilder().Concurrency(4).Post("/echo", func(request *coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Bytes(200, request.Bytes())
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	port, _ := service.Port()
	jobs := make(chan int)
	errorsFound := make(chan error, 200)
	var workers sync.WaitGroup
	for worker := 0; worker < 8; worker++ {
		workers.Add(1)
		go func() {
			defer workers.Done()
			for index := range jobs {
				expected := []byte(fmt.Sprintf("request-%d", index))
				response, err := http.Post(fmt.Sprintf("http://127.0.0.1:%d/echo", port), "application/octet-stream", bytes.NewReader(expected))
				if err != nil {
					errorsFound <- err
					continue
				}
				actual, readErr := io.ReadAll(response.Body)
				_ = response.Body.Close()
				if readErr != nil || response.StatusCode != 200 || !bytes.Equal(actual, expected) {
					errorsFound <- fmt.Errorf("request %d differs: status=%d body=%q err=%v", index, response.StatusCode, actual, readErr)
				}
			}
		}()
	}
	for index := 0; index < 200; index++ {
		jobs <- index
	}
	close(jobs)
	workers.Wait()
	close(errorsFound)
	for err := range errorsFound {
		t.Error(err)
	}
}

func TestConcurrentCloseIsIdempotent(t *testing.T) {
	service, err := coakkahttp.NewBuilder().Get("/", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Empty(204)
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	var wait sync.WaitGroup
	for index := 0; index < 32; index++ {
		wait.Add(3)
		go func() {
			defer wait.Done()
			if closeErr := service.Close(); closeErr != nil {
				t.Error(closeErr)
			}
		}()
		go func() {
			defer wait.Done()
			_ = service.PollError()
		}()
		go func() {
			defer wait.Done()
			_, _ = service.Port()
		}()
	}
	wait.Wait()
	if _, err = service.Port(); err == nil {
		t.Fatal("Port succeeded after close")
	}
}

func TestInvalidValuesFailBeforeNativeAllocation(t *testing.T) {
	if _, err := coakkahttp.NewHeader("bad name", "value"); err == nil {
		t.Fatal("invalid header name was accepted")
	}
	if _, err := coakkahttp.NewResponse(99, coakkahttp.Headers{}, nil); err == nil {
		t.Fatal("invalid response status was accepted")
	}
	if _, err := coakkahttp.Text(99, "invalid"); err == nil {
		t.Fatal("text response factory ignored an invalid status")
	}
	if _, err := coakkahttp.Bytes(600, nil); err == nil {
		t.Fatal("byte response factory ignored an invalid status")
	}
	if _, err := coakkahttp.Empty(0); err == nil {
		t.Fatal("empty response factory ignored an invalid status")
	}
	if _, err := coakkahttp.NewStreamingResponse(200, coakkahttp.Headers{}, nil); err == nil {
		t.Fatal("nil response stream producer was accepted")
	}
	if err := (coakkahttp.Limits{}).Validate(); err == nil {
		t.Fatal("zero limits were accepted")
	}
	if _, err := coakkahttp.NewBuilder().Handle("TRACE", "/", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Empty(204)
	}).Start(); err == nil {
		t.Fatal("unsupported route was accepted")
	}
	staticBuilder := coakkahttp.NewBuilder()
	for index := 1; index <= 17; index++ {
		staticBuilder.StaticMount(coakkahttp.StaticMount{
			ID: uint64(index), URLPrefix: fmt.Sprintf("/static-%d", index), RootPath: "/tmp",
		})
	}
	if _, err := staticBuilder.Start(); err == nil {
		t.Fatal("static mount count above the Core bound was accepted")
	}
	authorityBuilder := coakkahttp.NewBuilder().Get("/", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Empty(204)
	})
	for index := 1; index <= 17; index++ {
		authorityBuilder.FileAuthority(coakkahttp.FileAuthority{
			ID: uint64(index), RootPath: "/tmp", MaxActiveFiles: 1, MaxFileBytes: 1,
		})
	}
	if _, err := authorityBuilder.Start(); err == nil {
		t.Fatal("file authority count above the Core bound was accepted")
	}
}

func TestResponseOwnsBodyAndReturnsDefensiveCopies(t *testing.T) {
	body := []byte("owned")
	response, err := coakkahttp.Bytes(200, body)
	if err != nil {
		t.Fatal(err)
	}
	body[0] = 'x'
	first := response.Bytes()
	if string(first) != "owned" {
		t.Fatalf("response did not retain its body: %q", first)
	}
	first[0] = 'x'
	if got := string(response.Bytes()); got != "owned" {
		t.Fatalf("response exposed mutable body storage: %q", got)
	}
}

func TestMain(m *testing.M) {
	http.DefaultClient.Timeout = 10 * time.Second
	os.Exit(m.Run())
}
