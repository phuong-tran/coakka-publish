# TLS Test Fixtures

These PEM files are shared black-box fixtures for the high-level Service TLS
and mutual-TLS tests. They contain a test-only CA, a localhost server identity,
and one client identity. The server certificate covers `localhost` and
`127.0.0.1`; `openssl.cnf` records their X.509 extension profiles. The
certificates are generated with a ten-year validity window.

The private keys are intentionally committed test data. They must never be
used for development services outside the test suite or for production.
