# CoAkka HTTP Runtime for Go

Status: GitHub release `1.0.0`. Go module proxy mirror not yet available.

Install directly from the versioned GitHub source:

```sh
GOPROXY=direct go get github.com/phuong-tran/coakka-publish/coakka-http-runtime/go@v1.0.0
```

The API uses ordinary `Request`, `Response`, `Handler`, `Service`, `Client`,
stream, server-event and `WebSocketSession` concepts. It supports:

- buffered request and response values;
- bounded request and response streams;
- server events and WebSocket sessions;
- static files, byte ranges, validators and SPA fallback;
- outbound requests;
- TLS, HTTP/1.1 and HTTP/2;
- form and multipart values;
- revision-checked route updates;
- health, counters, inspection and bounded diagnostics;
- cancellation, pressure rejection and finite shutdown.

```go
service, err := coakkahttp.NewBuilder().
    Listen("127.0.0.1", 8080).
    Get("/customer/{id}", func(request *coakkahttp.Request) (coakkahttp.Response, error) {
        return coakkahttp.JSON(http.StatusOK, map[string]string{
            "id": request.Params["id"],
        })
    }).
    Start()
if err != nil {
    return err
}

defer func() {
    ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
    defer cancel()
    _ = service.Close(ctx)
}()
```

The builder owns mutable declarations until `Start`. A started service owns
the listener, immutable route generation, active handlers, upgraded sessions,
outbound client state and diagnostics until shutdown. Request bodies are
single-consumer values: buffered accessors share one bounded copy, while
`Stream` transfers reading to the caller.

Routes, request targets, headers, bodies, chunks, multipart parts, active
handlers, connections, messages and diagnostics have fixed ceilings. Invalid
configuration and invalid route sets fail before listening. Admission pressure
returns a stable error response, and `Close(ctx)` uses the caller's finite
cancellation boundary.

A response `Stream` reader remains handler-owned. It must return from `Read`
or implement `io.Closer` and unblock when closed so shutdown can converge; the
service cannot cancel an arbitrary blocking reader implementation.

The GitHub module and release archive carry target-selected compiled objects
for macOS arm64, Linux arm64/x64 and Windows arm64/x64. Additional sanitizer,
fault, stress and soak work remains planned; module proxy publication is a
separate future distribution step.
