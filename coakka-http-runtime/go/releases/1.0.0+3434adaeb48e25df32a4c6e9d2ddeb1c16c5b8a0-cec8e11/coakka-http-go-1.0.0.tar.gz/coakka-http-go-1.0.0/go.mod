module github.com/phuong-tran/coakka-http-runtime-connector/connectors/go/coakkahttp

go 1.23

require github.com/coder/websocket v1.8.15
