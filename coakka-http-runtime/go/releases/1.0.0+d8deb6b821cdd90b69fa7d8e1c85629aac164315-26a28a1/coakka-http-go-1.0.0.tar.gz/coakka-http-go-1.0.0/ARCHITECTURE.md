# Go Connector Architecture

## Boundary

The connector binds only `include/coakka/http/http.h`, vendored byte-for-byte
as `internal/native_api.h`. `bridge.c` resolves the complete ABI2 table before
configuration allocation. A missing symbol or an ABI revision other than 2
fails closed. No private runtime header, protobuf schema, callback, Go HTTP
server, socket, file descriptor, TLS engine, or client transport crosses this
boundary.

Core is the sole owner of listeners, connections, protocol state, filesystem
access, TLS material, WebSocket sessions, and outbound calls. Inputs are
ordinary Go values projected into temporary C allocations. Every configuration
and command API copies those inputs before a successful return; the temporary
arena is then released.

## Layers

- `config.go` and `outbound_config.go` model every construction-time ABI2
  option, including static/SPA mounts, application file authorities, TLS/mTLS,
  gzip, inspection, monitor reservation, and outbound topology.
- `native_config.go` is the only configuration projection owner. It creates
  the opaque native configuration, applies copied declarations, creates Core,
  destroys the temporary configuration, and transfers the library handle to
  `nativeCore`.
- `core.go` is the public lifecycle and concurrency boundary. It counts active
  native calls, enforces one reader per pull lane, and prevents destroy from
  overlapping a call.
- `native_protocol.go`, `native_extended.go`, and `native_monitor.go` project
  request, stream, SSE, WebSocket, outbound, health, rebind, and monitor values.
- `service.go` is an optional bounded buffered facade. One event pump feeds a
  fixed worker set through a bounded channel; it is implemented entirely over
  public `Core` methods.

## Lease Law

Each successful native `take_event`, `take_websocket`, or `take_outbound`
returns exactly one Core-owned lease. The matching native projection method:

1. initializes the public ABI output struct;
2. takes one item;
3. installs the matching release in a defer immediately;
4. copies every byte range and pointer-free field into Go storage;
5. joins a release failure into the returned error.

The public `Event`, `SocketEvent`, and `ClientTerminal` therefore never contain
native pointers and cannot outlive a lease accidentally. Even validation or
allocation failure follows the same release path.

## Lifecycle Law

`Core.acquire` rejects new operations after close begins and counts calls that
already crossed the boundary. `Close` marks the Core closing, invokes the two
ABI-defined reader interrupts, waits for the active count to reach zero, then
drains/stops a started Core, destroys it, and finally unloads the dynamic
library. WebSocket, outbound, liveness, rebind, and monitor waits are capped at
30 seconds, so non-interruptible joins remain finite.

After stop has joined native producers, `Core.Close` nonblockingly copies and
releases the remaining bounded terminal queue before destroy. ABI2 keeps queued
terminal observations readable after stop specifically for this ownership
handoff. A retained destroy keeps the native owner and a later close retries
without repeating completed connector shutdown stages.

`Service.Close` first marks connector admission closed and asks Core to drain.
The sole event pump remains alive: requests that crossed the Core boundary are
either delivered to an already admitted worker or completed with the bounded
internal response, and every resulting terminal observation is released. One
empty timed read with no tracked exchange is the pump quiescence barrier. Close
then closes the bounded work channel, joins the fixed workers, and delegates
native destruction to `Core.Close`. A `Handler` must return and must not call
`Service.Close`; Go cannot forcibly cancel arbitrary application code.

## Artifact Law

The selected payload is embedded by exact Go target, bounded to 64 MiB,
verified by SHA-256, extracted once into an owner-only process directory, and
loaded with local symbol visibility. `COAKKA_HTTP_CORE_PATH` is a development
override and accepts only a bounded regular non-symlink file. It does not relax
the ABI2 or complete-symbol-table check.
