# Known Limitations

Release `1.0.0` is distributed as a GitHub source artifact. A tagged public Go
module remains a separate publication gate.

## Artifact Evidence

- All five supported targets embed the exact ABI2 Core recorded in the package
  README. Each passed architecture, 125-export, dependency-closure and
  matching-host lifecycle checks.
- Windows x86-64 executes under Windows 11 ARM64's x64 emulation layer. That is
  matching-OS functional evidence, not physical-x86-64 or performance evidence.
- Cross-compilation remains build evidence only and never substitutes for the
  recorded matching-host executions.

## API Constraints

- Direct native waits accept durations from zero through 30 seconds. Longer
  application waits must poll and observe their own context or cancellation.
- `Builder`/`Service` deliberately supports buffered inline-body HTTP/1.1
  request/reply. Streaming bodies, response trailers, SSE, WebSockets, TLS,
  HTTP/2, HTTP/3, static/SPA files, outbound calls, rebind, inspection, and
  monitoring remain available through the complete low-level `Config`/`Core`
  API rather than being partially emulated in the facade.
- `Service.Close` waits for application handlers to return. Handlers must be
  cooperative and must not call `Close` on their own Service. The low-level
  `Core` API is the appropriate boundary for applications requiring their own
  cancellable worker supervision.
- The extracted embedded file and owner-only directory are retained for the
  process lifetime so repeated Core creation cannot create an unbounded number
  of temporary files.

## Verification

The embedded `darwin/arm64` payload is a Mach-O arm64 dylib with 125 public
exports. `otool -L` reports only CoreFoundation, libSystem, and libc++ outside
the payload. From this module directory, the following commands pass without a
development override:

```sh
go test ./...
go vet ./...
go test -race ./...
go test -count=20 ./...
```

The tests exercise the exact embedded bytes, callback-free pull dispatch,
automatic event lease release, buffered Service concurrency and close,
health/liveness, monitor snapshots, ABI surface completeness, GoDoc coverage, and
payload digest verification.
