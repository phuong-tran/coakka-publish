# CoAkka HTTP for Go

Release `1.0.0` source is available as a GitHub artifact. A tagged public Go
module is a separate publication gate and has not been opened.

The package binds the public callback-free Core ABI2. The native Core is the
sole owner of listeners, sockets, TLS state, files, HTTP protocol engines,
WebSockets, and outbound client connections. Go supplies copied configuration
and commands and pulls copied events; the connector does not host HTTP.

`Config` and `Core` expose the complete low-level surface: listener protocols
and TLS/mTLS, route body policy, resource limits, gzip, static/SPA mounts,
application file authorities, outbound topology and credentials, request and
response streams, trailers, SSE, WebSockets, route rebind, health, inspection,
and monitoring. `Builder` and `Service` remain the smaller buffered handler
facade for ordinary HTTP/1.1 request/reply services.

```go
service, err := coakkahttp.NewBuilder().
    Post("/echo", func(request *coakkahttp.Request) (coakkahttp.Response, error) {
        return coakkahttp.Bytes(200, request.Bytes())
    }).
    Start()
if err != nil {
    return err
}
defer service.Close()
```

For streaming or protocol-level control, create `Config`, call `Open`, start
the returned `Core`, and run exactly one reader for each required pull lane:

```go
core, err := coakkahttp.Open(coakkahttp.Config{
    Listeners: []coakkahttp.Listener{{
        ID: 1, BindAddress: "127.0.0.1",
        Protocol: coakkahttp.ProtocolHTTP11,
        Security: coakkahttp.SecurityPlaintext,
    }},
    Routes: []coakkahttp.Route{{
        ID: 1, HandlerBindingID: 1, Method: "GET", Pattern: "/events",
        BodyDelivery: coakkahttp.BodyStream,
    }},
})
if err != nil {
    return err
}
defer core.Close()
if err = core.Start(); err != nil {
    return err
}
event, err := core.TakeEvent(250 * time.Millisecond)
```

`TakeEvent`, `TakeWebSocket`, and `TakeOutbound` copy all borrowed data and
release the native lease exactly once before returning, including copy-error
paths. Pull waits are capped at 30 seconds so `Close` has a finite connector
join bound; longer application waits should poll and observe their own context.
`Close` interrupts the inbound and monitor waiters, waits for active native
calls, then destroys Core before unloading its library.

`COAKKA_HTTP_CORE_PATH` may select a matching ABI2 binary for development. The
override must resolve to a bounded regular non-symlink file. Packaged operation
extracts the build-tag-selected embedded payload once per process, verifies its
SHA-256 digest, and loads it locally. A package is releasable only when exact
Core payloads for `darwin/arm64`, `linux/amd64`, `linux/arm64`,
`windows/amd64`, and `windows/arm64` have matching-host dependency closure,
export, architecture, and runtime evidence.

Release payload state:

| Go target | Embedded ABI2 payload |
| --- | --- |
| `darwin/arm64` | `ee6e602692f71905b76f90205ad020409d667d429cd31bba29d62f8d4c60a009` |
| `linux/amd64` | `eaa502ed5ccd0398ffdd463a6930f38def4796e8cd87b81c9cb8c3d847c959e6` |
| `linux/arm64` | `ece8a618e763c10e23edea90bdd5fe968bf448fd5186b8c05d47f025f76b912b` |
| `windows/amd64` | `1bf2220891e35893b8d47725345ba3bc4740d532eac288b022f2d0f52cdc6e69` |
| `windows/arm64` | `1378347cb9ff27fee165e0711980ce2d8695f0c92a7ec61479788fedbc3ad043` |

All five payloads passed architecture, exact 125-export, dependency-closure and
matching-host lifecycle checks. Windows x86-64 execution used Windows 11
ARM64's x64 emulation layer and is not a physical-x86-64 performance claim.
