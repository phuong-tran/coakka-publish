#include "bridge.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(_WIN32)
#include <windows.h>
typedef HMODULE coakka_http_go_library_t;
#define CLOSE_LIBRARY FreeLibrary
#else
#include <dlfcn.h>
typedef void *coakka_http_go_library_t;
#define CLOSE_LIBRARY dlclose
#endif

/* Keep symbol ownership in one table. Opening fails before any Core state is
 * created when even one public ABI2 entrypoint is absent. */
#define API_FUNCTIONS(X)                                                       \
  X(uint32_t, abi_version, (void))                                             \
  X(coakka_http_capabilities_t, features, (void))                              \
  X(void, listener_init, (coakka_http_listener_t *))                           \
  X(void, body_policy_init, (coakka_http_body_policy_t *))                     \
  X(void, core_route_init, (coakka_http_core_route_t *))                       \
  X(void, core_limits_init, (coakka_http_core_limits_t *))                     \
  X(void, static_mount_init, (coakka_http_static_mount_t *))                   \
  X(void, file_authority_init, (coakka_http_file_authority_t *))               \
  X(void, compression_init, (coakka_http_compression_t *))                     \
  X(void, wait_policy_init, (coakka_http_wait_policy_t *))                     \
  X(void, outbound_options_init, (coakka_http_outbound_options_t *))           \
  X(void, inspection_options_init, (coakka_http_inspection_options_t *))       \
  X(void, outbound_endpoint_init, (coakka_http_outbound_endpoint_t *))         \
  X(void, outbound_target_init, (coakka_http_outbound_target_t *))             \
  X(void, monitor_options_init, (coakka_http_monitor_options_t *))             \
  X(void, event_init, (coakka_http_event_t *))                                 \
  X(void, response_init, (coakka_http_response_t *))                           \
  X(void, terminal_summary_init, (coakka_http_terminal_summary_t *))           \
  X(void, file_response_init, (coakka_http_file_response_t *))                 \
  X(void, sse_event_init, (coakka_http_sse_event_t *))                         \
  X(void, failure_init, (coakka_http_failure_t *))                             \
  X(void, outbound_request_init, (coakka_http_client_request_t *))             \
  X(void, outbound_terminal_init, (coakka_http_client_terminal_t *))           \
  X(void, health_init, (coakka_http_health_t *))                               \
  X(void, monitor_policy_view_init, (coakka_http_monitor_policy_view_t *))     \
  X(void, monitor_config_view_init, (coakka_http_monitor_config_view_t *))     \
  X(void, monitor_apply_outcome_init, (coakka_http_monitor_apply_outcome_t *)) \
  X(void, monitor_snapshot_view_init, (coakka_http_monitor_snapshot_view_t *)) \
  X(void, monitor_event_view_init, (coakka_http_monitor_event_view_t *))       \
  X(void, monitor_event_page_init, (coakka_http_monitor_event_page_view_t *))  \
  X(void, route_rebind_init, (coakka_http_route_rebind_t *))                   \
  X(void, route_rebind_outcome_init, (coakka_http_route_rebind_outcome_t *))   \
  X(coakka_http_result_t, configuration_create,                                \
    (coakka_http_configuration_t **))                                          \
  X(coakka_http_result_t, configuration_destroy,                               \
    (coakka_http_configuration_t **))                                          \
  X(coakka_http_result_t, configuration_set_limits,                            \
    (coakka_http_configuration_t *, const coakka_http_core_limits_t *))        \
  X(coakka_http_result_t, configuration_add_listener,                          \
    (coakka_http_configuration_t *, const coakka_http_listener_t *))           \
  X(coakka_http_result_t, configuration_add_route,                             \
    (coakka_http_configuration_t *, const coakka_http_core_route_t *))         \
  X(coakka_http_result_t, configuration_add_static_mount,                      \
    (coakka_http_configuration_t *, const coakka_http_static_mount_t *))       \
  X(coakka_http_result_t, configuration_add_file_authority,                    \
    (coakka_http_configuration_t *, const coakka_http_file_authority_t *))     \
  X(coakka_http_result_t, configuration_set_compression,                       \
    (coakka_http_configuration_t *, const coakka_http_compression_t *))        \
  X(coakka_http_result_t, configuration_set_io_backend,                        \
    (coakka_http_configuration_t *, coakka_http_io_backend_t))                 \
  X(coakka_http_result_t, configuration_set_wait_policy,                       \
    (coakka_http_configuration_t *, const coakka_http_wait_policy_t *))        \
  X(coakka_http_result_t, configuration_set_monitor,                           \
    (coakka_http_configuration_t *, const coakka_http_monitor_options_t *))    \
  X(coakka_http_result_t, configuration_set_inspection,                        \
    (coakka_http_configuration_t *, const coakka_http_inspection_options_t *)) \
  X(coakka_http_result_t, configuration_set_outbound,                          \
    (coakka_http_configuration_t *, const coakka_http_outbound_options_t *))   \
  X(coakka_http_result_t, configuration_enable_outbound,                       \
    (coakka_http_configuration_t *))                                           \
  X(coakka_http_result_t, configuration_add_outbound_target,                   \
    (coakka_http_configuration_t *, const coakka_http_outbound_target_t *))    \
  X(coakka_http_result_t, configuration_add_outbound_trust,                    \
    (coakka_http_configuration_t *, uint64_t, coakka_http_bytes_t))            \
  X(coakka_http_result_t, configuration_add_outbound_identity,                 \
    (coakka_http_configuration_t *, uint64_t, coakka_http_bytes_t,             \
     coakka_http_bytes_t))                                                     \
  X(coakka_http_result_t, core_create,                                         \
    (const coakka_http_configuration_t *, coakka_http_core_t **))              \
  X(coakka_http_result_t, core_start, (coakka_http_core_t *))                  \
  X(coakka_http_result_t, core_bound_port,                                     \
    (const coakka_http_core_t *, uint16_t *))                                  \
  X(coakka_http_result_t, core_drain, (coakka_http_core_t *))                  \
  X(coakka_http_result_t, core_stop, (coakka_http_core_t *))                   \
  X(coakka_http_result_t, core_interrupt, (coakka_http_core_t *))              \
  X(coakka_http_result_t, core_destroy, (coakka_http_core_t **))               \
  X(coakka_http_result_t, core_take_event,                                     \
    (coakka_http_core_t *, uint64_t, coakka_http_event_t *))                   \
  X(coakka_http_result_t, core_release_event,                                  \
    (coakka_http_core_t *, coakka_http_event_t *))                             \
  X(coakka_http_bytes_t, event_request_method, (const coakka_http_event_t *))  \
  X(coakka_http_bytes_t, event_request_scheme, (const coakka_http_event_t *))  \
  X(coakka_http_bytes_t, event_request_authority,                              \
    (const coakka_http_event_t *))                                             \
  X(coakka_http_bytes_t, event_request_target, (const coakka_http_event_t *))  \
  X(coakka_http_bytes_t, event_request_body, (const coakka_http_event_t *))    \
  X(uint32_t, event_request_body_delivery, (const coakka_http_event_t *))      \
  X(uint64_t, event_request_route_id, (const coakka_http_event_t *))           \
  X(uint64_t, event_request_route_generation, (const coakka_http_event_t *))   \
  X(uint64_t, event_request_binding_revision, (const coakka_http_event_t *))   \
  X(uint32_t, event_request_header_count, (const coakka_http_event_t *))       \
  X(uint8_t, event_request_header,                                             \
    (const coakka_http_event_t *, uint32_t, coakka_http_header_t *))           \
  X(uint32_t, event_request_path_parameter_count,                              \
    (const coakka_http_event_t *))                                             \
  X(uint8_t, event_request_path_parameter,                                     \
    (const coakka_http_event_t *, uint32_t, coakka_http_path_parameter_t *))   \
  X(uint32_t, event_request_query_parameter_count,                             \
    (const coakka_http_event_t *))                                             \
  X(uint8_t, event_request_query_parameter,                                    \
    (const coakka_http_event_t *, uint32_t, coakka_http_query_parameter_t *))  \
  X(uint32_t, event_request_trailer_count, (const coakka_http_event_t *))      \
  X(uint8_t, event_request_trailer,                                            \
    (const coakka_http_event_t *, uint32_t, coakka_http_header_t *))           \
  X(uint32_t, event_stream_trailer_count, (const coakka_http_event_t *))       \
  X(uint8_t, event_stream_trailer,                                             \
    (const coakka_http_event_t *, uint32_t, coakka_http_header_t *))           \
  X(coakka_http_result_t, event_terminal_summary,                              \
    (const coakka_http_event_t *, coakka_http_terminal_summary_t *))           \
  X(coakka_http_result_t, core_exchange_cancelled,                             \
    (coakka_http_core_t *, coakka_http_exchange_id_t, uint8_t *))              \
  X(coakka_http_result_t, core_respond,                                        \
    (coakka_http_core_t *, coakka_http_exchange_id_t,                          \
     const coakka_http_response_t *))                                          \
  X(coakka_http_result_t, core_respond_file,                                   \
    (coakka_http_core_t *, coakka_http_exchange_id_t,                          \
     const coakka_http_file_response_t *))                                     \
  X(coakka_http_result_t, core_fail,                                           \
    (coakka_http_core_t *, coakka_http_exchange_id_t,                          \
     const coakka_http_failure_t *))                                           \
  X(coakka_http_result_t, core_start_response_stream,                          \
    (coakka_http_core_t *, coakka_http_exchange_id_t,                          \
     const coakka_http_response_t *))                                          \
  X(coakka_http_result_t, core_start_sse,                                      \
    (coakka_http_core_t *, coakka_http_exchange_id_t,                          \
     const coakka_http_header_t *, uint32_t))                                  \
  X(coakka_http_result_t, core_write_response_stream,                          \
    (coakka_http_core_t *, coakka_http_exchange_id_t, coakka_http_bytes_t))    \
  X(coakka_http_result_t, core_write_sse,                                      \
    (coakka_http_core_t *, coakka_http_exchange_id_t,                          \
     const coakka_http_sse_event_t *))                                         \
  X(coakka_http_result_t, core_finish_response_stream,                         \
    (coakka_http_core_t *, coakka_http_exchange_id_t,                          \
     const coakka_http_header_t *, uint32_t))                                  \
  X(coakka_http_result_t, core_accept_websocket,                               \
    (coakka_http_core_t *, coakka_http_exchange_id_t, coakka_http_bytes_t))    \
  X(coakka_http_result_t, core_take_websocket,                                 \
    (coakka_http_core_t *, uint64_t, coakka_http_socket_event_t *))            \
  X(coakka_http_result_t, core_release_websocket,                              \
    (coakka_http_core_t *, coakka_http_socket_event_t *))                      \
  X(coakka_http_result_t, core_send_websocket,                                 \
    (coakka_http_core_t *, coakka_http_websocket_id_t,                         \
     coakka_http_socket_event_kind_t, coakka_http_bytes_t))                    \
  X(coakka_http_result_t, core_close_websocket,                                \
    (coakka_http_core_t *, coakka_http_websocket_id_t, uint32_t,               \
     coakka_http_bytes_t))                                                     \
  X(coakka_http_result_t, core_outbound_submit,                                \
    (coakka_http_core_t *, const coakka_http_client_request_t *,               \
     coakka_http_outbound_id_t *))                                             \
  X(coakka_http_result_t, core_outbound_cancel,                                \
    (coakka_http_core_t *, coakka_http_outbound_id_t))                         \
  X(coakka_http_result_t, core_take_outbound,                                  \
    (coakka_http_core_t *, uint64_t, coakka_http_client_terminal_t *))         \
  X(coakka_http_result_t, core_outbound_header,                                \
    (coakka_http_core_t *, const coakka_http_client_terminal_t *, uint32_t,    \
     coakka_http_header_t *))                                                  \
  X(coakka_http_result_t, core_release_outbound,                               \
    (coakka_http_core_t *, coakka_http_client_terminal_t *))                   \
  X(coakka_http_result_t, core_rebind,                                         \
    (coakka_http_core_t *, const coakka_http_route_rebind_t *, uint64_t,       \
     coakka_http_route_rebind_outcome_t *))                                    \
  X(coakka_http_result_t, core_health,                                         \
    (coakka_http_core_t *, coakka_http_health_t *))                            \
  X(coakka_http_result_t, core_probe_liveness,                                 \
    (coakka_http_core_t *, uint64_t, coakka_http_health_t *))                  \
  X(coakka_http_result_t, core_monitor_config,                                 \
    (coakka_http_core_t *, coakka_http_monitor_config_view_t *))               \
  X(coakka_http_result_t, core_monitor_snapshot,                               \
    (coakka_http_core_t *, coakka_http_monitor_snapshot_view_t *))             \
  X(coakka_http_result_t, core_monitor_apply,                                  \
    (coakka_http_core_t *, uint64_t,                                           \
     const coakka_http_monitor_policy_view_t *,                                \
     coakka_http_monitor_apply_outcome_t *))                                   \
  X(coakka_http_result_t, core_monitor_read,                                   \
    (coakka_http_core_t *, uint64_t, uint32_t,                                 \
     coakka_http_monitor_event_view_t *, uint32_t,                             \
     coakka_http_monitor_event_page_view_t *))                                 \
  X(coakka_http_result_t, core_monitor_wait, (coakka_http_core_t *, uint64_t)) \
  X(coakka_http_result_t, core_monitor_interrupt, (coakka_http_core_t *))

#define API_FIELD(result, name, arguments) result(*name) arguments;
struct coakka_http_go_api {
  coakka_http_go_library_t library;
  API_FUNCTIONS(API_FIELD)
};
#undef API_FIELD

static coakka_http_result_t result_value(coakka_http_result_code_t code,
                                         const char *detail) {
  coakka_http_result_t result;
  memset(&result, 0, sizeof(result));
  result.struct_size = (uint32_t)sizeof(result);
  result.code = code;
  if (detail != NULL) {
    (void)snprintf(result.detail, sizeof(result.detail), "%s", detail);
  }
  return result;
}

static void *library_symbol(coakka_http_go_library_t library,
                            const char *name) {
#if defined(_WIN32)
  return (void *)(uintptr_t)GetProcAddress(library, name);
#else
  return dlsym(library, name);
#endif
}

static coakka_http_go_library_t open_library(const char *path) {
#if defined(_WIN32)
  return LoadLibraryA(path);
#else
  return dlopen(path, RTLD_NOW | RTLD_LOCAL);
#endif
}

static int load_functions(coakka_http_go_api_t *api) {
#define LOAD_FIELD(result, name, arguments)                                    \
  do {                                                                         \
    const void *const symbol =                                                 \
        library_symbol(api->library, "coakka_http_" #name);                    \
    if (symbol == NULL) {                                                      \
      return 0;                                                                \
    }                                                                          \
    memcpy(&api->name, &symbol, sizeof(api->name));                            \
  } while (0);
  API_FUNCTIONS(LOAD_FIELD)
#undef LOAD_FIELD
  return api->abi_version() == COAKKA_HTTP_ABI_VERSION;
}

coakka_http_result_t coakka_http_go_open(const char *library_path,
                                         coakka_http_go_api_t **out_api) {
  coakka_http_go_api_t *api;
  if (library_path == NULL || out_api == NULL) {
    return result_value(COAKKA_HTTP_RESULT_INVALID_ARGUMENT,
                        "Go bridge open arguments are invalid");
  }
  *out_api = NULL;
  api = (coakka_http_go_api_t *)calloc(1U, sizeof(*api));
  if (api == NULL) {
    return result_value(COAKKA_HTTP_RESULT_OUT_OF_MEMORY,
                        "Go bridge allocation failed");
  }
  api->library = open_library(library_path);
  if (api->library == NULL || !load_functions(api)) {
    if (api->library != NULL) {
      (void)CLOSE_LIBRARY(api->library);
    }
    free(api);
    return result_value(COAKKA_HTTP_RESULT_UNSUPPORTED,
                        "complete CoAkka HTTP Core ABI2 could not be loaded");
  }
  *out_api = api;
  return result_value(COAKKA_HTTP_RESULT_OK, NULL);
}

void coakka_http_go_close(coakka_http_go_api_t **api) {
  if (api == NULL || *api == NULL) {
    return;
  }
  if ((*api)->library != NULL) {
    (void)CLOSE_LIBRARY((*api)->library);
  }
  free(*api);
  *api = NULL;
}

coakka_http_capabilities_t coakka_http_go_features(coakka_http_go_api_t *api) {
  return api == NULL ? UINT64_C(0) : api->features();
}

#define INIT_FORWARD(go_name, field, type)                                     \
  void coakka_http_go_##go_name(coakka_http_go_api_t *api, type *value) {      \
    if (api != NULL && value != NULL) {                                        \
      api->field(value);                                                       \
    }                                                                          \
  }
INIT_FORWARD(listener_init, listener_init, coakka_http_listener_t)
INIT_FORWARD(body_policy_init, body_policy_init, coakka_http_body_policy_t)
INIT_FORWARD(core_route_init, core_route_init, coakka_http_core_route_t)
INIT_FORWARD(core_limits_init, core_limits_init, coakka_http_core_limits_t)
INIT_FORWARD(static_mount_init, static_mount_init, coakka_http_static_mount_t)
INIT_FORWARD(file_authority_init, file_authority_init,
             coakka_http_file_authority_t)
INIT_FORWARD(compression_init, compression_init, coakka_http_compression_t)
INIT_FORWARD(wait_policy_init, wait_policy_init, coakka_http_wait_policy_t)
INIT_FORWARD(outbound_options_init, outbound_options_init,
             coakka_http_outbound_options_t)
INIT_FORWARD(inspection_options_init, inspection_options_init,
             coakka_http_inspection_options_t)
INIT_FORWARD(outbound_endpoint_init, outbound_endpoint_init,
             coakka_http_outbound_endpoint_t)
INIT_FORWARD(outbound_target_init, outbound_target_init,
             coakka_http_outbound_target_t)
INIT_FORWARD(monitor_options_init, monitor_options_init,
             coakka_http_monitor_options_t)
INIT_FORWARD(event_init, event_init, coakka_http_event_t)
INIT_FORWARD(response_init, response_init, coakka_http_response_t)
INIT_FORWARD(terminal_summary_init, terminal_summary_init,
             coakka_http_terminal_summary_t)
INIT_FORWARD(file_response_init, file_response_init,
             coakka_http_file_response_t)
INIT_FORWARD(sse_event_init, sse_event_init, coakka_http_sse_event_t)
INIT_FORWARD(failure_init, failure_init, coakka_http_failure_t)
INIT_FORWARD(outbound_request_init, outbound_request_init,
             coakka_http_client_request_t)
INIT_FORWARD(outbound_terminal_init, outbound_terminal_init,
             coakka_http_client_terminal_t)
INIT_FORWARD(health_init, health_init, coakka_http_health_t)
INIT_FORWARD(monitor_policy_init, monitor_policy_view_init,
             coakka_http_monitor_policy_view_t)
INIT_FORWARD(monitor_config_init, monitor_config_view_init,
             coakka_http_monitor_config_view_t)
INIT_FORWARD(monitor_apply_outcome_init, monitor_apply_outcome_init,
             coakka_http_monitor_apply_outcome_t)
INIT_FORWARD(monitor_snapshot_init, monitor_snapshot_view_init,
             coakka_http_monitor_snapshot_view_t)
INIT_FORWARD(monitor_event_init, monitor_event_view_init,
             coakka_http_monitor_event_view_t)
INIT_FORWARD(monitor_page_init, monitor_event_page_init,
             coakka_http_monitor_event_page_view_t)
INIT_FORWARD(rebind_init, route_rebind_init, coakka_http_route_rebind_t)
INIT_FORWARD(rebind_outcome_init, route_rebind_outcome_init,
             coakka_http_route_rebind_outcome_t)
#undef INIT_FORWARD

void coakka_http_go_socket_event_init(coakka_http_socket_event_t *value) {
  if (value != NULL) {
    memset(value, 0, sizeof(*value));
    value->struct_size = (uint32_t)sizeof(*value);
  }
}

#define FORWARD_RESULT_1(go_name, field, t1)                                   \
  coakka_http_result_t coakka_http_go_##go_name(coakka_http_go_api_t *api,     \
                                                t1 a1) {                       \
    return api->field(a1);                                                     \
  }
#define FORWARD_RESULT_2(go_name, field, t1, t2)                               \
  coakka_http_result_t coakka_http_go_##go_name(coakka_http_go_api_t *api,     \
                                                t1 a1, t2 a2) {                \
    return api->field(a1, a2);                                                 \
  }
#define FORWARD_RESULT_3(go_name, field, t1, t2, t3)                           \
  coakka_http_result_t coakka_http_go_##go_name(coakka_http_go_api_t *api,     \
                                                t1 a1, t2 a2, t3 a3) {         \
    return api->field(a1, a2, a3);                                             \
  }
#define FORWARD_RESULT_4(go_name, field, t1, t2, t3, t4)                       \
  coakka_http_result_t coakka_http_go_##go_name(coakka_http_go_api_t *api,     \
                                                t1 a1, t2 a2, t3 a3, t4 a4) {  \
    return api->field(a1, a2, a3, a4);                                         \
  }
#define FORWARD_RESULT_5(go_name, field, t1, t2, t3, t4, t5)                   \
  coakka_http_result_t coakka_http_go_##go_name(                               \
      coakka_http_go_api_t *api, t1 a1, t2 a2, t3 a3, t4 a4, t5 a5) {          \
    return api->field(a1, a2, a3, a4, a5);                                     \
  }
#define FORWARD_RESULT_6(go_name, field, t1, t2, t3, t4, t5, t6)               \
  coakka_http_result_t coakka_http_go_##go_name(                               \
      coakka_http_go_api_t *api, t1 a1, t2 a2, t3 a3, t4 a4, t5 a5, t6 a6) {   \
    return api->field(a1, a2, a3, a4, a5, a6);                                 \
  }

FORWARD_RESULT_1(configuration_create, configuration_create,
                 coakka_http_configuration_t **)
FORWARD_RESULT_1(configuration_destroy, configuration_destroy,
                 coakka_http_configuration_t **)
FORWARD_RESULT_2(configuration_set_limits, configuration_set_limits,
                 coakka_http_configuration_t *,
                 const coakka_http_core_limits_t *)
FORWARD_RESULT_2(configuration_add_listener, configuration_add_listener,
                 coakka_http_configuration_t *, const coakka_http_listener_t *)
FORWARD_RESULT_2(configuration_add_route, configuration_add_route,
                 coakka_http_configuration_t *,
                 const coakka_http_core_route_t *)
FORWARD_RESULT_2(configuration_add_static_mount, configuration_add_static_mount,
                 coakka_http_configuration_t *,
                 const coakka_http_static_mount_t *)
FORWARD_RESULT_2(configuration_add_file_authority,
                 configuration_add_file_authority,
                 coakka_http_configuration_t *,
                 const coakka_http_file_authority_t *)
FORWARD_RESULT_2(configuration_set_compression, configuration_set_compression,
                 coakka_http_configuration_t *,
                 const coakka_http_compression_t *)
FORWARD_RESULT_2(configuration_set_io_backend, configuration_set_io_backend,
                 coakka_http_configuration_t *, coakka_http_io_backend_t)
FORWARD_RESULT_2(configuration_set_wait_policy, configuration_set_wait_policy,
                 coakka_http_configuration_t *,
                 const coakka_http_wait_policy_t *)
FORWARD_RESULT_2(configuration_set_monitor, configuration_set_monitor,
                 coakka_http_configuration_t *,
                 const coakka_http_monitor_options_t *)
FORWARD_RESULT_2(configuration_set_inspection, configuration_set_inspection,
                 coakka_http_configuration_t *,
                 const coakka_http_inspection_options_t *)
FORWARD_RESULT_2(configuration_set_outbound, configuration_set_outbound,
                 coakka_http_configuration_t *,
                 const coakka_http_outbound_options_t *)
FORWARD_RESULT_1(configuration_enable_outbound, configuration_enable_outbound,
                 coakka_http_configuration_t *)
FORWARD_RESULT_2(configuration_add_outbound_target,
                 configuration_add_outbound_target,
                 coakka_http_configuration_t *,
                 const coakka_http_outbound_target_t *)
FORWARD_RESULT_3(configuration_add_outbound_trust,
                 configuration_add_outbound_trust,
                 coakka_http_configuration_t *, uint64_t, coakka_http_bytes_t)
FORWARD_RESULT_4(configuration_add_outbound_identity,
                 configuration_add_outbound_identity,
                 coakka_http_configuration_t *, uint64_t, coakka_http_bytes_t,
                 coakka_http_bytes_t)
FORWARD_RESULT_2(core_create, core_create, const coakka_http_configuration_t *,
                 coakka_http_core_t **)
FORWARD_RESULT_1(core_start, core_start, coakka_http_core_t *)
FORWARD_RESULT_2(core_bound_port, core_bound_port, const coakka_http_core_t *,
                 uint16_t *)
FORWARD_RESULT_1(core_drain, core_drain, coakka_http_core_t *)
FORWARD_RESULT_1(core_stop, core_stop, coakka_http_core_t *)
FORWARD_RESULT_1(core_interrupt, core_interrupt, coakka_http_core_t *)
FORWARD_RESULT_1(core_destroy, core_destroy, coakka_http_core_t **)
FORWARD_RESULT_3(core_take_event, core_take_event, coakka_http_core_t *,
                 uint64_t, coakka_http_event_t *)
FORWARD_RESULT_2(core_release_event, core_release_event, coakka_http_core_t *,
                 coakka_http_event_t *)
FORWARD_RESULT_3(core_exchange_cancelled, core_exchange_cancelled,
                 coakka_http_core_t *, coakka_http_exchange_id_t, uint8_t *)
FORWARD_RESULT_3(core_respond, core_respond, coakka_http_core_t *,
                 coakka_http_exchange_id_t, const coakka_http_response_t *)
FORWARD_RESULT_3(core_respond_file, core_respond_file, coakka_http_core_t *,
                 coakka_http_exchange_id_t, const coakka_http_file_response_t *)
FORWARD_RESULT_3(core_fail, core_fail, coakka_http_core_t *,
                 coakka_http_exchange_id_t, const coakka_http_failure_t *)
FORWARD_RESULT_3(core_start_response_stream, core_start_response_stream,
                 coakka_http_core_t *, coakka_http_exchange_id_t,
                 const coakka_http_response_t *)
FORWARD_RESULT_4(core_start_sse, core_start_sse, coakka_http_core_t *,
                 coakka_http_exchange_id_t, const coakka_http_header_t *,
                 uint32_t)
FORWARD_RESULT_3(core_write_response_stream, core_write_response_stream,
                 coakka_http_core_t *, coakka_http_exchange_id_t,
                 coakka_http_bytes_t)
FORWARD_RESULT_3(core_write_sse, core_write_sse, coakka_http_core_t *,
                 coakka_http_exchange_id_t, const coakka_http_sse_event_t *)
FORWARD_RESULT_4(core_finish_response_stream, core_finish_response_stream,
                 coakka_http_core_t *, coakka_http_exchange_id_t,
                 const coakka_http_header_t *, uint32_t)
FORWARD_RESULT_3(core_accept_websocket, core_accept_websocket,
                 coakka_http_core_t *, coakka_http_exchange_id_t,
                 coakka_http_bytes_t)
FORWARD_RESULT_3(core_take_websocket, core_take_websocket, coakka_http_core_t *,
                 uint64_t, coakka_http_socket_event_t *)
FORWARD_RESULT_2(core_release_websocket, core_release_websocket,
                 coakka_http_core_t *, coakka_http_socket_event_t *)
FORWARD_RESULT_4(core_send_websocket, core_send_websocket, coakka_http_core_t *,
                 coakka_http_websocket_id_t, coakka_http_socket_event_kind_t,
                 coakka_http_bytes_t)
FORWARD_RESULT_4(core_close_websocket, core_close_websocket,
                 coakka_http_core_t *, coakka_http_websocket_id_t, uint32_t,
                 coakka_http_bytes_t)
FORWARD_RESULT_3(core_outbound_submit, core_outbound_submit,
                 coakka_http_core_t *, const coakka_http_client_request_t *,
                 coakka_http_outbound_id_t *)
FORWARD_RESULT_2(core_outbound_cancel, core_outbound_cancel,
                 coakka_http_core_t *, coakka_http_outbound_id_t)
FORWARD_RESULT_3(core_take_outbound, core_take_outbound, coakka_http_core_t *,
                 uint64_t, coakka_http_client_terminal_t *)
FORWARD_RESULT_4(core_outbound_header, core_outbound_header,
                 coakka_http_core_t *, const coakka_http_client_terminal_t *,
                 uint32_t, coakka_http_header_t *)
FORWARD_RESULT_2(core_release_outbound, core_release_outbound,
                 coakka_http_core_t *, coakka_http_client_terminal_t *)
FORWARD_RESULT_4(core_rebind, core_rebind, coakka_http_core_t *,
                 const coakka_http_route_rebind_t *, uint64_t,
                 coakka_http_route_rebind_outcome_t *)
FORWARD_RESULT_2(core_health, core_health, coakka_http_core_t *,
                 coakka_http_health_t *)
FORWARD_RESULT_3(core_probe_liveness, core_probe_liveness, coakka_http_core_t *,
                 uint64_t, coakka_http_health_t *)
FORWARD_RESULT_2(core_monitor_config, core_monitor_config, coakka_http_core_t *,
                 coakka_http_monitor_config_view_t *)
FORWARD_RESULT_2(core_monitor_snapshot, core_monitor_snapshot,
                 coakka_http_core_t *, coakka_http_monitor_snapshot_view_t *)
FORWARD_RESULT_4(core_monitor_apply, core_monitor_apply, coakka_http_core_t *,
                 uint64_t, const coakka_http_monitor_policy_view_t *,
                 coakka_http_monitor_apply_outcome_t *)
FORWARD_RESULT_6(core_monitor_read, core_monitor_read, coakka_http_core_t *,
                 uint64_t, uint32_t, coakka_http_monitor_event_view_t *,
                 uint32_t, coakka_http_monitor_event_page_view_t *)
FORWARD_RESULT_2(core_monitor_wait, core_monitor_wait, coakka_http_core_t *,
                 uint64_t)
FORWARD_RESULT_1(core_monitor_interrupt, core_monitor_interrupt,
                 coakka_http_core_t *)

#undef FORWARD_RESULT_1
#undef FORWARD_RESULT_2
#undef FORWARD_RESULT_3
#undef FORWARD_RESULT_4
#undef FORWARD_RESULT_5
#undef FORWARD_RESULT_6

#define BYTES_FORWARD(go_name, field)                                          \
  coakka_http_bytes_t coakka_http_go_##go_name(                                \
      coakka_http_go_api_t *api, const coakka_http_event_t *event) {           \
    return api->field(event);                                                  \
  }
BYTES_FORWARD(event_request_method, event_request_method)
BYTES_FORWARD(event_request_scheme, event_request_scheme)
BYTES_FORWARD(event_request_authority, event_request_authority)
BYTES_FORWARD(event_request_target, event_request_target)
BYTES_FORWARD(event_request_body, event_request_body)
#undef BYTES_FORWARD

#define SCALAR_FORWARD(go_name, field, result)                                 \
  result coakka_http_go_##go_name(coakka_http_go_api_t *api,                   \
                                  const coakka_http_event_t *event) {          \
    return api->field(event);                                                  \
  }
SCALAR_FORWARD(event_request_body_delivery, event_request_body_delivery,
               uint32_t)
SCALAR_FORWARD(event_request_route_id, event_request_route_id, uint64_t)
SCALAR_FORWARD(event_request_route_generation, event_request_route_generation,
               uint64_t)
SCALAR_FORWARD(event_request_binding_revision, event_request_binding_revision,
               uint64_t)
SCALAR_FORWARD(event_request_header_count, event_request_header_count, uint32_t)
SCALAR_FORWARD(event_request_path_parameter_count,
               event_request_path_parameter_count, uint32_t)
SCALAR_FORWARD(event_request_query_parameter_count,
               event_request_query_parameter_count, uint32_t)
SCALAR_FORWARD(event_request_trailer_count, event_request_trailer_count,
               uint32_t)
SCALAR_FORWARD(event_stream_trailer_count, event_stream_trailer_count, uint32_t)
#undef SCALAR_FORWARD

uint8_t coakka_http_go_event_request_header(coakka_http_go_api_t *api,
                                            const coakka_http_event_t *event,
                                            uint32_t index,
                                            coakka_http_header_t *out_header) {
  return api->event_request_header(event, index, out_header);
}
uint8_t coakka_http_go_event_request_path_parameter(
    coakka_http_go_api_t *api, const coakka_http_event_t *event, uint32_t index,
    coakka_http_path_parameter_t *out_parameter) {
  return api->event_request_path_parameter(event, index, out_parameter);
}
uint8_t coakka_http_go_event_request_query_parameter(
    coakka_http_go_api_t *api, const coakka_http_event_t *event, uint32_t index,
    coakka_http_query_parameter_t *out_parameter) {
  return api->event_request_query_parameter(event, index, out_parameter);
}
uint8_t coakka_http_go_event_request_trailer(
    coakka_http_go_api_t *api, const coakka_http_event_t *event, uint32_t index,
    coakka_http_header_t *out_trailer) {
  return api->event_request_trailer(event, index, out_trailer);
}
uint8_t coakka_http_go_event_stream_trailer(coakka_http_go_api_t *api,
                                            const coakka_http_event_t *event,
                                            uint32_t index,
                                            coakka_http_header_t *out_trailer) {
  return api->event_stream_trailer(event, index, out_trailer);
}
coakka_http_result_t coakka_http_go_event_terminal_summary(
    coakka_http_go_api_t *api, const coakka_http_event_t *event,
    coakka_http_terminal_summary_t *out_summary) {
  return api->event_terminal_summary(event, out_summary);
}
