#ifndef COAKKA_HTTP_GO_BRIDGE_H
#define COAKKA_HTTP_GO_BRIDGE_H

#include "internal/native_api.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct coakka_http_go_api coakka_http_go_api_t;

/* The bridge owns one dynamic-library reference and a complete ABI2 function
 * table. Go destroys every Core/configuration before closing this handle. */
coakka_http_result_t coakka_http_go_open(const char *, coakka_http_go_api_t **);
void coakka_http_go_close(coakka_http_go_api_t **);
coakka_http_capabilities_t coakka_http_go_features(coakka_http_go_api_t *);

void coakka_http_go_listener_init(coakka_http_go_api_t *,
                                  coakka_http_listener_t *);
void coakka_http_go_body_policy_init(coakka_http_go_api_t *,
                                     coakka_http_body_policy_t *);
void coakka_http_go_core_route_init(coakka_http_go_api_t *,
                                    coakka_http_core_route_t *);
void coakka_http_go_core_limits_init(coakka_http_go_api_t *,
                                     coakka_http_core_limits_t *);
void coakka_http_go_static_mount_init(coakka_http_go_api_t *,
                                      coakka_http_static_mount_t *);
void coakka_http_go_file_authority_init(coakka_http_go_api_t *,
                                        coakka_http_file_authority_t *);
void coakka_http_go_compression_init(coakka_http_go_api_t *,
                                     coakka_http_compression_t *);
void coakka_http_go_wait_policy_init(coakka_http_go_api_t *,
                                     coakka_http_wait_policy_t *);
void coakka_http_go_outbound_options_init(coakka_http_go_api_t *,
                                          coakka_http_outbound_options_t *);
void coakka_http_go_inspection_options_init(coakka_http_go_api_t *,
                                            coakka_http_inspection_options_t *);
void coakka_http_go_outbound_endpoint_init(coakka_http_go_api_t *,
                                           coakka_http_outbound_endpoint_t *);
void coakka_http_go_outbound_target_init(coakka_http_go_api_t *,
                                         coakka_http_outbound_target_t *);
void coakka_http_go_monitor_options_init(coakka_http_go_api_t *,
                                         coakka_http_monitor_options_t *);
void coakka_http_go_event_init(coakka_http_go_api_t *, coakka_http_event_t *);
void coakka_http_go_response_init(coakka_http_go_api_t *,
                                  coakka_http_response_t *);
void coakka_http_go_terminal_summary_init(coakka_http_go_api_t *,
                                          coakka_http_terminal_summary_t *);
void coakka_http_go_file_response_init(coakka_http_go_api_t *,
                                       coakka_http_file_response_t *);
void coakka_http_go_sse_event_init(coakka_http_go_api_t *,
                                   coakka_http_sse_event_t *);
void coakka_http_go_failure_init(coakka_http_go_api_t *,
                                 coakka_http_failure_t *);
void coakka_http_go_socket_event_init(coakka_http_socket_event_t *);
void coakka_http_go_outbound_request_init(coakka_http_go_api_t *,
                                          coakka_http_client_request_t *);
void coakka_http_go_outbound_terminal_init(coakka_http_go_api_t *,
                                           coakka_http_client_terminal_t *);
void coakka_http_go_health_init(coakka_http_go_api_t *, coakka_http_health_t *);
void coakka_http_go_monitor_policy_init(coakka_http_go_api_t *,
                                        coakka_http_monitor_policy_view_t *);
void coakka_http_go_monitor_config_init(coakka_http_go_api_t *,
                                        coakka_http_monitor_config_view_t *);
void coakka_http_go_monitor_apply_outcome_init(
    coakka_http_go_api_t *, coakka_http_monitor_apply_outcome_t *);
void coakka_http_go_monitor_snapshot_init(
    coakka_http_go_api_t *, coakka_http_monitor_snapshot_view_t *);
void coakka_http_go_monitor_event_init(coakka_http_go_api_t *,
                                       coakka_http_monitor_event_view_t *);
void coakka_http_go_monitor_page_init(coakka_http_go_api_t *,
                                      coakka_http_monitor_event_page_view_t *);
void coakka_http_go_rebind_init(coakka_http_go_api_t *,
                                coakka_http_route_rebind_t *);
void coakka_http_go_rebind_outcome_init(coakka_http_go_api_t *,
                                        coakka_http_route_rebind_outcome_t *);

coakka_http_result_t
coakka_http_go_configuration_create(coakka_http_go_api_t *,
                                    coakka_http_configuration_t **);
coakka_http_result_t
coakka_http_go_configuration_destroy(coakka_http_go_api_t *,
                                     coakka_http_configuration_t **);
coakka_http_result_t
coakka_http_go_configuration_set_limits(coakka_http_go_api_t *,
                                        coakka_http_configuration_t *,
                                        const coakka_http_core_limits_t *);
coakka_http_result_t
coakka_http_go_configuration_add_listener(coakka_http_go_api_t *,
                                          coakka_http_configuration_t *,
                                          const coakka_http_listener_t *);
coakka_http_result_t
coakka_http_go_configuration_add_route(coakka_http_go_api_t *,
                                       coakka_http_configuration_t *,
                                       const coakka_http_core_route_t *);
coakka_http_result_t coakka_http_go_configuration_add_static_mount(
    coakka_http_go_api_t *, coakka_http_configuration_t *,
    const coakka_http_static_mount_t *);
coakka_http_result_t coakka_http_go_configuration_add_file_authority(
    coakka_http_go_api_t *, coakka_http_configuration_t *,
    const coakka_http_file_authority_t *);
coakka_http_result_t
coakka_http_go_configuration_set_compression(coakka_http_go_api_t *,
                                             coakka_http_configuration_t *,
                                             const coakka_http_compression_t *);
coakka_http_result_t
coakka_http_go_configuration_set_io_backend(coakka_http_go_api_t *,
                                            coakka_http_configuration_t *,
                                            coakka_http_io_backend_t);
coakka_http_result_t
coakka_http_go_configuration_set_wait_policy(coakka_http_go_api_t *,
                                             coakka_http_configuration_t *,
                                             const coakka_http_wait_policy_t *);
coakka_http_result_t
coakka_http_go_configuration_set_monitor(coakka_http_go_api_t *,
                                         coakka_http_configuration_t *,
                                         const coakka_http_monitor_options_t *);
coakka_http_result_t coakka_http_go_configuration_set_inspection(
    coakka_http_go_api_t *, coakka_http_configuration_t *,
    const coakka_http_inspection_options_t *);
coakka_http_result_t coakka_http_go_configuration_set_outbound(
    coakka_http_go_api_t *, coakka_http_configuration_t *,
    const coakka_http_outbound_options_t *);
coakka_http_result_t
coakka_http_go_configuration_enable_outbound(coakka_http_go_api_t *,
                                             coakka_http_configuration_t *);
coakka_http_result_t coakka_http_go_configuration_add_outbound_target(
    coakka_http_go_api_t *, coakka_http_configuration_t *,
    const coakka_http_outbound_target_t *);
coakka_http_result_t
coakka_http_go_configuration_add_outbound_trust(coakka_http_go_api_t *,
                                                coakka_http_configuration_t *,
                                                uint64_t, coakka_http_bytes_t);
coakka_http_result_t coakka_http_go_configuration_add_outbound_identity(
    coakka_http_go_api_t *, coakka_http_configuration_t *, uint64_t,
    coakka_http_bytes_t, coakka_http_bytes_t);

coakka_http_result_t
coakka_http_go_core_create(coakka_http_go_api_t *,
                           const coakka_http_configuration_t *,
                           coakka_http_core_t **);
coakka_http_result_t coakka_http_go_core_start(coakka_http_go_api_t *,
                                               coakka_http_core_t *);
coakka_http_result_t coakka_http_go_core_bound_port(coakka_http_go_api_t *,
                                                    const coakka_http_core_t *,
                                                    uint16_t *);
coakka_http_result_t coakka_http_go_core_drain(coakka_http_go_api_t *,
                                               coakka_http_core_t *);
coakka_http_result_t coakka_http_go_core_stop(coakka_http_go_api_t *,
                                              coakka_http_core_t *);
coakka_http_result_t coakka_http_go_core_interrupt(coakka_http_go_api_t *,
                                                   coakka_http_core_t *);
coakka_http_result_t coakka_http_go_core_destroy(coakka_http_go_api_t *,
                                                 coakka_http_core_t **);
coakka_http_result_t coakka_http_go_core_take_event(coakka_http_go_api_t *,
                                                    coakka_http_core_t *,
                                                    uint64_t,
                                                    coakka_http_event_t *);
coakka_http_result_t coakka_http_go_core_release_event(coakka_http_go_api_t *,
                                                       coakka_http_core_t *,
                                                       coakka_http_event_t *);

coakka_http_bytes_t
coakka_http_go_event_request_method(coakka_http_go_api_t *,
                                    const coakka_http_event_t *);
coakka_http_bytes_t
coakka_http_go_event_request_scheme(coakka_http_go_api_t *,
                                    const coakka_http_event_t *);
coakka_http_bytes_t
coakka_http_go_event_request_authority(coakka_http_go_api_t *,
                                       const coakka_http_event_t *);
coakka_http_bytes_t
coakka_http_go_event_request_target(coakka_http_go_api_t *,
                                    const coakka_http_event_t *);
coakka_http_bytes_t
coakka_http_go_event_request_body(coakka_http_go_api_t *,
                                  const coakka_http_event_t *);
uint32_t
coakka_http_go_event_request_body_delivery(coakka_http_go_api_t *,
                                           const coakka_http_event_t *);
uint64_t coakka_http_go_event_request_route_id(coakka_http_go_api_t *,
                                               const coakka_http_event_t *);
uint64_t
coakka_http_go_event_request_route_generation(coakka_http_go_api_t *,
                                              const coakka_http_event_t *);
uint64_t
coakka_http_go_event_request_binding_revision(coakka_http_go_api_t *,
                                              const coakka_http_event_t *);
uint32_t coakka_http_go_event_request_header_count(coakka_http_go_api_t *,
                                                   const coakka_http_event_t *);
uint8_t coakka_http_go_event_request_header(coakka_http_go_api_t *,
                                            const coakka_http_event_t *,
                                            uint32_t, coakka_http_header_t *);
uint32_t
coakka_http_go_event_request_path_parameter_count(coakka_http_go_api_t *,
                                                  const coakka_http_event_t *);
uint8_t coakka_http_go_event_request_path_parameter(
    coakka_http_go_api_t *, const coakka_http_event_t *, uint32_t,
    coakka_http_path_parameter_t *);
uint32_t
coakka_http_go_event_request_query_parameter_count(coakka_http_go_api_t *,
                                                   const coakka_http_event_t *);
uint8_t coakka_http_go_event_request_query_parameter(
    coakka_http_go_api_t *, const coakka_http_event_t *, uint32_t,
    coakka_http_query_parameter_t *);
uint32_t
coakka_http_go_event_request_trailer_count(coakka_http_go_api_t *,
                                           const coakka_http_event_t *);
uint8_t coakka_http_go_event_request_trailer(coakka_http_go_api_t *,
                                             const coakka_http_event_t *,
                                             uint32_t, coakka_http_header_t *);
uint32_t coakka_http_go_event_stream_trailer_count(coakka_http_go_api_t *,
                                                   const coakka_http_event_t *);
uint8_t coakka_http_go_event_stream_trailer(coakka_http_go_api_t *,
                                            const coakka_http_event_t *,
                                            uint32_t, coakka_http_header_t *);
coakka_http_result_t
coakka_http_go_event_terminal_summary(coakka_http_go_api_t *,
                                      const coakka_http_event_t *,
                                      coakka_http_terminal_summary_t *);

coakka_http_result_t
coakka_http_go_core_exchange_cancelled(coakka_http_go_api_t *,
                                       coakka_http_core_t *,
                                       coakka_http_exchange_id_t, uint8_t *);
coakka_http_result_t
coakka_http_go_core_respond(coakka_http_go_api_t *, coakka_http_core_t *,
                            coakka_http_exchange_id_t,
                            const coakka_http_response_t *);
coakka_http_result_t
coakka_http_go_core_respond_file(coakka_http_go_api_t *, coakka_http_core_t *,
                                 coakka_http_exchange_id_t,
                                 const coakka_http_file_response_t *);
coakka_http_result_t coakka_http_go_core_fail(coakka_http_go_api_t *,
                                              coakka_http_core_t *,
                                              coakka_http_exchange_id_t,
                                              const coakka_http_failure_t *);
coakka_http_result_t coakka_http_go_core_start_response_stream(
    coakka_http_go_api_t *, coakka_http_core_t *, coakka_http_exchange_id_t,
    const coakka_http_response_t *);
coakka_http_result_t coakka_http_go_core_start_sse(coakka_http_go_api_t *,
                                                   coakka_http_core_t *,
                                                   coakka_http_exchange_id_t,
                                                   const coakka_http_header_t *,
                                                   uint32_t);
coakka_http_result_t coakka_http_go_core_write_response_stream(
    coakka_http_go_api_t *, coakka_http_core_t *, coakka_http_exchange_id_t,
    coakka_http_bytes_t);
coakka_http_result_t
coakka_http_go_core_write_sse(coakka_http_go_api_t *, coakka_http_core_t *,
                              coakka_http_exchange_id_t,
                              const coakka_http_sse_event_t *);
coakka_http_result_t coakka_http_go_core_finish_response_stream(
    coakka_http_go_api_t *, coakka_http_core_t *, coakka_http_exchange_id_t,
    const coakka_http_header_t *, uint32_t);

coakka_http_result_t coakka_http_go_core_accept_websocket(
    coakka_http_go_api_t *, coakka_http_core_t *, coakka_http_exchange_id_t,
    coakka_http_bytes_t);
coakka_http_result_t
coakka_http_go_core_take_websocket(coakka_http_go_api_t *, coakka_http_core_t *,
                                   uint64_t, coakka_http_socket_event_t *);
coakka_http_result_t coakka_http_go_core_release_websocket(
    coakka_http_go_api_t *, coakka_http_core_t *, coakka_http_socket_event_t *);
coakka_http_result_t coakka_http_go_core_send_websocket(
    coakka_http_go_api_t *, coakka_http_core_t *, coakka_http_websocket_id_t,
    coakka_http_socket_event_kind_t, coakka_http_bytes_t);
coakka_http_result_t coakka_http_go_core_close_websocket(
    coakka_http_go_api_t *, coakka_http_core_t *, coakka_http_websocket_id_t,
    uint32_t, coakka_http_bytes_t);

coakka_http_result_t coakka_http_go_core_outbound_submit(
    coakka_http_go_api_t *, coakka_http_core_t *,
    const coakka_http_client_request_t *, coakka_http_outbound_id_t *);
coakka_http_result_t coakka_http_go_core_outbound_cancel(
    coakka_http_go_api_t *, coakka_http_core_t *, coakka_http_outbound_id_t);
coakka_http_result_t
coakka_http_go_core_take_outbound(coakka_http_go_api_t *, coakka_http_core_t *,
                                  uint64_t, coakka_http_client_terminal_t *);
coakka_http_result_t coakka_http_go_core_outbound_header(
    coakka_http_go_api_t *, coakka_http_core_t *,
    const coakka_http_client_terminal_t *, uint32_t, coakka_http_header_t *);
coakka_http_result_t
coakka_http_go_core_release_outbound(coakka_http_go_api_t *,
                                     coakka_http_core_t *,
                                     coakka_http_client_terminal_t *);

coakka_http_result_t
coakka_http_go_core_rebind(coakka_http_go_api_t *, coakka_http_core_t *,
                           const coakka_http_route_rebind_t *, uint64_t,
                           coakka_http_route_rebind_outcome_t *);
coakka_http_result_t coakka_http_go_core_health(coakka_http_go_api_t *,
                                                coakka_http_core_t *,
                                                coakka_http_health_t *);
coakka_http_result_t coakka_http_go_core_probe_liveness(coakka_http_go_api_t *,
                                                        coakka_http_core_t *,
                                                        uint64_t,
                                                        coakka_http_health_t *);
coakka_http_result_t
coakka_http_go_core_monitor_config(coakka_http_go_api_t *, coakka_http_core_t *,
                                   coakka_http_monitor_config_view_t *);
coakka_http_result_t
coakka_http_go_core_monitor_snapshot(coakka_http_go_api_t *,
                                     coakka_http_core_t *,
                                     coakka_http_monitor_snapshot_view_t *);
coakka_http_result_t
coakka_http_go_core_monitor_apply(coakka_http_go_api_t *, coakka_http_core_t *,
                                  uint64_t,
                                  const coakka_http_monitor_policy_view_t *,
                                  coakka_http_monitor_apply_outcome_t *);
coakka_http_result_t
coakka_http_go_core_monitor_read(coakka_http_go_api_t *, coakka_http_core_t *,
                                 uint64_t, uint32_t,
                                 coakka_http_monitor_event_view_t *, uint32_t,
                                 coakka_http_monitor_event_page_view_t *);
coakka_http_result_t coakka_http_go_core_monitor_wait(coakka_http_go_api_t *,
                                                      coakka_http_core_t *,
                                                      uint64_t);
coakka_http_result_t
coakka_http_go_core_monitor_interrupt(coakka_http_go_api_t *,
                                      coakka_http_core_t *);

#ifdef __cplusplus
}
#endif
#endif
