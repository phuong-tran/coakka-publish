package coakkahttp

// Config is a complete copied declaration for one Core instance. Nil optional
// sections retain Core defaults; all slices are copied during Open.
type Config struct {
	// Limits optionally overrides Core's conservative resource defaults.
	Limits *CoreLimits
	// Listeners declares Core-owned inbound sockets.
	Listeners []Listener
	// Routes declares inbound routing and body-delivery policy.
	Routes []Route
	// StaticMounts declares Core-owned static and SPA file trees.
	StaticMounts []StaticMount
	// FileAuthorities declares roots allowed for application file responses.
	FileAuthorities []FileAuthority
	// Compression optionally configures bounded response compression.
	Compression *Compression
	// IOBackend optionally selects a native I/O backend; zero retains the default.
	IOBackend IOBackend
	// WaitPolicy optionally controls native idle waiting.
	WaitPolicy *WaitPolicy
	// Monitor optionally reserves monitoring resources.
	Monitor *MonitorOptions
	// Inspection optionally enables authenticated Core-owned inspection.
	Inspection *InspectionOptions
	// Outbound optionally reserves the native client topology and limits.
	Outbound *OutboundOptions
	// OutboundEnabled enables the native client with defaults when Outbound is nil.
	OutboundEnabled bool
	// OutboundTargets declares named target topology copied by Core.
	OutboundTargets []OutboundTarget
	// OutboundTrust declares generation-keyed CA material copied by Core.
	OutboundTrust []OutboundTrust
	// OutboundIdentities declares generation-keyed client identities copied by Core.
	OutboundIdentities []OutboundIdentity
}

// Listener declares one Core-owned listening endpoint and optional file-backed
// TLS identity. Certificate, key, and trust files remain under Core ownership.
type Listener struct {
	// ID is a stable nonzero listener identifier.
	ID uint64
	// Protocol selects HTTP/1.1, HTTP/2, or HTTP/3.
	Protocol ListenerProtocol
	// BindAddress is the host or address copied by Core.
	BindAddress string
	// Port selects a fixed port; zero requests an available port.
	Port uint16
	// Security selects plaintext, TLS, or mutual TLS.
	Security TransportSecurity
	// CredentialGeneration identifies the TLS material revision.
	CredentialGeneration uint64
	// CredentialID is a stable application credential label.
	CredentialID string
	// CertificateChainFile is the Core-opened certificate chain path.
	CertificateChainFile string
	// PrivateKeyFile is the Core-opened private key path.
	PrivateKeyFile string
	// TrustRootsFile is the Core-opened client trust path for mutual TLS.
	TrustRootsFile string
}

// BodyPolicy constrains accepted request content types and body size.
type BodyPolicy struct {
	// Enabled applies the policy when true.
	Enabled bool
	// AcceptAbsent permits requests without a content type.
	AcceptAbsent bool
	// AcceptOther permits content types outside the two form types.
	AcceptOther bool
	// AcceptFormURLEncoded permits application/x-www-form-urlencoded.
	AcceptFormURLEncoded bool
	// AcceptMultipartFormData permits multipart/form-data.
	AcceptMultipartFormData bool
	// MaxBodyBytes bounds one accepted request body.
	MaxBodyBytes uint64
}

// Route declares one immutable Core route and its application binding.
type Route struct {
	// ID is the stable route identifier.
	ID uint64
	// RequestCaptureProfileID selects request metadata capture policy.
	RequestCaptureProfileID uint64
	// HandlerBindingID selects the application handler generation.
	HandlerBindingID uint64
	// Method is the normalized HTTP method copied by Core.
	Method string
	// Pattern is the encoded absolute route pattern copied by Core.
	Pattern string
	// BodyDelivery selects inline or streamed request data.
	BodyDelivery BodyDelivery
	// BodyPolicy constrains admission for request bodies.
	BodyPolicy BodyPolicy
}

// CoreLimits contains construction-time finite resource ceilings. Zero-valued
// fields select the corresponding Core default.
type CoreLimits struct {
	// EventLoopThreads bounds native event-loop threads.
	EventLoopThreads uint32
	// MaxListeners bounds configured listeners.
	MaxListeners uint32
	// MaxConnections bounds retained connections.
	MaxConnections uint32
	// MaxActiveExchanges bounds concurrent inbound exchanges.
	MaxActiveExchanges uint32
	// RequestQueueDepth bounds queued inbound work.
	RequestQueueDepth uint32
	// CompletionQueueDepth bounds queued application completions.
	CompletionQueueDepth uint32
	// CompletionBatchSize bounds completions handled per runtime turn.
	CompletionBatchSize uint32
	// MaxHeaderCount bounds headers on one message.
	MaxHeaderCount uint32
	// MaxHeaderBytes bounds total header bytes on one message.
	MaxHeaderBytes uint32
	// MaxRoutes bounds route declarations.
	MaxRoutes uint32
	// MaxRouteSegments bounds segments in one route.
	MaxRouteSegments uint32
	// MaxCapturesPerRoute bounds named captures in one route.
	MaxCapturesPerRoute uint32
	// RequestStreamChunkSlots bounds queued request chunks.
	RequestStreamChunkSlots uint32
	// RequestStreamMaxRetainedItems bounds retained request stream items.
	RequestStreamMaxRetainedItems uint32
	// ResponseStreamChunkSlots bounds queued response chunks.
	ResponseStreamChunkSlots uint32
	// ResponseStreamMaxRetainedItems bounds retained response stream items.
	ResponseStreamMaxRetainedItems uint32
	// MaxStaticMounts bounds static mount declarations.
	MaxStaticMounts uint32
	// MaxTotalStaticFiles bounds files indexed across static mounts.
	MaxTotalStaticFiles uint32
	// MaxFileAuthorities bounds application file roots.
	MaxFileAuthorities uint32
	// RouteRebindCommandCapacity bounds pending rebind commands.
	RouteRebindCommandCapacity uint32
	// RouteRebindHistoryCapacity bounds idempotency history.
	RouteRebindHistoryCapacity uint32
	// RouteRebindMaxCommandsPerTurn bounds rebind work per runtime turn.
	RouteRebindMaxCommandsPerTurn uint32
	// TerminalObservationQueueDepth bounds terminal event retention.
	TerminalObservationQueueDepth uint32
	// DeadlineTickMillis selects the bounded deadline scan interval.
	DeadlineTickMillis uint32
	// ConnectionTimeoutBatchSize bounds timeout work per runtime turn.
	ConnectionTimeoutBatchSize uint32
	// MaxRequestBodyBytes bounds one request body.
	MaxRequestBodyBytes uint64
	// MaxResponseBodyBytes bounds one response body.
	MaxResponseBodyBytes uint64
	// MaxSerializedRequestBytes bounds one serialized request projection.
	MaxSerializedRequestBytes uint64
	// MaxSerializedResponseBytes bounds one serialized response projection.
	MaxSerializedResponseBytes uint64
	// MaxTotalRequestBodyBytes bounds all retained request bodies.
	MaxTotalRequestBodyBytes uint64
	// MaxTotalResponseBodyBytes bounds all retained response bodies.
	MaxTotalResponseBodyBytes uint64
	// MaxTotalSerializedRequestBytes bounds all serialized request projections.
	MaxTotalSerializedRequestBytes uint64
	// MaxTotalSerializedResponseBytes bounds all serialized response projections.
	MaxTotalSerializedResponseBytes uint64
	// KeepAliveTimeoutMillis bounds idle keep-alive connections.
	KeepAliveTimeoutMillis uint64
	// HeaderTimeoutMillis bounds request header receipt.
	HeaderTimeoutMillis uint64
	// BodyTimeoutMillis bounds request body receipt.
	BodyTimeoutMillis uint64
	// AppHostTimeoutMillis bounds application response latency.
	AppHostTimeoutMillis uint64
	// IdleTimeoutMillis bounds protocol idle time.
	IdleTimeoutMillis uint64
	// DrainTimeoutMillis bounds graceful drain.
	DrainTimeoutMillis uint64
	// StopTimeoutMillis bounds forced stop.
	StopTimeoutMillis uint64
	// ResponseWriteTimeoutMillis bounds stream backpressure waits.
	ResponseWriteTimeoutMillis uint64
	// RequestStreamMaxChunkBytes bounds one request stream chunk.
	RequestStreamMaxChunkBytes uint64
	// RequestStreamMaxTrailerBytes bounds one request trailer block.
	RequestStreamMaxTrailerBytes uint64
	// RequestStreamMaxRetainedBytes bounds one request stream's retained bytes.
	RequestStreamMaxRetainedBytes uint64
	// RequestStreamMaxTotalRetainedBytes bounds retained request stream bytes.
	RequestStreamMaxTotalRetainedBytes uint64
	// ResponseStreamMaxChunkBytes bounds one response stream write.
	ResponseStreamMaxChunkBytes uint64
	// ResponseStreamMaxTrailerBytes bounds one response trailer block.
	ResponseStreamMaxTrailerBytes uint64
	// ResponseStreamMaxRetainedBytes bounds one response stream's retained bytes.
	ResponseStreamMaxRetainedBytes uint64
	// ResponseStreamMaxTotalRetainedBytes bounds retained response stream bytes.
	ResponseStreamMaxTotalRetainedBytes uint64
	// MaxRouteManifestBytes bounds one compiled route manifest.
	MaxRouteManifestBytes uint64
	// MaxTotalRouteMetadataBytes bounds all retained route metadata.
	MaxTotalRouteMetadataBytes uint64
	// MaxSerializedTerminalObservationBytes bounds one terminal projection.
	MaxSerializedTerminalObservationBytes uint64
	// MaxTotalSerializedTerminalObservationBytes bounds all terminal projections.
	MaxTotalSerializedTerminalObservationBytes uint64
}

// StaticMount declares one Core-owned static tree with optional index, cache,
// and SPA fallback behavior.
type StaticMount struct {
	// ID is the stable mount identifier.
	ID uint64
	// URLPrefix is the encoded URL path prefix.
	URLPrefix string
	// RootPath is the filesystem root opened by Core.
	RootPath string
	// IndexFile is the optional directory index path.
	IndexFile string
	// CacheControl is the optional emitted cache-control value.
	CacheControl string
	// SPAFallbackFile is the optional fallback path for unmatched frontend routes.
	SPAFallbackFile string
	// IncludeDotfiles permits dot-prefixed paths when true.
	IncludeDotfiles bool
	// HasIndexFile distinguishes an empty index value from no index policy.
	HasIndexFile bool
	// HasCacheControl distinguishes an empty value from no cache header.
	HasCacheControl bool
	// HasSPAFallbackFile distinguishes an empty fallback from no SPA policy.
	HasSPAFallbackFile bool
}

// FileAuthority declares a Core-owned filesystem root available to application
// file responses.
type FileAuthority struct {
	// ID is the stable authority identifier.
	ID uint64
	// RootPath is the filesystem root opened by Core.
	RootPath string
	// MaxActiveFiles bounds simultaneously active files for this authority.
	MaxActiveFiles uint32
	// MaxFileBytes bounds one served file.
	MaxFileBytes uint64
}

// Compression configures bounded response compression.
type Compression struct {
	// Mode selects disabled or gzip behavior.
	Mode CompressionMode
	// MinimumBodyBytes is the smallest eligible body.
	MinimumBodyBytes uint64
	// MaximumBodyBytes is the largest eligible input body.
	MaximumBodyBytes uint64
	// MaximumEncodedBytes bounds encoded output.
	MaximumEncodedBytes uint64
	// WorkspaceBytes bounds native compression workspace.
	WorkspaceBytes uint64
	// GZIPLevel selects the gzip compression level.
	GZIPLevel int32
}

// WaitPolicy configures native idle behavior.
type WaitPolicy struct {
	// Mode selects blocking, adaptive, or busy polling.
	Mode WaitMode
	// SpinIterations bounds adaptive spin iterations.
	SpinIterations uint32
	// YieldIterations bounds adaptive scheduler yields.
	YieldIterations uint32
}

// InspectionOptions enables bounded authenticated target-runtime inspection.
type InspectionOptions struct {
	// AllowPlaintextLoopback permits inspection on plaintext loopback listeners.
	AllowPlaintextLoopback bool
	// RuntimeInstanceID identifies the inspected runtime instance.
	RuntimeInstanceID uint64
	// RuntimeGeneration identifies the inspected runtime generation.
	RuntimeGeneration uint64
	// BearerFile is the credential file opened by Core.
	BearerFile string
	// MaxBearerTokenBytes bounds the loaded credential.
	MaxBearerTokenBytes uint32
	// CallCapacity bounds concurrent inspection calls.
	CallCapacity uint32
	// MaxEntriesPerTurn bounds inspection work per runtime turn.
	MaxEntriesPerTurn uint32
	// SnapshotDeadlineMillis bounds snapshot collection.
	SnapshotDeadlineMillis uint32
	// MaxBytesPerTurn bounds inspection serialization work per turn.
	MaxBytesPerTurn uint64
	// MaxResponseBytes bounds one inspection response.
	MaxResponseBytes uint64
	// MaxTotalResponseBytes bounds all retained inspection responses.
	MaxTotalResponseBytes uint64
}

// MonitorOptions reserves bounded construction-time monitoring resources.
type MonitorOptions struct {
	// Collection selects disabled, aggregate, or event collection.
	Collection MonitorCollection
	// EventCapacity reserves retained event slots.
	EventCapacity uint32
	// MaxEventsPerRead bounds one read page.
	MaxEventsPerRead uint32
	// DetailBytesPerEvent reserves bounded runtime-safe detail.
	DetailBytesPerEvent uint32
	// LatencyBucketCount reserves fixed latency buckets.
	LatencyBucketCount uint32
	// AggregateCategories selects aggregate categories.
	AggregateCategories uint64
	// EventCategories selects retained event categories.
	EventCategories uint64
	// SignalReserved reserves native notification signaling.
	SignalReserved bool
	// RuntimeSafeDetail permits bounded non-payload detail.
	RuntimeSafeDetail bool
	// FixedLatencyBuckets reserves the fixed histogram shape.
	FixedLatencyBuckets bool
}
