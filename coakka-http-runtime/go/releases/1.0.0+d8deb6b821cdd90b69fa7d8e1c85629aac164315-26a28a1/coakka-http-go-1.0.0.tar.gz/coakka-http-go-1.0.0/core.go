package coakkahttp

import (
	"errors"
	"sync"
	"time"
)

var errCoreClosed = errors.New("CoAkka HTTP Core is closing or closed")

// Core is the lifecycle owner for one callback-free native HTTP runtime.
// Methods may be called concurrently. Lifecycle transitions are serialized,
// and each Take lane admits one reader at a time. Close interrupts interruptible
// readers and waits for every acquired call before destroying Core and
// unloading its exact binary.
type Core struct {
	mu        sync.Mutex
	condition *sync.Cond
	lifecycle sync.Mutex
	native    *nativeCore
	active    uint32
	closing   bool
	started   bool
	closeErr  error

	eventReader     sync.Mutex
	webSocketReader sync.Mutex
	outboundReader  sync.Mutex
	monitorWaiter   sync.Mutex
}

// Features loads the selected exact Core binary, verifies the complete ABI2
// symbol table, and returns its immutable feature-bit matrix without creating
// a runtime instance.
func Features() (Capabilities, error) {
	api, err := openNativeAPI()
	if err != nil {
		return 0, err
	}
	capabilities := nativeFeatures(api)
	closeNativeAPI(&api)
	return capabilities, nil
}

// Open validates and copies a complete Config into a new, unstarted Core.
func Open(config Config) (*Core, error) {
	native, err := openNativeCore(config)
	if err != nil {
		return nil, err
	}
	core := &Core{native: native}
	core.condition = sync.NewCond(&core.mu)
	return core, nil
}

func (core *Core) acquire() (*nativeCore, func(), error) {
	if core == nil {
		return nil, nil, errors.New("CoAkka HTTP Core is nil")
	}
	core.mu.Lock()
	if core.native == nil || core.closing {
		core.mu.Unlock()
		return nil, nil, errCoreClosed
	}
	core.active++
	native := core.native
	core.mu.Unlock()
	return native, func() {
		core.mu.Lock()
		core.active--
		if core.active == 0 {
			core.condition.Broadcast()
		}
		core.mu.Unlock()
	}, nil
}

// Capabilities returns the immutable feature-bit matrix of the loaded Core.
func (core *Core) Capabilities() Capabilities {
	if core == nil {
		return 0
	}
	core.mu.Lock()
	defer core.mu.Unlock()
	if core.native == nil {
		return 0
	}
	return core.native.capabilities
}

// Start binds configured listeners and starts native admission.
func (core *Core) Start() error {
	if core == nil {
		return errors.New("CoAkka HTTP Core is nil")
	}
	core.lifecycle.Lock()
	defer core.lifecycle.Unlock()
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	if err = native.start(); err != nil {
		return err
	}
	core.mu.Lock()
	core.started = true
	core.mu.Unlock()
	return nil
}

// BoundPort returns Core's selected port for a started single-listener setup.
func (core *Core) BoundPort() (uint16, error) {
	native, done, err := core.acquire()
	if err != nil {
		return 0, err
	}
	defer done()
	return native.boundPort()
}

// Drain closes admission and performs Core's bounded graceful drain.
func (core *Core) Drain() error {
	if core == nil {
		return errors.New("CoAkka HTTP Core is nil")
	}
	core.lifecycle.Lock()
	defer core.lifecycle.Unlock()
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.drain()
}

// Stop performs Core's bounded idempotent stop.
func (core *Core) Stop() error {
	if core == nil {
		return errors.New("CoAkka HTTP Core is nil")
	}
	core.lifecycle.Lock()
	defer core.lifecycle.Unlock()
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	err = native.stop()
	if err == nil {
		core.mu.Lock()
		core.started = false
		core.mu.Unlock()
	}
	return err
}

// Interrupt wakes the sole inbound event reader without fabricating an event.
func (core *Core) Interrupt() error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.interrupt()
}

// Close interrupts readers, waits for all native calls and automatic lease
// releases, then drains, stops, destroys, and unloads. Concurrent calls share
// the same terminal result; a failed destroy remains retryable.
func (core *Core) Close() error {
	if core == nil {
		return nil
	}
	// Core's public C ABI forbids overlapping lifecycle transitions. Holding
	// this lock before reading started state also prevents Close from racing a
	// Start that has crossed the native boundary but has not published success.
	core.lifecycle.Lock()
	defer core.lifecycle.Unlock()
	core.mu.Lock()
	for core.closing {
		core.condition.Wait()
	}
	if core.native == nil {
		err := core.closeErr
		core.mu.Unlock()
		return err
	}
	core.closing = true
	native := core.native
	started := core.started
	core.mu.Unlock()

	// These wakeups are specifically defined to overlap the corresponding sole
	// readers. Other Take lanes are finite-bounded by nativeDuration.
	_ = native.interrupt()
	_ = native.monitorInterrupt()
	core.mu.Lock()
	for core.active != 0 {
		core.condition.Wait()
	}
	core.mu.Unlock()

	var err error
	if started {
		drainErr := native.drain()
		stopErr := native.stop()
		err = errors.Join(err, drainErr, stopErr)
		if stopErr == nil {
			core.mu.Lock()
			core.started = false
			core.mu.Unlock()
			err = errors.Join(err, releaseRetainedEvents(native))
		}
	}
	err = errors.Join(err, native.destroy())

	core.mu.Lock()
	if native.core == nil {
		core.native = nil
		core.started = false
	}
	core.closeErr = err
	core.closing = false
	core.condition.Broadcast()
	core.mu.Unlock()
	return err
}

// releaseRetainedEvents runs only after native stop has joined every producer.
// The queue is bounded, so reaching the connector ceiling indicates corrupted
// accounting instead of an unbounded shutdown loop.
func releaseRetainedEvents(native *nativeCore) error {
	for count := 0; count < maximumProjectionItems; count++ {
		_, err := native.takeEvent(0)
		if err == nil {
			continue
		}
		var coreErr *Error
		if errors.As(err, &coreErr) &&
			(coreErr.Code == ResultTimeout || coreErr.Code == ResultClosed || coreErr.Code == ResultCancelled) {
			return nil
		}
		return err
	}
	return errors.New("native retained event count exceeds the Go shutdown bound")
}

// TakeEvent waits for and copies one inbound event. The native event lease is
// released exactly once before this method returns, including copy failures.
func (core *Core) TakeEvent(timeout time.Duration) (*Event, error) {
	value, err := nativeDuration(timeout)
	if err != nil {
		return nil, err
	}
	core.eventReader.Lock()
	defer core.eventReader.Unlock()
	native, done, err := core.acquire()
	if err != nil {
		return nil, err
	}
	defer done()
	return native.takeEvent(value)
}

// ExchangeCancelled reports whether Core has observed cancellation.
func (core *Core) ExchangeCancelled(exchange ExchangeID) (bool, error) {
	native, done, err := core.acquire()
	if err != nil {
		return false, err
	}
	defer done()
	return native.exchangeCancelled(exchange)
}

// Respond completes an exchange with one copied buffered response.
func (core *Core) Respond(exchange ExchangeID, response Response) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.respond(exchange, response)
}

// RespondFile completes an exchange with a Core-opened authority-scoped file.
func (core *Core) RespondFile(exchange ExchangeID, response FileResponse) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.respondFile(exchange, response)
}

// Fail completes an exchange with a typed copied failure.
func (core *Core) Fail(exchange ExchangeID, failure Failure) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.fail(exchange, failure)
}

// StartResponseStream sends a copied response head and opens a stream.
func (core *Core) StartResponseStream(exchange ExchangeID, head Response) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.startResponseStream(exchange, head)
}

// StartSSE sends a Core-defined SSE response head with copied extra headers.
func (core *Core) StartSSE(exchange ExchangeID, headers Headers) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.startSSE(exchange, headers)
}

// WriteResponseStream copies one bounded response body chunk into Core.
func (core *Core) WriteResponseStream(exchange ExchangeID, data []byte) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.writeResponseStream(exchange, data)
}

// WriteSSE copies one typed server-sent event into Core.
func (core *Core) WriteSSE(exchange ExchangeID, event SSEEvent) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.writeSSE(exchange, event)
}

// FinishResponseStream completes a stream with copied trailers.
func (core *Core) FinishResponseStream(exchange ExchangeID, trailers Headers) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.finishResponseStream(exchange, trailers)
}

// AcceptWebSocket accepts an upgrade and copies the selected subprotocol.
func (core *Core) AcceptWebSocket(exchange ExchangeID, selectedSubprotocol string) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.acceptWebSocket(exchange, selectedSubprotocol)
}

// TakeWebSocket waits for and copies one socket event, releasing the native
// lease exactly once before returning.
func (core *Core) TakeWebSocket(timeout time.Duration) (*SocketEvent, error) {
	value, err := nativeDuration(timeout)
	if err != nil {
		return nil, err
	}
	core.webSocketReader.Lock()
	defer core.webSocketReader.Unlock()
	native, done, err := core.acquire()
	if err != nil {
		return nil, err
	}
	defer done()
	return native.takeWebSocket(value)
}

// SendWebSocket copies one text, binary, ping, or pong frame into Core.
func (core *Core) SendWebSocket(session WebSocketID, kind SocketEventKind, data []byte) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.sendWebSocket(session, kind, data)
}

// CloseWebSocket asks Core to close a session with a copied reason.
func (core *Core) CloseWebSocket(session WebSocketID, code uint32, reason string) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.closeWebSocket(session, code, reason)
}

// SubmitOutbound copies and admits one Core-owned HTTP client call.
func (core *Core) SubmitOutbound(request ClientRequest) (OutboundID, error) {
	native, done, err := core.acquire()
	if err != nil {
		return OutboundID{}, err
	}
	defer done()
	return native.submitOutbound(request)
}

// CancelOutbound requests cancellation of one outbound call.
func (core *Core) CancelOutbound(call OutboundID) error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.cancelOutbound(call)
}

// TakeOutbound waits for and copies one outbound terminal, releasing the
// native terminal lease exactly once before returning.
func (core *Core) TakeOutbound(timeout time.Duration) (*ClientTerminal, error) {
	value, err := nativeDuration(timeout)
	if err != nil {
		return nil, err
	}
	core.outboundReader.Lock()
	defer core.outboundReader.Unlock()
	native, done, err := core.acquire()
	if err != nil {
		return nil, err
	}
	defer done()
	return native.takeOutbound(value)
}

// Rebind applies a generation-checked handler-binding update.
func (core *Core) Rebind(request RebindRequest, timeout time.Duration) (RebindOutcome, error) {
	value, err := nativeDuration(timeout)
	if err != nil {
		return RebindOutcome{}, err
	}
	native, done, err := core.acquire()
	if err != nil {
		return RebindOutcome{}, err
	}
	defer done()
	return native.rebind(request, value)
}

// Health returns a non-blocking copied health snapshot.
func (core *Core) Health() (Health, error) {
	native, done, err := core.acquire()
	if err != nil {
		return Health{}, err
	}
	defer done()
	return native.health()
}

// ProbeLiveness requests and waits for fresh Core progress evidence.
func (core *Core) ProbeLiveness(timeout time.Duration) (Health, error) {
	value, err := nativeDuration(timeout)
	if err != nil {
		return Health{}, err
	}
	native, done, err := core.acquire()
	if err != nil {
		return Health{}, err
	}
	defer done()
	return native.probeLiveness(value)
}

// MonitorConfig returns the copied effective monitoring configuration.
func (core *Core) MonitorConfig() (MonitorConfig, error) {
	native, done, err := core.acquire()
	if err != nil {
		return MonitorConfig{}, err
	}
	defer done()
	return native.monitorConfig()
}

// MonitorSnapshot returns copied bounded aggregates and co-observed health.
func (core *Core) MonitorSnapshot() (MonitorSnapshot, error) {
	native, done, err := core.acquire()
	if err != nil {
		return MonitorSnapshot{}, err
	}
	defer done()
	return native.monitorSnapshot()
}

// ApplyMonitorPolicy performs an optimistic live monitor policy update.
func (core *Core) ApplyMonitorPolicy(expectedGeneration uint64, policy MonitorPolicy) (MonitorApplyOutcome, error) {
	native, done, err := core.acquire()
	if err != nil {
		return MonitorApplyOutcome{}, err
	}
	defer done()
	return native.monitorApply(expectedGeneration, policy)
}

// ReadMonitorEvents reads one bounded cursor page of copied monitor events.
func (core *Core) ReadMonitorEvents(afterSequence uint64, maximumEvents uint32) (MonitorEventPage, error) {
	native, done, err := core.acquire()
	if err != nil {
		return MonitorEventPage{}, err
	}
	defer done()
	return native.monitorRead(afterSequence, maximumEvents)
}

// WaitMonitor waits until newer monitoring truth may be available.
func (core *Core) WaitMonitor(timeout time.Duration) error {
	value, err := nativeDuration(timeout)
	if err != nil {
		return err
	}
	core.monitorWaiter.Lock()
	defer core.monitorWaiter.Unlock()
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.monitorWait(value)
}

// InterruptMonitor wakes the sole monitor waiter without fabricating data.
func (core *Core) InterruptMonitor() error {
	native, done, err := core.acquire()
	if err != nil {
		return err
	}
	defer done()
	return native.monitorInterrupt()
}
