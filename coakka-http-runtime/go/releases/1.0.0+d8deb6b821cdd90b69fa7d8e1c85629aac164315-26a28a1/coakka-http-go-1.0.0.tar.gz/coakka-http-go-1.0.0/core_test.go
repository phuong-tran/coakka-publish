package coakkahttp_test

import (
	"bytes"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	coakkahttp "github.com/phuong-tran/coakka-http-runtime-go"
)

func TestAdvancedConfigurationSectionsReachCore(t *testing.T) {
	root := t.TempDir()
	staticRoot := filepath.Join(root, "static")
	if err := os.Mkdir(staticRoot, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(staticRoot, "index.html"), []byte("index"), 0o600); err != nil {
		t.Fatal(err)
	}
	bearerFile := filepath.Join(root, "inspect.token")
	if err := os.WriteFile(bearerFile, []byte("0123456789abcdef0123456789abcdef"), 0o600); err != nil {
		t.Fatal(err)
	}
	features, err := coakkahttp.Features()
	if err != nil {
		t.Fatal(err)
	}
	config := coakkahttp.Config{
		Listeners: []coakkahttp.Listener{{ID: 1, BindAddress: "127.0.0.1"}},
		Routes: []coakkahttp.Route{{
			ID: 1, HandlerBindingID: 1, Method: "GET", Pattern: "/api",
			BodyPolicy: coakkahttp.BodyPolicy{Enabled: true, AcceptAbsent: true, MaxBodyBytes: 1024},
		}},
		IOBackend:  coakkahttp.IOPlatformDefault,
		WaitPolicy: &coakkahttp.WaitPolicy{Mode: coakkahttp.WaitBlocking},
		Monitor:    &coakkahttp.MonitorOptions{Collection: coakkahttp.MonitorDisabled},
		Inspection: &coakkahttp.InspectionOptions{
			AllowPlaintextLoopback: true,
			RuntimeInstanceID:      77,
			RuntimeGeneration:      9,
			BearerFile:             bearerFile,
			MaxBearerTokenBytes:    256,
			CallCapacity:           1,
			MaxEntriesPerTurn:      16,
			SnapshotDeadlineMillis: 1000,
			MaxBytesPerTurn:        8192,
			MaxResponseBytes:       256 << 10,
			MaxTotalResponseBytes:  256 << 10,
		},
	}
	if features.Has(coakkahttp.CapabilityStaticFiles) {
		config.StaticMounts = []coakkahttp.StaticMount{{
			ID: 2, URLPrefix: "/assets", RootPath: staticRoot,
			IndexFile: "index.html", HasIndexFile: true,
			SPAFallbackFile: "index.html", HasSPAFallbackFile: true,
		}}
	}
	if features.Has(coakkahttp.CapabilityApplicationFiles) {
		config.FileAuthorities = []coakkahttp.FileAuthority{{
			ID: 3, RootPath: staticRoot, MaxActiveFiles: 4, MaxFileBytes: 4096,
		}}
	}
	if features.Has(coakkahttp.CapabilityGZIP) {
		config.Compression = &coakkahttp.Compression{Mode: coakkahttp.CompressionGZIP}
	}
	if features.Has(coakkahttp.CapabilityOutbound) {
		config.Outbound = &coakkahttp.OutboundOptions{}
		config.OutboundTargets = []coakkahttp.OutboundTarget{{
			Name: "local", Generation: 1,
			Endpoints: []coakkahttp.OutboundEndpoint{{
				NodeID: "node-1", ConnectHost: "127.0.0.1", ConnectPort: 9,
				HTTPAuthority: "local.invalid", Security: coakkahttp.SecurityPlaintext,
			}},
		}}
	}
	core, err := coakkahttp.Open(config)
	if err != nil {
		t.Fatal(err)
	}
	if err = core.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestCallbackFreeCorePullAndAutomaticLeaseRelease(t *testing.T) {
	features, err := coakkahttp.Features()
	if err != nil {
		t.Fatal(err)
	}
	core, err := coakkahttp.Open(coakkahttp.Config{
		Monitor: &coakkahttp.MonitorOptions{
			Collection:          coakkahttp.MonitorAggregatesAndEvents,
			EventCapacity:       8,
			MaxEventsPerRead:    8,
			AggregateCategories: coakkahttp.MonitorCategoryLifecycle | coakkahttp.MonitorCategoryExchange,
			EventCategories:     coakkahttp.MonitorCategoryLifecycle | coakkahttp.MonitorCategoryExchange,
		},
		Listeners: []coakkahttp.Listener{{
			ID:          7,
			Protocol:    coakkahttp.ProtocolHTTP11,
			BindAddress: "127.0.0.1",
			Security:    coakkahttp.SecurityPlaintext,
		}},
		Routes: []coakkahttp.Route{{
			ID:               41,
			HandlerBindingID: 101,
			Method:           http.MethodPost,
			Pattern:          "/items/{item_id}",
			BodyDelivery:     coakkahttp.BodyInline,
			BodyPolicy: coakkahttp.BodyPolicy{
				Enabled:      true,
				AcceptOther:  true,
				MaxBodyBytes: 1024,
			},
		}},
	})
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if closeErr := core.Close(); closeErr != nil {
			t.Error(closeErr)
		}
	}()
	required := coakkahttp.CapabilityInbound |
		coakkahttp.CapabilityRequestStream |
		coakkahttp.CapabilityResponseStream |
		coakkahttp.CapabilityResponseTrailers |
		coakkahttp.CapabilityResponseWriteTimeout |
		coakkahttp.CapabilityServerSentEvents |
		coakkahttp.CapabilityWebSocket |
		coakkahttp.CapabilityRouteRebind |
		coakkahttp.CapabilityHealth |
		coakkahttp.CapabilityMonitor
	if !core.Capabilities().Has(required) {
		t.Fatalf("Core feature matrix 0x%x lacks required baseline 0x%x", core.Capabilities(), required)
	}
	if features != core.Capabilities() {
		t.Fatalf("standalone and instance feature matrices differ: 0x%x != 0x%x", features, core.Capabilities())
	}
	if err = core.Start(); err != nil {
		t.Fatal(err)
	}
	port, err := core.BoundPort()
	if err != nil {
		t.Fatal(err)
	}
	type result struct {
		status int
		body   string
		err    error
	}
	completed := make(chan result, 1)
	go func() {
		request, requestErr := http.NewRequest(http.MethodPost, fmt.Sprintf("http://127.0.0.1:%d/items/a%%2Fb?mode=fast&flag", port), bytes.NewBufferString("request-body"))
		if requestErr != nil {
			completed <- result{err: requestErr}
			return
		}
		request.Header.Set("content-type", "text/plain")
		response, requestErr := http.DefaultClient.Do(request)
		if requestErr != nil {
			completed <- result{err: requestErr}
			return
		}
		body, readErr := io.ReadAll(response.Body)
		_ = response.Body.Close()
		completed <- result{status: response.StatusCode, body: string(body), err: readErr}
	}()
	event, err := core.TakeEvent(5 * time.Second)
	if err != nil {
		t.Fatal(err)
	}
	if event.Kind != coakkahttp.EventRequest || event.Request == nil {
		t.Fatalf("unexpected event: %#v", event)
	}
	request := event.Request
	if event.HandlerBindingID != 101 || request.HandlerBindingID != 101 || request.RouteID != 41 || request.Text() != "request-body" {
		t.Fatalf("request projection differs: event=%#v request=%#v", event, request)
	}
	if len(request.PathParameters) != 1 || request.PathParameters[0].EncodedValue != "a%2Fb" {
		t.Fatalf("path captures differ: %#v", request.PathParameters)
	}
	if len(request.QueryParameters) != 2 || request.QueryParameters[1].HasValue {
		t.Fatalf("query projection differs: %#v", request.QueryParameters)
	}
	cancelled, err := core.ExchangeCancelled(event.Exchange)
	if err != nil || cancelled {
		t.Fatalf("cancellation differs: cancelled=%v err=%v", cancelled, err)
	}
	reply, err := coakkahttp.Text(201, "core-runtime-ready")
	if err != nil {
		t.Fatal(err)
	}
	if err = core.Respond(event.Exchange, reply); err != nil {
		t.Fatal(err)
	}
	clientResult := <-completed
	if clientResult.err != nil || clientResult.status != 201 || clientResult.body != "core-runtime-ready" {
		t.Fatalf("response differs: %#v", clientResult)
	}
	terminal, err := core.TakeEvent(5 * time.Second)
	if err != nil {
		t.Fatal(err)
	}
	if terminal.Kind != coakkahttp.EventTerminal || terminal.Terminal == nil || terminal.Terminal.Outcome != coakkahttp.ExchangeCompleted {
		t.Fatalf("terminal differs: %#v", terminal)
	}
	health, err := core.Health()
	if err != nil {
		t.Fatal(err)
	}
	if health.ServerActiveExchanges != 0 || health.ClientOutstandingTerminalLeases != 0 {
		t.Fatalf("automatic release left native leases: %#v", health)
	}
	if _, err = core.ProbeLiveness(2 * time.Second); err != nil {
		t.Fatal(err)
	}
	monitorConfig, err := core.MonitorConfig()
	if err != nil {
		t.Fatal(err)
	}
	if monitorConfig.Policy.Collection != coakkahttp.MonitorAggregatesAndEvents || monitorConfig.Policy.ActiveEventCapacity != 8 {
		t.Fatalf("monitor configuration differs: %#v", monitorConfig)
	}
	monitorSnapshot, err := core.MonitorSnapshot()
	if err != nil {
		t.Fatal(err)
	}
	if !monitorSnapshot.Collecting || monitorSnapshot.InboundAdmittedRequests == 0 {
		t.Fatalf("monitor snapshot lacks request evidence: %#v", monitorSnapshot)
	}
	page, err := core.ReadMonitorEvents(0, 8)
	if err != nil {
		t.Fatal(err)
	}
	if len(page.Events) == 0 {
		t.Fatal("monitor event page is empty")
	}
	apply, err := core.ApplyMonitorPolicy(monitorConfig.Generation, monitorConfig.Policy)
	if err != nil || apply.Reason != coakkahttp.MonitorApplyApplied {
		t.Fatalf("monitor apply differs: outcome=%#v err=%v", apply, err)
	}
}

func TestNativeTimeoutsStayBounded(t *testing.T) {
	core, err := coakkahttp.Open(coakkahttp.Config{})
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = core.Close() }()
	if _, err = core.TakeEvent(time.Hour); err == nil {
		t.Fatal("unbounded event wait was accepted")
	}
	if _, err = core.TakeWebSocket(time.Hour); err == nil {
		t.Fatal("unbounded WebSocket wait was accepted")
	}
	if _, err = core.TakeOutbound(time.Hour); err == nil {
		t.Fatal("unbounded outbound wait was accepted")
	}
	if err = core.WaitMonitor(time.Hour); err == nil {
		t.Fatal("unbounded monitor wait was accepted")
	}
}

func TestConcurrentLifecycleCallsConverge(t *testing.T) {
	core, err := coakkahttp.Open(coakkahttp.Config{
		Listeners: []coakkahttp.Listener{{ID: 1, BindAddress: "127.0.0.1"}},
	})
	if err != nil {
		t.Fatal(err)
	}
	if err = core.Start(); err != nil {
		t.Fatal(err)
	}

	var wait sync.WaitGroup
	errors := make(chan error, 16)
	for index := 0; index < 16; index++ {
		wait.Add(1)
		go func() {
			defer wait.Done()
			errors <- core.Stop()
		}()
	}
	wait.Wait()
	close(errors)
	for stopErr := range errors {
		if stopErr != nil {
			t.Errorf("concurrent Stop failed: %v", stopErr)
		}
	}

	errors = make(chan error, 16)
	for index := 0; index < 16; index++ {
		wait.Add(1)
		go func() {
			defer wait.Done()
			errors <- core.Close()
		}()
	}
	wait.Wait()
	close(errors)
	for closeErr := range errors {
		if closeErr != nil {
			t.Errorf("concurrent Close failed: %v", closeErr)
		}
	}
}

func TestResponseStreamAndTrailers(t *testing.T) {
	core, err := coakkahttp.Open(coakkahttp.Config{
		Listeners: []coakkahttp.Listener{{ID: 1, BindAddress: "127.0.0.1"}},
		Routes: []coakkahttp.Route{{
			ID: 1, HandlerBindingID: 1, Method: http.MethodGet, Pattern: "/stream",
			BodyPolicy: coakkahttp.BodyPolicy{Enabled: true, AcceptAbsent: true, MaxBodyBytes: 1},
		}},
	})
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = core.Close() }()
	if err = core.Start(); err != nil {
		t.Fatal(err)
	}
	port, err := core.BoundPort()
	if err != nil {
		t.Fatal(err)
	}
	type clientResult struct {
		status  int
		body    string
		trailer string
		err     error
	}
	completed := make(chan clientResult, 1)
	go func() {
		response, requestErr := http.Get(fmt.Sprintf("http://127.0.0.1:%d/stream", port))
		if requestErr != nil {
			completed <- clientResult{err: requestErr}
			return
		}
		body, readErr := io.ReadAll(response.Body)
		_ = response.Body.Close()
		completed <- clientResult{status: response.StatusCode, body: string(body), trailer: response.Trailer.Get("x-stream-end"), err: readErr}
	}()
	requestEvent, err := core.TakeEvent(5 * time.Second)
	if err != nil {
		t.Fatal(err)
	}
	if requestEvent.Kind != coakkahttp.EventRequest {
		t.Fatalf("unexpected first event: %#v", requestEvent)
	}
	contentType, _ := coakkahttp.NewHeader("content-type", "text/plain")
	headers, _ := coakkahttp.NewHeaders(contentType)
	head, _ := coakkahttp.NewResponse(200, headers, nil)
	if err = core.StartResponseStream(requestEvent.Exchange, head); err != nil {
		t.Fatal(err)
	}
	writable, err := core.TakeEvent(5 * time.Second)
	if err != nil {
		t.Fatal(err)
	}
	if writable.Kind != coakkahttp.EventResponseWritable || writable.Exchange != requestEvent.Exchange {
		t.Fatalf("unexpected initial stream credit: %#v", writable)
	}
	if err = core.WriteResponseStream(requestEvent.Exchange, []byte("stream-body")); err != nil {
		t.Fatal(err)
	}
	trailer, _ := coakkahttp.NewHeader("x-stream-end", "done")
	trailers, _ := coakkahttp.NewHeaders(trailer)
	if err = core.FinishResponseStream(requestEvent.Exchange, trailers); err != nil {
		t.Fatal(err)
	}
	result := <-completed
	if result.err != nil || result.status != 200 || result.body != "stream-body" || result.trailer != "done" {
		t.Fatalf("stream response differs: %#v", result)
	}
	for attempts := 0; attempts < 4; attempts++ {
		event, takeErr := core.TakeEvent(5 * time.Second)
		if takeErr != nil {
			t.Fatal(takeErr)
		}
		if event.Kind == coakkahttp.EventTerminal {
			if event.Terminal == nil || event.Terminal.Outcome != coakkahttp.ExchangeCompleted {
				t.Fatalf("stream terminal differs: %#v", event)
			}
			return
		}
	}
	t.Fatal("stream terminal was not observed")
}
