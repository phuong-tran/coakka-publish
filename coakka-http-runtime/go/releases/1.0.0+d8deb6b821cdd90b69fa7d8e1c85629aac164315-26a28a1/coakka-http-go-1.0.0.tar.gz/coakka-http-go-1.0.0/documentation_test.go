package coakkahttp

import (
	"go/ast"
	"go/parser"
	"go/token"
	"io/fs"
	"strings"
	"testing"
)

// TestPublicDeclarationsHaveGoDoc prevents undocumented exported types and
// functions from entering a release candidate.
func TestPublicDeclarationsHaveGoDoc(t *testing.T) {
	fileSet := token.NewFileSet()
	files, err := parser.ParseDir(fileSet, ".", func(info fs.FileInfo) bool {
		return !strings.HasSuffix(info.Name(), "_test.go")
	}, parser.ParseComments)
	if err != nil {
		t.Fatal(err)
	}
	for _, file := range files["coakkahttp"].Files {
		for _, declaration := range file.Decls {
			switch value := declaration.(type) {
			case *ast.FuncDecl:
				if ast.IsExported(value.Name.Name) && value.Doc == nil {
					t.Errorf("%s lacks GoDoc", value.Name.Name)
				}
			case *ast.GenDecl:
				for _, specification := range value.Specs {
					switch spec := specification.(type) {
					case *ast.TypeSpec:
						if ast.IsExported(spec.Name.Name) && value.Doc == nil && spec.Doc == nil {
							t.Errorf("%s lacks GoDoc", spec.Name.Name)
						}
					case *ast.ValueSpec:
						for _, name := range spec.Names {
							if ast.IsExported(name.Name) && value.Doc == nil && spec.Doc == nil && spec.Comment == nil {
								t.Errorf("%s lacks GoDoc", name.Name)
							}
						}
					}
				}
			}
		}
		ast.Inspect(file, func(node ast.Node) bool {
			field, ok := node.(*ast.Field)
			if !ok || len(field.Names) == 0 {
				return true
			}
			for _, name := range field.Names {
				if name.IsExported() && field.Doc == nil {
					position := fileSet.Position(field.Pos())
					t.Errorf("%s:%d: exported field %s lacks GoDoc", position.Filename, position.Line, name.Name)
				}
			}
			return true
		})
	}
}
