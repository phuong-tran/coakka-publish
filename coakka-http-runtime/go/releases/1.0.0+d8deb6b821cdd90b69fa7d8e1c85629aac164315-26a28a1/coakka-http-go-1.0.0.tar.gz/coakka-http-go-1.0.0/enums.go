package coakkahttp

// Capabilities is the ABI2 feature-bit set implemented by the loaded Core.
type Capabilities uint64

const (
	// CapabilityInbound enables Core-owned inbound HTTP listeners.
	CapabilityInbound Capabilities = 1 << iota
	// CapabilityTLS enables server and client TLS.
	CapabilityTLS
	// CapabilityMutualTLS enables mutually authenticated TLS.
	CapabilityMutualTLS
	// CapabilityGZIP enables bounded gzip response compression.
	CapabilityGZIP
	// CapabilityRequestStream enables pulled request body chunks and trailers.
	CapabilityRequestStream
	// CapabilityResponseStream enables incremental response writes.
	CapabilityResponseStream
	// CapabilityResponseTrailers enables response-stream trailers.
	CapabilityResponseTrailers
	// CapabilityResponseWriteTimeout enables bounded response backpressure waits.
	CapabilityResponseWriteTimeout
	// CapabilityServerSentEvents enables typed SSE response writes.
	CapabilityServerSentEvents
	// CapabilityWebSocket enables Core-owned WebSocket sessions.
	CapabilityWebSocket
	// CapabilityHTTP2 enables HTTP/2 listeners or outbound policy.
	CapabilityHTTP2
	// CapabilityHTTP3 enables HTTP/3 listeners or outbound policy.
	CapabilityHTTP3
	// CapabilityStaticFiles enables Core-owned static file mounts.
	CapabilityStaticFiles
	// CapabilityApplicationFiles enables authority-scoped application file responses.
	CapabilityApplicationFiles
	// CapabilityOutbound enables the Core-owned HTTP client.
	CapabilityOutbound
	// CapabilityRouteRebind enables generation-checked handler rebinding.
	CapabilityRouteRebind
	// CapabilityOutboundLogicalTarget enables named outbound target topology.
	CapabilityOutboundLogicalTarget
	// CapabilityStaticFrontend enables index and SPA fallback behavior.
	CapabilityStaticFrontend
	// CapabilityHealth enables health snapshots and active liveness probes.
	CapabilityHealth
	// CapabilityMonitor enables bounded aggregate and event monitoring.
	CapabilityMonitor
)

// Has reports whether every requested feature bit is present.
func (capabilities Capabilities) Has(requested Capabilities) bool {
	return capabilities&requested == requested
}

// ListenerProtocol selects the inbound protocol owned by Core.
type ListenerProtocol uint32

const (
	// ProtocolHTTP11 selects HTTP/1.1.
	ProtocolHTTP11 ListenerProtocol = 1
	// ProtocolHTTP2 selects HTTP/2.
	ProtocolHTTP2 ListenerProtocol = 2
	// ProtocolHTTP3 selects HTTP/3.
	ProtocolHTTP3 ListenerProtocol = 3
)

// TransportSecurity selects plaintext, TLS, or mutual TLS.
type TransportSecurity uint32

const (
	// SecurityPlaintext disables transport encryption.
	SecurityPlaintext TransportSecurity = 1
	// SecurityTLS enables server-authenticated TLS.
	SecurityTLS TransportSecurity = 2
	// SecurityMutualTLS enables client and server authentication.
	SecurityMutualTLS TransportSecurity = 3
)

// BodyDelivery selects inline or pulled request-body delivery.
type BodyDelivery uint32

const (
	// BodyInline places the bounded request body on the request event.
	BodyInline BodyDelivery = 1
	// BodyStream emits request data, trailer, and end events.
	BodyStream BodyDelivery = 2
)

// CompressionMode selects response compression behavior.
type CompressionMode uint32

const (
	// CompressionDisabled disables response compression.
	CompressionDisabled CompressionMode = 1
	// CompressionGZIP enables bounded gzip compression.
	CompressionGZIP CompressionMode = 2
)

// IOBackend selects the native event I/O backend.
type IOBackend uint32

const (
	// IOPlatformDefault selects the platform's production backend.
	IOPlatformDefault IOBackend = 1
	// IOUring requests io_uring where supported.
	IOUring IOBackend = 2
)

// WaitMode selects how a Core worker waits when idle.
type WaitMode uint32

const (
	// WaitBlocking uses blocking waits.
	WaitBlocking WaitMode = 1
	// WaitAdaptive spins, yields, and then blocks.
	WaitAdaptive WaitMode = 2
	// WaitBusyPoll continuously polls within the configured policy.
	WaitBusyPoll WaitMode = 3
)

// OutboundStrategy selects endpoint ownership and balancing.
type OutboundStrategy uint32

const (
	// OutboundSingleOwner selects one endpoint owner.
	OutboundSingleOwner OutboundStrategy = 1
	// OutboundWeightedRoundRobin balances by endpoint weight.
	OutboundWeightedRoundRobin OutboundStrategy = 2
)

// MonitorCollection selects disabled, aggregate, or aggregate-plus-event collection.
type MonitorCollection uint32

const (
	// MonitorDisabled disables monitoring collection.
	MonitorDisabled MonitorCollection = 0
	// MonitorAggregates collects bounded counters and histograms.
	MonitorAggregates MonitorCollection = 1
	// MonitorAggregatesAndEvents also retains bounded operational events.
	MonitorAggregatesAndEvents MonitorCollection = 2
)

// EventKind identifies an event pulled from the inbound Core lane.
type EventKind uint32

const (
	// EventRequest begins an admitted exchange.
	EventRequest EventKind = 1
	// EventRequestData carries one streamed request chunk.
	EventRequestData EventKind = 2
	// EventRequestTrailers carries request trailers.
	EventRequestTrailers EventKind = 3
	// EventRequestEnd marks the end of a streamed request.
	EventRequestEnd EventKind = 4
	// EventRequestCancelled reports request cancellation.
	EventRequestCancelled EventKind = 5
	// EventResponseWritable reports released response-stream capacity.
	EventResponseWritable EventKind = 6
	// EventTerminal carries the final exchange summary.
	EventTerminal EventKind = 7
)

// ExchangeOutcome is the terminal state of an inbound exchange.
type ExchangeOutcome uint32

const (
	// ExchangeCompleted reports successful terminal completion.
	ExchangeCompleted ExchangeOutcome = 1
	// ExchangeTimedOut reports a monotonic deadline expiry.
	ExchangeTimedOut ExchangeOutcome = 2
	// ExchangeDisconnected reports peer disconnection.
	ExchangeDisconnected ExchangeOutcome = 3
	// ExchangeCancelled reports explicit cancellation.
	ExchangeCancelled ExchangeOutcome = 4
	// ExchangeFailed reports a typed failure.
	ExchangeFailed ExchangeOutcome = 5
	// ExchangeStopped reports runtime shutdown.
	ExchangeStopped ExchangeOutcome = 6
)

// SocketEventKind identifies a pulled or sent WebSocket event.
type SocketEventKind uint32

const (
	// WebSocketOpen reports an accepted session.
	WebSocketOpen SocketEventKind = 1
	// WebSocketText carries UTF-8 application data.
	WebSocketText SocketEventKind = 2
	// WebSocketBinary carries binary application data.
	WebSocketBinary SocketEventKind = 3
	// WebSocketPing carries a peer ping.
	WebSocketPing SocketEventKind = 4
	// WebSocketPong carries a peer pong.
	WebSocketPong SocketEventKind = 5
	// WebSocketWritable reports released outbound capacity.
	WebSocketWritable SocketEventKind = 6
	// WebSocketClose reports terminal session closure.
	WebSocketClose SocketEventKind = 7
	// WebSocketAcceptFailed reports failed protocol upgrade.
	WebSocketAcceptFailed SocketEventKind = 8
)

// MonitorNotification selects polling or a reserved signal notification.
type MonitorNotification uint32

const (
	// MonitorNotifyPoll requires polling or MonitorWait.
	MonitorNotifyPoll MonitorNotification = 0
	// MonitorNotifySignal requests the pre-reserved signal path.
	MonitorNotifySignal MonitorNotification = 1
)

// MonitorLatency selects latency collection.
type MonitorLatency uint32

const (
	// MonitorLatencyNone disables latency buckets.
	MonitorLatencyNone MonitorLatency = 0
	// MonitorLatencyFixed enables Core's fixed bounded buckets.
	MonitorLatencyFixed MonitorLatency = 1
)

// MonitorDetail selects whether runtime-safe event detail is retained.
type MonitorDetail uint32

const (
	// MonitorDetailNone omits event detail.
	MonitorDetailNone MonitorDetail = 0
	// MonitorDetailRuntimeSafe retains bounded non-payload detail.
	MonitorDetailRuntimeSafe MonitorDetail = 1
)

// MonitorApplyReason explains an accepted or rejected live monitor policy.
type MonitorApplyReason uint32

const (
	// MonitorApplyApplied reports successful application.
	MonitorApplyApplied MonitorApplyReason = 0
	// MonitorApplyInvalidArgument reports malformed input.
	MonitorApplyInvalidArgument MonitorApplyReason = 1
	// MonitorApplyInvalidEnum reports an unknown enum value.
	MonitorApplyInvalidEnum MonitorApplyReason = 2
	// MonitorApplyUnsupportedCategory reports a category unavailable in this Core.
	MonitorApplyUnsupportedCategory MonitorApplyReason = 3
	// MonitorApplyInvalidCategoryRelationship reports inconsistent category sets.
	MonitorApplyInvalidCategoryRelationship MonitorApplyReason = 4
	// MonitorApplyResourceReservationExceeded reports a construction-time bound.
	MonitorApplyResourceReservationExceeded MonitorApplyReason = 5
	// MonitorApplySignalNotReserved reports an unreserved signal request.
	MonitorApplySignalNotReserved MonitorApplyReason = 6
	// MonitorApplyGenerationConflict reports optimistic-concurrency failure.
	MonitorApplyGenerationConflict MonitorApplyReason = 7
	// MonitorApplyInvalidLifecycle reports a disallowed lifecycle state.
	MonitorApplyInvalidLifecycle MonitorApplyReason = 8
	// MonitorApplySequenceExhausted reports sequence-space exhaustion.
	MonitorApplySequenceExhausted MonitorApplyReason = 9
	// MonitorApplyInternal reports an internal policy failure.
	MonitorApplyInternal MonitorApplyReason = 10
)

// MonitorEventKind identifies a retained operational monitor event.
type MonitorEventKind uint32

const (
	// MonitorEventLifecycleChanged reports a lifecycle transition.
	MonitorEventLifecycleChanged MonitorEventKind = 1
	// MonitorEventPolicyApplied reports a live policy update.
	MonitorEventPolicyApplied MonitorEventKind = 2
	// MonitorEventPolicyRejected reports a rejected live policy.
	MonitorEventPolicyRejected MonitorEventKind = 3
	// MonitorEventExchangeCompleted reports successful exchange completion.
	MonitorEventExchangeCompleted MonitorEventKind = 4
	// MonitorEventExchangeFailed reports exchange failure.
	MonitorEventExchangeFailed MonitorEventKind = 5
	// MonitorEventExchangeTimedOut reports exchange timeout.
	MonitorEventExchangeTimedOut MonitorEventKind = 6
	// MonitorEventExchangeDisconnected reports peer disconnection.
	MonitorEventExchangeDisconnected MonitorEventKind = 7
	// MonitorEventExchangeCancelled reports exchange cancellation.
	MonitorEventExchangeCancelled MonitorEventKind = 8
)

const (
	// MonitorCategoryLifecycle selects lifecycle measurements.
	MonitorCategoryLifecycle uint64 = 1 << iota
	// MonitorCategoryConfig selects configuration measurements.
	MonitorCategoryConfig
	// MonitorCategoryConnection selects connection measurements.
	MonitorCategoryConnection
	// MonitorCategoryTraffic selects byte and request measurements.
	MonitorCategoryTraffic
	// MonitorCategoryHTTP selects HTTP protocol measurements.
	MonitorCategoryHTTP
	// MonitorCategoryExchange selects exchange measurements.
	MonitorCategoryExchange
	// MonitorCategoryQueue selects queue measurements.
	MonitorCategoryQueue
	// MonitorCategoryFailure selects failure measurements.
	MonitorCategoryFailure
	// MonitorCategoryTLS selects TLS measurements.
	MonitorCategoryTLS
	// MonitorCategoryConnector selects connector measurements.
	MonitorCategoryConnector
	// MonitorCategoryResponse selects response measurements.
	MonitorCategoryResponse
	// MonitorCategoryLatency selects latency measurements.
	MonitorCategoryLatency
)
