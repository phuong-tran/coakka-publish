package coakkahttp

import "fmt"

// ResultCode is the stable numeric result reported by Core ABI2.
type ResultCode uint32

const (
	// ResultOK reports successful completion.
	ResultOK ResultCode = 0
	// ResultInvalidArgument reports a malformed caller value.
	ResultInvalidArgument ResultCode = 1
	// ResultInvalidState reports an operation that is invalid for the lifecycle state.
	ResultInvalidState ResultCode = 2
	// ResultLimitExceeded reports a configured resource bound was exceeded.
	ResultLimitExceeded ResultCode = 3
	// ResultQueueFull reports bounded queue pressure.
	ResultQueueFull ResultCode = 4
	// ResultTimeout reports expiry of a monotonic timeout.
	ResultTimeout ResultCode = 5
	// ResultClosed reports an already closed owner or lane.
	ResultClosed ResultCode = 6
	// ResultCancelled reports explicit or peer cancellation.
	ResultCancelled ResultCode = 7
	// ResultOutOfMemory reports allocation refusal.
	ResultOutOfMemory ResultCode = 8
	// ResultUnsupported reports a missing ABI or unavailable capability.
	ResultUnsupported ResultCode = 9
	// ResultSystemError reports an operating-system failure.
	ResultSystemError ResultCode = 10
	// ResultInternal reports an invariant failure inside Core.
	ResultInternal ResultCode = 11
	// ResultNotFound reports an unknown stable identifier.
	ResultNotFound ResultCode = 12
	// ResultUnavailable reports a temporarily unavailable runtime component.
	ResultUnavailable ResultCode = 13
)

// Error is a copied Core failure. Actual and Limit describe a rejected bound
// when Core supplied that information.
type Error struct {
	// Code is the stable machine-readable result.
	Code ResultCode
	// Actual is the observed size or count for a bound failure.
	Actual uint64
	// Limit is the configured ceiling for a bound failure.
	Limit uint64
	// Detail is a bounded diagnostic safe after the native call returns.
	Detail string
}

// Error returns the bounded Core diagnostic and stable result code.
func (err *Error) Error() string {
	if err == nil {
		return ""
	}
	if err.Detail != "" {
		if err.Actual != 0 || err.Limit != 0 {
			return fmt.Sprintf("%s (actual=%d limit=%d)", err.Detail, err.Actual, err.Limit)
		}
		return err.Detail
	}
	return fmt.Sprintf("CoAkka HTTP operation failed with code %d", err.Code)
}

// Is reports whether target is a Core error with the same result code.
func (err *Error) Is(target error) bool {
	other, ok := target.(*Error)
	return ok && err != nil && err.Code == other.Code
}
