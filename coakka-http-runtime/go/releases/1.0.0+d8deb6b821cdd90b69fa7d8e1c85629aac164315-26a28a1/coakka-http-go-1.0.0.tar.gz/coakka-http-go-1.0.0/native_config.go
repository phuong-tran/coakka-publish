package coakkahttp

/*
#include "bridge.h"
#include <stdlib.h>
*/
import "C"

import (
	"errors"
	"unsafe"
)

func openNativeCore(config Config) (_ *nativeCore, returned error) {
	api, err := openNativeAPI()
	if err != nil {
		return nil, err
	}
	var configuration *C.coakka_http_configuration_t
	defer func() {
		if configuration != nil {
			returned = errors.Join(returned, resultError(C.coakka_http_go_configuration_destroy(api, &configuration)))
		}
		if returned != nil {
			C.coakka_http_go_close(&api)
		}
	}()
	if err = resultError(C.coakka_http_go_configuration_create(api, &configuration)); err != nil {
		return nil, err
	}
	if configuration == nil {
		return nil, errors.New("native Core returned an empty configuration")
	}
	if config.Limits != nil {
		value := nativeLimits(api, *config.Limits)
		if err = resultError(C.coakka_http_go_configuration_set_limits(api, configuration, &value)); err != nil {
			return nil, err
		}
	}
	for _, listener := range config.Listeners {
		if err = addNativeListener(api, configuration, listener); err != nil {
			return nil, err
		}
	}
	for _, route := range config.Routes {
		if err = addNativeRoute(api, configuration, route); err != nil {
			return nil, err
		}
	}
	for _, mount := range config.StaticMounts {
		if err = addNativeStaticMount(api, configuration, mount); err != nil {
			return nil, err
		}
	}
	for _, authority := range config.FileAuthorities {
		if err = addNativeFileAuthority(api, configuration, authority); err != nil {
			return nil, err
		}
	}
	if config.Compression != nil {
		value := nativeCompression(api, *config.Compression)
		if err = resultError(C.coakka_http_go_configuration_set_compression(api, configuration, &value)); err != nil {
			return nil, err
		}
	}
	if config.IOBackend != 0 {
		if err = resultError(C.coakka_http_go_configuration_set_io_backend(api, configuration, C.coakka_http_io_backend_t(config.IOBackend))); err != nil {
			return nil, err
		}
	}
	if config.WaitPolicy != nil {
		value := nativeWaitPolicy(api, *config.WaitPolicy)
		if err = resultError(C.coakka_http_go_configuration_set_wait_policy(api, configuration, &value)); err != nil {
			return nil, err
		}
	}
	if config.Monitor != nil {
		value := nativeMonitorOptions(api, *config.Monitor)
		if err = resultError(C.coakka_http_go_configuration_set_monitor(api, configuration, &value)); err != nil {
			return nil, err
		}
	}
	if config.Inspection != nil {
		if err = setNativeInspection(api, configuration, *config.Inspection); err != nil {
			return nil, err
		}
	}
	if config.Outbound != nil {
		if err = setNativeOutbound(api, configuration, *config.Outbound); err != nil {
			return nil, err
		}
	} else if config.OutboundEnabled {
		if err = resultError(C.coakka_http_go_configuration_enable_outbound(api, configuration)); err != nil {
			return nil, err
		}
	}
	for _, trust := range config.OutboundTrust {
		arena := nativeArena{}
		pem, projectionErr := arena.bytes(trust.CAPEM)
		if projectionErr == nil {
			projectionErr = resultError(C.coakka_http_go_configuration_add_outbound_trust(api, configuration, C.uint64_t(trust.Generation), pem))
		}
		arena.close()
		if projectionErr != nil {
			return nil, projectionErr
		}
	}
	for _, identity := range config.OutboundIdentities {
		arena := nativeArena{}
		certificate, projectionErr := arena.bytes(identity.CertificateChainPEM)
		var key C.coakka_http_bytes_t
		if projectionErr == nil {
			key, projectionErr = arena.bytes(identity.PrivateKeyPEM)
		}
		if projectionErr == nil {
			projectionErr = resultError(C.coakka_http_go_configuration_add_outbound_identity(api, configuration, C.uint64_t(identity.Generation), certificate, key))
		}
		arena.close()
		if projectionErr != nil {
			return nil, projectionErr
		}
	}
	for _, target := range config.OutboundTargets {
		if err = addNativeOutboundTarget(api, configuration, target); err != nil {
			return nil, err
		}
	}
	var core *C.coakka_http_core_t
	if err = resultError(C.coakka_http_go_core_create(api, configuration, &core)); err != nil {
		return nil, err
	}
	if core == nil {
		return nil, errors.New("native Core returned an empty instance")
	}
	if err = resultError(C.coakka_http_go_configuration_destroy(api, &configuration)); err != nil {
		_ = resultError(C.coakka_http_go_core_destroy(api, &core))
		return nil, err
	}
	return &nativeCore{api: api, core: core, capabilities: Capabilities(C.coakka_http_go_features(api))}, nil
}

func nativeLimits(api *C.coakka_http_go_api_t, source CoreLimits) C.coakka_http_core_limits_t {
	var value C.coakka_http_core_limits_t
	C.coakka_http_go_core_limits_init(api, &value)
	value.event_loop_threads = C.uint32_t(source.EventLoopThreads)
	value.max_listeners = C.uint32_t(source.MaxListeners)
	value.max_connections = C.uint32_t(source.MaxConnections)
	value.max_active_exchanges = C.uint32_t(source.MaxActiveExchanges)
	value.request_queue_depth = C.uint32_t(source.RequestQueueDepth)
	value.completion_queue_depth = C.uint32_t(source.CompletionQueueDepth)
	value.completion_batch_size = C.uint32_t(source.CompletionBatchSize)
	value.max_header_count = C.uint32_t(source.MaxHeaderCount)
	value.max_header_bytes = C.uint32_t(source.MaxHeaderBytes)
	value.max_routes = C.uint32_t(source.MaxRoutes)
	value.max_route_segments = C.uint32_t(source.MaxRouteSegments)
	value.max_captures_per_route = C.uint32_t(source.MaxCapturesPerRoute)
	value.request_stream_chunk_slots = C.uint32_t(source.RequestStreamChunkSlots)
	value.request_stream_max_retained_items = C.uint32_t(source.RequestStreamMaxRetainedItems)
	value.response_stream_chunk_slots = C.uint32_t(source.ResponseStreamChunkSlots)
	value.response_stream_max_retained_items = C.uint32_t(source.ResponseStreamMaxRetainedItems)
	value.max_static_mounts = C.uint32_t(source.MaxStaticMounts)
	value.max_total_static_files = C.uint32_t(source.MaxTotalStaticFiles)
	value.max_file_authorities = C.uint32_t(source.MaxFileAuthorities)
	value.route_rebind_command_capacity = C.uint32_t(source.RouteRebindCommandCapacity)
	value.route_rebind_history_capacity = C.uint32_t(source.RouteRebindHistoryCapacity)
	value.route_rebind_max_commands_per_turn = C.uint32_t(source.RouteRebindMaxCommandsPerTurn)
	value.terminal_observation_queue_depth = C.uint32_t(source.TerminalObservationQueueDepth)
	value.deadline_tick_ms = C.uint32_t(source.DeadlineTickMillis)
	value.connection_timeout_batch_size = C.uint32_t(source.ConnectionTimeoutBatchSize)
	value.max_request_body_bytes = C.uint64_t(source.MaxRequestBodyBytes)
	value.max_response_body_bytes = C.uint64_t(source.MaxResponseBodyBytes)
	value.max_serialized_request_bytes = C.uint64_t(source.MaxSerializedRequestBytes)
	value.max_serialized_response_bytes = C.uint64_t(source.MaxSerializedResponseBytes)
	value.max_total_request_body_bytes = C.uint64_t(source.MaxTotalRequestBodyBytes)
	value.max_total_response_body_bytes = C.uint64_t(source.MaxTotalResponseBodyBytes)
	value.max_total_serialized_request_bytes = C.uint64_t(source.MaxTotalSerializedRequestBytes)
	value.max_total_serialized_response_bytes = C.uint64_t(source.MaxTotalSerializedResponseBytes)
	value.keep_alive_timeout_ms = C.uint64_t(source.KeepAliveTimeoutMillis)
	value.header_timeout_ms = C.uint64_t(source.HeaderTimeoutMillis)
	value.body_timeout_ms = C.uint64_t(source.BodyTimeoutMillis)
	value.app_host_timeout_ms = C.uint64_t(source.AppHostTimeoutMillis)
	value.idle_timeout_ms = C.uint64_t(source.IdleTimeoutMillis)
	value.drain_timeout_ms = C.uint64_t(source.DrainTimeoutMillis)
	value.stop_timeout_ms = C.uint64_t(source.StopTimeoutMillis)
	value.response_write_timeout_ms = C.uint64_t(source.ResponseWriteTimeoutMillis)
	value.request_stream_max_chunk_bytes = C.uint64_t(source.RequestStreamMaxChunkBytes)
	value.request_stream_max_trailer_bytes = C.uint64_t(source.RequestStreamMaxTrailerBytes)
	value.request_stream_max_retained_bytes = C.uint64_t(source.RequestStreamMaxRetainedBytes)
	value.request_stream_max_total_retained_bytes = C.uint64_t(source.RequestStreamMaxTotalRetainedBytes)
	value.response_stream_max_chunk_bytes = C.uint64_t(source.ResponseStreamMaxChunkBytes)
	value.response_stream_max_trailer_bytes = C.uint64_t(source.ResponseStreamMaxTrailerBytes)
	value.response_stream_max_retained_bytes = C.uint64_t(source.ResponseStreamMaxRetainedBytes)
	value.response_stream_max_total_retained_bytes = C.uint64_t(source.ResponseStreamMaxTotalRetainedBytes)
	value.max_route_manifest_bytes = C.uint64_t(source.MaxRouteManifestBytes)
	value.max_total_route_metadata_bytes = C.uint64_t(source.MaxTotalRouteMetadataBytes)
	value.max_serialized_terminal_observation_bytes = C.uint64_t(source.MaxSerializedTerminalObservationBytes)
	value.max_total_serialized_terminal_observation_bytes = C.uint64_t(source.MaxTotalSerializedTerminalObservationBytes)
	return value
}

func addNativeListener(api *C.coakka_http_go_api_t, configuration *C.coakka_http_configuration_t, source Listener) error {
	arena := nativeArena{}
	defer arena.close()
	var value C.coakka_http_listener_t
	C.coakka_http_go_listener_init(api, &value)
	value.listener_id = C.uint64_t(source.ID)
	if source.Protocol != 0 {
		value.protocol = C.coakka_http_listener_protocol_t(source.Protocol)
	}
	value.port = C.uint16_t(source.Port)
	if source.Security != 0 {
		value.security = C.coakka_http_transport_security_t(source.Security)
	}
	value.credential_generation = C.uint64_t(source.CredentialGeneration)
	var err error
	if value.bind_address, err = arena.text(source.BindAddress); err != nil {
		return err
	}
	if value.credential_id, err = arena.text(source.CredentialID); err != nil {
		return err
	}
	if value.certificate_chain_file, err = arena.text(source.CertificateChainFile); err != nil {
		return err
	}
	if value.private_key_file, err = arena.text(source.PrivateKeyFile); err != nil {
		return err
	}
	if value.trust_roots_file, err = arena.text(source.TrustRootsFile); err != nil {
		return err
	}
	return resultError(C.coakka_http_go_configuration_add_listener(api, configuration, &value))
}

func addNativeRoute(api *C.coakka_http_go_api_t, configuration *C.coakka_http_configuration_t, source Route) error {
	arena := nativeArena{}
	defer arena.close()
	var value C.coakka_http_core_route_t
	C.coakka_http_go_core_route_init(api, &value)
	value.route_id = C.uint64_t(source.ID)
	value.request_capture_profile_id = C.uint64_t(source.RequestCaptureProfileID)
	value.handler_binding_id = C.uint64_t(source.HandlerBindingID)
	if source.BodyDelivery != 0 {
		value.body_delivery = C.coakka_http_body_delivery_t(source.BodyDelivery)
	}
	value.body_policy.enabled = boolByte(source.BodyPolicy.Enabled)
	value.body_policy.accept_absent = boolByte(source.BodyPolicy.AcceptAbsent)
	value.body_policy.accept_other = boolByte(source.BodyPolicy.AcceptOther)
	value.body_policy.accept_form_urlencoded = boolByte(source.BodyPolicy.AcceptFormURLEncoded)
	value.body_policy.accept_multipart_form_data = boolByte(source.BodyPolicy.AcceptMultipartFormData)
	value.body_policy.max_body_bytes = C.uint64_t(source.BodyPolicy.MaxBodyBytes)
	var err error
	if value.method, err = arena.text(source.Method); err != nil {
		return err
	}
	if value.path, err = arena.text(source.Pattern); err != nil {
		return err
	}
	return resultError(C.coakka_http_go_configuration_add_route(api, configuration, &value))
}

func addNativeStaticMount(api *C.coakka_http_go_api_t, configuration *C.coakka_http_configuration_t, source StaticMount) error {
	arena := nativeArena{}
	defer arena.close()
	var value C.coakka_http_static_mount_t
	C.coakka_http_go_static_mount_init(api, &value)
	value.mount_id = C.uint64_t(source.ID)
	value.include_dotfiles = boolByte(source.IncludeDotfiles)
	value.has_index_file = boolByte(source.HasIndexFile)
	value.has_cache_control = boolByte(source.HasCacheControl)
	value.has_spa_fallback_file = boolByte(source.HasSPAFallbackFile)
	var err error
	if value.url_prefix, err = arena.text(source.URLPrefix); err != nil {
		return err
	}
	if value.root_path, err = arena.text(source.RootPath); err != nil {
		return err
	}
	if value.index_file, err = arena.text(source.IndexFile); err != nil {
		return err
	}
	if value.cache_control, err = arena.text(source.CacheControl); err != nil {
		return err
	}
	if value.spa_fallback_file, err = arena.text(source.SPAFallbackFile); err != nil {
		return err
	}
	return resultError(C.coakka_http_go_configuration_add_static_mount(api, configuration, &value))
}

func addNativeFileAuthority(api *C.coakka_http_go_api_t, configuration *C.coakka_http_configuration_t, source FileAuthority) error {
	arena := nativeArena{}
	defer arena.close()
	var value C.coakka_http_file_authority_t
	C.coakka_http_go_file_authority_init(api, &value)
	value.authority_id = C.uint64_t(source.ID)
	value.max_active_files = C.uint32_t(source.MaxActiveFiles)
	value.max_file_bytes = C.uint64_t(source.MaxFileBytes)
	var err error
	if value.root_path, err = arena.text(source.RootPath); err != nil {
		return err
	}
	return resultError(C.coakka_http_go_configuration_add_file_authority(api, configuration, &value))
}

func nativeCompression(api *C.coakka_http_go_api_t, source Compression) C.coakka_http_compression_t {
	var value C.coakka_http_compression_t
	C.coakka_http_go_compression_init(api, &value)
	if source.Mode != 0 {
		value.mode = C.coakka_http_compression_mode_t(source.Mode)
	}
	value.minimum_body_bytes = C.uint64_t(source.MinimumBodyBytes)
	value.maximum_body_bytes = C.uint64_t(source.MaximumBodyBytes)
	value.maximum_encoded_bytes = C.uint64_t(source.MaximumEncodedBytes)
	value.workspace_bytes = C.uint64_t(source.WorkspaceBytes)
	value.gzip_level = C.int32_t(source.GZIPLevel)
	return value
}

func nativeWaitPolicy(api *C.coakka_http_go_api_t, source WaitPolicy) C.coakka_http_wait_policy_t {
	var value C.coakka_http_wait_policy_t
	C.coakka_http_go_wait_policy_init(api, &value)
	if source.Mode != 0 {
		value.mode = C.coakka_http_wait_mode_t(source.Mode)
	}
	value.spin_iterations = C.uint32_t(source.SpinIterations)
	value.yield_iterations = C.uint32_t(source.YieldIterations)
	return value
}

func nativeMonitorOptions(api *C.coakka_http_go_api_t, source MonitorOptions) C.coakka_http_monitor_options_t {
	var value C.coakka_http_monitor_options_t
	C.coakka_http_go_monitor_options_init(api, &value)
	value.collection = C.coakka_http_monitor_collection_t(source.Collection)
	value.event_capacity = C.uint32_t(source.EventCapacity)
	value.max_events_per_read = C.uint32_t(source.MaxEventsPerRead)
	value.detail_bytes_per_event = C.uint32_t(source.DetailBytesPerEvent)
	value.latency_bucket_count = C.uint32_t(source.LatencyBucketCount)
	value.aggregate_categories = C.uint64_t(source.AggregateCategories)
	value.event_categories = C.uint64_t(source.EventCategories)
	value.signal_reserved = boolByte(source.SignalReserved)
	value.runtime_safe_detail = boolByte(source.RuntimeSafeDetail)
	value.fixed_latency_buckets = boolByte(source.FixedLatencyBuckets)
	return value
}

func setNativeInspection(api *C.coakka_http_go_api_t, configuration *C.coakka_http_configuration_t, source InspectionOptions) error {
	arena := nativeArena{}
	defer arena.close()
	var value C.coakka_http_inspection_options_t
	C.coakka_http_go_inspection_options_init(api, &value)
	value.allow_plaintext_loopback = boolByte(source.AllowPlaintextLoopback)
	value.runtime_instance_id = C.uint64_t(source.RuntimeInstanceID)
	value.runtime_generation = C.uint64_t(source.RuntimeGeneration)
	value.max_bearer_token_bytes = C.uint32_t(source.MaxBearerTokenBytes)
	value.call_capacity = C.uint32_t(source.CallCapacity)
	value.max_entries_per_turn = C.uint32_t(source.MaxEntriesPerTurn)
	value.snapshot_deadline_ms = C.uint32_t(source.SnapshotDeadlineMillis)
	value.max_bytes_per_turn = C.uint64_t(source.MaxBytesPerTurn)
	value.max_response_bytes = C.uint64_t(source.MaxResponseBytes)
	value.max_total_response_bytes = C.uint64_t(source.MaxTotalResponseBytes)
	var err error
	if value.bearer_file, err = arena.text(source.BearerFile); err != nil {
		return err
	}
	return resultError(C.coakka_http_go_configuration_set_inspection(api, configuration, &value))
}

func setNativeOutbound(api *C.coakka_http_go_api_t, configuration *C.coakka_http_configuration_t, source OutboundOptions) error {
	arena := nativeArena{}
	defer arena.close()
	var value C.coakka_http_outbound_options_t
	C.coakka_http_go_outbound_options_init(api, &value)
	value.resolver_enabled = boolByte(source.ResolverEnabled)
	value.pool_enabled = boolByte(source.PoolEnabled)
	value.lane.call_capacity = C.uint32_t(source.Lane.CallCapacity)
	value.lane.target_profile_capacity = C.uint32_t(source.Lane.TargetProfileCapacity)
	value.lane.work_batch = C.uint32_t(source.Lane.WorkBatch)
	value.lane.max_method_bytes = C.uint32_t(source.Lane.MaxMethodBytes)
	value.lane.max_origin_target_bytes = C.uint32_t(source.Lane.MaxOriginTargetBytes)
	value.lane.max_profile_component_bytes = C.uint32_t(source.Lane.MaxProfileComponentBytes)
	value.lane.max_total_profile_bytes = C.uint64_t(source.Lane.MaxTotalProfileBytes)
	value.lane.max_header_count = C.uint32_t(source.Lane.MaxHeaderCount)
	value.lane.max_header_name_bytes = C.uint32_t(source.Lane.MaxHeaderNameBytes)
	value.lane.max_header_value_bytes = C.uint32_t(source.Lane.MaxHeaderValueBytes)
	value.lane.max_header_bytes = C.uint32_t(source.Lane.MaxHeaderBytes)
	value.lane.max_request_body_bytes = C.uint64_t(source.Lane.MaxRequestBodyBytes)
	value.lane.max_total_request_bytes = C.uint64_t(source.Lane.MaxTotalRequestBytes)
	value.lane.max_response_head_bytes = C.uint64_t(source.Lane.MaxResponseHeadBytes)
	value.lane.max_response_body_bytes = C.uint64_t(source.Lane.MaxResponseBodyBytes)
	value.lane.max_total_response_bytes = C.uint64_t(source.Lane.MaxTotalResponseBytes)
	value.lane.deadline_tick_ms = C.uint32_t(source.Lane.DeadlineTickMillis)
	value.lane.stop_timeout_ms = C.uint32_t(source.Lane.StopTimeoutMillis)
	value.transport.active_call_capacity = C.uint32_t(source.Transport.ActiveCallCapacity)
	value.transport.max_response_header_count = C.uint32_t(source.Transport.MaxResponseHeaderCount)
	value.transport.max_response_header_name_bytes = C.uint32_t(source.Transport.MaxResponseHeaderNameBytes)
	value.transport.max_response_header_value_bytes = C.uint32_t(source.Transport.MaxResponseHeaderValueBytes)
	value.transport.max_response_head_bytes = C.uint64_t(source.Transport.MaxResponseHeadBytes)
	value.transport.max_response_body_bytes = C.uint64_t(source.Transport.MaxResponseBodyBytes)
	value.transport.max_total_buffer_bytes = C.uint64_t(source.Transport.MaxTotalBufferBytes)
	value.transport.max_serialized_url_bytes = C.uint32_t(source.Transport.MaxSerializedURLBytes)
	value.transport.max_resolve_entry_bytes = C.uint32_t(source.Transport.MaxResolveEntryBytes)
	value.resolver.max_resolved_addresses = C.uint32_t(source.Resolver.MaxResolvedAddresses)
	value.resolver.socket_capacity = C.uint32_t(source.Resolver.SocketCapacity)
	value.resolver.timeout_ms = C.uint32_t(source.Resolver.TimeoutMillis)
	value.resolver.tries = C.uint32_t(source.Resolver.Tries)
	var err error
	if value.resolver.server_endpoint, err = arena.text(source.Resolver.ServerEndpoint); err != nil {
		return err
	}
	value.pool.key_capacity = C.uint32_t(source.Pool.KeyCapacity)
	value.pool.max_connections_per_key = C.uint32_t(source.Pool.MaxConnectionsPerKey)
	value.pool.max_waiting_per_key = C.uint32_t(source.Pool.MaxWaitingPerKey)
	value.pool.max_idle_seconds = C.uint32_t(source.Pool.MaxIdleSeconds)
	value.pool.max_lifetime_seconds = C.uint32_t(source.Pool.MaxLifetimeSeconds)
	value.tls.trust_capacity = C.uint32_t(source.TLS.TrustCapacity)
	value.tls.client_identity_capacity = C.uint32_t(source.TLS.ClientIdentityCapacity)
	value.tls.max_trust_bundle_bytes = C.uint64_t(source.TLS.MaxTrustBundleBytes)
	value.tls.max_client_certificate_bytes = C.uint64_t(source.TLS.MaxClientCertificateBytes)
	value.tls.max_client_private_key_bytes = C.uint64_t(source.TLS.MaxClientPrivateKeyBytes)
	value.tls.max_total_bytes = C.uint64_t(source.TLS.MaxTotalBytes)
	value.registry.target_capacity = C.uint32_t(source.Registry.TargetCapacity)
	value.registry.endpoint_capacity = C.uint32_t(source.Registry.EndpointCapacity)
	value.registry.max_endpoints_per_target = C.uint32_t(source.Registry.MaxEndpointsPerTarget)
	value.registry.max_target_name_bytes = C.uint32_t(source.Registry.MaxTargetNameBytes)
	value.registry.max_node_id_bytes = C.uint32_t(source.Registry.MaxNodeIDBytes)
	value.registry.max_total_bytes = C.uint64_t(source.Registry.MaxTotalBytes)
	return resultError(C.coakka_http_go_configuration_set_outbound(api, configuration, &value))
}

func addNativeOutboundTarget(api *C.coakka_http_go_api_t, configuration *C.coakka_http_configuration_t, source OutboundTarget) error {
	if len(source.Endpoints) > maximumProjectionItems {
		return errors.New("outbound endpoint count exceeds the Go bound")
	}
	arena := nativeArena{}
	defer arena.close()
	var target C.coakka_http_outbound_target_t
	C.coakka_http_go_outbound_target_init(api, &target)
	if source.Strategy != 0 {
		target.strategy = C.coakka_http_outbound_strategy_t(source.Strategy)
	}
	target.generation = C.uint64_t(source.Generation)
	var err error
	if target.name, err = arena.text(source.Name); err != nil {
		return err
	}
	if len(source.Endpoints) != 0 {
		memory, allocationErr := arena.allocate(uintptr(len(source.Endpoints)) * unsafe.Sizeof(C.coakka_http_outbound_endpoint_t{}))
		if allocationErr != nil {
			return allocationErr
		}
		endpoints := unsafe.Slice((*C.coakka_http_outbound_endpoint_t)(memory), len(source.Endpoints))
		for index, sourceEndpoint := range source.Endpoints {
			endpoint := &endpoints[index]
			C.coakka_http_go_outbound_endpoint_init(api, endpoint)
			if sourceEndpoint.Weight != 0 {
				endpoint.weight = C.uint32_t(sourceEndpoint.Weight)
			}
			endpoint.connect_port = C.uint16_t(sourceEndpoint.ConnectPort)
			if sourceEndpoint.Security != 0 {
				endpoint.security = C.coakka_http_transport_security_t(sourceEndpoint.Security)
			}
			if sourceEndpoint.Available != nil {
				endpoint.available = C.uint32_t(boolByte(*sourceEndpoint.Available))
			}
			if sourceEndpoint.ProxyMode != 0 {
				endpoint.proxy_mode = C.uint32_t(sourceEndpoint.ProxyMode)
			}
			if sourceEndpoint.ProtocolPolicy != 0 {
				endpoint.protocol_policy = C.uint32_t(sourceEndpoint.ProtocolPolicy)
			}
			if sourceEndpoint.ConnectionStrategy != 0 {
				endpoint.connection_strategy = C.uint32_t(sourceEndpoint.ConnectionStrategy)
			}
			endpoint.tls_trust_generation = C.uint64_t(sourceEndpoint.TLSTrustGeneration)
			endpoint.tls_client_identity_generation = C.uint64_t(sourceEndpoint.TLSClientIdentityGeneration)
			endpoint.connection_strategy_generation = C.uint64_t(sourceEndpoint.ConnectionStrategyGeneration)
			endpoint.local_network_policy_id = C.uint64_t(sourceEndpoint.LocalNetworkPolicyID)
			if endpoint.node_id, err = arena.text(sourceEndpoint.NodeID); err != nil {
				return err
			}
			if endpoint.connect_host, err = arena.text(sourceEndpoint.ConnectHost); err != nil {
				return err
			}
			if endpoint.http_authority, err = arena.text(sourceEndpoint.HTTPAuthority); err != nil {
				return err
			}
			if endpoint.tls_peer_identity, err = arena.text(sourceEndpoint.TLSPeerIdentity); err != nil {
				return err
			}
			if endpoint.proxy_identity, err = arena.text(sourceEndpoint.ProxyIdentity); err != nil {
				return err
			}
		}
		target.endpoints = (*C.coakka_http_outbound_endpoint_t)(memory)
		target.endpoint_count = C.uint32_t(len(source.Endpoints))
	}
	return resultError(C.coakka_http_go_configuration_add_outbound_target(api, configuration, &target))
}
