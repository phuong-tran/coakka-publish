//go:build darwin && arm64

package coakkahttp

import _ "embed"

//go:embed native/darwin-arm64/libcoakka_http_runtime.1.0.0.dylib
var packagedCore []byte

const packagedCoreName = "libcoakka_http_runtime.1.0.0.dylib"
const packagedCoreSHA256 = "ee6e602692f71905b76f90205ad020409d667d429cd31bba29d62f8d4c60a009"
