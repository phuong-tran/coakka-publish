package coakkahttp

/*
#include "bridge.h"
*/
import "C"

import (
	"errors"
)

func (native *nativeCore) acceptWebSocket(exchange ExchangeID, subprotocol string) error {
	arena := nativeArena{}
	defer arena.close()
	value, err := arena.text(subprotocol)
	if err != nil {
		return err
	}
	return resultError(C.coakka_http_go_core_accept_websocket(native.api, native.core, nativeExchange(exchange), value))
}

func (native *nativeCore) takeWebSocket(timeout C.uint64_t) (_ *SocketEvent, returned error) {
	var source C.coakka_http_socket_event_t
	C.coakka_http_go_socket_event_init(&source)
	if err := resultError(C.coakka_http_go_core_take_websocket(native.api, native.core, timeout, &source)); err != nil {
		return nil, err
	}
	defer func() {
		returned = errors.Join(returned, resultError(C.coakka_http_go_core_release_websocket(native.api, native.core, &source)))
	}()
	data, err := nativeBytes(C.coakka_http_bytes_t{data: source.data, size: source.data_size})
	if err != nil {
		return nil, err
	}
	return &SocketEvent{
		Kind:           SocketEventKind(source.kind),
		Session:        WebSocketID{Slot: uint64(source.session.slot), Generation: uint64(source.session.generation)},
		OriginExchange: ExchangeID{Slot: uint64(source.origin_exchange.slot), Generation: uint64(source.origin_exchange.generation)},
		CloseCode:      uint32(source.close_code),
		Data:           data,
	}, nil
}

func (native *nativeCore) sendWebSocket(session WebSocketID, kind SocketEventKind, data []byte) error {
	arena := nativeArena{}
	defer arena.close()
	value, err := arena.bytes(data)
	if err != nil {
		return err
	}
	return resultError(C.coakka_http_go_core_send_websocket(native.api, native.core, nativeWebSocket(session), C.coakka_http_socket_event_kind_t(kind), value))
}

func (native *nativeCore) closeWebSocket(session WebSocketID, code uint32, reason string) error {
	arena := nativeArena{}
	defer arena.close()
	value, err := arena.text(reason)
	if err != nil {
		return err
	}
	return resultError(C.coakka_http_go_core_close_websocket(native.api, native.core, nativeWebSocket(session), C.uint32_t(code), value))
}

func (native *nativeCore) submitOutbound(request ClientRequest) (OutboundID, error) {
	arena := nativeArena{}
	defer arena.close()
	var value C.coakka_http_client_request_t
	C.coakka_http_go_outbound_request_init(native.api, &value)
	value.timeout_ms = C.uint32_t(request.TimeoutMillis)
	var err error
	if value.logical_target, err = arena.text(request.LogicalTarget); err != nil {
		return OutboundID{}, err
	}
	if value.method, err = arena.text(request.Method); err != nil {
		return OutboundID{}, err
	}
	if value.target, err = arena.text(request.Target); err != nil {
		return OutboundID{}, err
	}
	if value.headers, value.header_count, err = arena.headers(request.Headers); err != nil {
		return OutboundID{}, err
	}
	if value.body, err = arena.bytes(request.Body); err != nil {
		return OutboundID{}, err
	}
	var call C.coakka_http_outbound_id_t
	if err = resultError(C.coakka_http_go_core_outbound_submit(native.api, native.core, &value, &call)); err != nil {
		return OutboundID{}, err
	}
	return OutboundID{Slot: uint64(call.slot), Generation: uint64(call.generation)}, nil
}

func (native *nativeCore) cancelOutbound(call OutboundID) error {
	return resultError(C.coakka_http_go_core_outbound_cancel(native.api, native.core, nativeOutbound(call)))
}

func (native *nativeCore) takeOutbound(timeout C.uint64_t) (_ *ClientTerminal, returned error) {
	var source C.coakka_http_client_terminal_t
	C.coakka_http_go_outbound_terminal_init(native.api, &source)
	if err := resultError(C.coakka_http_go_core_take_outbound(native.api, native.core, timeout, &source)); err != nil {
		return nil, err
	}
	defer func() {
		returned = errors.Join(returned, resultError(C.coakka_http_go_core_release_outbound(native.api, native.core, &source)))
	}()
	logicalTarget, err := nativeText(source.logical_target)
	if err != nil {
		return nil, err
	}
	selectedNode, err := nativeText(source.selected_node_id)
	if err != nil {
		return nil, err
	}
	body, err := nativeBytes(source.response_body)
	if err != nil {
		return nil, err
	}
	diagnostic, err := nativeText(source.diagnostic)
	if err != nil {
		return nil, err
	}
	count, err := checkedCount(source.response_header_count)
	if err != nil {
		return nil, err
	}
	entries := make([]Header, 0, count)
	for index := 0; index < count; index++ {
		var header C.coakka_http_header_t
		if err = resultError(C.coakka_http_go_core_outbound_header(native.api, native.core, &source, C.uint32_t(index), &header)); err != nil {
			return nil, err
		}
		entry, copyErr := copiedHeader(header)
		if copyErr != nil {
			return nil, copyErr
		}
		entries = append(entries, entry)
	}
	headers, err := NewHeaders(entries...)
	if err != nil {
		return nil, err
	}
	return &ClientTerminal{
		Reason:           uint32(source.reason),
		Call:             OutboundID{Slot: uint64(source.call.slot), Generation: uint64(source.call.generation)},
		LogicalTarget:    logicalTarget,
		TargetGeneration: uint64(source.target_generation),
		SelectedNodeID:   selectedNode,
		Phase:            uint32(source.phase),
		Retry:            uint32(source.retry),
		Certainty:        uint32(source.certainty),
		ResponseStatus:   uint16(source.response_status),
		ProviderCode:     int32(source.provider_code),
		ResponseHeaders:  headers,
		ResponseBody:     body,
		Diagnostic:       diagnostic,
	}, nil
}

func (native *nativeCore) rebind(request RebindRequest, timeout C.uint64_t) (RebindOutcome, error) {
	var value C.coakka_http_route_rebind_t
	C.coakka_http_go_rebind_init(native.api, &value)
	value.activation_id = C.uint64_t(request.ActivationID)
	value.expected_route_generation = C.uint64_t(request.ExpectedRouteGeneration)
	value.route_id = C.uint64_t(request.RouteID)
	value.expected_binding_revision = C.uint64_t(request.ExpectedBindingRevision)
	value.new_handler_binding_id = C.uint64_t(request.NewHandlerBindingID)
	var outcome C.coakka_http_route_rebind_outcome_t
	C.coakka_http_go_rebind_outcome_init(native.api, &outcome)
	if err := resultError(C.coakka_http_go_core_rebind(native.api, native.core, &value, timeout, &outcome)); err != nil {
		return RebindOutcome{}, err
	}
	return RebindOutcome{
		Code:                             uint32(outcome.code),
		ActivationID:                     uint64(outcome.activation_id),
		OperationDigest:                  uint64(outcome.operation_digest),
		RouteGeneration:                  uint64(outcome.route_generation),
		RouteID:                          uint64(outcome.route_id),
		PreviousHandlerBindingID:         uint64(outcome.previous_handler_binding_id),
		PreviousBindingRevision:          uint64(outcome.previous_binding_revision),
		EffectiveHandlerBindingID:        uint64(outcome.effective_handler_binding_id),
		EffectiveBindingRevision:         uint64(outcome.effective_binding_revision),
		BindingChangeSequence:            uint64(outcome.binding_change_sequence),
		RetainedPreviousExchanges:        uint32(outcome.retained_previous_exchanges),
		PreviousEffectiveRouteReferences: uint32(outcome.previous_effective_route_references),
		Changed:                          outcome.changed != 0,
		Replayed:                         outcome.replayed != 0,
	}, nil
}

func copyHealth(source C.coakka_http_health_t) Health {
	return Health{
		Lifecycle:                        uint32(source.lifecycle),
		SnapshotSequence:                 uint64(source.snapshot_sequence),
		ChangeSequence:                   uint64(source.change_sequence),
		LifecycleGeneration:              uint64(source.lifecycle_generation),
		ObservedMonotonicNanos:           uint64(source.observed_monotonic_ns),
		ProgressSequence:                 uint64(source.progress_sequence),
		ProgressMonotonicNanos:           uint64(source.progress_monotonic_ns),
		AcknowledgedProbeSequence:        uint64(source.acknowledged_probe_sequence),
		AcknowledgedProbeMonotonicNanos:  uint64(source.acknowledged_probe_monotonic_ns),
		ConfiguredComponents:             uint32(source.configured_components),
		RunningComponents:                uint32(source.running_components),
		FailedComponents:                 uint32(source.failed_components),
		Startup:                          uint32(source.startup),
		Liveness:                         uint32(source.liveness),
		Readiness:                        uint32(source.readiness),
		AdmissionOpen:                    source.admission_open != 0,
		Partial:                          source.partial != 0,
		ServerActiveExchanges:            uint32(source.server_active_exchanges),
		ClientActiveCalls:                uint32(source.client_active_calls),
		ClientReadyTerminals:             uint32(source.client_ready_terminals),
		ClientOutstandingTerminalLeases:  uint32(source.client_outstanding_terminal_leases),
		ClientRetainedRequestBytes:       uint64(source.client_retained_request_bytes),
		ClientRetainedTargetProfileBytes: uint64(source.client_retained_target_profile_bytes),
		ClientRetainedResponseBytes:      uint64(source.client_retained_response_bytes),
		ClientAdmittedCalls:              uint64(source.client_admitted_calls),
		ClientTerminalCalls:              uint64(source.client_terminal_calls),
		ClientStaleProviderTerminals:     uint64(source.client_stale_provider_terminals),
	}
}

func (native *nativeCore) health() (Health, error) {
	var value C.coakka_http_health_t
	C.coakka_http_go_health_init(native.api, &value)
	err := resultError(C.coakka_http_go_core_health(native.api, native.core, &value))
	return copyHealth(value), err
}

func (native *nativeCore) probeLiveness(timeout C.uint64_t) (Health, error) {
	var value C.coakka_http_health_t
	C.coakka_http_go_health_init(native.api, &value)
	err := resultError(C.coakka_http_go_core_probe_liveness(native.api, native.core, timeout, &value))
	return copyHealth(value), err
}
