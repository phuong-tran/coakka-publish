//go:build linux && amd64

package coakkahttp

import _ "embed"

//go:embed native/linux-amd64/libcoakka_http_runtime.so.1.0.0
var packagedCore []byte

const packagedCoreName = "libcoakka_http_runtime.so.1.0.0"
const packagedCoreSHA256 = "eaa502ed5ccd0398ffdd463a6930f38def4796e8cd87b81c9cb8c3d847c959e6"
