//go:build linux && arm64

package coakkahttp

import _ "embed"

//go:embed native/linux-arm64/libcoakka_http_runtime.so.1.0.0
var packagedCore []byte

const packagedCoreName = "libcoakka_http_runtime.so.1.0.0"
const packagedCoreSHA256 = "ece8a618e763c10e23edea90bdd5fe968bf448fd5186b8c05d47f025f76b912b"
