package coakkahttp

/*
#include "bridge.h"
*/
import "C"

import (
	"errors"
	"unsafe"
)

func nativeMonitorPolicy(api *C.coakka_http_go_api_t, source MonitorPolicy) C.coakka_http_monitor_policy_view_t {
	var value C.coakka_http_monitor_policy_view_t
	C.coakka_http_go_monitor_policy_init(api, &value)
	value.collection = C.coakka_http_monitor_collection_t(source.Collection)
	value.notification = C.coakka_http_monitor_notification_t(source.Notification)
	value.latency = C.coakka_http_monitor_latency_t(source.Latency)
	value.detail = C.coakka_http_monitor_detail_t(source.Detail)
	value.active_event_capacity = C.uint32_t(source.ActiveEventCapacity)
	value.active_detail_bytes = C.uint32_t(source.ActiveDetailBytes)
	value.aggregate_categories = C.uint64_t(source.AggregateCategories)
	value.event_categories = C.uint64_t(source.EventCategories)
	return value
}

func copyMonitorPolicy(source C.coakka_http_monitor_policy_view_t) MonitorPolicy {
	return MonitorPolicy{
		Collection:          MonitorCollection(source.collection),
		Notification:        MonitorNotification(source.notification),
		Latency:             MonitorLatency(source.latency),
		Detail:              MonitorDetail(source.detail),
		ActiveEventCapacity: uint32(source.active_event_capacity),
		ActiveDetailBytes:   uint32(source.active_detail_bytes),
		AggregateCategories: uint64(source.aggregate_categories),
		EventCategories:     uint64(source.event_categories),
	}
}

func copyMonitorConfig(source C.coakka_http_monitor_config_view_t) MonitorConfig {
	return MonitorConfig{
		Provenance:                  uint32(source.provenance),
		Generation:                  uint64(source.generation),
		CollectionEpoch:             uint64(source.collection_epoch),
		ChangeSequence:              uint64(source.change_sequence),
		EpochStartedMonotonicNanos:  uint64(source.epoch_started_monotonic_ns),
		PolicyAppliedMonotonicNanos: uint64(source.policy_applied_monotonic_ns),
		SupportedCategories:         uint64(source.supported_categories),
		ReservedEventCapacity:       uint32(source.reserved_event_capacity),
		MaxEventsPerRead:            uint32(source.max_events_per_read),
		ReservedDetailBytesPerEvent: uint32(source.reserved_detail_bytes_per_event),
		ReservedLatencyBucketCount:  uint32(source.reserved_latency_bucket_count),
		SignalReserved:              source.signal_reserved != 0,
		Policy:                      copyMonitorPolicy(source.policy),
	}
}

func (native *nativeCore) monitorConfig() (MonitorConfig, error) {
	var value C.coakka_http_monitor_config_view_t
	C.coakka_http_go_monitor_config_init(native.api, &value)
	err := resultError(C.coakka_http_go_core_monitor_config(native.api, native.core, &value))
	return copyMonitorConfig(value), err
}

func (native *nativeCore) monitorSnapshot() (MonitorSnapshot, error) {
	var source C.coakka_http_monitor_snapshot_view_t
	C.coakka_http_go_monitor_snapshot_init(native.api, &source)
	if err := resultError(C.coakka_http_go_core_monitor_snapshot(native.api, native.core, &source)); err != nil {
		return MonitorSnapshot{}, err
	}
	failureCount, err := checkedCount(source.failure_count)
	if err != nil || failureCount > len(source.failure_counts) {
		return MonitorSnapshot{}, errors.New("native monitor failure count exceeds its ABI bound")
	}
	latencyCount, err := checkedCount(source.latency_bucket_count)
	if err != nil || latencyCount > len(source.latency_buckets) {
		return MonitorSnapshot{}, errors.New("native monitor latency count exceeds its ABI bound")
	}
	failures := make([]MonitorFailureCount, failureCount)
	for index := range failures {
		failures[index] = MonitorFailureCount{Reason: uint32(source.failure_counts[index].reason), Count: uint64(source.failure_counts[index].count)}
	}
	latencies := make([]MonitorLatencyBucket, latencyCount)
	for index := range latencies {
		latencies[index] = MonitorLatencyBucket{UpperBoundNanos: uint64(source.latency_buckets[index].upper_bound_ns), Count: uint64(source.latency_buckets[index].count)}
	}
	var statuses [5]uint64
	for index := range statuses {
		statuses[index] = uint64(source.response_status_family[index])
	}
	return MonitorSnapshot{
		Collecting:              source.collecting != 0,
		Stale:                   source.stale != 0,
		Partial:                 source.partial != 0,
		SnapshotSequence:        uint64(source.snapshot_sequence),
		ObservedMonotonicNanos:  uint64(source.observed_monotonic_ns),
		CollectedChangeSequence: uint64(source.collected_change_sequence),
		InboundAdmittedRequests: uint64(source.inbound_admitted_requests),
		InboundRequestBytes:     uint64(source.inbound_request_bytes),
		ExchangeCompleted:       uint64(source.exchange_completed),
		ExchangeFailed:          uint64(source.exchange_failed),
		ExchangeTimedOut:        uint64(source.exchange_timed_out),
		ExchangeDisconnected:    uint64(source.exchange_disconnected),
		ExchangeCancelled:       uint64(source.exchange_cancelled),
		ResponseStatusFamily:    statuses,
		RetainedEvents:          uint64(source.retained_events),
		EventOverwriteCount:     uint64(source.event_overwrite_count),
		EventDropCount:          uint64(source.event_drop_count),
		SignalNotifyCount:       uint64(source.signal_notify_count),
		SignalCoalescedCount:    uint64(source.signal_coalesced_count),
		SignalFailureCount:      uint64(source.signal_failure_count),
		Config:                  copyMonitorConfig(source.config),
		Health:                  copyHealth(source.health),
		FailureCounts:           failures,
		LatencyBuckets:          latencies,
	}, nil
}

func (native *nativeCore) monitorApply(expectedGeneration uint64, policy MonitorPolicy) (MonitorApplyOutcome, error) {
	value := nativeMonitorPolicy(native.api, policy)
	var source C.coakka_http_monitor_apply_outcome_t
	C.coakka_http_go_monitor_apply_outcome_init(native.api, &source)
	if err := resultError(C.coakka_http_go_core_monitor_apply(native.api, native.core, C.uint64_t(expectedGeneration), &value, &source)); err != nil {
		return MonitorApplyOutcome{}, err
	}
	return MonitorApplyOutcome{
		Reason:    MonitorApplyReason(source.reason),
		Actual:    uint64(source.actual),
		Limit:     uint64(source.limit),
		Changed:   source.changed != 0,
		Effective: copyMonitorConfig(source.effective),
	}, nil
}

func (native *nativeCore) monitorRead(afterSequence uint64, maximumEvents uint32) (MonitorEventPage, error) {
	if maximumEvents == 0 || uint64(maximumEvents) > maximumProjectionItems {
		return MonitorEventPage{}, errors.New("monitor page size is outside the Go bound")
	}
	arena := nativeArena{}
	defer arena.close()
	memory, err := arena.allocate(uintptr(maximumEvents) * unsafe.Sizeof(C.coakka_http_monitor_event_view_t{}))
	if err != nil {
		return MonitorEventPage{}, err
	}
	events := unsafe.Slice((*C.coakka_http_monitor_event_view_t)(memory), int(maximumEvents))
	for index := range events {
		C.coakka_http_go_monitor_event_init(native.api, &events[index])
	}
	var page C.coakka_http_monitor_event_page_view_t
	C.coakka_http_go_monitor_page_init(native.api, &page)
	if err = resultError(C.coakka_http_go_core_monitor_read(native.api, native.core, C.uint64_t(afterSequence), C.uint32_t(maximumEvents), (*C.coakka_http_monitor_event_view_t)(memory), C.uint32_t(maximumEvents), &page)); err != nil {
		return MonitorEventPage{}, err
	}
	count, err := checkedCount(page.count)
	if err != nil || count > len(events) {
		return MonitorEventPage{}, errors.New("native monitor page count exceeds its supplied capacity")
	}
	result := make([]MonitorEvent, count)
	for index := range result {
		source := events[index]
		detailSize := uint32(source.detail_size)
		if detailSize > uint32(len(source.detail)) {
			return MonitorEventPage{}, errors.New("native monitor detail exceeds its ABI bound")
		}
		detail := ""
		if detailSize != 0 {
			detail = C.GoStringN((*C.char)(unsafe.Pointer(&source.detail[0])), C.int(detailSize))
		}
		result[index] = MonitorEvent{
			Kind:                   MonitorEventKind(source.kind),
			Sequence:               uint64(source.sequence),
			ChangeSequence:         uint64(source.change_sequence),
			ConfigGeneration:       uint64(source.config_generation),
			CollectionEpoch:        uint64(source.collection_epoch),
			ObservedMonotonicNanos: uint64(source.observed_monotonic_ns),
			Category:               uint64(source.category),
			FailureReason:          uint32(source.failure_reason),
			QueueScope:             uint32(source.queue_scope),
			QueueDepth:             uint32(source.queue_depth),
			QueueCapacity:          uint32(source.queue_capacity),
			Exchange:               ExchangeID{Slot: uint64(source.exchange.slot), Generation: uint64(source.exchange.generation)},
			Detail:                 detail,
		}
	}
	return MonitorEventPage{
		Events:                  result,
		OldestAvailableSequence: uint64(page.oldest_available_sequence),
		LatestSequence:          uint64(page.latest_sequence),
		MissedEvents:            uint64(page.missed_events),
		RemainingEvents:         uint64(page.remaining_events),
	}, nil
}

func (native *nativeCore) monitorWait(timeout C.uint64_t) error {
	return resultError(C.coakka_http_go_core_monitor_wait(native.api, native.core, timeout))
}

func (native *nativeCore) monitorInterrupt() error {
	return resultError(C.coakka_http_go_core_monitor_interrupt(native.api, native.core))
}
