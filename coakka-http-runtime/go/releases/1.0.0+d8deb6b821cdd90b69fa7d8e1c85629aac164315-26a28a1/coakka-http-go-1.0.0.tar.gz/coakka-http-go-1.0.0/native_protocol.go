package coakkahttp

/*
#include "bridge.h"
#include <stdlib.h>
*/
import "C"

import (
	"errors"
	"unsafe"
)

func nativeExchange(value ExchangeID) C.coakka_http_exchange_id_t {
	return C.coakka_http_exchange_id_t{slot: C.uint64_t(value.Slot), generation: C.uint64_t(value.Generation)}
}

func nativeWebSocket(value WebSocketID) C.coakka_http_websocket_id_t {
	return C.coakka_http_websocket_id_t{slot: C.uint64_t(value.Slot), generation: C.uint64_t(value.Generation)}
}

func nativeOutbound(value OutboundID) C.coakka_http_outbound_id_t {
	return C.coakka_http_outbound_id_t{slot: C.uint64_t(value.Slot), generation: C.uint64_t(value.Generation)}
}

func (arena *nativeArena) headers(headers Headers) (*C.coakka_http_header_t, C.uint32_t, error) {
	entries := headers.entries
	if len(entries) == 0 {
		return nil, 0, nil
	}
	if len(entries) > maximumHeaders {
		return nil, 0, errors.New("HTTP header count exceeds the Go bound")
	}
	memory, err := arena.allocate(uintptr(len(entries)) * unsafe.Sizeof(C.coakka_http_header_t{}))
	if err != nil {
		return nil, 0, err
	}
	values := unsafe.Slice((*C.coakka_http_header_t)(memory), len(entries))
	for index, entry := range entries {
		validated, validationErr := NewHeader(entry.Name, entry.Value)
		if validationErr != nil {
			return nil, 0, validationErr
		}
		if values[index].name, err = arena.text(validated.Name); err != nil {
			return nil, 0, err
		}
		if values[index].value, err = arena.text(validated.Value); err != nil {
			return nil, 0, err
		}
	}
	return (*C.coakka_http_header_t)(memory), C.uint32_t(len(entries)), nil
}

func nativeResponse(api *C.coakka_http_go_api_t, arena *nativeArena, source Response) (C.coakka_http_response_t, error) {
	var value C.coakka_http_response_t
	C.coakka_http_go_response_init(api, &value)
	if source.Status < 100 || source.Status > 599 {
		return value, errors.New("HTTP response status is invalid")
	}
	value.status_code = C.uint32_t(source.Status)
	headers, count, err := arena.headers(source.Headers)
	if err != nil {
		return value, err
	}
	value.headers = headers
	value.header_count = count
	if value.body, err = arena.bytes(source.body); err != nil {
		return value, err
	}
	return value, nil
}

func (native *nativeCore) start() error {
	return resultError(C.coakka_http_go_core_start(native.api, native.core))
}

func (native *nativeCore) boundPort() (uint16, error) {
	var port C.uint16_t
	err := resultError(C.coakka_http_go_core_bound_port(native.api, native.core, &port))
	return uint16(port), err
}

func (native *nativeCore) drain() error {
	return resultError(C.coakka_http_go_core_drain(native.api, native.core))
}

func (native *nativeCore) stop() error {
	return resultError(C.coakka_http_go_core_stop(native.api, native.core))
}

func (native *nativeCore) interrupt() error {
	return resultError(C.coakka_http_go_core_interrupt(native.api, native.core))
}

func (native *nativeCore) takeEvent(timeout C.uint64_t) (_ *Event, returned error) {
	var source C.coakka_http_event_t
	C.coakka_http_go_event_init(native.api, &source)
	if err := resultError(C.coakka_http_go_core_take_event(native.api, native.core, timeout, &source)); err != nil {
		return nil, err
	}
	defer func() {
		returned = errors.Join(returned, resultError(C.coakka_http_go_core_release_event(native.api, native.core, &source)))
	}()
	data, err := nativeBytes(C.coakka_http_bytes_t{data: source.data, size: source.data_size})
	if err != nil {
		return nil, err
	}
	event := &Event{
		Kind:             EventKind(source.kind),
		Exchange:         ExchangeID{Slot: uint64(source.exchange.slot), Generation: uint64(source.exchange.generation)},
		Sequence:         uint64(source.sequence),
		HandlerBindingID: uint64(source.handler_binding_id),
		Data:             data,
	}
	switch event.Kind {
	case EventRequest:
		event.Request, err = native.copyRequest(&source, event.Exchange, event.HandlerBindingID)
	case EventRequestTrailers:
		event.StreamTrailers, err = native.copyStreamTrailers(&source)
	case EventTerminal:
		event.Terminal, err = native.copyTerminal(&source)
	}
	if err != nil {
		return nil, err
	}
	return event, nil
}

func (native *nativeCore) copyRequest(source *C.coakka_http_event_t, exchange ExchangeID, handlerBindingID uint64) (*Request, error) {
	method, err := nativeText(C.coakka_http_go_event_request_method(native.api, source))
	if err != nil {
		return nil, err
	}
	scheme, err := nativeText(C.coakka_http_go_event_request_scheme(native.api, source))
	if err != nil {
		return nil, err
	}
	authority, err := nativeText(C.coakka_http_go_event_request_authority(native.api, source))
	if err != nil {
		return nil, err
	}
	target, err := nativeText(C.coakka_http_go_event_request_target(native.api, source))
	if err != nil {
		return nil, err
	}
	body, err := nativeBytes(C.coakka_http_go_event_request_body(native.api, source))
	if err != nil {
		return nil, err
	}
	headers, err := native.copyRequestHeaders(source, C.coakka_http_go_event_request_header_count(native.api, source), 0)
	if err != nil {
		return nil, err
	}
	trailers, err := native.copyRequestHeaders(source, C.coakka_http_go_event_request_trailer_count(native.api, source), 1)
	if err != nil {
		return nil, err
	}
	pathParameters, err := native.copyPathParameters(source)
	if err != nil {
		return nil, err
	}
	queryParameters, err := native.copyQueryParameters(source)
	if err != nil {
		return nil, err
	}
	return &Request{
		Exchange:         exchange,
		Method:           method,
		Scheme:           scheme,
		Authority:        authority,
		Target:           target,
		Headers:          headers,
		PathParameters:   pathParameters,
		QueryParameters:  queryParameters,
		Trailers:         trailers,
		RouteID:          uint64(C.coakka_http_go_event_request_route_id(native.api, source)),
		RouteGeneration:  uint64(C.coakka_http_go_event_request_route_generation(native.api, source)),
		BindingRevision:  uint64(C.coakka_http_go_event_request_binding_revision(native.api, source)),
		HandlerBindingID: handlerBindingID,
		BodyDelivery:     BodyDelivery(C.coakka_http_go_event_request_body_delivery(native.api, source)),
		body:             body,
	}, nil
}

func checkedCount(value C.uint32_t) (int, error) {
	if uint64(value) > maximumProjectionItems {
		return 0, errors.New("native collection exceeds the Go bound")
	}
	return int(value), nil
}

func copiedHeader(source C.coakka_http_header_t) (Header, error) {
	name, err := nativeText(source.name)
	if err != nil {
		return Header{}, err
	}
	value, err := nativeText(source.value)
	if err != nil {
		return Header{}, err
	}
	return NewHeader(name, value)
}

func (native *nativeCore) copyRequestHeaders(event *C.coakka_http_event_t, countValue C.uint32_t, trailer uint8) (Headers, error) {
	count, err := checkedCount(countValue)
	if err != nil {
		return Headers{}, err
	}
	entries := make([]Header, 0, count)
	for index := 0; index < count; index++ {
		var source C.coakka_http_header_t
		var ok C.uint8_t
		if trailer == 0 {
			ok = C.coakka_http_go_event_request_header(native.api, event, C.uint32_t(index), &source)
		} else {
			ok = C.coakka_http_go_event_request_trailer(native.api, event, C.uint32_t(index), &source)
		}
		if ok == 0 {
			return Headers{}, errors.New("native header projection failed")
		}
		entry, copyErr := copiedHeader(source)
		if copyErr != nil {
			return Headers{}, copyErr
		}
		entries = append(entries, entry)
	}
	return NewHeaders(entries...)
}

func (native *nativeCore) copyStreamTrailers(event *C.coakka_http_event_t) (Headers, error) {
	count, err := checkedCount(C.coakka_http_go_event_stream_trailer_count(native.api, event))
	if err != nil {
		return Headers{}, err
	}
	entries := make([]Header, 0, count)
	for index := 0; index < count; index++ {
		var source C.coakka_http_header_t
		if C.coakka_http_go_event_stream_trailer(native.api, event, C.uint32_t(index), &source) == 0 {
			return Headers{}, errors.New("native stream trailer projection failed")
		}
		entry, copyErr := copiedHeader(source)
		if copyErr != nil {
			return Headers{}, copyErr
		}
		entries = append(entries, entry)
	}
	return NewHeaders(entries...)
}

func (native *nativeCore) copyPathParameters(event *C.coakka_http_event_t) ([]PathParameter, error) {
	count, err := checkedCount(C.coakka_http_go_event_request_path_parameter_count(native.api, event))
	if err != nil {
		return nil, err
	}
	values := make([]PathParameter, 0, count)
	for index := 0; index < count; index++ {
		var source C.coakka_http_path_parameter_t
		if C.coakka_http_go_event_request_path_parameter(native.api, event, C.uint32_t(index), &source) == 0 {
			return nil, errors.New("native path parameter projection failed")
		}
		name, copyErr := nativeText(source.name)
		if copyErr != nil {
			return nil, copyErr
		}
		value, copyErr := nativeText(source.encoded_value)
		if copyErr != nil {
			return nil, copyErr
		}
		values = append(values, PathParameter{Name: name, EncodedValue: value})
	}
	return values, nil
}

func (native *nativeCore) copyQueryParameters(event *C.coakka_http_event_t) ([]QueryParameter, error) {
	count, err := checkedCount(C.coakka_http_go_event_request_query_parameter_count(native.api, event))
	if err != nil {
		return nil, err
	}
	values := make([]QueryParameter, 0, count)
	for index := 0; index < count; index++ {
		var source C.coakka_http_query_parameter_t
		if C.coakka_http_go_event_request_query_parameter(native.api, event, C.uint32_t(index), &source) == 0 {
			return nil, errors.New("native query parameter projection failed")
		}
		key, copyErr := nativeText(source.encoded_key)
		if copyErr != nil {
			return nil, copyErr
		}
		value, copyErr := nativeText(source.encoded_value)
		if copyErr != nil {
			return nil, copyErr
		}
		values = append(values, QueryParameter{EncodedKey: key, EncodedValue: value, HasValue: source.has_value != 0})
	}
	return values, nil
}

func (native *nativeCore) copyTerminal(event *C.coakka_http_event_t) (*TerminalSummary, error) {
	var source C.coakka_http_terminal_summary_t
	C.coakka_http_go_terminal_summary_init(native.api, &source)
	if err := resultError(C.coakka_http_go_event_terminal_summary(native.api, event, &source)); err != nil {
		return nil, err
	}
	stored := uint32(source.stored_detail_size)
	if stored > uint32(len(source.detail)) {
		return nil, errors.New("native terminal detail exceeds its ABI bound")
	}
	detail := C.GoStringN((*C.char)(unsafe.Pointer(&source.detail[0])), C.int(stored))
	return &TerminalSummary{
		Outcome:                        ExchangeOutcome(source.outcome),
		ResponseStatus:                 uint32(source.response_status),
		FailureDomain:                  uint32(source.failure_domain),
		FailurePhase:                   uint32(source.failure_phase),
		FailureReason:                  uint32(source.failure_reason),
		RetryDisposition:               uint32(source.retry_disposition),
		HTTPStatusHint:                 uint32(source.http_status_hint),
		HasResponse:                    source.has_response != 0,
		HasFailure:                     source.has_failure != 0,
		HasHTTPStatusHint:              source.has_http_status_hint != 0,
		DetailTruncated:                source.detail_truncated != 0,
		HasAdmittedTime:                source.has_admitted_time != 0,
		HasDispatchedTime:              source.has_dispatched_time != 0,
		HasResponseAcceptedTime:        source.has_response_accepted_time != 0,
		HasCompletedTime:               source.has_completed_time != 0,
		AdmittedMonotonicNanos:         uint64(source.admitted_monotonic_ns),
		DispatchedMonotonicNanos:       uint64(source.dispatched_monotonic_ns),
		ResponseAcceptedMonotonicNanos: uint64(source.response_accepted_monotonic_ns),
		CompletedMonotonicNanos:        uint64(source.completed_monotonic_ns),
		DetailSize:                     uint64(source.detail_size),
		Detail:                         detail,
	}, nil
}

func (native *nativeCore) exchangeCancelled(exchange ExchangeID) (bool, error) {
	var cancelled C.uint8_t
	err := resultError(C.coakka_http_go_core_exchange_cancelled(native.api, native.core, nativeExchange(exchange), &cancelled))
	return cancelled != 0, err
}

func (native *nativeCore) respond(exchange ExchangeID, response Response) error {
	arena := nativeArena{}
	defer arena.close()
	value, err := nativeResponse(native.api, &arena, response)
	if err != nil {
		return err
	}
	return resultError(C.coakka_http_go_core_respond(native.api, native.core, nativeExchange(exchange), &value))
}

func (native *nativeCore) respondFile(exchange ExchangeID, response FileResponse) error {
	arena := nativeArena{}
	defer arena.close()
	var value C.coakka_http_file_response_t
	C.coakka_http_go_file_response_init(native.api, &value)
	head, err := nativeResponse(native.api, &arena, response.Head)
	if err != nil {
		return err
	}
	value.head = head
	value.authority_id = C.uint64_t(response.AuthorityID)
	if value.encoded_path, err = arena.text(response.EncodedPath); err != nil {
		return err
	}
	return resultError(C.coakka_http_go_core_respond_file(native.api, native.core, nativeExchange(exchange), &value))
}

func (native *nativeCore) fail(exchange ExchangeID, failure Failure) error {
	arena := nativeArena{}
	defer arena.close()
	var value C.coakka_http_failure_t
	C.coakka_http_go_failure_init(native.api, &value)
	value.reason = C.uint32_t(failure.Reason)
	var err error
	if value.detail, err = arena.text(failure.Detail); err != nil {
		return err
	}
	return resultError(C.coakka_http_go_core_fail(native.api, native.core, nativeExchange(exchange), &value))
}

func (native *nativeCore) startResponseStream(exchange ExchangeID, head Response) error {
	arena := nativeArena{}
	defer arena.close()
	value, err := nativeResponse(native.api, &arena, head)
	if err != nil {
		return err
	}
	return resultError(C.coakka_http_go_core_start_response_stream(native.api, native.core, nativeExchange(exchange), &value))
}

func (native *nativeCore) startSSE(exchange ExchangeID, headers Headers) error {
	arena := nativeArena{}
	defer arena.close()
	values, count, err := arena.headers(headers)
	if err != nil {
		return err
	}
	return resultError(C.coakka_http_go_core_start_sse(native.api, native.core, nativeExchange(exchange), values, count))
}

func (native *nativeCore) writeResponseStream(exchange ExchangeID, data []byte) error {
	arena := nativeArena{}
	defer arena.close()
	value, err := arena.bytes(data)
	if err != nil {
		return err
	}
	return resultError(C.coakka_http_go_core_write_response_stream(native.api, native.core, nativeExchange(exchange), value))
}

func (native *nativeCore) writeSSE(exchange ExchangeID, event SSEEvent) error {
	arena := nativeArena{}
	defer arena.close()
	var value C.coakka_http_sse_event_t
	C.coakka_http_go_sse_event_init(native.api, &value)
	var err error
	if value.data, err = arena.bytes(event.Data); err != nil {
		return err
	}
	if value.event_type, err = arena.text(event.EventType); err != nil {
		return err
	}
	if value.id, err = arena.text(event.ID); err != nil {
		return err
	}
	value.retry_ms = C.uint64_t(event.RetryMillis)
	value.has_event_type = boolByte(event.HasEventType)
	value.has_id = boolByte(event.HasID)
	value.has_retry = boolByte(event.HasRetry)
	return resultError(C.coakka_http_go_core_write_sse(native.api, native.core, nativeExchange(exchange), &value))
}

func (native *nativeCore) finishResponseStream(exchange ExchangeID, trailers Headers) error {
	arena := nativeArena{}
	defer arena.close()
	values, count, err := arena.headers(trailers)
	if err != nil {
		return err
	}
	return resultError(C.coakka_http_go_core_finish_response_stream(native.api, native.core, nativeExchange(exchange), values, count))
}
