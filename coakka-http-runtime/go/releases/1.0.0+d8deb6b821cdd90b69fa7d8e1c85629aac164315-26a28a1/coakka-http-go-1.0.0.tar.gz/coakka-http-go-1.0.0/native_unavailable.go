//go:build !(darwin && arm64) && !(linux && amd64) && !(linux && arm64) && !(windows && amd64) && !(windows && arm64)

package coakkahttp

// Non-macOS artifacts are deliberately absent until their ABI2 matching-host
// dependency, export, architecture, stress, and race gates pass.
var packagedCore []byte

const packagedCoreName = "unavailable"
const packagedCoreSHA256 = ""
