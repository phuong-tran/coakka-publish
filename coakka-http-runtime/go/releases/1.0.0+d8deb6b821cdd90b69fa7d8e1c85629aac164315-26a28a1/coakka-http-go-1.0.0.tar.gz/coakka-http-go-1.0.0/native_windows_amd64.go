//go:build windows && amd64

package coakkahttp

import _ "embed"

// packagedCore is the exact dependency-closed Windows x86-64 Core image. The
// loader validates the digest before creating its private extraction file.
//
//go:embed native/windows-amd64/coakka_http_runtime.dll
var packagedCore []byte

const packagedCoreName = "coakka_http_runtime.dll"
const packagedCoreSHA256 = "1bf2220891e35893b8d47725345ba3bc4740d532eac288b022f2d0f52cdc6e69"
