//go:build windows && arm64

package coakkahttp

import _ "embed"

//go:embed native/windows-arm64/coakka_http_runtime.dll
var packagedCore []byte

const packagedCoreName = "coakka_http_runtime.dll"
const packagedCoreSHA256 = "1378347cb9ff27fee165e0711980ce2d8695f0c92a7ec61479788fedbc3ad043"
