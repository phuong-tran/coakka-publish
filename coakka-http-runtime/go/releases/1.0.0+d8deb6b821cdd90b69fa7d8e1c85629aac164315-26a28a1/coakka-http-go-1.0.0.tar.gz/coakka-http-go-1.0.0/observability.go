package coakkahttp

// RebindRequest performs generation-checked handler rebinding.
type RebindRequest struct {
	// ActivationID is the idempotency identifier.
	ActivationID uint64
	// ExpectedRouteGeneration guards the route table generation.
	ExpectedRouteGeneration uint64
	// RouteID selects the route.
	RouteID uint64
	// ExpectedBindingRevision guards the current binding.
	ExpectedBindingRevision uint64
	// NewHandlerBindingID selects the replacement application binding.
	NewHandlerBindingID uint64
}

// RebindOutcome is the copied result of one route rebind command.
type RebindOutcome struct {
	// Code is Core's typed rebind outcome.
	Code uint32
	// ActivationID echoes the idempotency identifier.
	ActivationID uint64
	// OperationDigest identifies the normalized operation.
	OperationDigest uint64
	// RouteGeneration is the effective route generation.
	RouteGeneration uint64
	// RouteID is the affected route.
	RouteID uint64
	// PreviousHandlerBindingID is the replaced binding.
	PreviousHandlerBindingID uint64
	// PreviousBindingRevision is the prior revision.
	PreviousBindingRevision uint64
	// EffectiveHandlerBindingID is the resulting binding.
	EffectiveHandlerBindingID uint64
	// EffectiveBindingRevision is the resulting revision.
	EffectiveBindingRevision uint64
	// BindingChangeSequence is the resulting change sequence.
	BindingChangeSequence uint64
	// RetainedPreviousExchanges counts exchanges still using the old binding.
	RetainedPreviousExchanges uint32
	// PreviousEffectiveRouteReferences counts retained old references.
	PreviousEffectiveRouteReferences uint32
	// Changed reports whether the binding changed.
	Changed bool
	// Replayed reports an idempotent history replay.
	Replayed bool
}

// Health is a copied pointer-free Core health snapshot.
type Health struct {
	// Lifecycle is Core's lifecycle state.
	Lifecycle uint32
	// SnapshotSequence is the snapshot version.
	SnapshotSequence uint64
	// ChangeSequence is the latest state-change version.
	ChangeSequence uint64
	// LifecycleGeneration is the lifecycle revision.
	LifecycleGeneration uint64
	// ObservedMonotonicNanos is the snapshot timestamp.
	ObservedMonotonicNanos uint64
	// ProgressSequence is the latest forward-progress counter.
	ProgressSequence uint64
	// ProgressMonotonicNanos is the latest progress timestamp.
	ProgressMonotonicNanos uint64
	// AcknowledgedProbeSequence is the last liveness probe acknowledgement.
	AcknowledgedProbeSequence uint64
	// AcknowledgedProbeMonotonicNanos is its monotonic timestamp.
	AcknowledgedProbeMonotonicNanos uint64
	// ConfiguredComponents counts configured runtime components.
	ConfiguredComponents uint32
	// RunningComponents counts running runtime components.
	RunningComponents uint32
	// FailedComponents counts failed runtime components.
	FailedComponents uint32
	// Startup is Core's startup status.
	Startup uint32
	// Liveness is Core's liveness status.
	Liveness uint32
	// Readiness is Core's readiness status.
	Readiness uint32
	// AdmissionOpen reports whether inbound admission is open.
	AdmissionOpen bool
	// Partial reports incomplete health data.
	Partial bool
	// ServerActiveExchanges counts active inbound exchanges.
	ServerActiveExchanges uint32
	// ClientActiveCalls counts active outbound calls.
	ClientActiveCalls uint32
	// ClientReadyTerminals counts ready outbound terminals.
	ClientReadyTerminals uint32
	// ClientOutstandingTerminalLeases counts unreleased outbound leases.
	ClientOutstandingTerminalLeases uint32
	// ClientRetainedRequestBytes counts retained outbound request bytes.
	ClientRetainedRequestBytes uint64
	// ClientRetainedTargetProfileBytes counts retained target profile bytes.
	ClientRetainedTargetProfileBytes uint64
	// ClientRetainedResponseBytes counts retained outbound response bytes.
	ClientRetainedResponseBytes uint64
	// ClientAdmittedCalls counts admitted outbound calls.
	ClientAdmittedCalls uint64
	// ClientTerminalCalls counts terminal outbound calls.
	ClientTerminalCalls uint64
	// ClientStaleProviderTerminals counts discarded stale provider completions.
	ClientStaleProviderTerminals uint64
}

// MonitorPolicy is the live mutable subset of monitoring configuration.
type MonitorPolicy struct {
	// Collection selects disabled, aggregate, or event collection.
	Collection MonitorCollection
	// Notification selects polling or a reserved signal path.
	Notification MonitorNotification
	// Latency selects fixed histogram collection.
	Latency MonitorLatency
	// Detail selects runtime-safe detail retention.
	Detail MonitorDetail
	// ActiveEventCapacity selects active slots within the reservation.
	ActiveEventCapacity uint32
	// ActiveDetailBytes selects retained bytes within the reservation.
	ActiveDetailBytes uint32
	// AggregateCategories selects aggregate categories.
	AggregateCategories uint64
	// EventCategories selects retained event categories.
	EventCategories uint64
}

// MonitorConfig is the copied effective monitoring configuration.
type MonitorConfig struct {
	// Provenance identifies configuration origin.
	Provenance uint32
	// Generation is used for optimistic live updates.
	Generation uint64
	// CollectionEpoch identifies the current collection epoch.
	CollectionEpoch uint64
	// ChangeSequence is the latest observed runtime change.
	ChangeSequence uint64
	// EpochStartedMonotonicNanos is the epoch start timestamp.
	EpochStartedMonotonicNanos uint64
	// PolicyAppliedMonotonicNanos is the policy application timestamp.
	PolicyAppliedMonotonicNanos uint64
	// SupportedCategories is Core's supported category bit set.
	SupportedCategories uint64
	// ReservedEventCapacity is the construction-time slot reservation.
	ReservedEventCapacity uint32
	// MaxEventsPerRead is the construction-time page bound.
	MaxEventsPerRead uint32
	// ReservedDetailBytesPerEvent is the detail reservation.
	ReservedDetailBytesPerEvent uint32
	// ReservedLatencyBucketCount is the histogram reservation.
	ReservedLatencyBucketCount uint32
	// SignalReserved reports whether signaling was reserved.
	SignalReserved bool
	// Policy is the effective live policy.
	Policy MonitorPolicy
}

// MonitorApplyOutcome is a typed accepted or rejected live policy result.
type MonitorApplyOutcome struct {
	// Reason explains application or rejection.
	Reason MonitorApplyReason
	// Actual is the observed value for a bound rejection.
	Actual uint64
	// Limit is the reserved bound for a rejection.
	Limit uint64
	// Changed reports whether the policy changed.
	Changed bool
	// Effective is the effective configuration after the attempt.
	Effective MonitorConfig
}

// MonitorFailureCount is one bounded failure counter.
type MonitorFailureCount struct {
	// Reason is Core's failure reason.
	Reason uint32
	// Count is the cumulative count for the current epoch.
	Count uint64
}

// MonitorLatencyBucket is one fixed histogram bucket.
type MonitorLatencyBucket struct {
	// UpperBoundNanos is the inclusive bucket ceiling.
	UpperBoundNanos uint64
	// Count is the cumulative bucket count.
	Count uint64
}

// MonitorSnapshot is a copied aggregate and health observation.
type MonitorSnapshot struct {
	// Collecting reports active collection.
	Collecting bool
	// Stale reports a snapshot behind current truth.
	Stale bool
	// Partial reports incomplete values.
	Partial bool
	// SnapshotSequence identifies the snapshot.
	SnapshotSequence uint64
	// ObservedMonotonicNanos is the observation timestamp.
	ObservedMonotonicNanos uint64
	// CollectedChangeSequence is the latest included change.
	CollectedChangeSequence uint64
	// InboundAdmittedRequests counts admitted requests.
	InboundAdmittedRequests uint64
	// InboundRequestBytes counts admitted request bytes.
	InboundRequestBytes uint64
	// ExchangeCompleted counts completed exchanges.
	ExchangeCompleted uint64
	// ExchangeFailed counts failed exchanges.
	ExchangeFailed uint64
	// ExchangeTimedOut counts timed-out exchanges.
	ExchangeTimedOut uint64
	// ExchangeDisconnected counts disconnected exchanges.
	ExchangeDisconnected uint64
	// ExchangeCancelled counts cancelled exchanges.
	ExchangeCancelled uint64
	// ResponseStatusFamily contains 1xx through 5xx counts.
	ResponseStatusFamily [5]uint64
	// RetainedEvents is the current event ring occupancy.
	RetainedEvents uint64
	// EventOverwriteCount counts overwritten retained events.
	EventOverwriteCount uint64
	// EventDropCount counts dropped events.
	EventDropCount uint64
	// SignalNotifyCount counts notification attempts.
	SignalNotifyCount uint64
	// SignalCoalescedCount counts coalesced notifications.
	SignalCoalescedCount uint64
	// SignalFailureCount counts notification failures.
	SignalFailureCount uint64
	// Config is the effective monitoring configuration.
	Config MonitorConfig
	// Health is the co-observed health snapshot.
	Health Health
	// FailureCounts contains the populated bounded failure counters.
	FailureCounts []MonitorFailureCount
	// LatencyBuckets contains the populated fixed histogram buckets.
	LatencyBuckets []MonitorLatencyBucket
}

// MonitorEvent is one copied pointer-free operational event.
type MonitorEvent struct {
	// Kind identifies the event.
	Kind MonitorEventKind
	// Sequence is the event cursor.
	Sequence uint64
	// ChangeSequence is the associated runtime change.
	ChangeSequence uint64
	// ConfigGeneration is the monitoring configuration generation.
	ConfigGeneration uint64
	// CollectionEpoch is the event collection epoch.
	CollectionEpoch uint64
	// ObservedMonotonicNanos is the event timestamp.
	ObservedMonotonicNanos uint64
	// Category is the event category bit.
	Category uint64
	// FailureReason is an optional Core failure reason.
	FailureReason uint32
	// QueueScope identifies an optional bounded queue.
	QueueScope uint32
	// QueueDepth is the observed queue occupancy.
	QueueDepth uint32
	// QueueCapacity is the configured queue ceiling.
	QueueCapacity uint32
	// Exchange is the optional associated exchange.
	Exchange ExchangeID
	// Detail is bounded runtime-safe detail, never application payload.
	Detail string
}

// MonitorEventPage is one cursor-based bounded monitoring page.
type MonitorEventPage struct {
	// Events contains at most the requested and reserved maximum.
	Events []MonitorEvent
	// OldestAvailableSequence is the oldest retained cursor.
	OldestAvailableSequence uint64
	// LatestSequence is the latest retained cursor.
	LatestSequence uint64
	// MissedEvents counts overwritten events after the supplied cursor.
	MissedEvents uint64
	// RemainingEvents counts newer retained events not in this page.
	RemainingEvents uint64
}
