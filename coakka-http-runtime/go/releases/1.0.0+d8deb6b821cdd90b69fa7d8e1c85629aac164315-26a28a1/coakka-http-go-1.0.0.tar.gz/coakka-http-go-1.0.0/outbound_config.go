package coakkahttp

// OutboundOptions reserves all native client lanes and optional resolver and
// connection-pool resources.
type OutboundOptions struct {
	// ResolverEnabled enables the configured native resolver.
	ResolverEnabled bool
	// PoolEnabled enables native connection pooling.
	PoolEnabled bool
	// Lane configures call admission and retained request/response bounds.
	Lane OutboundLaneLimits
	// Transport configures native transport buffers and parsing bounds.
	Transport OutboundTransportLimits
	// Resolver configures the optional native resolver.
	Resolver OutboundResolver
	// Pool configures optional per-key connection pooling.
	Pool OutboundPoolLimits
	// TLS reserves outbound trust and identity material.
	TLS OutboundTLSLimits
	// Registry reserves named target and endpoint topology.
	Registry OutboundRegistryLimits
}

// OutboundLaneLimits bounds native client call state. Zero-valued fields use
// Core defaults.
type OutboundLaneLimits struct {
	// CallCapacity bounds active and terminal calls.
	CallCapacity uint32
	// TargetProfileCapacity bounds retained target profiles.
	TargetProfileCapacity uint32
	// WorkBatch bounds client lane work per runtime turn.
	WorkBatch uint32
	// MaxMethodBytes bounds an outbound method.
	MaxMethodBytes uint32
	// MaxOriginTargetBytes bounds an encoded origin target.
	MaxOriginTargetBytes uint32
	// MaxProfileComponentBytes bounds one target-profile component.
	MaxProfileComponentBytes uint32
	// MaxTotalProfileBytes bounds all retained target profiles.
	MaxTotalProfileBytes uint64
	// MaxHeaderCount bounds outbound request headers.
	MaxHeaderCount uint32
	// MaxHeaderNameBytes bounds one outbound header name.
	MaxHeaderNameBytes uint32
	// MaxHeaderValueBytes bounds one outbound header value.
	MaxHeaderValueBytes uint32
	// MaxHeaderBytes bounds an outbound request header block.
	MaxHeaderBytes uint32
	// MaxRequestBodyBytes bounds one outbound request body.
	MaxRequestBodyBytes uint64
	// MaxTotalRequestBytes bounds all retained outbound requests.
	MaxTotalRequestBytes uint64
	// MaxResponseHeadBytes bounds one retained response head.
	MaxResponseHeadBytes uint64
	// MaxResponseBodyBytes bounds one retained response body.
	MaxResponseBodyBytes uint64
	// MaxTotalResponseBytes bounds all retained responses.
	MaxTotalResponseBytes uint64
	// DeadlineTickMillis selects deadline scan frequency.
	DeadlineTickMillis uint32
	// StopTimeoutMillis bounds client stop.
	StopTimeoutMillis uint32
}

// OutboundTransportLimits bounds native socket and HTTP response storage.
type OutboundTransportLimits struct {
	// ActiveCallCapacity bounds transport-owned calls.
	ActiveCallCapacity uint32
	// MaxResponseHeaderCount bounds one response's headers.
	MaxResponseHeaderCount uint32
	// MaxResponseHeaderNameBytes bounds one response header name.
	MaxResponseHeaderNameBytes uint32
	// MaxResponseHeaderValueBytes bounds one response header value.
	MaxResponseHeaderValueBytes uint32
	// MaxResponseHeadBytes bounds one response head.
	MaxResponseHeadBytes uint64
	// MaxResponseBodyBytes bounds one response body.
	MaxResponseBodyBytes uint64
	// MaxTotalBufferBytes bounds all transport buffers.
	MaxTotalBufferBytes uint64
	// MaxSerializedURLBytes bounds one URL projection.
	MaxSerializedURLBytes uint32
	// MaxResolveEntryBytes bounds one resolver result.
	MaxResolveEntryBytes uint32
}

// OutboundResolver configures the optional Core-owned resolver.
type OutboundResolver struct {
	// MaxResolvedAddresses bounds addresses retained per lookup.
	MaxResolvedAddresses uint32
	// ServerEndpoint selects the resolver service endpoint.
	ServerEndpoint string
	// SocketCapacity bounds resolver sockets.
	SocketCapacity uint32
	// TimeoutMillis bounds one lookup attempt.
	TimeoutMillis uint32
	// Tries bounds lookup attempts.
	Tries uint32
}

// OutboundPoolLimits bounds native connection pooling by topology key.
type OutboundPoolLimits struct {
	// KeyCapacity bounds retained pool keys.
	KeyCapacity uint32
	// MaxConnectionsPerKey bounds live connections for one key.
	MaxConnectionsPerKey uint32
	// MaxWaitingPerKey bounds calls waiting for one key.
	MaxWaitingPerKey uint32
	// MaxIdleSeconds bounds idle connection lifetime.
	MaxIdleSeconds uint32
	// MaxLifetimeSeconds bounds absolute connection lifetime.
	MaxLifetimeSeconds uint32
}

// OutboundTLSLimits reserves bounded outbound credential storage.
type OutboundTLSLimits struct {
	// TrustCapacity bounds trust bundle generations.
	TrustCapacity uint32
	// ClientIdentityCapacity bounds client identity generations.
	ClientIdentityCapacity uint32
	// MaxTrustBundleBytes bounds one CA bundle.
	MaxTrustBundleBytes uint64
	// MaxClientCertificateBytes bounds one client certificate chain.
	MaxClientCertificateBytes uint64
	// MaxClientPrivateKeyBytes bounds one client private key.
	MaxClientPrivateKeyBytes uint64
	// MaxTotalBytes bounds all outbound TLS material.
	MaxTotalBytes uint64
}

// OutboundRegistryLimits reserves named targets and endpoint topology.
type OutboundRegistryLimits struct {
	// TargetCapacity bounds named targets.
	TargetCapacity uint32
	// EndpointCapacity bounds total endpoints.
	EndpointCapacity uint32
	// MaxEndpointsPerTarget bounds endpoints on one target.
	MaxEndpointsPerTarget uint32
	// MaxTargetNameBytes bounds a logical target name.
	MaxTargetNameBytes uint32
	// MaxNodeIDBytes bounds an endpoint node identifier.
	MaxNodeIDBytes uint32
	// MaxTotalBytes bounds retained registry text.
	MaxTotalBytes uint64
}

// OutboundEndpoint declares one Core-owned connection destination.
type OutboundEndpoint struct {
	// Weight participates in weighted round-robin selection.
	Weight uint32
	// NodeID is the stable topology node identifier.
	NodeID string
	// ConnectHost is the DNS name or address Core connects to.
	ConnectHost string
	// ConnectPort is the destination port.
	ConnectPort uint16
	// HTTPAuthority is the HTTP Host or :authority value.
	HTTPAuthority string
	// Security selects plaintext, TLS, or mutual TLS.
	Security TransportSecurity
	// Available optionally controls endpoint admission. Nil keeps Core's
	// available-by-default initializer; a pointer to false disables the endpoint.
	Available *bool
	// TLSPeerIdentity is the expected peer identity.
	TLSPeerIdentity string
	// ProxyMode is the Core-defined proxy mode.
	ProxyMode uint32
	// ProtocolPolicy is the Core-defined HTTP protocol policy.
	ProtocolPolicy uint32
	// ConnectionStrategy is the Core-defined connection strategy.
	ConnectionStrategy uint32
	// ProxyIdentity is the stable proxy identity.
	ProxyIdentity string
	// TLSTrustGeneration selects an added trust bundle.
	TLSTrustGeneration uint64
	// TLSClientIdentityGeneration selects an added client identity.
	TLSClientIdentityGeneration uint64
	// ConnectionStrategyGeneration versions connection behavior.
	ConnectionStrategyGeneration uint64
	// LocalNetworkPolicyID selects Core's local-network admission policy.
	LocalNetworkPolicyID uint64
}

// OutboundTarget declares a named, generation-scoped endpoint set.
type OutboundTarget struct {
	// Name is the logical target used by outbound requests.
	Name string
	// Generation versions the target topology.
	Generation uint64
	// Strategy selects single-owner or weighted round-robin routing.
	Strategy OutboundStrategy
	// Endpoints are copied into Core in declaration order.
	Endpoints []OutboundEndpoint
}

// OutboundTrust supplies one generation-keyed CA bundle copied by Core.
type OutboundTrust struct {
	// Generation is referenced by outbound endpoints.
	Generation uint64
	// CAPEM contains PEM-encoded trust roots.
	CAPEM []byte
}

// OutboundIdentity supplies one generation-keyed mutual-TLS identity.
type OutboundIdentity struct {
	// Generation is referenced by outbound endpoints.
	Generation uint64
	// CertificateChainPEM contains the PEM certificate chain.
	CertificateChainPEM []byte
	// PrivateKeyPEM contains the PEM private key.
	PrivateKeyPEM []byte
}
