package coakkahttp

import (
	"errors"
	"strings"
)

const maximumHeaders = 1 << 16

// ExchangeID is a generation-checked inbound exchange handle.
type ExchangeID struct {
	// Slot is the bounded Core slot.
	Slot uint64
	// Generation prevents stale handle reuse.
	Generation uint64
}

// WebSocketID is a generation-checked Core-owned session handle.
type WebSocketID struct {
	// Slot is the bounded Core slot.
	Slot uint64
	// Generation prevents stale handle reuse.
	Generation uint64
}

// OutboundID is a generation-checked Core-owned client call handle.
type OutboundID struct {
	// Slot is the bounded Core slot.
	Slot uint64
	// Generation prevents stale handle reuse.
	Generation uint64
}

// Header is one copied HTTP field. NewHeader validates it before native use.
type Header struct {
	// Name is an RFC token field name.
	Name string
	// Value excludes NUL, carriage return, and line feed.
	Value string
}

// NewHeader validates and returns one HTTP header.
func NewHeader(name, value string) (Header, error) {
	if name == "" || len(name) > maximumBridgeBytes {
		return Header{}, errors.New("HTTP header name is invalid")
	}
	for index := range len(name) {
		if !headerNameByte(name[index]) {
			return Header{}, errors.New("HTTP header name is invalid")
		}
	}
	if len(value) > maximumBridgeBytes || strings.ContainsAny(value, "\x00\r\n") {
		return Header{}, errors.New("HTTP header value is invalid")
	}
	return Header{Name: name, Value: value}, nil
}

func headerNameByte(value byte) bool {
	return value >= '0' && value <= '9' || value >= 'A' && value <= 'Z' ||
		value >= 'a' && value <= 'z' || strings.ContainsRune("!#$%&'*+-.^_`|~", rune(value))
}

// Headers preserves declaration order and duplicate names.
type Headers struct {
	entries []Header
}

// NewHeaders validates and defensively copies every entry.
func NewHeaders(entries ...Header) (Headers, error) {
	if len(entries) > maximumHeaders {
		return Headers{}, errors.New("HTTP header count exceeds the Go bound")
	}
	owned := make([]Header, len(entries))
	for index, entry := range entries {
		validated, err := NewHeader(entry.Name, entry.Value)
		if err != nil {
			return Headers{}, err
		}
		owned[index] = validated
	}
	return Headers{entries: owned}, nil
}

// Get returns the first case-insensitive value for name.
func (headers Headers) Get(name string) (string, bool) {
	for _, header := range headers.entries {
		if strings.EqualFold(header.Name, name) {
			return header.Value, true
		}
	}
	return "", false
}

// GetAll returns every case-insensitive value for name in wire order.
func (headers Headers) GetAll(name string) []string {
	values := make([]string, 0)
	for _, header := range headers.entries {
		if strings.EqualFold(header.Name, name) {
			values = append(values, header.Value)
		}
	}
	return values
}

// Entries returns a defensive copy of the ordered fields.
func (headers Headers) Entries() []Header {
	return append([]Header(nil), headers.entries...)
}

// PathParameter is one named route capture with its encoded value.
type PathParameter struct {
	// Name is the copied route capture name.
	Name string
	// EncodedValue is the copied, still-encoded path value.
	EncodedValue string
}

// QueryParameter is one ordered encoded query item.
type QueryParameter struct {
	// EncodedKey is the copied, still-encoded key.
	EncodedKey string
	// EncodedValue is the copied, still-encoded value.
	EncodedValue string
	// HasValue distinguishes `key` from `key=`.
	HasValue bool
}

// Request is a fully Go-owned projection of an inbound request event.
type Request struct {
	// Exchange is the generation-checked exchange handle.
	Exchange ExchangeID
	// Method is the normalized HTTP method.
	Method string
	// Scheme is the request scheme reported by Core.
	Scheme string
	// Authority is the HTTP authority reported by Core.
	Authority string
	// Target is the encoded origin target including its query.
	Target string
	// Headers preserves request header order and duplicates.
	Headers Headers
	// PathParameters contains ordered route captures.
	PathParameters []PathParameter
	// QueryParameters contains ordered encoded query items.
	QueryParameters []QueryParameter
	// Trailers contains buffered request trailers when available on the request event.
	Trailers Headers
	// RouteID identifies the matched route.
	RouteID uint64
	// RouteGeneration identifies the matched route table generation.
	RouteGeneration uint64
	// BindingRevision identifies the handler binding revision.
	BindingRevision uint64
	// HandlerBindingID selects the application handler registered for this event.
	HandlerBindingID uint64
	// BodyDelivery reports inline or streamed body delivery.
	BodyDelivery BodyDelivery
	body         []byte
}

// Bytes returns a defensive copy of the inline request body.
func (request *Request) Bytes() []byte {
	if request == nil {
		return nil
	}
	return append([]byte(nil), request.body...)
}

// Text returns the inline request body as a Go string.
func (request *Request) Text() string {
	if request == nil {
		return ""
	}
	return string(request.body)
}

// TerminalSummary is a pointer-free copied terminal exchange observation.
type TerminalSummary struct {
	// Outcome is the terminal exchange state.
	Outcome ExchangeOutcome
	// ResponseStatus is the accepted HTTP response status.
	ResponseStatus uint32
	// FailureDomain is Core's typed failure domain.
	FailureDomain uint32
	// FailurePhase is Core's typed failure phase.
	FailurePhase uint32
	// FailureReason is Core's typed failure reason.
	FailureReason uint32
	// RetryDisposition is Core's retry classification.
	RetryDisposition uint32
	// HTTPStatusHint is the optional mapped HTTP status.
	HTTPStatusHint uint32
	// HasResponse reports whether a response was accepted.
	HasResponse bool
	// HasFailure reports whether failure fields are present.
	HasFailure bool
	// HasHTTPStatusHint reports whether HTTPStatusHint is present.
	HasHTTPStatusHint bool
	// DetailTruncated reports that Detail is a prefix.
	DetailTruncated bool
	// HasAdmittedTime reports whether AdmittedMonotonicNanos is present.
	HasAdmittedTime bool
	// HasDispatchedTime reports whether DispatchedMonotonicNanos is present.
	HasDispatchedTime bool
	// HasResponseAcceptedTime reports whether ResponseAcceptedMonotonicNanos is present.
	HasResponseAcceptedTime bool
	// HasCompletedTime reports whether CompletedMonotonicNanos is present.
	HasCompletedTime bool
	// AdmittedMonotonicNanos is the request admission timestamp.
	AdmittedMonotonicNanos uint64
	// DispatchedMonotonicNanos is the connector dispatch timestamp.
	DispatchedMonotonicNanos uint64
	// ResponseAcceptedMonotonicNanos is the first-completion timestamp.
	ResponseAcceptedMonotonicNanos uint64
	// CompletedMonotonicNanos is the terminal timestamp.
	CompletedMonotonicNanos uint64
	// DetailSize is the original diagnostic size.
	DetailSize uint64
	// Detail is the bounded copied diagnostic prefix.
	Detail string
}

// Event is a copied inbound lane item. TakeEvent releases the native lease
// before returning, so every slice and nested value is Go-owned.
type Event struct {
	// Kind identifies the event payload.
	Kind EventKind
	// Exchange identifies the exchange.
	Exchange ExchangeID
	// Sequence is the Core event sequence.
	Sequence uint64
	// HandlerBindingID selects application dispatch.
	HandlerBindingID uint64
	// Data is copied event-specific stream data.
	Data []byte
	// Request is present for EventRequest.
	Request *Request
	// StreamTrailers is present for a streamed trailer event.
	StreamTrailers Headers
	// Terminal is present for EventTerminal.
	Terminal *TerminalSummary
}

// Response is a copied buffered response or response-stream head.
type Response struct {
	// Status is an HTTP status from 100 through 599.
	Status uint32
	// Headers preserves response field order and duplicates.
	Headers Headers
	body    []byte
}

// NewResponse validates and copies one buffered response.
func NewResponse(status uint32, headers Headers, body []byte) (Response, error) {
	if status < 100 || status > 599 || len(body) > maximumBridgeBytes {
		return Response{}, errors.New("HTTP response status or body is invalid")
	}
	validated, err := NewHeaders(headers.entries...)
	if err != nil {
		return Response{}, err
	}
	return Response{Status: status, Headers: validated, body: append([]byte(nil), body...)}, nil
}

// Bytes returns a defensive copy of the response body.
func (response Response) Bytes() []byte {
	return append([]byte(nil), response.body...)
}

// Text returns a validated UTF-8-compatible plain text response.
func Text(status uint32, body string) (Response, error) {
	header, err := NewHeader("content-type", "text/plain; charset=utf-8")
	if err != nil {
		return Response{}, err
	}
	headers, err := NewHeaders(header)
	if err != nil {
		return Response{}, err
	}
	return NewResponse(status, headers, []byte(body))
}

// Bytes returns a validated response that owns a copy of body.
func Bytes(status uint32, body []byte) (Response, error) {
	return NewResponse(status, Headers{}, body)
}

// Empty returns a validated response with no headers or body.
func Empty(status uint32) (Response, error) {
	return NewResponse(status, Headers{}, nil)
}

// FileResponse serves a path under a configured Core file authority.
type FileResponse struct {
	// Head supplies status and headers; its body should be empty.
	Head Response
	// AuthorityID selects a configured file root.
	AuthorityID uint64
	// EncodedPath is resolved and opened by Core under that root.
	EncodedPath string
}

// Failure submits a typed application failure as the exchange's first completion.
type Failure struct {
	// Reason is the Core-defined failure reason.
	Reason uint32
	// Detail is copied into Core's bounded diagnostic storage.
	Detail string
}

// SSEEvent is one copied server-sent event write.
type SSEEvent struct {
	// Data is the event payload.
	Data []byte
	// EventType is the optional event field.
	EventType string
	// ID is the optional id field.
	ID string
	// RetryMillis is the optional client retry delay.
	RetryMillis uint64
	// HasEventType distinguishes an empty field from absence.
	HasEventType bool
	// HasID distinguishes an empty field from absence.
	HasID bool
	// HasRetry distinguishes zero from absence.
	HasRetry bool
}

// SocketEvent is a copied WebSocket lane item. TakeWebSocket releases its
// native lease before returning.
type SocketEvent struct {
	// Kind identifies the WebSocket event.
	Kind SocketEventKind
	// Session is the generation-checked WebSocket handle.
	Session WebSocketID
	// OriginExchange identifies the upgrade request.
	OriginExchange ExchangeID
	// CloseCode carries a close event's status code.
	CloseCode uint32
	// Data is copied event data or close reason.
	Data []byte
}

// ClientRequest submits one buffered outbound call to a logical target.
type ClientRequest struct {
	// TimeoutMillis is the monotonic call deadline.
	TimeoutMillis uint32
	// LogicalTarget selects a configured target.
	LogicalTarget string
	// Method is the outbound HTTP method.
	Method string
	// Target is the encoded origin target.
	Target string
	// Headers preserves outbound field order and duplicates.
	Headers Headers
	// Body is copied before SubmitOutbound returns successfully.
	Body []byte
}

// ClientTerminal is a copied outbound terminal. TakeOutbound releases the
// native response lease before returning.
type ClientTerminal struct {
	// Reason is Core's terminal reason.
	Reason uint32
	// Call is the generation-checked outbound call handle.
	Call OutboundID
	// LogicalTarget is the selected logical target.
	LogicalTarget string
	// TargetGeneration is the selected topology generation.
	TargetGeneration uint64
	// SelectedNodeID is the selected endpoint node.
	SelectedNodeID string
	// Phase is Core's terminal phase.
	Phase uint32
	// Retry is Core's retry disposition.
	Retry uint32
	// Certainty is Core's delivery certainty.
	Certainty uint32
	// ResponseStatus is the received HTTP status.
	ResponseStatus uint16
	// ProviderCode is the native provider result.
	ProviderCode int32
	// ResponseHeaders are copied before lease release.
	ResponseHeaders Headers
	// ResponseBody is copied before lease release.
	ResponseBody []byte
	// Diagnostic is copied before lease release.
	Diagnostic string
}

// Handler processes one copied inline Request and returns one buffered response.
type Handler func(*Request) (Response, error)
