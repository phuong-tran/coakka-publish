package coakkahttp

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"
)

const (
	maximumRoutes       = 1024
	servicePollInterval = 100 * time.Millisecond
)

var serviceMethods = map[string]struct{}{
	"DELETE": {},
	"GET":    {},
	"PATCH":  {},
	"POST":   {},
	"PUT":    {},
}

// Limits contains the buffered Service's principal Core and pump bounds.
type Limits struct {
	// MaxConnections bounds accepted connections retained by Core.
	MaxConnections uint32
	// MaxActiveRequests bounds concurrent exchanges retained by Core.
	MaxActiveRequests uint32
	// RequestQueueCapacity bounds requests waiting for a Go worker.
	RequestQueueCapacity uint32
	// ResponseQueueCapacity bounds native response completions.
	ResponseQueueCapacity uint32
	// MaxRequestBodyBytes bounds one inline request body.
	MaxRequestBodyBytes uint64
	// MaxResponseBodyBytes bounds one buffered response body.
	MaxResponseBodyBytes uint64
	// RequestTimeoutMillis bounds application response latency in Core.
	RequestTimeoutMillis uint32
	// ShutdownTimeoutMillis bounds native drain and stop.
	ShutdownTimeoutMillis uint32
}

// DefaultLimits returns conservative finite bounds for a small service.
func DefaultLimits() Limits {
	return Limits{
		MaxConnections:        128,
		MaxActiveRequests:     64,
		RequestQueueCapacity:  64,
		ResponseQueueCapacity: 64,
		MaxRequestBodyBytes:   1 << 20,
		MaxResponseBodyBytes:  4 << 20,
		RequestTimeoutMillis:  30_000,
		ShutdownTimeoutMillis: 5_000,
	}
}

// Validate rejects zero, excessive, or inconsistent Service limits.
func (limits Limits) Validate() error {
	if limits.MaxConnections == 0 || limits.MaxConnections > 65_536 ||
		limits.MaxActiveRequests == 0 || limits.MaxActiveRequests > limits.MaxConnections ||
		limits.RequestQueueCapacity == 0 || limits.RequestQueueCapacity > limits.MaxActiveRequests ||
		limits.ResponseQueueCapacity == 0 || limits.ResponseQueueCapacity > limits.MaxActiveRequests ||
		limits.MaxRequestBodyBytes == 0 || limits.MaxRequestBodyBytes > maximumBridgeBytes ||
		limits.MaxResponseBodyBytes == 0 || limits.MaxResponseBodyBytes > maximumBridgeBytes ||
		limits.RequestTimeoutMillis == 0 || limits.ShutdownTimeoutMillis == 0 {
		return errors.New("CoAkka HTTP service limits are invalid")
	}
	return nil
}

type routeDeclaration struct {
	route   Route
	handler Handler
}

// Builder collects one buffered inline-body Service declaration. Configure it
// from one goroutine and call Start once. Advanced and streaming applications
// should construct Config directly and use Open.
type Builder struct {
	host     string
	port     uint16
	workers  uint32
	limits   Limits
	routes   []routeDeclaration
	started  bool
	deferred error
}

// NewBuilder returns a loopback builder with conservative finite defaults.
func NewBuilder() *Builder {
	return &Builder{host: "127.0.0.1", workers: 1, limits: DefaultLimits()}
}

// Listen selects the bind host and port. Port zero requests an available port.
func (builder *Builder) Listen(host string, port uint16) *Builder {
	if !builder.mutable() {
		return builder
	}
	if strings.TrimSpace(host) == "" || strings.ContainsRune(host, '\x00') {
		builder.deferred = errors.New("listener host is invalid")
		return builder
	}
	builder.host, builder.port = host, port
	return builder
}

// Concurrency selects the fixed number of Go handler workers.
func (builder *Builder) Concurrency(workers uint32) *Builder {
	if !builder.mutable() {
		return builder
	}
	if workers == 0 || workers > 1024 {
		builder.deferred = errors.New("handler worker count is invalid")
		return builder
	}
	builder.workers = workers
	return builder
}

// Limits replaces every principal Service resource ceiling.
func (builder *Builder) Limits(limits Limits) *Builder {
	if !builder.mutable() {
		return builder
	}
	if err := limits.Validate(); err != nil {
		builder.deferred = err
		return builder
	}
	builder.limits = limits
	return builder
}

// Handle registers a buffered inline-body handler for one method and pattern.
func (builder *Builder) Handle(method, pattern string, handler Handler) *Builder {
	if !builder.mutable() {
		return builder
	}
	normalized := strings.ToUpper(strings.TrimSpace(method))
	_, supported := serviceMethods[normalized]
	if !supported || !strings.HasPrefix(pattern, "/") || handler == nil {
		builder.deferred = errors.New("route declaration is invalid")
		return builder
	}
	if len(builder.routes) >= maximumRoutes {
		builder.deferred = errors.New("route count exceeds the Service bound")
		return builder
	}
	id := uint64(len(builder.routes) + 1)
	builder.routes = append(builder.routes, routeDeclaration{
		route: Route{
			ID:               id,
			HandlerBindingID: id,
			Method:           normalized,
			Pattern:          pattern,
			BodyDelivery:     BodyInline,
			BodyPolicy: BodyPolicy{
				Enabled:      true,
				AcceptAbsent: true,
				AcceptOther:  true,
				MaxBodyBytes: builder.limits.MaxRequestBodyBytes,
			},
		},
		handler: handler,
	})
	return builder
}

// Get registers a GET handler.
func (builder *Builder) Get(pattern string, handler Handler) *Builder {
	return builder.Handle("GET", pattern, handler)
}

// Post registers a POST handler.
func (builder *Builder) Post(pattern string, handler Handler) *Builder {
	return builder.Handle("POST", pattern, handler)
}

// Put registers a PUT handler.
func (builder *Builder) Put(pattern string, handler Handler) *Builder {
	return builder.Handle("PUT", pattern, handler)
}

// Patch registers a PATCH handler.
func (builder *Builder) Patch(pattern string, handler Handler) *Builder {
	return builder.Handle("PATCH", pattern, handler)
}

// Delete registers a DELETE handler.
func (builder *Builder) Delete(pattern string, handler Handler) *Builder {
	return builder.Handle("DELETE", pattern, handler)
}

func (builder *Builder) mutable() bool {
	if builder == nil {
		return false
	}
	if builder.started {
		builder.deferred = errors.New("builder can only be started once")
		return false
	}
	return true
}

// Start creates Core, starts listeners, and launches one bounded event pump
// plus the configured fixed worker set.
func (builder *Builder) Start() (*Service, error) {
	if builder == nil {
		return nil, errors.New("builder is nil")
	}
	if builder.started {
		return nil, errors.New("builder can only be started once")
	}
	builder.started = true
	if builder.deferred != nil {
		return nil, builder.deferred
	}
	if len(builder.routes) == 0 {
		return nil, errors.New("at least one route is required")
	}
	if err := builder.limits.Validate(); err != nil {
		return nil, err
	}
	limits := builder.limits
	routes := make([]Route, len(builder.routes))
	handlers := make(map[uint64]Handler, len(builder.routes))
	for index, declaration := range builder.routes {
		route := declaration.route
		route.BodyPolicy.MaxBodyBytes = limits.MaxRequestBodyBytes
		routes[index] = route
		handlers[route.HandlerBindingID] = declaration.handler
	}
	core, err := Open(Config{
		Limits: &CoreLimits{
			EventLoopThreads:              1,
			MaxListeners:                  1,
			MaxConnections:                limits.MaxConnections,
			MaxActiveExchanges:            limits.MaxActiveRequests,
			RequestQueueDepth:             limits.RequestQueueCapacity,
			CompletionQueueDepth:          limits.ResponseQueueCapacity,
			ConnectionTimeoutBatchSize:    limits.MaxConnections,
			TerminalObservationQueueDepth: limits.MaxActiveRequests,
			MaxRequestBodyBytes:           limits.MaxRequestBodyBytes,
			MaxResponseBodyBytes:          limits.MaxResponseBodyBytes,
			MaxSerializedResponseBytes:    limits.MaxResponseBodyBytes + (1 << 20),
			AppHostTimeoutMillis:          uint64(limits.RequestTimeoutMillis),
			DrainTimeoutMillis:            uint64(limits.ShutdownTimeoutMillis),
			StopTimeoutMillis:             uint64(limits.ShutdownTimeoutMillis),
		},
		Listeners: []Listener{{ID: 1, Protocol: ProtocolHTTP11, BindAddress: builder.host, Port: builder.port, Security: SecurityPlaintext}},
		Routes:    routes,
	})
	if err != nil {
		return nil, err
	}
	if err = core.Start(); err != nil {
		_ = core.Close()
		return nil, err
	}
	service := &Service{
		core:     core,
		routes:   routes,
		handlers: handlers,
		jobs:     make(chan *Request, limits.RequestQueueCapacity),
		pending:  make(map[ExchangeID]struct{}, limits.MaxActiveRequests),
	}
	for worker := uint32(0); worker < builder.workers; worker++ {
		service.workers.Add(1)
		go service.runWorker()
	}
	service.pump.Add(1)
	go service.runPump()
	return service, nil
}

type diagnosticQueue struct {
	mu     sync.Mutex
	values []error
}

func (queue *diagnosticQueue) add(err error) {
	if err == nil {
		return
	}
	queue.mu.Lock()
	defer queue.mu.Unlock()
	if len(queue.values) == 64 {
		copy(queue.values, queue.values[1:])
		queue.values = queue.values[:63]
	}
	queue.values = append(queue.values, err)
}

func (queue *diagnosticQueue) take() error {
	queue.mu.Lock()
	defer queue.mu.Unlock()
	if len(queue.values) == 0 {
		return nil
	}
	err := queue.values[0]
	copy(queue.values, queue.values[1:])
	queue.values = queue.values[:len(queue.values)-1]
	return err
}

// Service is a buffered Handler facade over the callback-free Core API.
// Close waits for admitted handlers; handlers must therefore return and must
// not call Close on their own Service.
type Service struct {
	closeMu         sync.Mutex
	closed          bool
	shutdownStarted bool
	stateMu         sync.Mutex
	closing         bool
	pending         map[ExchangeID]struct{}
	core            *Core
	routes          []Route
	handlers        map[uint64]Handler
	jobs            chan *Request
	pump            sync.WaitGroup
	workers         sync.WaitGroup
	errors          diagnosticQueue
}

// Port returns the selected port of the Service listener.
func (service *Service) Port() (uint16, error) {
	if service == nil {
		return 0, errors.New("service is closed")
	}
	return service.core.BoundPort()
}

// Routes returns a defensive copy of the Service route declarations.
func (service *Service) Routes() []Route {
	if service == nil {
		return nil
	}
	return append([]Route(nil), service.routes...)
}

// PollError removes and returns the oldest bounded pump or handler diagnostic.
func (service *Service) PollError() error {
	if service == nil {
		return nil
	}
	return service.errors.take()
}

func (service *Service) runPump() {
	defer service.pump.Done()
	for {
		event, err := service.core.TakeEvent(servicePollInterval)
		if err != nil {
			var coreErr *Error
			if errors.As(err, &coreErr) && (coreErr.Code == ResultTimeout || coreErr.Code == ResultClosed || coreErr.Code == ResultCancelled) {
				if service.pumpMayStop() {
					return
				}
				continue
			}
			if errors.Is(err, errCoreClosed) {
				return
			}
			service.errors.add(err)
			continue
		}
		if event.Kind == EventTerminal {
			service.observeTerminal(event.Exchange)
			continue
		}
		if event.Kind != EventRequest || event.Request == nil {
			continue
		}
		if service.trackRequest(event.Exchange) {
			if responseErr := service.core.Respond(event.Exchange, internalResponse()); responseErr != nil {
				service.errors.add(responseErr)
			}
			continue
		}
		select {
		case service.jobs <- event.Request:
		default:
			service.errors.add(errors.New("Go handler queue is full"))
			_ = service.core.Respond(event.Exchange, internalResponse())
		}
	}
}

// trackRequest records every request event before it can be dispatched. Once
// shutdown begins, the pump still completes already-admitted Core exchanges
// with a bounded failure instead of abandoning their terminal observations.
func (service *Service) trackRequest(exchange ExchangeID) bool {
	service.stateMu.Lock()
	defer service.stateMu.Unlock()
	service.pending[exchange] = struct{}{}
	return service.closing
}

func (service *Service) observeTerminal(exchange ExchangeID) {
	service.stateMu.Lock()
	delete(service.pending, exchange)
	service.stateMu.Unlock()
}

func (service *Service) beginShutdown() {
	service.stateMu.Lock()
	service.closing = true
	service.stateMu.Unlock()
}

// A timed-out read is the quiescence barrier: the sole reader has observed no
// queued event after shutdown began, and every request it saw reached terminal.
func (service *Service) pumpMayStop() bool {
	service.stateMu.Lock()
	defer service.stateMu.Unlock()
	return service.closing && len(service.pending) == 0
}

func (service *Service) runWorker() {
	defer service.workers.Done()
	for request := range service.jobs {
		service.handle(request)
	}
}

func (service *Service) handle(request *Request) {
	response := internalResponse()
	handler := service.handlers[request.HandlerBindingID]
	if handler == nil {
		service.errors.add(errors.New("request has no registered Go handler"))
		_ = service.core.Respond(request.Exchange, response)
		return
	}
	func() {
		defer func() {
			if recovered := recover(); recovered != nil {
				service.errors.add(fmt.Errorf("handler panic: %v", recovered))
				response = internalResponse()
			}
		}()
		value, err := handler(request)
		if err != nil {
			service.errors.add(err)
			return
		}
		response = value
	}()
	if err := service.core.Respond(request.Exchange, response); err != nil {
		service.errors.add(err)
		fallback := internalResponse()
		if response.Status != fallback.Status || string(response.body) != string(fallback.body) {
			if fallbackErr := service.core.Respond(request.Exchange, fallback); fallbackErr != nil {
				service.errors.add(fallbackErr)
			}
		}
	}
}

func internalResponse() Response {
	response, err := Text(500, "internal server error")
	if err != nil {
		panic("static internal response is invalid")
	}
	return response
}

// Close stops admission, drains admitted handlers, stops the event pump, and
// releases Core. It is idempotent and serialized for concurrent callers.
func (service *Service) Close() error {
	if service == nil {
		return nil
	}
	service.closeMu.Lock()
	defer service.closeMu.Unlock()
	if service.closed {
		return nil
	}
	var drainErr error
	if !service.shutdownStarted {
		service.shutdownStarted = true
		service.beginShutdown()
		drainErr = service.core.Drain()
		service.pump.Wait()
		close(service.jobs)
		service.workers.Wait()
	}
	closeErr := service.core.Close()
	service.closed = closeErr == nil
	return errors.Join(drainErr, closeErr)
}
