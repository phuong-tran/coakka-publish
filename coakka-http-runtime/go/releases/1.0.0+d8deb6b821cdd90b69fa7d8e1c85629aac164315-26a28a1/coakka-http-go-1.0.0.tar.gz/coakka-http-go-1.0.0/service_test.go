package coakkahttp_test

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"sync"
	"testing"
	"time"

	coakkahttp "github.com/phuong-tran/coakka-http-runtime-go"
)

func TestRequestResponseAndIdempotentClose(t *testing.T) {
	header, err := coakkahttp.NewHeader("x-reply", "two")
	if err != nil {
		t.Fatal(err)
	}
	headers, err := coakkahttp.NewHeaders(header)
	if err != nil {
		t.Fatal(err)
	}
	service, err := coakkahttp.NewBuilder().Concurrency(2).Post(
		"/echo",
		func(request *coakkahttp.Request) (coakkahttp.Response, error) {
			if request.Method != http.MethodPost || request.Target != "/echo?value=1" {
				return coakkahttp.Response{}, errors.New("request projection differs")
			}
			value, ok := request.Headers.Get("x-test")
			if !ok || value != "one" {
				return coakkahttp.Response{}, errors.New("request header differs")
			}
			return coakkahttp.NewResponse(201, headers, request.Bytes())
		},
	).Start()
	if err != nil {
		t.Fatal(err)
	}
	port, err := service.Port()
	if err != nil {
		t.Fatal(err)
	}
	request, err := http.NewRequest(http.MethodPost, fmt.Sprintf("http://127.0.0.1:%d/echo?value=1", port), bytes.NewReader([]byte("payload")))
	if err != nil {
		t.Fatal(err)
	}
	request.Header.Set("x-test", "one")
	response, err := http.DefaultClient.Do(request)
	if err != nil {
		t.Fatal(err)
	}
	body, err := io.ReadAll(response.Body)
	_ = response.Body.Close()
	if err != nil || response.StatusCode != 201 || response.Header.Get("x-reply") != "two" || string(body) != "payload" {
		t.Fatalf("response differs: status=%d header=%q body=%q err=%v", response.StatusCode, response.Header.Get("x-reply"), body, err)
	}
	if err = service.Close(); err != nil {
		t.Fatal(err)
	}
	if err = service.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestHandlerFailureReturnsBoundedResponse(t *testing.T) {
	service, err := coakkahttp.NewBuilder().Get("/fail", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Response{}, errors.New("failure from handler")
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	port, _ := service.Port()
	response, err := http.Get(fmt.Sprintf("http://127.0.0.1:%d/fail", port))
	if err != nil {
		t.Fatal(err)
	}
	body, _ := io.ReadAll(response.Body)
	_ = response.Body.Close()
	if response.StatusCode != 500 || string(body) != "internal server error" {
		t.Fatalf("failure response differs: status=%d body=%q", response.StatusCode, body)
	}
	if err := service.PollError(); err == nil || err.Error() != "failure from handler" {
		t.Fatalf("handler diagnostic differs: %v", err)
	}
}

func TestConcurrentRequestsRemainIsolated(t *testing.T) {
	service, err := coakkahttp.NewBuilder().Concurrency(4).Post("/echo", func(request *coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Bytes(200, request.Bytes())
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = service.Close() }()
	port, _ := service.Port()
	jobs := make(chan int)
	errorsFound := make(chan error, 200)
	var workers sync.WaitGroup
	for worker := 0; worker < 8; worker++ {
		workers.Add(1)
		go func() {
			defer workers.Done()
			for index := range jobs {
				expected := []byte(fmt.Sprintf("request-%d", index))
				response, err := http.Post(fmt.Sprintf("http://127.0.0.1:%d/echo", port), "application/octet-stream", bytes.NewReader(expected))
				if err != nil {
					errorsFound <- err
					continue
				}
				actual, readErr := io.ReadAll(response.Body)
				_ = response.Body.Close()
				if readErr != nil || response.StatusCode != 200 || !bytes.Equal(actual, expected) {
					errorsFound <- fmt.Errorf("request %d differs: status=%d body=%q err=%v", index, response.StatusCode, actual, readErr)
				}
			}
		}()
	}
	for index := 0; index < 200; index++ {
		jobs <- index
	}
	close(jobs)
	workers.Wait()
	close(errorsFound)
	for err := range errorsFound {
		t.Error(err)
	}
}

func TestConcurrentCloseIsIdempotent(t *testing.T) {
	service, err := coakkahttp.NewBuilder().Get("/", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Empty(204)
	}).Start()
	if err != nil {
		t.Fatal(err)
	}
	var wait sync.WaitGroup
	for index := 0; index < 32; index++ {
		wait.Add(3)
		go func() {
			defer wait.Done()
			if closeErr := service.Close(); closeErr != nil {
				t.Error(closeErr)
			}
		}()
		go func() {
			defer wait.Done()
			_ = service.PollError()
		}()
		go func() {
			defer wait.Done()
			_, _ = service.Port()
		}()
	}
	wait.Wait()
	if _, err = service.Port(); err == nil {
		t.Fatal("Port succeeded after close")
	}
}

func TestInvalidValuesFailBeforeNativeAllocation(t *testing.T) {
	if _, err := coakkahttp.NewHeader("bad name", "value"); err == nil {
		t.Fatal("invalid header name was accepted")
	}
	if _, err := coakkahttp.NewResponse(99, coakkahttp.Headers{}, nil); err == nil {
		t.Fatal("invalid response status was accepted")
	}
	if _, err := coakkahttp.Text(99, "invalid"); err == nil {
		t.Fatal("text response factory ignored an invalid status")
	}
	if _, err := coakkahttp.Bytes(600, nil); err == nil {
		t.Fatal("byte response factory ignored an invalid status")
	}
	if _, err := coakkahttp.Empty(0); err == nil {
		t.Fatal("empty response factory ignored an invalid status")
	}
	if err := (coakkahttp.Limits{}).Validate(); err == nil {
		t.Fatal("zero limits were accepted")
	}
	if _, err := coakkahttp.NewBuilder().Handle("TRACE", "/", func(*coakkahttp.Request) (coakkahttp.Response, error) {
		return coakkahttp.Empty(204)
	}).Start(); err == nil {
		t.Fatal("unsupported route was accepted")
	}
}

func TestResponseOwnsBodyAndReturnsDefensiveCopies(t *testing.T) {
	body := []byte("owned")
	response, err := coakkahttp.Bytes(200, body)
	if err != nil {
		t.Fatal(err)
	}
	body[0] = 'x'
	first := response.Bytes()
	if string(first) != "owned" {
		t.Fatalf("response did not retain its body: %q", first)
	}
	first[0] = 'x'
	if got := string(response.Bytes()); got != "owned" {
		t.Fatalf("response exposed mutable body storage: %q", got)
	}
}

func TestMain(m *testing.M) {
	http.DefaultClient.Timeout = 10 * time.Second
	os.Exit(m.Run())
}
