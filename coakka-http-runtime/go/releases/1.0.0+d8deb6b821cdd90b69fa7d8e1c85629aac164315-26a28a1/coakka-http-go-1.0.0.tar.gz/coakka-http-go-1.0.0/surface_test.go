package coakkahttp

import (
	"crypto/sha256"
	"fmt"
	"os"
	"reflect"
	"runtime"
	"strings"
	"testing"
)

// TestCoreExposesEveryABI2Capability prevents a feature family from becoming
// unreachable while the native bridge still loads its symbols.
func TestCoreExposesEveryABI2Capability(t *testing.T) {
	methods := []string{
		"AcceptWebSocket", "ApplyMonitorPolicy", "BoundPort", "CancelOutbound",
		"Capabilities", "Close", "CloseWebSocket", "Drain", "ExchangeCancelled",
		"Fail", "FinishResponseStream", "Health", "Interrupt", "InterruptMonitor",
		"MonitorConfig", "MonitorSnapshot", "ProbeLiveness", "ReadMonitorEvents",
		"Rebind", "Respond", "RespondFile", "SendWebSocket", "Start",
		"StartResponseStream", "StartSSE", "Stop", "SubmitOutbound", "TakeEvent",
		"TakeOutbound", "TakeWebSocket", "WaitMonitor", "WriteResponseStream", "WriteSSE",
	}
	typeOfCore := reflect.TypeOf((*Core)(nil))
	for _, name := range methods {
		if _, ok := typeOfCore.MethodByName(name); !ok {
			t.Errorf("Core.%s is missing", name)
		}
	}
	fields := []string{
		"Limits", "Listeners", "Routes", "StaticMounts", "FileAuthorities",
		"Compression", "IOBackend", "WaitPolicy", "Monitor", "Inspection",
		"Outbound", "OutboundEnabled", "OutboundTargets", "OutboundTrust",
		"OutboundIdentities",
	}
	typeOfConfig := reflect.TypeOf(Config{})
	for _, name := range fields {
		if _, ok := typeOfConfig.FieldByName(name); !ok {
			t.Errorf("Config.%s is missing", name)
		}
	}
}

// TestBridgeLoadsOnlyTheCallbackFreeSurface rejects accidental restoration of
// the old callback adapter or a private runtime/schema include.
func TestBridgeLoadsOnlyTheCallbackFreeSurface(t *testing.T) {
	bridge, err := os.ReadFile("bridge.c")
	if err != nil {
		t.Fatal(err)
	}
	text := string(bridge)
	for _, forbidden := range []string{"coakkaHttpGoDispatch", "server_create", "runtime.h", ".proto"} {
		if strings.Contains(text, forbidden) {
			t.Errorf("bridge contains forbidden callback/private token %q", forbidden)
		}
	}
	header, err := os.ReadFile("internal/native_api.h")
	if err != nil {
		t.Fatal(err)
	}
	for _, required := range []string{
		"#define COAKKA_HTTP_ABI_VERSION UINT32_C(2)",
		"coakka_http_core_take_event", "coakka_http_core_release_event",
		"coakka_http_core_take_websocket", "coakka_http_core_release_websocket",
		"coakka_http_core_take_outbound", "coakka_http_core_release_outbound",
		"coakka_http_core_monitor_snapshot", "coakka_http_configuration_set_inspection",
	} {
		if !strings.Contains(string(header), required) {
			t.Errorf("public ABI snapshot lacks %q", required)
		}
	}
}

// TestPackagedCoreIntegrity keeps the selected embedded bytes synchronized
// with their build-tag-specific digest.
func TestPackagedCoreIntegrity(t *testing.T) {
	gatedTarget := (runtime.GOOS == "darwin" && runtime.GOARCH == "arm64") ||
		(runtime.GOOS == "linux" && (runtime.GOARCH == "arm64" || runtime.GOARCH == "amd64")) ||
		(runtime.GOOS == "windows" && (runtime.GOARCH == "arm64" || runtime.GOARCH == "amd64"))
	if gatedTarget {
		if len(packagedCore) == 0 {
			t.Fatalf("%s/%s ABI2 payload is absent", runtime.GOOS, runtime.GOARCH)
		}
		actual := fmt.Sprintf("%x", sha256.Sum256(packagedCore))
		if actual != packagedCoreSHA256 {
			t.Fatalf("embedded Core digest differs: actual=%s declared=%s", actual, packagedCoreSHA256)
		}
		return
	}
	if len(packagedCore) != 0 || packagedCoreSHA256 != "" {
		t.Fatal("an ungated native payload was embedded")
	}
}
