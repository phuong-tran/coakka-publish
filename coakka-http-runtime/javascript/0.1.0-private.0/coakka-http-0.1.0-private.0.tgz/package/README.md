# CoAkka HTTP for Node and Bun

This private GitHub draft provides one API for Node and Bun. It is not
published to a package registry and is not a production-support claim.

```javascript
import { Builder, Response } from "@coakka/http";

const service = await new Builder()
  .get("/customers/{id}", (request) => Response.json({ id: request.params.id }))
  .post("/customers", async (request) =>
    Response.json(await request.json(), { status: 201 }),
  )
  .start();

console.log(service.url);
```

The draft includes buffered and streaming requests and responses, server
events, WebSocket sessions, static and single-page application content,
outbound calls, TLS and protocol selection, form and multipart values, route
rebinding, health and inspection snapshots, cancellation, bounded capacity,
and finite shutdown.

`Service.close()` is idempotent. Application signal handling is opt-in through
`attachProcessShutdown(service)`. Requests, responses, stream chunks, headers,
connections, active handlers, outbound calls, WebSocket messages, retained
errors, routes, and static mounts all have explicit bounds and reject excess
work.

## Release status

Development draft. Registry publication, performance claims, sanitizer
campaigns, long-running stress evidence, and production support remain closed.
