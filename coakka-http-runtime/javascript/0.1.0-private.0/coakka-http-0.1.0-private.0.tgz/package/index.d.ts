export type Bytes = string | Uint8Array;
export interface HeaderEntry {
  readonly name: string;
  readonly value: string;
}
export type HeaderInput =
  | Headers
  | ReadonlyArray<HeaderEntry>
  | Record<string, string | number | boolean>;
export interface FormField {
  readonly name: string;
  readonly value: string;
}
export interface MultipartPart {
  readonly name: string;
  readonly filename: string;
  readonly contentType: string;
  readonly data: Uint8Array;
}

export class HeaderList implements Iterable<HeaderEntry> {
  constructor(entries?: HeaderInput);
  get(name: string): string | null;
  getAll(name: string): string[];
  has(name: string): boolean;
  entries(): IterableIterator<HeaderEntry>;
  [Symbol.iterator](): IterableIterator<HeaderEntry>;
}

export class Request {
  private constructor();
  readonly method: string;
  readonly target: string;
  readonly path: string;
  readonly query: URLSearchParams;
  readonly headers: HeaderList;
  readonly params: Readonly<Record<string, string>>;
  readonly form: ReadonlyArray<FormField>;
  readonly multipart: ReadonlyArray<MultipartPart>;
  readonly signal: AbortSignal;
  bytes(): Uint8Array;
  text(): string;
  json<T = unknown>(): T;
  stream(): AsyncIterable<Uint8Array>;
}

export interface ResponseOptions {
  readonly status?: number;
  readonly headers?: HeaderInput;
}

export class Response {
  constructor(body?: Bytes, options?: ResponseOptions);
  readonly status: number;
  readonly headers: ReadonlyArray<HeaderEntry>;
  readonly body?: Uint8Array;
  static empty(options?: ResponseOptions): Response;
  static bytes(body: Uint8Array, options?: ResponseOptions): Response;
  static text(body: string, options?: ResponseOptions): Response;
  static json(value: unknown, options?: ResponseOptions): Response;
}

export type ChunkSource = Iterable<Bytes> | AsyncIterable<Bytes>;

export interface StreamResponseOptions extends ResponseOptions {
  readonly trailers?: HeaderInput;
}

export class StreamResponse {
  constructor(source: ChunkSource, options?: StreamResponseOptions);
  readonly source: ChunkSource;
  readonly status: number;
  readonly headers: ReadonlyArray<HeaderEntry>;
  readonly trailers: ReadonlyArray<HeaderEntry>;
}

export interface ServerEventOptions {
  readonly event?: string;
  readonly id?: string;
  readonly retryMillis?: number;
}

export class ServerEvent {
  constructor(data: string, options?: ServerEventOptions);
  readonly data: string;
  readonly event?: string;
  readonly id?: string;
  readonly retryMillis?: number;
  encode(): Uint8Array;
}

export interface EventResponseOptions extends ResponseOptions {}
export type EventSource = Iterable<ServerEvent> | AsyncIterable<ServerEvent>;

export class EventResponse {
  constructor(events: EventSource, options?: EventResponseOptions);
  readonly events: EventSource;
  readonly status: number;
  readonly headers: ReadonlyArray<HeaderEntry>;
}

export interface StaticContentOptions {
  readonly urlPrefix?: string;
  readonly indexFile?: string;
  readonly spaFallback?: boolean;
  readonly cacheControl?: string;
}

export class StaticContent {
  constructor(directory: string, options?: StaticContentOptions);
  readonly directory: string;
  readonly urlPrefix: string;
  readonly indexFile: string;
  readonly spaFallback: boolean;
  readonly cacheControl: string;
}

export type CertificateSource = string | Uint8Array;
export interface TlsOptions {
  readonly caCertificate?: CertificateSource;
  readonly requireClientCertificate?: boolean;
}

export class TlsConfiguration {
  constructor(
    certificate: CertificateSource,
    privateKey: CertificateSource,
    options?: TlsOptions,
  );
  readonly certificate: CertificateSource;
  readonly privateKey: CertificateSource;
  readonly caCertificate?: CertificateSource;
  readonly requireClientCertificate: boolean;
}

export const HttpProtocol: Readonly<{
  HTTP_1_1: "http/1.1";
  HTTP_2: "h2";
}>;
export type HttpProtocolValue =
  (typeof HttpProtocol)[keyof typeof HttpProtocol];

export interface BoundsOptions {
  readonly maxRoutes?: number;
  readonly maxStaticMounts?: number;
  readonly maxActiveHandlers?: number;
  readonly maxConnections?: number;
  readonly backlog?: number;
  readonly maxRequestTargetBytes?: number;
  readonly maxRequestHeaders?: number;
  readonly maxRequestHeaderBytes?: number;
  readonly maxRequestBodyBytes?: number;
  readonly maxRequestChunks?: number;
  readonly maxRequestChunkBytes?: number;
  readonly maxResponseHeaders?: number;
  readonly maxResponseHeaderBytes?: number;
  readonly maxResponseBodyBytes?: number;
  readonly maxResponseChunks?: number;
  readonly maxResponseChunkBytes?: number;
  readonly maxFormFields?: number;
  readonly maxMultipartParts?: number;
  readonly maxWebSocketMessageBytes?: number;
  readonly maxWebSocketBufferedBytes?: number;
  readonly maxOutboundRequests?: number;
  readonly maxOutboundBodyBytes?: number;
  readonly maxErrors?: number;
  readonly shutdownTimeoutMs?: number;
}

export class Bounds implements Required<BoundsOptions> {
  constructor(options?: BoundsOptions);
  readonly maxRoutes: number;
  readonly maxStaticMounts: number;
  readonly maxActiveHandlers: number;
  readonly maxConnections: number;
  readonly backlog: number;
  readonly maxRequestTargetBytes: number;
  readonly maxRequestHeaders: number;
  readonly maxRequestHeaderBytes: number;
  readonly maxRequestBodyBytes: number;
  readonly maxRequestChunks: number;
  readonly maxRequestChunkBytes: number;
  readonly maxResponseHeaders: number;
  readonly maxResponseHeaderBytes: number;
  readonly maxResponseBodyBytes: number;
  readonly maxResponseChunks: number;
  readonly maxResponseChunkBytes: number;
  readonly maxFormFields: number;
  readonly maxMultipartParts: number;
  readonly maxWebSocketMessageBytes: number;
  readonly maxWebSocketBufferedBytes: number;
  readonly maxOutboundRequests: number;
  readonly maxOutboundBodyBytes: number;
  readonly maxErrors: number;
  readonly shutdownTimeoutMs: number;
}

export type HandlerResult =
  Response | globalThis.Response | StreamResponse | EventResponse;
export type Handler = (
  request: Request,
) => HandlerResult | Promise<HandlerResult>;
export type WebSocketMessage = string | Uint8Array | undefined;
export type WebSocketHandler = (
  session: WebSocketSession,
  request: Request,
  message: WebSocketMessage,
) => void | Promise<void>;

export class WebSocketSession {
  private constructor();
  readonly protocol: string;
  readonly signal: AbortSignal;
  readonly open: boolean;
  send(data: Bytes): Promise<void>;
  ping(data?: Uint8Array): void;
  pong(data?: Uint8Array): void;
  close(code?: number, reason?: string): void;
}

export interface RouteOptions {
  readonly streamingRequest?: boolean;
}
export interface RouteBinding {
  readonly routeId: number;
  readonly method: string;
  readonly pattern: string;
  readonly revision: number;
  readonly websocket: boolean;
}

export class Builder {
  listen(host: string, port: number): this;
  bounds(bounds: Bounds): this;
  protocols(...protocols: HttpProtocolValue[]): this;
  tls(configuration: TlsConfiguration): this;
  route(
    method: string,
    pattern: string,
    handler: Handler,
    options?: RouteOptions,
  ): this;
  routeStreaming(method: string, pattern: string, handler: Handler): this;
  get(pattern: string, handler: Handler): this;
  post(pattern: string, handler: Handler): this;
  put(pattern: string, handler: Handler): this;
  patch(pattern: string, handler: Handler): this;
  delete(pattern: string, handler: Handler): this;
  websocket(pattern: string, handler: WebSocketHandler): this;
  static(content: StaticContent): this;
  start(): Promise<Service>;
}

export interface Health {
  readonly status: string;
  readonly ready: boolean;
  readonly acceptingRequests: boolean;
}
export interface Snapshot {
  readonly running: boolean;
  readonly dispatched: number;
  readonly rejected: number;
  readonly failed: number;
  readonly completed: number;
  readonly pending: number;
  readonly maxActiveHandlers: number;
  readonly activeConnections: number;
  readonly outboundPending: number;
  readonly outboundCompleted: number;
  readonly outboundRejected: number;
  readonly websocketSessions: number;
  readonly routeGeneration: number;
  readonly droppedErrors: number;
}
export interface Inspection {
  readonly host: string;
  readonly port: number;
  readonly secure: boolean;
  readonly protocols: ReadonlyArray<HttpProtocolValue>;
  readonly routes: ReadonlyArray<RouteBinding>;
  readonly staticPrefixes: ReadonlyArray<string>;
}

export class ClientError extends Error {
  readonly code:
    "cancelled" | "capacity" | "timeout" | "connection" | "response_too_large";
}
export class ClientResponse {
  private constructor();
  readonly status: number;
  readonly headers: ReadonlyArray<HeaderEntry>;
  bytes(): Uint8Array;
  text(): string;
  json<T = unknown>(): T;
}
export interface ClientOptions {
  readonly maxPending?: number;
  readonly maxBodyBytes?: number;
}
export interface ClientRequestOptions {
  readonly method?: string;
  readonly headers?: HeaderInput;
  readonly body?: Bytes;
  readonly timeoutMs?: number;
  readonly signal?: AbortSignal;
}
export class HttpClient {
  constructor(options?: ClientOptions);
  readonly maxPending: number;
  readonly maxBodyBytes: number;
  readonly pending: number;
  readonly completed: number;
  readonly rejected: number;
  execute(
    url: string | URL,
    options?: ClientRequestOptions,
  ): Promise<ClientResponse>;
  close(): Promise<void>;
}

export class Service {
  private constructor();
  readonly port: number;
  readonly url: string;
  readonly client: HttpClient;
  health(): Health;
  snapshot(): Snapshot;
  inspect(): Inspection;
  routes(): ReadonlyArray<RouteBinding>;
  pollError(): unknown | undefined;
  rebind(
    routeId: number,
    expectedRevision: number,
    handler: Handler,
  ): RouteBinding;
  close(timeoutMs?: number): Promise<void>;
}

export function attachProcessShutdown(
  service: Service,
  options?: { readonly signals?: ReadonlyArray<string> },
): () => void;
