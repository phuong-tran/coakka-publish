export class ClientError extends Error {
  constructor(code, message, cause) {
    super(message, cause === undefined ? undefined : { cause });
    this.name = "ClientError";
    this.code = code;
  }
}

export class ClientResponse {
  #body;

  constructor(status, headers, body) {
    this.status = status;
    this.headers = Object.freeze(headers);
    this.#body = new Uint8Array(body);
    Object.freeze(this);
  }

  bytes() {
    return new Uint8Array(this.#body);
  }

  text() {
    return new TextDecoder().decode(this.#body);
  }

  json() {
    return JSON.parse(this.text());
  }
}

export class HttpClient {
  #closed = false;
  #pending = 0;
  #completed = 0;
  #rejected = 0;

  constructor({ maxPending = 256, maxBodyBytes = 8 << 20 } = {}) {
    if (
      !Number.isSafeInteger(maxPending) ||
      maxPending <= 0 ||
      maxPending > 16384 ||
      !Number.isSafeInteger(maxBodyBytes) ||
      maxBodyBytes <= 0
    ) {
      throw new RangeError("HTTP client bounds are invalid");
    }
    this.maxPending = maxPending;
    this.maxBodyBytes = maxBodyBytes;
  }

  get pending() {
    return this.#pending;
  }
  get completed() {
    return this.#completed;
  }
  get rejected() {
    return this.#rejected;
  }

  async execute(
    url,
    { method = "GET", headers, body, timeoutMs = 10_000, signal } = {},
  ) {
    if (this.#closed)
      throw new ClientError("cancelled", "HTTP client is closed");
    if (this.#pending >= this.maxPending) {
      this.#rejected += 1;
      throw new ClientError("capacity", "outbound capacity exhausted");
    }
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0) {
      throw new RangeError("outbound timeout must be a positive integer");
    }
    if (
      body !== undefined &&
      typeof body !== "string" &&
      !(body instanceof Uint8Array)
    ) {
      throw new TypeError("outbound body must be a string or Uint8Array");
    }
    if (
      body instanceof Uint8Array &&
      typeof SharedArrayBuffer !== "undefined" &&
      body.buffer instanceof SharedArrayBuffer
    ) {
      throw new TypeError("outbound body must not use SharedArrayBuffer");
    }
    const requestBody =
      body === undefined
        ? undefined
        : new Uint8Array(
            typeof body === "string" ? new TextEncoder().encode(body) : body,
          );
    if (
      requestBody !== undefined &&
      requestBody.byteLength > this.maxBodyBytes
    ) {
      throw new ClientError(
        "capacity",
        "outbound request body exceeds its bound",
      );
    }
    const timeout = AbortSignal.timeout(timeoutMs);
    const combined =
      signal === undefined ? timeout : AbortSignal.any([signal, timeout]);
    this.#pending += 1;
    try {
      const response = await fetch(url, {
        method,
        headers,
        body: requestBody,
        signal: combined,
      });
      const chunks = [];
      let size = 0;
      for await (const chunk of response.body ?? []) {
        const owned = new Uint8Array(chunk);
        size += owned.byteLength;
        if (size > this.maxBodyBytes) {
          throw new ClientError(
            "response_too_large",
            "outbound response exceeds its bound",
          );
        }
        chunks.push(owned);
      }
      const bodyBytes = new Uint8Array(size);
      let offset = 0;
      for (const chunk of chunks) {
        bodyBytes.set(chunk, offset);
        offset += chunk.byteLength;
      }
      this.#completed += 1;
      return new ClientResponse(
        response.status,
        [...response.headers.entries()].map(([name, value]) =>
          Object.freeze({ name, value }),
        ),
        bodyBytes,
      );
    } catch (error) {
      if (error instanceof ClientError) throw error;
      if (combined.aborted) {
        throw new ClientError(
          signal?.aborted ? "cancelled" : "timeout",
          "outbound request aborted",
          error,
        );
      }
      throw new ClientError("connection", "outbound request failed", error);
    } finally {
      this.#pending -= 1;
    }
  }

  async close() {
    this.#closed = true;
  }
}
