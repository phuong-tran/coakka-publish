import { loadNativeAddon } from "./native_loader.mjs";

function compile(pattern) {
  if (pattern === "/") return [];
  return pattern
    .slice(1)
    .split("/")
    .map((segment) => {
      const capture = /^\{([^/{}]+)\}$/u.exec(segment);
      return capture === null
        ? Object.freeze({ literal: decodeURIComponent(segment) })
        : Object.freeze({ capture: capture[1] });
    });
}

export function admissiblePath(path) {
  if (!path.startsWith("/") || path.includes("//")) return false;
  if (/(?:^|\/)\.\.?(?:\/|$)/u.test(path)) return false;
  try {
    decodeURIComponent(path);
    return true;
  } catch {
    return false;
  }
}

export class Router {
  #routes;

  constructor(routes) {
    loadNativeAddon().validateRoutes(
      routes.map(({ routeId, method, pattern }) => ({
        routeId,
        method,
        pattern,
      })),
    );
    this.#routes = Object.freeze(
      routes.map((route) =>
        Object.freeze({ ...route, segments: compile(route.pattern) }),
      ),
    );
  }

  match(method, rawPath, websocket = false) {
    if (!admissiblePath(rawPath)) return null;
    const actual = rawPath === "/" ? [] : rawPath.slice(1).split("/");
    for (const route of this.#routes) {
      if (route.method !== method || route.websocket !== websocket) continue;
      if (route.segments.length !== actual.length) continue;
      const params = Object.create(null);
      let matched = true;
      for (let index = 0; index < actual.length; index += 1) {
        const segment = route.segments[index];
        const decoded = decodeURIComponent(actual[index]);
        if (segment.capture !== undefined) {
          if (decoded.length === 0) {
            matched = false;
            break;
          }
          params[segment.capture] = decoded;
        } else if (segment.literal !== decoded) {
          matched = false;
          break;
        }
      }
      if (matched)
        return Object.freeze({ route, params: Object.freeze(params) });
    }
    return null;
  }

  bindings() {
    return Object.freeze(
      this.#routes.map(({ routeId, method, pattern, revision, websocket }) =>
        Object.freeze({ routeId, method, pattern, revision, websocket }),
      ),
    );
  }

  rebind(routeId, expectedRevision, handler) {
    const index = this.#routes.findIndex((route) => route.routeId === routeId);
    if (index < 0) throw new RangeError("route id is unknown");
    const previous = this.#routes[index];
    if (previous.websocket)
      throw new Error("WebSocket route cannot use an HTTP handler");
    if (previous.revision !== expectedRevision)
      throw new Error("route revision is stale");
    const routes = [...this.#routes];
    routes[index] = Object.freeze({
      ...previous,
      revision: previous.revision + 1,
      handler,
    });
    this.#routes = Object.freeze(routes);
    return this.bindings()[index];
  }
}
