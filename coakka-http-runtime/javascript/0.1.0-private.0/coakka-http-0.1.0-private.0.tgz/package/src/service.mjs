import { once } from "node:events";
import { readFile, realpath, stat } from "node:fs/promises";
import { createServer as createHttpServer } from "node:http";
import {
  createServer as createHttp2Server,
  createSecureServer,
} from "node:http2";
import { createServer as createHttpsServer } from "node:https";
import { isAbsolute, relative, resolve } from "node:path";
import { WebSocketServer } from "ws";

import { HttpClient } from "./client.mjs";
import { Router } from "./routing.mjs";
import {
  EventResponse,
  HeaderList,
  HttpProtocol,
  Request,
  Response,
  ServerEvent,
  StaticContent,
  StreamResponse,
  TlsConfiguration,
  asChunk,
  normalizeHeaders,
} from "./values.mjs";

const METHODS = Object.freeze(["GET", "POST", "PUT", "PATCH", "DELETE"]);
const MIME_TYPES = Object.freeze({
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".txt": "text/plain; charset=utf-8",
  ".wasm": "application/wasm",
});

export class Bounds {
  constructor(options = {}) {
    Object.assign(this, {
      maxRoutes: 1024,
      maxStaticMounts: 32,
      maxActiveHandlers: 256,
      maxConnections: 256,
      backlog: 256,
      maxRequestTargetBytes: 8 << 10,
      maxRequestHeaders: 100,
      maxRequestHeaderBytes: 1 << 20,
      maxRequestBodyBytes: 1 << 20,
      maxRequestChunks: 4096,
      maxRequestChunkBytes: 256 << 10,
      maxResponseHeaders: 100,
      maxResponseHeaderBytes: 1 << 20,
      maxResponseBodyBytes: 8 << 20,
      maxResponseChunks: 4096,
      maxResponseChunkBytes: 256 << 10,
      maxFormFields: 1024,
      maxMultipartParts: 128,
      maxWebSocketMessageBytes: 1 << 20,
      maxWebSocketBufferedBytes: 1 << 20,
      maxOutboundRequests: 256,
      maxOutboundBodyBytes: 8 << 20,
      maxErrors: 64,
      shutdownTimeoutMs: 5000,
      ...options,
    });
    const integers = Object.entries(this).filter(
      ([name]) => name !== "shutdownTimeoutMs",
    );
    if (
      integers.some(
        ([, value]) => !Number.isSafeInteger(value) || value <= 0,
      ) ||
      !Number.isSafeInteger(this.shutdownTimeoutMs) ||
      this.shutdownTimeoutMs <= 0
    ) {
      throw new RangeError("CoAkka HTTP bounds must be positive safe integers");
    }
    if (
      this.maxRoutes > 16384 ||
      this.maxActiveHandlers > 16384 ||
      this.maxConnections > 65536
    ) {
      throw new RangeError(
        "CoAkka HTTP route or concurrency bound is excessive",
      );
    }
    Object.freeze(this);
  }
}

export class WebSocketSession {
  #socket;
  #bounds;
  #closed = false;

  constructor(socket, protocol, bounds, signal) {
    this.#socket = socket;
    this.#bounds = bounds;
    this.protocol = protocol;
    this.signal = signal;
    Object.freeze(this);
  }

  get open() {
    return !this.#closed && this.#socket.readyState === this.#socket.OPEN;
  }

  async send(data) {
    if (!this.open) throw new Error("WebSocket session is closed");
    const payload = typeof data === "string" ? data : asChunk(data);
    const size =
      typeof payload === "string"
        ? Buffer.byteLength(payload)
        : payload.byteLength;
    if (size > this.#bounds.maxWebSocketMessageBytes) {
      throw new RangeError("WebSocket message exceeds its bound");
    }
    if (
      this.#socket.bufferedAmount + size >
      this.#bounds.maxWebSocketBufferedBytes
    ) {
      throw new RangeError("WebSocket outbound capacity exhausted");
    }
    await new Promise((accept, reject) =>
      this.#socket.send(payload, (error) => {
        if (error === undefined) accept();
        else reject(error);
      }),
    );
  }

  ping(data = new Uint8Array()) {
    if (!this.open) throw new Error("WebSocket session is closed");
    this.#socket.ping(asChunk(data));
  }

  pong(data = new Uint8Array()) {
    if (!this.open) throw new Error("WebSocket session is closed");
    this.#socket.pong(asChunk(data));
  }

  close(code = 1000, reason = "") {
    if (this.#closed) return;
    if (code !== 1000 && (code < 3000 || code > 4999)) {
      throw new RangeError("WebSocket close code is invalid");
    }
    if (Buffer.byteLength(reason) > 123) {
      throw new RangeError("WebSocket close reason exceeds 123 bytes");
    }
    this.#closed = true;
    this.#socket.close(code, reason);
  }

  _remoteClosed() {
    this.#closed = true;
  }
}

export class Service {
  #server;
  #webSockets;
  #router;
  #bounds;
  #host;
  #protocols;
  #secure;
  #static;
  #state = "running";
  #closePromise;
  #activeHandlers = 0;
  #activeConnections = 0;
  #webSocketSessions = 0;
  #dispatched = 0;
  #rejected = 0;
  #failed = 0;
  #completed = 0;
  #routeGeneration = 1;
  #errors = [];
  #droppedErrors = 0;
  #controllers = new Set();
  #sockets = new Set();

  constructor(server, webSockets, router, declaration, mounts, port) {
    this.#server = server;
    this.#webSockets = webSockets;
    this.#router = router;
    this.#bounds = declaration.bounds;
    this.#host = declaration.host;
    this.#protocols = declaration.protocols;
    this.#secure = declaration.tls !== undefined;
    this.#static = mounts;
    this.port = port;
    const displayHost = declaration.host.includes(":")
      ? `[${declaration.host}]`
      : declaration.host;
    this.url = `${this.#secure ? "https" : "http"}://${displayHost}:${port}`;
    this.client = new HttpClient({
      maxPending: this.#bounds.maxOutboundRequests,
      maxBodyBytes: this.#bounds.maxOutboundBodyBytes,
    });
    server.maxConnections = this.#bounds.maxConnections;
    server.on("connection", (socket) => {
      this.#sockets.add(socket);
      this.#activeConnections = this.#sockets.size;
      socket.once("close", () => {
        this.#sockets.delete(socket);
        this.#activeConnections = this.#sockets.size;
      });
    });
    Object.freeze(this);
  }

  health() {
    const running = this.#state === "running";
    return Object.freeze({
      status: running ? "ready" : this.#state,
      ready: running,
      acceptingRequests: running,
    });
  }

  snapshot() {
    return Object.freeze({
      running: this.#state === "running",
      dispatched: this.#dispatched,
      rejected: this.#rejected,
      failed: this.#failed,
      completed: this.#completed,
      pending: this.#activeHandlers,
      maxActiveHandlers: this.#bounds.maxActiveHandlers,
      activeConnections: this.#activeConnections,
      outboundPending: this.client.pending,
      outboundCompleted: this.client.completed,
      outboundRejected: this.client.rejected,
      websocketSessions: this.#webSocketSessions,
      routeGeneration: this.#routeGeneration,
      droppedErrors: this.#droppedErrors,
    });
  }

  inspect() {
    return Object.freeze({
      host: this.#host,
      port: this.port,
      secure: this.#secure,
      protocols: this.#protocols,
      routes: this.#router.bindings(),
      staticPrefixes: Object.freeze(this.#static.map((item) => item.urlPrefix)),
    });
  }

  routes() {
    return this.#router.bindings();
  }

  pollError() {
    return this.#errors.shift();
  }

  rebind(routeId, expectedRevision, handler) {
    if (this.#state !== "running") throw new Error("service is not running");
    if (typeof handler !== "function")
      throw new TypeError("handler must be a function");
    const binding = this.#router.rebind(routeId, expectedRevision, handler);
    this.#routeGeneration += 1;
    return binding;
  }

  async close(timeoutMs = this.#bounds.shutdownTimeoutMs) {
    if (this.#closePromise !== undefined) return this.#closePromise;
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0) {
      throw new RangeError("shutdown timeout must be a positive integer");
    }
    this.#state = "stopping";
    this.#closePromise = this.#closeOwned(timeoutMs);
    return this.#closePromise;
  }

  async #closeOwned(timeoutMs) {
    for (const controller of this.#controllers) controller.abort();
    for (const socket of this.#webSockets.clients)
      socket.close(1001, "service stopping");
    if (this.#controllers.size === 0 && this.#webSockets.clients.size === 0) {
      this.#server.closeAllConnections?.();
    }
    const closed = new Promise((accept, reject) =>
      this.#server.close((error) => {
        if (error === undefined || error?.code === "ERR_SERVER_NOT_RUNNING")
          accept();
        else reject(error);
      }),
    );
    this.#server.closeIdleConnections?.();
    let timer;
    const timeout = new Promise((accept) => {
      timer = setTimeout(accept, timeoutMs, "timeout");
    });
    const outcome = await Promise.race([closed.then(() => "closed"), timeout]);
    clearTimeout(timer);
    if (outcome === "timeout") {
      for (const socket of this.#webSockets.clients) socket.terminate();
      this.#server.closeAllConnections?.();
      for (const socket of this.#sockets) socket.destroy();
      await closed;
    }
    await this.client.close();
    this.#state = "stopped";
  }

  _record(error) {
    if (this.#errors.length === this.#bounds.maxErrors) {
      this.#errors.shift();
      this.#droppedErrors += 1;
    }
    this.#errors.push(error);
  }

  async _http(incoming, outgoing) {
    if (this.#state !== "running")
      return sendBuffered(outgoing, 503, [], Buffer.from("service stopping"));
    const target = incoming.url ?? "/";
    if (Buffer.byteLength(target) > this.#bounds.maxRequestTargetBytes) {
      this.#rejected += 1;
      return sendBuffered(
        outgoing,
        414,
        [],
        Buffer.from("request target rejected"),
      );
    }
    const headerAdmission = incomingHeaderAdmission(incoming, this.#bounds);
    if (headerAdmission !== undefined) {
      this.#rejected += 1;
      return sendBuffered(
        outgoing,
        headerAdmission.status,
        [],
        Buffer.from(headerAdmission.message),
      );
    }
    let url;
    try {
      url = new URL(target, `${this.#secure ? "https" : "http"}://localhost`);
    } catch {
      this.#rejected += 1;
      return sendBuffered(
        outgoing,
        400,
        [],
        Buffer.from("request target rejected"),
      );
    }
    const match = this.#router.match(
      incoming.method ?? "",
      url.pathname,
      false,
    );
    if (match === null) {
      const response = await staticResponse(
        this.#static,
        incoming.method,
        url.pathname,
        incoming.headers,
        this.#bounds,
      );
      return response === null
        ? sendBuffered(outgoing, 404, [], Buffer.from("not found"))
        : this.#write(outgoing, response);
    }
    if (this.#activeHandlers >= this.#bounds.maxActiveHandlers) {
      this.#rejected += 1;
      return sendBuffered(outgoing, 503, [], Buffer.from("service busy"));
    }
    const controller = new AbortController();
    const cancel = () => controller.abort();
    incoming.once("aborted", cancel);
    outgoing.once("close", () => {
      if (!outgoing.writableFinished) cancel();
    });
    this.#controllers.add(controller);
    this.#activeHandlers += 1;
    this.#dispatched += 1;
    try {
      const headers = incomingHeaders(incoming);
      const streaming = match.route.streamingRequest;
      const bodyStream = boundedBody(incoming, this.#bounds);
      const body = streaming
        ? undefined
        : await collectBody(bodyStream, this.#bounds.maxRequestBodyBytes);
      const values = streaming
        ? { form: [], multipart: [] }
        : await parseBodyValues(headers, body, this.#bounds);
      const request = new Request({
        method: incoming.method,
        target,
        path: url.pathname,
        query: url.searchParams,
        headers,
        params: match.params,
        body,
        bodyStream: streaming ? bodyStream : undefined,
        form: values.form,
        multipart: values.multipart,
        signal: controller.signal,
      });
      const result = await match.route.handler(request);
      await this.#write(outgoing, result);
      if (streaming && !incoming.complete) incoming.destroy();
      this.#completed += 1;
    } catch (error) {
      if (error instanceof RequestRejected) {
        this.#rejected += 1;
        if (!outgoing.headersSent) {
          sendBuffered(outgoing, error.status, [], Buffer.from(error.message));
        } else {
          outgoing.destroy(error);
        }
        return;
      }
      if (controller.signal.aborted) return;
      this.#failed += 1;
      this._record(error);
      if (!outgoing.headersSent)
        sendBuffered(outgoing, 500, [], Buffer.from("internal server error"));
      else outgoing.destroy(error);
    } finally {
      incoming.off("aborted", cancel);
      this.#controllers.delete(controller);
      this.#activeHandlers -= 1;
    }
  }

  async #write(outgoing, result) {
    if (result instanceof globalThis.Response) {
      result = new Response(new Uint8Array(await result.arrayBuffer()), {
        status: result.status,
        headers: [...result.headers.entries()].map(([name, value]) => ({
          name,
          value,
        })),
      });
    }
    if (result instanceof Response) {
      const body = result.body ?? new Uint8Array();
      validateResponse(
        result.status,
        result.headers,
        body.byteLength,
        this.#bounds,
      );
      sendBuffered(outgoing, result.status, result.headers, body);
      return;
    }
    if (result instanceof StreamResponse) {
      await sendStream(
        outgoing,
        result.status,
        result.headers,
        result.source,
        result.trailers,
        this.#bounds,
      );
      return;
    }
    if (result instanceof EventResponse) {
      const headers = withDefault(
        result.headers,
        "content-type",
        "text/event-stream; charset=utf-8",
      );
      const source = (async function* () {
        for await (const event of result.events) {
          if (!(event instanceof ServerEvent))
            throw new TypeError("event stream yielded an invalid value");
          yield event.encode();
        }
      })();
      await sendStream(
        outgoing,
        result.status,
        headers,
        source,
        [],
        this.#bounds,
      );
      return;
    }
    throw new TypeError("handler must return a Response");
  }

  _upgrade(incoming, socket, head) {
    if (this.#state !== "running") return socket.destroy();
    const target = incoming.url ?? "/";
    if (
      Buffer.byteLength(target) > this.#bounds.maxRequestTargetBytes ||
      incomingHeaderAdmission(incoming, this.#bounds) !== undefined
    ) {
      this.#rejected += 1;
      return socket.destroy();
    }
    let url;
    try {
      url = new URL(target, `${this.#secure ? "https" : "http"}://localhost`);
    } catch {
      this.#rejected += 1;
      return socket.destroy();
    }
    const match = this.#router.match("GET", url.pathname, true);
    if (
      match === null ||
      this.#activeHandlers + this.#webSocketSessions >=
        this.#bounds.maxActiveHandlers
    ) {
      this.#rejected += 1;
      return socket.destroy();
    }
    this.#webSockets.handleUpgrade(incoming, socket, head, (webSocket) => {
      const controller = new AbortController();
      const session = new WebSocketSession(
        webSocket,
        webSocket.protocol,
        this.#bounds,
        controller.signal,
      );
      this.#webSocketSessions += 1;
      this.#dispatched += 1;
      const request = new Request({
        method: "GET",
        target: incoming.url,
        path: url.pathname,
        query: url.searchParams,
        headers: incomingHeaders(incoming),
        params: match.params,
        signal: controller.signal,
      });
      let pendingMessages = 0;
      let tail = Promise.resolve();
      webSocket.on("message", (data, binary) => {
        const value = binary ? new Uint8Array(data) : data.toString();
        if (
          data.byteLength > this.#bounds.maxWebSocketMessageBytes ||
          pendingMessages >= this.#bounds.maxRequestChunks
        ) {
          webSocket.close(1009);
          return;
        }
        pendingMessages += 1;
        tail = tail
          .then(() => match.route.handler(session, request, value))
          .catch((error) => {
            this.#failed += 1;
            this._record(error);
            webSocket.close(1011, "handler failed");
          })
          .finally(() => {
            pendingMessages -= 1;
          });
      });
      webSocket.once("close", () => {
        session._remoteClosed();
        controller.abort();
        this.#webSocketSessions -= 1;
      });
      webSocket.on("error", (error) => {
        this.#failed += 1;
        this._record(error);
        webSocket.terminate();
      });
      Promise.resolve(match.route.handler(session, request, undefined)).catch(
        (error) => {
          this.#failed += 1;
          this._record(error);
          webSocket.close(1011, "handler failed");
        },
      );
    });
  }
}

export class Builder {
  #host = "127.0.0.1";
  #port = 0;
  #bounds = new Bounds();
  #protocols = [HttpProtocol.HTTP_1_1];
  #tls;
  #routes = [];
  #static = [];
  #started = false;

  listen(host, port) {
    this.#mutable();
    if (
      typeof host !== "string" ||
      host.length === 0 ||
      !Number.isInteger(port) ||
      port < 0 ||
      port > 65535
    ) {
      throw new RangeError("listen address is invalid");
    }
    this.#host = host;
    this.#port = port;
    return this;
  }

  bounds(bounds) {
    this.#mutable();
    if (!(bounds instanceof Bounds))
      throw new TypeError("bounds must be a Bounds value");
    this.#bounds = bounds;
    return this;
  }

  protocols(...protocols) {
    this.#mutable();
    if (
      protocols.length === 0 ||
      new Set(protocols).size !== protocols.length ||
      protocols.some((value) => !Object.values(HttpProtocol).includes(value))
    )
      throw new RangeError("protocol selection is invalid");
    this.#protocols = protocols;
    return this;
  }

  tls(configuration) {
    this.#mutable();
    if (!(configuration instanceof TlsConfiguration))
      throw new TypeError("TLS configuration is invalid");
    this.#tls = configuration;
    return this;
  }

  route(method, pattern, handler, { streamingRequest = false } = {}) {
    this.#mutable();
    method = String(method).toUpperCase();
    if (!METHODS.includes(method))
      throw new RangeError("HTTP method is unsupported");
    this.#route(method, pattern, handler, Boolean(streamingRequest), false);
    return this;
  }

  routeStreaming(method, pattern, handler) {
    return this.route(method, pattern, handler, { streamingRequest: true });
  }

  get(pattern, handler) {
    return this.route("GET", pattern, handler);
  }
  post(pattern, handler) {
    return this.route("POST", pattern, handler);
  }
  put(pattern, handler) {
    return this.route("PUT", pattern, handler);
  }
  patch(pattern, handler) {
    return this.route("PATCH", pattern, handler);
  }
  delete(pattern, handler) {
    return this.route("DELETE", pattern, handler);
  }

  websocket(pattern, handler) {
    this.#mutable();
    this.#route("GET", pattern, handler, false, true);
    return this;
  }

  static(content) {
    this.#mutable();
    if (!(content instanceof StaticContent))
      throw new TypeError("static content is invalid");
    if (this.#static.length >= this.#bounds.maxStaticMounts)
      throw new RangeError("static mount capacity exhausted");
    this.#static.push(content);
    return this;
  }

  async start() {
    this.#mutable();
    this.#started = true;
    if (this.#routes.length === 0 && this.#static.length === 0)
      throw new Error("at least one route or static mount is required");
    if (
      this.#protocols.includes(HttpProtocol.HTTP_2) &&
      this.#protocols.includes(HttpProtocol.HTTP_1_1) &&
      this.#tls === undefined
    ) {
      throw new Error("a mixed HTTP/1.1 and HTTP/2 listener requires TLS");
    }
    const router = new Router(this.#routes);
    const mounts = await prepareStatic(this.#static);
    const declaration = Object.freeze({
      host: this.#host,
      port: this.#port,
      bounds: this.#bounds,
      protocols: Object.freeze([...this.#protocols]),
      tls: this.#tls,
    });
    const options = await tlsOptions(this.#tls);
    let resolveService;
    const serviceReady = new Promise((accept) => {
      resolveService = accept;
    });
    const listener = (incoming, outgoing) => {
      void serviceReady
        .then((service) => service._http(incoming, outgoing))
        .catch((error) => {
          if (!outgoing.headersSent) {
            sendBuffered(
              outgoing,
              500,
              [],
              Buffer.from("internal server error"),
            );
          } else {
            outgoing.destroy(error);
          }
        });
    };
    let server;
    if (this.#protocols.includes(HttpProtocol.HTTP_2)) {
      server =
        options === undefined
          ? createHttp2Server({}, listener)
          : createSecureServer(
              {
                ...options,
                allowHTTP1: this.#protocols.includes(HttpProtocol.HTTP_1_1),
              },
              listener,
            );
    } else {
      server =
        options === undefined
          ? createHttpServer(listener)
          : createHttpsServer(options, listener);
    }
    const webSockets = new WebSocketServer({
      noServer: true,
      maxPayload: this.#bounds.maxWebSocketMessageBytes,
      perMessageDeflate: false,
    });
    server.on("upgrade", (request, socket, head) => {
      void serviceReady.then((service) =>
        service._upgrade(request, socket, head),
      );
    });
    server.listen({
      host: this.#host,
      port: this.#port,
      backlog: this.#bounds.backlog,
    });
    await awaitListening(server);
    const address = server.address();
    if (address === null || typeof address === "string")
      throw new Error("listener address is unavailable");
    const service = new Service(
      server,
      webSockets,
      router,
      declaration,
      mounts,
      address.port,
    );
    resolveService(service);
    return service;
  }

  #route(method, pattern, handler, streamingRequest, websocket) {
    if (
      typeof pattern !== "string" ||
      !pattern.startsWith("/") ||
      Buffer.byteLength(pattern) > 4096
    ) {
      throw new RangeError("route pattern is invalid");
    }
    if (typeof handler !== "function")
      throw new TypeError("route handler must be a function");
    if (this.#routes.length >= this.#bounds.maxRoutes)
      throw new RangeError("route capacity exhausted");
    this.#routes.push(
      Object.freeze({
        routeId: this.#routes.length + 1,
        method,
        pattern,
        handler,
        streamingRequest,
        websocket,
        revision: 1,
      }),
    );
  }

  #mutable() {
    if (this.#started) throw new Error("builder is frozen");
  }
}

export function attachProcessShutdown(
  service,
  { signals = ["SIGINT", "SIGTERM"] } = {},
) {
  if (!(service instanceof Service))
    throw new TypeError("service must be a started Service");
  const handlers = new Map();
  const detach = () => {
    for (const [signal, handler] of handlers) process.off(signal, handler);
    handlers.clear();
  };
  for (const signal of signals) {
    const handler = () => void service.close().finally(detach);
    handlers.set(signal, handler);
    process.on(signal, handler);
  }
  return detach;
}

async function tlsOptions(configuration) {
  if (configuration === undefined) return undefined;
  const load = async (value) =>
    typeof value === "string" ? readFile(value) : Buffer.from(value);
  if (
    configuration.requireClientCertificate &&
    configuration.caCertificate === undefined
  ) {
    throw new Error(
      "client certificate verification requires a CA certificate",
    );
  }
  return {
    cert: await load(configuration.certificate),
    key: await load(configuration.privateKey),
    ca:
      configuration.caCertificate === undefined
        ? undefined
        : await load(configuration.caCertificate),
    requestCert: configuration.requireClientCertificate,
    rejectUnauthorized: configuration.requireClientCertificate,
  };
}

function incomingHeaders(incoming) {
  const values = [];
  for (let index = 0; index < incoming.rawHeaders.length; index += 2) {
    if (incoming.rawHeaders[index].startsWith(":")) continue;
    values.push({
      name: incoming.rawHeaders[index],
      value: incoming.rawHeaders[index + 1],
    });
  }
  return values;
}

function incomingHeaderAdmission(incoming, bounds) {
  const raw = incoming.rawHeaders;
  if (raw.length / 2 > bounds.maxRequestHeaders) {
    return { status: 431, message: "request headers rejected" };
  }
  let bytes = 0;
  for (const value of raw) bytes += Buffer.byteLength(value);
  if (bytes > bounds.maxRequestHeaderBytes) {
    return { status: 431, message: "request headers rejected" };
  }
  const declaredLength = incoming.headers["content-length"];
  if (
    declaredLength !== undefined &&
    (!/^\d+$/u.test(String(declaredLength)) ||
      Number(declaredLength) > bounds.maxRequestBodyBytes)
  ) {
    return { status: 413, message: "request body rejected" };
  }
  return undefined;
}

function awaitListening(server) {
  return new Promise((accept, reject) => {
    const cleanup = () => {
      server.off("listening", listening);
      server.off("error", failed);
    };
    const listening = () => {
      cleanup();
      accept();
    };
    const failed = (error) => {
      cleanup();
      reject(error);
    };
    server.once("listening", listening);
    server.once("error", failed);
  });
}

async function* boundedBody(incoming, bounds) {
  let chunks = 0;
  let total = 0;
  for await (const value of incoming) {
    const chunk = new Uint8Array(value);
    chunks += 1;
    total += chunk.byteLength;
    if (
      chunks > bounds.maxRequestChunks ||
      chunk.byteLength > bounds.maxRequestChunkBytes ||
      total > bounds.maxRequestBodyBytes
    ) {
      throw new RequestRejected(413, "request body rejected");
    }
    yield chunk;
  }
}

async function collectBody(source, maximum) {
  const chunks = [];
  let size = 0;
  for await (const chunk of source) {
    size += chunk.byteLength;
    if (size > maximum) throw new RequestRejected(413, "request body rejected");
    chunks.push(chunk);
  }
  const body = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return body;
}

async function parseBodyValues(headers, body, bounds) {
  const headerList = new HeaderList(headers);
  const contentType = headerList.get("content-type") ?? "";
  if (
    contentType.toLowerCase().startsWith("application/x-www-form-urlencoded")
  ) {
    const values = [...new URLSearchParams(new TextDecoder().decode(body))];
    if (values.length > bounds.maxFormFields)
      throw new RequestRejected(413, "form field capacity exhausted");
    return {
      form: values.map(([name, value]) => Object.freeze({ name, value })),
      multipart: [],
    };
  }
  if (!contentType.toLowerCase().startsWith("multipart/form-data"))
    return { form: [], multipart: [] };
  const parsed = await new globalThis.Request("http://localhost/", {
    method: "POST",
    headers: { "content-type": contentType },
    body,
  }).formData();
  const form = [];
  const multipart = [];
  for (const [name, value] of parsed) {
    if (form.length + multipart.length >= bounds.maxMultipartParts)
      throw new RequestRejected(413, "multipart part capacity exhausted");
    if (typeof value === "string") form.push(Object.freeze({ name, value }));
    else {
      const data = new Uint8Array(await value.arrayBuffer());
      if (data.byteLength > bounds.maxRequestBodyBytes)
        throw new RequestRejected(413, "multipart part exceeds its bound");
      multipart.push(
        Object.freeze({
          name,
          filename: value.name,
          contentType: value.type,
          data,
        }),
      );
    }
  }
  return { form, multipart };
}

function validateResponse(status, headers, bodyBytes, bounds) {
  if (
    !Number.isInteger(status) ||
    status < 200 ||
    status > 599 ||
    bodyBytes > bounds.maxResponseBodyBytes
  ) {
    throw new RangeError("response is outside its configured bound");
  }
  if (headers.length > bounds.maxResponseHeaders)
    throw new RangeError("response header capacity exhausted");
  const bytes = headers.reduce(
    (sum, entry) =>
      sum + Buffer.byteLength(entry.name) + Buffer.byteLength(entry.value),
    0,
  );
  if (bytes > bounds.maxResponseHeaderBytes)
    throw new RangeError("response headers exceed their bound");
}

function sendBuffered(outgoing, status, headers, body) {
  const values = withDefault(
    headers,
    "content-length",
    String(body.byteLength),
  );
  outgoing.writeHead(
    status,
    values.map(({ name, value }) => [name, value]),
  );
  outgoing.end(body);
}

async function sendStream(outgoing, status, headers, source, trailers, bounds) {
  validateResponse(status, headers, 0, bounds);
  outgoing.writeHead(
    status,
    headers.map(({ name, value }) => [name, value]),
  );
  let chunks = 0;
  let total = 0;
  for await (const value of source) {
    const chunk = asChunk(value);
    chunks += 1;
    total += chunk.byteLength;
    if (
      chunks > bounds.maxResponseChunks ||
      chunk.byteLength > bounds.maxResponseChunkBytes ||
      total > bounds.maxResponseBodyBytes
    ) {
      throw new RangeError("response stream exceeds its configured bound");
    }
    if (!outgoing.write(chunk)) await once(outgoing, "drain");
  }
  if (trailers.length !== 0)
    outgoing.addTrailers(
      Object.fromEntries(trailers.map(({ name, value }) => [name, value])),
    );
  outgoing.end();
}

function withDefault(headers, name, value) {
  const normalized = normalizeHeaders(headers);
  return normalized.some((entry) => entry.name === name)
    ? normalized
    : [...normalized, { name, value }];
}

async function prepareStatic(items) {
  const mounts = [];
  for (const item of items) {
    const root = await realpath(resolve(item.directory));
    if (
      !item.urlPrefix.startsWith("/") ||
      (item.urlPrefix !== "/" && item.urlPrefix.endsWith("/"))
    ) {
      throw new RangeError("static URL prefix is invalid");
    }
    mounts.push(Object.freeze({ ...item, root }));
  }
  return Object.freeze(
    mounts.sort(
      (left, right) => right.urlPrefix.length - left.urlPrefix.length,
    ),
  );
}

async function staticResponse(mounts, method, pathname, headers, bounds) {
  if (method !== "GET" && method !== "HEAD") return null;
  for (const mount of mounts) {
    if (
      mount.urlPrefix !== "/" &&
      pathname !== mount.urlPrefix &&
      !pathname.startsWith(`${mount.urlPrefix}/`)
    )
      continue;
    let decoded;
    try {
      decoded = decodeURIComponent(
        pathname.slice(mount.urlPrefix.length),
      ).replace(/^\/+/, "");
    } catch {
      return Response.text("not found", { status: 404 });
    }
    if (
      decoded
        .split(/[\\/]/u)
        .some((segment) => segment === "." || segment === "..")
    )
      return Response.text("not found", { status: 404 });
    let candidate = resolve(mount.root, decoded);
    if (!inside(mount.root, candidate))
      return Response.text("not found", { status: 404 });
    let details = await optionalStat(candidate);
    if (details?.isDirectory()) {
      candidate = resolve(candidate, mount.indexFile);
      details = await optionalStat(candidate);
    }
    const acceptsHtml = String(headers.accept ?? "")
      .toLowerCase()
      .includes("text/html");
    if (!details?.isFile() && mount.spaFallback && acceptsHtml) {
      candidate = resolve(mount.root, mount.indexFile);
      details = await optionalStat(candidate);
    }
    if (!details?.isFile() || !inside(mount.root, await realpath(candidate)))
      return Response.text("not found", { status: 404 });
    if (details.size > bounds.maxResponseBodyBytes)
      return Response.text("file too large", { status: 413 });
    const modified = Math.trunc(details.mtimeMs / 1000) * 1000;
    const etag = `"${details.size.toString(16)}-${modified.toString(16)}"`;
    const extension = /\.[^.]+$/u.exec(candidate)?.[0].toLowerCase() ?? "";
    const responseHeaders = [
      { name: "etag", value: etag },
      { name: "last-modified", value: new Date(modified).toUTCString() },
      { name: "cache-control", value: mount.cacheControl },
      { name: "accept-ranges", value: "bytes" },
      {
        name: "content-type",
        value: MIME_TYPES[extension] ?? "application/octet-stream",
      },
    ];
    if (
      headers["if-none-match"] === etag ||
      notModified(headers["if-modified-since"], modified)
    ) {
      return new Response(undefined, { status: 304, headers: responseHeaders });
    }
    let body = new Uint8Array(await readFile(candidate));
    if (body.byteLength !== details.size)
      throw new Error("static file changed while being read");
    const rangeValue = headers.range;
    const range = parseRange(rangeValue, body.byteLength);
    if (rangeValue !== undefined && range === null) {
      return new Response(undefined, {
        status: 416,
        headers: [
          ...responseHeaders,
          { name: "content-range", value: `bytes */${body.byteLength}` },
        ],
      });
    }
    let statusCode = 200;
    if (range !== null) {
      statusCode = 206;
      responseHeaders.push({
        name: "content-range",
        value: `bytes ${range.start}-${range.end}/${body.byteLength}`,
      });
      body = body.slice(range.start, range.end + 1);
    }
    return new Response(method === "HEAD" ? undefined : body, {
      status: statusCode,
      headers: responseHeaders,
    });
  }
  return null;
}

async function optionalStat(path) {
  try {
    return await stat(path);
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    throw error;
  }
}

function inside(root, candidate) {
  const value = relative(root, candidate);
  return value === "" || (!value.startsWith("..") && !isAbsolute(value));
}

function parseRange(value, size) {
  if (value === undefined) return null;
  const match = /^bytes=(\d*)-(\d*)$/u.exec(value);
  if (match === null || size === 0 || (match[1] === "" && match[2] === ""))
    return null;
  let start;
  let end;
  if (match[1] === "") {
    const suffix = Number(match[2]);
    if (!Number.isSafeInteger(suffix) || suffix <= 0) return null;
    start = Math.max(0, size - suffix);
    end = size - 1;
  } else {
    start = Number(match[1]);
    end = match[2] === "" ? size - 1 : Number(match[2]);
  }
  return Number.isSafeInteger(start) &&
    Number.isSafeInteger(end) &&
    start >= 0 &&
    start < size &&
    end >= start &&
    end < size
    ? { start, end }
    : null;
}

function notModified(value, modified) {
  if (value === undefined) return false;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) && parsed >= modified;
}

class RequestRejected extends Error {
  constructor(status, message) {
    super(message);
    this.name = "RequestRejected";
    this.status = status;
  }
}
