import { Buffer } from "node:buffer";

const encoder = new TextEncoder();
const decoder = new TextDecoder();

function ownedBytes(value, label = "bytes") {
  if (value === undefined || value === null) return new Uint8Array();
  if (typeof value === "string") return encoder.encode(value);
  if (!(value instanceof Uint8Array)) {
    throw new TypeError(`${label} must be a string or Uint8Array`);
  }
  if (
    typeof SharedArrayBuffer !== "undefined" &&
    value.buffer instanceof SharedArrayBuffer
  ) {
    throw new TypeError(`${label} must not use SharedArrayBuffer`);
  }
  return new Uint8Array(value);
}

export function normalizeHeaders(input) {
  if (input === undefined) return Object.freeze([]);
  const entries =
    input instanceof Headers
      ? [...input.entries()].map(([name, value]) => ({ name, value }))
      : Array.isArray(input)
        ? input
        : Object.entries(input).map(([name, value]) => ({
            name,
            value: String(value),
          }));
  return Object.freeze(
    entries.map((entry) => {
      if (entry === null || typeof entry !== "object") {
        throw new TypeError("header entries must be objects");
      }
      const name = String(entry.name).toLowerCase();
      const value = String(entry.value);
      if (!/^[!#$%&'*+.^_`|~0-9a-z-]+$/u.test(name) || /[\r\n]/u.test(value)) {
        throw new RangeError("header entry is invalid");
      }
      return Object.freeze({ name, value });
    }),
  );
}

export class HeaderList {
  #entries;

  constructor(entries = []) {
    this.#entries = normalizeHeaders(entries);
    Object.freeze(this);
  }

  get(name) {
    const key = String(name).toLowerCase();
    return this.#entries.find((entry) => entry.name === key)?.value ?? null;
  }

  getAll(name) {
    const key = String(name).toLowerCase();
    return this.#entries
      .filter((entry) => entry.name === key)
      .map((entry) => entry.value);
  }

  has(name) {
    return this.get(name) !== null;
  }

  entries() {
    return this.#entries[Symbol.iterator]();
  }

  [Symbol.iterator]() {
    return this.entries();
  }
}

export class Request {
  #body;
  #bodyStream;

  constructor({
    method,
    target,
    path,
    query,
    headers,
    params,
    body,
    bodyStream,
    form,
    multipart,
    signal,
  }) {
    this.method = method;
    this.target = target;
    this.path = path;
    this.query = query;
    this.headers = new HeaderList(headers);
    this.params = Object.freeze(Object.assign(Object.create(null), params));
    this.form = Object.freeze(form ?? []);
    this.multipart = Object.freeze(multipart ?? []);
    this.signal = signal;
    this.#body = ownedBytes(body, "request body");
    this.#bodyStream = bodyStream;
    Object.freeze(this);
  }

  bytes() {
    return new Uint8Array(this.#body);
  }

  text() {
    return decoder.decode(this.#body);
  }

  json() {
    return JSON.parse(this.text());
  }

  stream() {
    if (this.#bodyStream !== undefined) return this.#bodyStream;
    const body = this.bytes();
    return (async function* () {
      if (body.byteLength !== 0) yield body;
    })();
  }
}

export class Response {
  constructor(body = undefined, { status = 200, headers } = {}) {
    if (!Number.isInteger(status) || status < 200 || status > 599) {
      throw new RangeError("response status must be an integer in [200, 599]");
    }
    this.status = status;
    this.headers = normalizeHeaders(headers);
    this.body =
      body === undefined ? undefined : ownedBytes(body, "response body");
    Object.freeze(this);
  }

  static empty({ status = 204, headers } = {}) {
    return new Response(undefined, { status, headers });
  }

  static bytes(body, options) {
    return new Response(body, options);
  }

  static text(body, { status = 200, headers } = {}) {
    return new Response(body, {
      status,
      headers: withDefaultHeader(
        headers,
        "content-type",
        "text/plain; charset=utf-8",
      ),
    });
  }

  static json(value, { status = 200, headers } = {}) {
    const body = JSON.stringify(value);
    if (body === undefined)
      throw new TypeError("JSON response is not serializable");
    return new Response(body, {
      status,
      headers: withDefaultHeader(
        headers,
        "content-type",
        "application/json; charset=utf-8",
      ),
    });
  }
}

export class StreamResponse {
  constructor(source, { status = 200, headers, trailers } = {}) {
    requireIterable(source, "response stream");
    requireResponseStatus(status);
    this.source = source;
    this.status = status;
    this.headers = normalizeHeaders(headers);
    this.trailers = normalizeHeaders(trailers);
    Object.freeze(this);
  }
}

export class ServerEvent {
  constructor(data, { event, id, retryMillis } = {}) {
    this.data = String(data);
    this.event = event;
    this.id = id;
    this.retryMillis = retryMillis;
    if (event !== undefined && /[\r\n]/u.test(event)) {
      throw new RangeError("server event name contains a line break");
    }
    if (id !== undefined && /[\r\n\0]/u.test(id)) {
      throw new RangeError("server event id contains a forbidden character");
    }
    if (
      retryMillis !== undefined &&
      (!Number.isSafeInteger(retryMillis) || retryMillis < 0)
    ) {
      throw new RangeError("server event retry must be a nonnegative integer");
    }
    Object.freeze(this);
  }

  encode() {
    const lines = [];
    if (this.event !== undefined) lines.push(`event: ${this.event}`);
    if (this.id !== undefined) lines.push(`id: ${this.id}`);
    if (this.retryMillis !== undefined)
      lines.push(`retry: ${this.retryMillis}`);
    for (const line of this.data.split(/\r?\n/u)) lines.push(`data: ${line}`);
    return encoder.encode(`${lines.join("\n")}\n\n`);
  }
}

export class EventResponse {
  constructor(events, { status = 200, headers } = {}) {
    requireIterable(events, "server event stream");
    requireResponseStatus(status);
    this.events = events;
    this.status = status;
    this.headers = normalizeHeaders(headers);
    Object.freeze(this);
  }
}

export class StaticContent {
  constructor(
    directory,
    {
      urlPrefix = "/",
      indexFile = "index.html",
      spaFallback = false,
      cacheControl = "public, max-age=60",
    } = {},
  ) {
    this.directory = String(directory);
    this.urlPrefix = urlPrefix;
    this.indexFile = indexFile;
    this.spaFallback = Boolean(spaFallback);
    this.cacheControl = cacheControl;
    if (this.directory.length === 0)
      throw new RangeError("static directory is empty");
    if (
      !this.urlPrefix.startsWith("/") ||
      (this.urlPrefix !== "/" && this.urlPrefix.endsWith("/")) ||
      this.indexFile.length === 0 ||
      /[\\/]/u.test(this.indexFile) ||
      this.indexFile === "." ||
      this.indexFile === ".." ||
      /[\r\n]/u.test(this.cacheControl)
    ) {
      throw new RangeError("static content declaration is invalid");
    }
    Object.freeze(this);
  }
}

export class TlsConfiguration {
  constructor(
    certificate,
    privateKey,
    { caCertificate, requireClientCertificate = false } = {},
  ) {
    this.certificate = certificate;
    this.privateKey = privateKey;
    this.caCertificate = caCertificate;
    this.requireClientCertificate = Boolean(requireClientCertificate);
    for (const value of [certificate, privateKey, caCertificate]) {
      if (
        value !== undefined &&
        typeof value !== "string" &&
        !(value instanceof Uint8Array)
      ) {
        throw new TypeError(
          "certificate sources must be paths or Uint8Array values",
        );
      }
    }
    Object.freeze(this);
  }
}

export const HttpProtocol = Object.freeze({
  HTTP_1_1: "http/1.1",
  HTTP_2: "h2",
});

export function asChunk(value) {
  return ownedBytes(value, "stream chunk");
}

function requireIterable(value, label) {
  if (
    value === null ||
    value === undefined ||
    (typeof value[Symbol.iterator] !== "function" &&
      typeof value[Symbol.asyncIterator] !== "function") ||
    typeof value === "string" ||
    value instanceof Uint8Array
  ) {
    throw new TypeError(`${label} must yield chunks`);
  }
}

function withDefaultHeader(headers, name, value) {
  const normalized = normalizeHeaders(headers);
  return normalized.some((entry) => entry.name === name)
    ? normalized
    : [{ name, value }, ...normalized];
}

function requireResponseStatus(status) {
  if (!Number.isInteger(status) || status < 200 || status > 599) {
    throw new RangeError("response status must be an integer in [200, 599]");
  }
}

export function byteLength(value) {
  return typeof value === "string"
    ? Buffer.byteLength(value)
    : value.byteLength;
}
