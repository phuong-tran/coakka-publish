# CoAkka HTTP for Bun and Node — local candidate

Host-inlined JavaScript handlers, with Core owning HTTP I/O, bounded work,
configuration, timeouts and lifecycle. This is a local package candidate, not
a published npm release. See the Windows guidance below for engine qualification.

The consumer baseline is Node.js22 or Bun1.2.22. Choose the archive matching
the **runtime process architecture**, not merely the computer's architecture.
An x64 process under emulation consumes the x86-64 archive. Native compatibility
also depends on the chosen JavaScript engine's own OS requirements.

| Archive target | Native baseline |
| --- | --- |
| macos-aarch64 | macOS11+, ARM64 process |
| linux-aarch64 | glibc2.28+, ARM64 process |
| linux-x86_64 | glibc2.28+, x86-64 process |
| windows-aarch64 | Windows ARM64 process; runtime availability must be qualified |
| windows-x86_64 | Windows x86-64 process |

No musl, Android or macOS x86-64 package is included. Version minima describe
API requirements, not a recommendation to stay on an old security patch.

**Windows Bun recommendation:** use Bun **1.4.2 or later**, choosing native
ARM64 Bun on Windows ARM64. Version 1.4.2 is the tested reference; the API
baseline stays Bun1.2.22 on Linux/macOS. Earlier Windows x64 Bun builds crashed
in our Windows ARM64 emulation tests, including a standalone test without
CoAkka. Related upstream reports are
[Bun #26150](https://github.com/oven-sh/bun/issues/26150) and
[Bun #21869](https://github.com/oven-sh/bun/issues/21869); neither is confirmed
as the exact cause or as fixed by 1.4.2. Physical Intel/AMD Windows qualification
remains separate from the emulated x64 result.

## Install locally

Install the archive for your process into your application. There are no
postinstall scripts, compiler steps, dependency downloads or runtime extraction:

```sh
npm install --ignore-scripts /absolute/path/coakka-http-javascript-1.0.0-candidate-macos-aarch64.tgz
```

The package contains a single JavaScript module, documented TypeScript types,
the matching native files and legal notices. Keep its `native/` directory intact.
The package loads its own native addon by a fixed relative path; no environment
variable is required. Do not mix native files from different packages, modify
installed files while loaded, or add untrusted library search directories.

For a deliberate development override, set `COAKKA_HTTP_JAVASCRIPT_ADDON` before
importing the package to a nonempty absolute addon path. An invalid override
fails; it never silently falls back to another addon. Import is fail-fast when
native loading or ABI validation fails, and owns no HTTP listener by itself.

## A server

```js
import { Builder, Response } from "@coakka/http";

const service = new Builder()
  .listen("127.0.0.1", 8080)
  .get("/hello", () => Response.text("Hello from CoAkka HTTP"))
  .start();

console.log(`Listening on http://127.0.0.1:${service.port}`);
process.once("SIGINT", async () => {
  try {
    await service.close();
  } catch (error) {
    console.error("HTTP service shutdown failed", error);
    process.exitCode = 1;
  }
});
```

Handlers may return a response or a promise. Application work stays in the host
language. Core can use multiple native CPUs/loops without making one JavaScript
handler execute concurrently on multiple JS threads. Do not block the JS event
loop with long synchronous application work.

## Configuration and lifecycle

Incremental upload handlers receive `start`, `data`, `trailers`, `end`, and
exactly one final `dispose` event for every admitted start. Release any
per-request application buffers in `dispose`, not only in `end`: a client can
disconnect before sending its complete body. The callback must return
`undefined` synchronously, without a response or an awaited service close.
Its typed cause identifies connector scope disposal, not successful HTTP
delivery. `end` disposal waits for the end handler and response producer to
settle; cancellation/terminal disposal follows Core events. Successful Core
stop disposes remaining input scopes, while refused stop retains them.
One accepted handler slot bounds each stream and its continuations. Cleanup
exceptions remain diagnostics; they never cause a second HTTP response.

Start with defaults. Optional `Limits`, `CpuPolicy` and
`NotificationProfile` values express intent; Core decides and reports accepted
settings through `service.runtimeInfo()`. HTTP-loop tuning is private to the
connector, not an application setting in either construction API. Core's
immutable decision is in `execution.selection`, meaningful when
`execution.observed` is true. CPU budget, native loops and JS handler concurrency
are distinct. Core never disables a feature to admit a preference; connector
code does not probe the OS, retry with different tuning or invent effective
configuration. Configuration settings are startup-only.

Core owns header, body, keep-alive, idle, request and drain deadlines. Await
`service.close()` to stop admission and allow admitted work to finish within
the configured budget. Expiry is a typed failure, not graceful success. A caller
wait ending does not transfer ownership or authorize a replacement service;
retain the owner and handle/retry according to the reported outcome. Close must
not be awaited from its own handler. Core outcome and handler completion remain
distinct; never infer native completion from a client receiving its response.

`index.d.ts` documents the full public surface: HTTP/TLS, routing and versioned
handler changes, streams, SSE, WebSockets, static/file delivery, outbound calls,
monitoring and runtime information. Await stream writes and terminal operations;
Core's writable admission precedes producer execution. Header lookups are
case-insensitive; ordered duplicate values remain available. Request snapshots
do not expose mutable native memory.

Use route generations and binding revisions returned by Core for control-plane
updates. A timeout is not proof that an update was rejected; retry the exact
activation identity and inspect the Core-issued effective state. A retirement
observation does not dispose outstanding JavaScript promises or WebSocket work.

`service.routes` and `service.routeSnapshot()` both pull an immutable coherent
Core route cut, independently of monitoring. They do not return local handler
declarations or fabricate state on failed inspection. Retained snapshots stay
unchanged after publication.

Outbound results preserve numeric Core causes through `OutboundReason`,
`OutboundPhase`, `OutboundRetry` and `OutboundCertainty` named constants. Unknown
numeric values remain intact. A complete HTTP error response has reason
`OutboundReason.RESPONSE`, not a transport failure. Neither HTTP status nor
diagnostic text substitutes for Core's typed result.

Buffered GZIP policy composes with identity streaming: enabling compression
does not buffer streaming responses or silently enable streaming compression.

Diagnostics are for trusted operators. Do not automatically expose internal
error detail, credentials or peer identity to HTTP clients. Authentication and
application authorization remain app-host responsibilities.
