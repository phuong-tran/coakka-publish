# CoAkka HTTP for Bun and Node — candidate release notes

This is an unpublished candidate note. It does not announce a registry release.

## Incremental request cleanup

This candidate adds the typed `dispose` event to incremental upload handlers.
It closes a gap where a disconnected upload could leave application-owned
chunk buffers waiting for an `end` event that never arrives. Handle disposal
synchronously and release retained state there. It is not a success response
or an inferred cancellation timeout. Stream scopes and their asynchronous
continuations share the existing bounded handler admission budget. Core and
native addon binaries are unchanged by this JavaScript contract correction.

## Windows: recommended Bun version

On Windows, use **Bun 1.4.2 or later**, with the native ARM64 Bun build on
Windows ARM64. Bun 1.4.2 is the tested reference version for this recommendation;
later versions are not individually certified by that result.

The connector's API compatibility baseline remains Bun 1.2.22. This Windows
recommendation does not raise the Linux/macOS baseline or change Node.js
requirements. Choose the CoAkka package matching the Bun process architecture.

Windows qualification reproduced a native process crash in Bun 1.2.22 x64
under Windows ARM64 emulation using a standalone JavaScript test that did not
load CoAkka. Bun 1.3.14 x64 also crashed during candidate package tests in that
environment. Bun 1.4.2 passed the standalone control and the candidate package
suite on the same Windows 11 ARM64 runner, both as a native ARM64 process and
as an emulated x64 process: five standalone trials and three complete suite
runs per architecture, with no crash observed. This is bounded test evidence,
not a guarantee that
every Bun crash is fixed. Physical Intel/AMD Windows execution was not tested
in this qualification.

Related upstream reports:

- [Bun issue 26150: Windows update failures on a Windows ARM64 Mac VM](https://github.com/oven-sh/bun/issues/26150).
- [Bun issue 21869: x64-baseline build crash on Windows ARM64](https://github.com/oven-sh/bun/issues/21869).

These reports provide environment context; neither has been established as the
exact cause of the failure observed here. This note does not claim an upstream
fix for either issue in Bun 1.4.2. JavaScript `try/catch` is not a recovery
mechanism for a native process access violation.
