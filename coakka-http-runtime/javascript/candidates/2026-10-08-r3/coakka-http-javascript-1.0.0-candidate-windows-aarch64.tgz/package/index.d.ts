/** JavaScript input accepted for an unsigned 64-bit identifier. */
export type UInt64 = number | bigint;
/** Bytes accepted by request and response methods. */
export type Bytes = string | Uint8Array;
/** Response family declared before a service starts. */
export type ResponseKind = "buffered" | "file" | "stream" | "sse" | "websocket";

/** Core-issued native I/O drain outcome, independent of JavaScript promises. */
export const DrainState: Readonly<{
  /** Drain was not accepted; observation includes its native error. */
  NOT_STARTED: 0;
  /** Core is still draining; caller wait expiry does not change this state. */
  PENDING: 1;
  /** Native work quiesced, not a guarantee that every exchange succeeded. */
  COMPLETE: 2;
  /** Core's own drain deadline forced termination. */
  EXPIRED: 3;
  /** Explicit stop interrupted drain. */
  ABORTED: 4;
  /** Native drain failed. */
  FAILED: 5;
  /** Core cannot certify this configured scope. */
  UNSUPPORTED: 6;
}>;
/** Immutable observation copied from Core; unknown future state numbers remain intact. */
export interface DrainObservation {
  /** Core's typed outcome; use DrainState for known values. */
  readonly state: number;
  /** Native cause, absent for COMPLETE and PENDING; no status-text inference. */
  readonly error: Error | undefined;
}
/** Graceful-close failure; cleanup success never erases a failed Core outcome. */
export class ServiceCloseError extends Error {
  private constructor();
  /** Core observation, not a JavaScript timer-derived state. */
  readonly drainState: number;
  /** True requires retaining the Service and retrying close. */
  readonly runtimeRetained: boolean;
  /** Native drain wait or the separate bounded JavaScript continuation wait. */
  readonly phase: "drain" | "handlers";
}
/** Startup and cleanup both failed; this error retains the sole retry owner. */
export class StartupCleanupError extends AggregateError {
  private constructor();
  /** Original cleanup failure; the inherited cause is the original startup error. */
  readonly cleanupError: unknown;
  /** True until retry cleanup succeeds or Core reports no resources retained. */
  readonly runtimeRetained: boolean;
  /** Retry cleanup without re-running startup; preserve both original causes. */
  retryCleanup(): void;
}

/** One immutable HTTP header. */
export class Header {
  /** Validate and copy one field name and value. */
  constructor(name: string, value: string);
  /** Original field name. */
  readonly name: string;
  /** Latin-1 field value. */
  readonly value: string;
}

/** Immutable ordered headers with average O(1) case-insensitive lookup. */
export class Headers implements Iterable<Header> {
  /** Copy entries while preserving declaration order and duplicates. */
  constructor(entries?: Headers | ReadonlyArray<Header>);
  /** Number of entries including duplicates. */
  readonly size: number;
  /** Return the first matching value, or `null`. */
  get(name: string): string | null;
  /** Return all matching values in declaration order. */
  getAll(name: string): string[];
  /** Iterate in declaration order. */
  [Symbol.iterator](): Iterator<Header>;
}

/** Named startup notification bounds; Auto leaves default selection to Core. */
export const NotificationProfile: Readonly<{
  /** Select the Core default independently for this lane. */
  AUTO: "auto";
  /** Small notification bound. */
  SMALL: "small";
  /** Medium notification bound. */
  MEDIUM: "medium";
  /** Large notification bound. */
  LARGE: "large";
  /** Extra-large notification bound. */
  XLARGE: "xlarge";
  /** Double-extra-large notification bound. */
  XXLARGE: "xxlarge";
  /** Largest supported notification bound. */
  ULTRA: "ultra";
}>;

/** One named notification profile accepted at construction time. */
export type NotificationProfile = typeof NotificationProfile[keyof typeof NotificationProfile];

/** Startup-only host dispatcher placement; never a process CPU quota. */
export const CpuPolicy: Readonly<{
  /** Core selects up to two allowed logical CPUs; one CPU is a valid fallback. */
  AUTO: "auto";
  /** Core selects one allowed logical CPU; unsupported platforms reject it. */
  SINGLE: "single";
}>;
/** One Core-owned dispatcher placement preference. */
export type CpuPolicy = typeof CpuPolicy[keyof typeof CpuPolicy];
/** Entry-time placement result. Later OS policy may change affinity. */
export const CpuPlacement: Readonly<{
  /** Requested one-/two-CPU placement was applied. */
  APPLIED: 0;
  /** Auto was applied to the sole allowed logical CPU. */
  SINGLE_AVAILABLE: 1;
  /** Auto inherited OS placement; selected/available counts are unknown. */
  UNSUPPORTED: 2;
}>;

/** Core-issued mode constants for observation; not application settings. */
export const ExecutionMode: Readonly<{
  /** Core received no preference. */
  DEFAULT: 0;
  /** Core accepted exact intent. */
  EXACT: 1;
  /** Core admitted a preference against complete configuration. */
  PREFER_SUPPORTED: 2;
}>;
/** Core selection explanations; unknown raw values remain visible. */
export const ExecutionReason: Readonly<{
  /** Core selected its default. */
  DEFAULTED: 0;
  /** Core accepted the exact topology. */
  EXACT_SELECTED: 1;
  /** Core accepted the preferred topology. */
  PREFERRED_SELECTED: 2;
  /** A configured facility restricts topology. */
  FACILITY_RESTRICTED: 3;
  /** The resource budget restricts topology. */
  BUDGET_RESTRICTED: 4;
  /** Core's observed CPU allowance restricts topology. */
  CPU_RESTRICTED: 5;
  /** Core has no observed CPU allowance. */
  CPU_UNOBSERVED: 6;
}>;

/** Builder intent. Null/omission delegates numeric native fields to Core; zero also selects its defaults. */
export interface LimitsOptions {
  /** Default Auto. Applies to this JS dispatcher and subsequently created Core threads. */
  readonly cpuPolicy?: CpuPolicy;
  /** Maximum accepted connections. */
  readonly maxConnections?: number | null;
  /** Maximum active requests. */
  readonly maxActiveRequests?: number | null;
  /** Maximum queued requests. */
  readonly requestQueueCapacity?: number | null;
  /** Maximum queued completions. */
  readonly responseQueueCapacity?: number | null;
  /** Maximum bytes in one request body. */
  readonly maxRequestBodyBytes?: number | null;
  /** Maximum bytes in one response body. */
  readonly maxResponseBodyBytes?: number | null;
  /** Handler deadline in milliseconds. */
  readonly requestTimeoutMillis?: number | null;
  /** Stream-write deadline in milliseconds. */
  readonly responseWriteTimeoutMillis?: number | null;
  /** Drain and stop deadline in milliseconds. */
  readonly shutdownTimeoutMillis?: number | null;
  /** Header reception ceiling in milliseconds; null or omitted inherits Core. */
  readonly headerTimeoutMillis?: number | null;
  /** Body reception ceiling in milliseconds; null or omitted inherits Core. */
  readonly bodyTimeoutMillis?: number | null;
  /** Between-request keep-alive ceiling; null or omitted inherits Core. */
  readonly keepAliveTimeoutMillis?: number | null;
  /** Between-request idle ceiling, not a handler deadline; null inherits Core. */
  readonly idleTimeoutMillis?: number | null;
  /** Maximum lifetime handler bindings. */
  readonly maxHandlerBindings?: number;
  /** HTTP/1 request notification profile; omitted or Auto uses the Core default. */
  readonly requestNotificationProfile?: NotificationProfile;
  /** Terminal notification profile; independent of the request profile and startup-only. */
  readonly terminalNotificationProfile?: NotificationProfile;
  /** Linux server event-loop CPU bits; zero inherits OS placement. */
  readonly eventLoopCpuMask?: bigint;
}

/** Immutable construction intent, not the accepted running configuration. */
export class Limits implements Required<LimitsOptions> {
  /** Check JS representation; Core validates native policy at start. */
  constructor(options?: LimitsOptions);
  /** Startup preference. Matching services share placement until the last closes. */
  readonly cpuPolicy: CpuPolicy;
  /** Maximum accepted connections. */
  readonly maxConnections: number | null;
  /** Maximum active requests. */
  readonly maxActiveRequests: number | null;
  /** Maximum queued requests. */
  readonly requestQueueCapacity: number | null;
  /** Maximum queued completions. */
  readonly responseQueueCapacity: number | null;
  /** Maximum bytes in one request body. */
  readonly maxRequestBodyBytes: number | null;
  /** Maximum bytes in one response body. */
  readonly maxResponseBodyBytes: number | null;
  /** Handler deadline in milliseconds. */
  readonly requestTimeoutMillis: number | null;
  /** Stream-write deadline in milliseconds. */
  readonly responseWriteTimeoutMillis: number | null;
  /** Drain and stop deadline in milliseconds. */
  readonly shutdownTimeoutMillis: number | null;
  /** Requested header ceiling, or null for Core's startup default. */
  readonly headerTimeoutMillis: number | null;
  /** Requested body ceiling, or null for Core's startup default. */
  readonly bodyTimeoutMillis: number | null;
  /** Requested keep-alive ceiling, or null for Core's startup default. */
  readonly keepAliveTimeoutMillis: number | null;
  /** Requested between-request idle ceiling, or null for Core's default. */
  readonly idleTimeoutMillis: number | null;
  /** Maximum lifetime handler bindings. */
  readonly maxHandlerBindings: number;
  /** Requested request notification profile; Auto delegates to Core. */
  readonly requestNotificationProfile: NotificationProfile;
  /** Requested terminal notification profile; Auto delegates to Core. */
  readonly terminalNotificationProfile: NotificationProfile;
  /** Requested event-loop CPU bits, or zero to inherit. */
  readonly eventLoopCpuMask: bigint;
}

/** One named route path capture. */
export interface PathParameter {
  /** Capture name. */
  readonly name: string;
  /** Percent-encoded capture bytes. */
  readonly encodedValue: Uint8Array;
}

/** One ordered encoded query item. */
export interface QueryParameter {
  /** Percent-encoded key bytes. */
  readonly encodedKey: Uint8Array;
  /** Percent-encoded value bytes, or `null` when absent. */
  readonly encodedValue: Uint8Array | null;
}

/** Immutable JavaScript-owned inbound request. */
export class Request {
  /** HTTP method. */
  readonly method: string;
  /** Request scheme. */
  readonly scheme: string;
  /** Request authority. */
  readonly authority: string;
  /** Encoded target including query text. */
  readonly target: string;
  /** Ordered request headers. */
  readonly headers: Headers;
  /** Ordered request trailers. */
  readonly trailers: Headers;
  /** Stable logical route ID. */
  readonly routeId: bigint;
  /** Captured structural generation. */
  readonly routeGeneration: bigint;
  /** Captured handler revision. */
  readonly bindingRevision: bigint;
  /** Ordered route path captures. */
  readonly pathParameters: ReadonlyArray<PathParameter>;
  /** Ordered encoded query items. */
  readonly queryParameters: ReadonlyArray<QueryParameter>;
  /** Cancellation observed when the value was copied. */
  readonly cancelled: boolean;
  /** Return a defensive body copy. */
  bytes(): Uint8Array;
  /** Decode the body as UTF-8. */
  text(): string;
}

/** Status and headers shared by response families. */
export interface ResponseOptions {
  /** HTTP status code. */
  readonly status?: number;
  /** Ordered response headers. */
  readonly headers?: Headers | ReadonlyArray<Header>;
}

/** Immutable buffered HTTP response. */
export class Response {
  /** Copy a buffered response body. */
  constructor(body?: Bytes, options?: ResponseOptions);
  /** HTTP status code. */
  readonly status: number;
  /** Ordered immutable response headers. */
  readonly headers: ReadonlyArray<Readonly<{ name: string; value: string }>>;
  /** Defensive response-body copy. */
  readonly body: Uint8Array;
  /** Create a UTF-8 text response. */
  static text(body: string, options?: ResponseOptions): Response;
  /** Create a binary response. */
  static bytes(body: Uint8Array, options?: ResponseOptions): Response;
  /** Create an empty response. */
  static empty(options?: ResponseOptions): Response;
}

/** Application-selected file response confined by one configured authority. */
export class FileResponse {
  /** Select one encoded path within a configured authority. */
  constructor(authorityId: UInt64, encodedPath: string, options?: ResponseOptions);
  /** Configured file authority. */
  readonly authorityId: UInt64;
  /** Relative encoded path. */
  readonly encodedPath: string;
  /** HTTP status code. */
  readonly status: number;
  /** Ordered response headers. */
  readonly headers: ReadonlyArray<Readonly<{ name: string; value: string }>>;
}

/** Single-owner writer supplied to a response-stream producer. */
export class ResponseStreamWriter {
  /** Copy one chunk, waiting for bounded pressure recovery when necessary. */
  write(chunk: Bytes): Promise<number>;
}

/** Response whose producer writes bounded chunks and optional final trailers. */
export class StreamingResponse {
  /** Declare a response-stream producer. */
  constructor(
    producer: (writer: ResponseStreamWriter) =>
      void | ReadonlyArray<Header> | Headers |
      Promise<void | ReadonlyArray<Header> | Headers>,
    options?: ResponseOptions,
  );
  /** HTTP status code. */
  readonly status: number;
  /** Ordered response headers. */
  readonly headers: ReadonlyArray<Readonly<{ name: string; value: string }>>;
}

/** One typed server-sent event. */
export interface SseEvent {
  /** Event data. */
  readonly data: Bytes;
  /** Optional event name. */
  readonly event?: string;
  /** Optional event ID. */
  readonly id?: string;
  /** Optional reconnection delay. */
  readonly retry?: UInt64;
}

/** Typed server-sent-event response. */
export class ServiceSseResponse {
  /** Adopt a bounded iterable event source. */
  constructor(
    source: Iterable<Bytes | SseEvent> | AsyncIterable<Bytes | SseEvent>,
    options?: { readonly headers?: Headers | ReadonlyArray<Header> },
  );
}

/** Create a server-sent-event response. */
export function sse(source: Iterable<Bytes | SseEvent> | AsyncIterable<Bytes | SseEvent>, options?: { readonly headers?: Headers | ReadonlyArray<Header> }): ServiceSseResponse;

/** One inbound WebSocket message. */
export interface WebSocketMessage {
  /** Text or binary frame family. */
  readonly type: "text" | "binary";
  /** Decoded text or copied binary bytes. */
  readonly data: string | Uint8Array;
}

/** One admitted WebSocket session. */
export class ServiceWebSocketSession {
  /** Selected subprotocol. */
  readonly protocol: string;
  /** Whether the session is still open. */
  readonly open: boolean;
  /** Send one text or binary message. */
  send(data: string | Uint8Array): void;
  /** Send a ping control frame. */
  ping(data?: Bytes): void;
  /** Send a pong control frame. */
  pong(data?: Bytes): void;
  /** Start an idempotent close. */
  close(code?: number, reason?: string): void;
}

/** Ordered callback set for one WebSocket route. */
export interface WebSocketCallbacks {
  /** Selected subprotocol. */
  readonly protocol?: string;
  /** Called after upgrade admission. */
  readonly open?: (session: ServiceWebSocketSession) => void | Promise<void>;
  /** Called for each text or binary message. */
  readonly message?: (session: ServiceWebSocketSession, message: WebSocketMessage) => void | Promise<void>;
  /** Called for each ping. */
  readonly ping?: (session: ServiceWebSocketSession, data: Uint8Array) => void | Promise<void>;
  /** Called for each pong. */
  readonly pong?: (session: ServiceWebSocketSession, data: Uint8Array) => void | Promise<void>;
  /** Called after bounded write capacity returns. */
  readonly writable?: (session: ServiceWebSocketSession) => void | Promise<void>;
  /** Called after the session closes. */
  readonly close?: (session: ServiceWebSocketSession, event: Readonly<{ code: number; reason: string }>) => void | Promise<void>;
  /** Observes a callback failure. */
  readonly error?: (error: unknown, session: ServiceWebSocketSession) => void | Promise<void>;
}

/** Handler-selected WebSocket upgrade. */
export class ServiceWebSocketResponse {
  /** Declare a handler-selected WebSocket upgrade. */
  constructor(options?: WebSocketCallbacks);
  /** Selected subprotocol. */
  readonly protocol: string;
}

/** Create a handler-selected WebSocket upgrade. */
export function websocket(options?: WebSocketCallbacks): ServiceWebSocketResponse;

/** Optional bounded request-body admission policy. */
export interface BodyPolicy {
  /** Whether policy checking is enabled. */
  readonly enabled?: boolean;
  /** Accept a missing content type. */
  readonly acceptAbsent?: boolean;
  /** Accept content types outside the specialized families. */
  readonly acceptOther?: boolean;
  /** Accept URL-encoded form bodies. */
  readonly acceptFormUrlencoded?: boolean;
  /** Accept multipart form bodies. */
  readonly acceptMultipartFormData?: boolean;
  /** Maximum admitted body bytes. */
  readonly maxBodyBytes?: UInt64;
}

/** Optional route declaration details. */
export interface RouteOptions {
  /** Declared response family. */
  readonly response?: ResponseKind;
  /** Stable prepared handler binding. */
  readonly handlerBindingId?: UInt64;
  /** Request-body admission policy. */
  readonly bodyPolicy?: BodyPolicy;
}

/** Immutable copied route declaration; query routeSnapshot for effective Core state. */
export class Route {
  /** Create one immutable route declaration value. */
  constructor(
    id: UInt64,
    method: string,
    pattern: string,
    bodyDelivery?: number,
    response?: ResponseKind,
    options?: RouteOptions,
  );
  /** Stable logical route ID. */
  readonly id: UInt64;
  /** Normalized HTTP method. */
  readonly method: string;
  /** Encoded path pattern. */
  readonly pattern: string;
  /** Inline or incremental request-body delivery. */
  readonly bodyDelivery: number;
  /** Declared response family. */
  readonly response: ResponseKind;
  /** Captured handler binding. */
  readonly handlerBindingId: UInt64;
  /** Copied policy intent, or undefined when omitted. */
  readonly bodyPolicy: Readonly<BodyPolicy> | undefined;
}

/** Fields shared by one incremental request-body event. */
export interface StreamRequestEventBase {
  /** Generation-checked request identity. */
  readonly id: GenerationId;
  /** Monotonic per-request sequence. */
  readonly sequence: bigint;
}

/** Why the connector's input scope is being disposed, not an HTTP result.
 * `end` follows the end handler and any response producer settling; `cancelled`
 * and `terminal` follow Core events; `service-stopped` requires successful Core
 * stop. `handler-failed` follows a handler throw/rejection or invalid return.
 */
export type StreamDisposalCause = "end" | "cancelled" | "terminal" |
  "handler-failed" | "service-stopped";

/** One event delivered to an incremental-body handler.
 * Each admitted start receives exactly one dispose, even when no end arrives.
 * Release per-request application state in dispose. Its callback must return
 * undefined synchronously and must not submit a response. Disposal is not
 * proof of successful wire delivery. No event sequence is fabricated for it.
 */
export type StreamRequestEvent =
  | (StreamRequestEventBase & Readonly<{ kind: "start"; request: Request }>)
  | (StreamRequestEventBase & Readonly<{ kind: "data"; data: Uint8Array }>)
  | (StreamRequestEventBase & Readonly<{ kind: "trailers"; trailers: Headers }>)
  | (StreamRequestEventBase & Readonly<{ kind: "end"; trailers: Headers }>)
  | Readonly<{ kind: "dispose"; id: GenerationId; cause: StreamDisposalCause }>;

/** Response value accepted from a handler. */
export type HandlerResponse = Response | FileResponse | StreamingResponse |
  ServiceSseResponse | ServiceWebSocketResponse;
/** Inline-body handler signature. */
export type Handler = (request: Request) => HandlerResponse | Promise<HandlerResponse>;
/** Incremental-body handler signature. */
export type StreamHandler = (event: StreamRequestEvent) =>
  void | HandlerResponse | Promise<void | HandlerResponse>;

/** Listener transport and credential declaration. */
export interface ListenerOptions {
  /** Numeric bind address or host. */
  readonly host?: string;
  /** TCP or UDP port; zero selects an available port. */
  readonly port?: number;
  /** Listener protocol enum value. */
  readonly protocol?: number;
  /** Transport-security enum value. */
  readonly security?: number;
  /** Credential snapshot generation. */
  readonly credentialGeneration?: UInt64;
  /** Stable credential ID. */
  readonly credentialId?: string;
  /** Certificate-chain file. */
  readonly certificateChainFile?: string;
  /** Private-key file. */
  readonly privateKeyFile?: string;
  /** Mutual-TLS trust-roots file. */
  readonly trustRootsFile?: string;
}

/** Construction-time buffered compression intent; Core owns validation and defaults. */
export interface CompressionOptions {
  /** Required named mode; identity response streams remain independent. */
  readonly mode: typeof CompressionMode[keyof typeof CompressionMode];
  /** Minimum eligible body size; omission/zero requests Core's default. */
  readonly minimumBodyBytes?: UInt64;
  /** Maximum eligible body size; omission/zero requests Core's bound. */
  readonly maximumBodyBytes?: UInt64;
  /** Maximum encoded output bytes; omission/zero requests Core's bound. */
  readonly maximumEncodedBytes?: UInt64;
  /** Startup workspace reservation; omission/zero requests Core's bound. */
  readonly workspaceBytes?: UInt64;
  /** Signed encoding effort validated by Core; omission/zero requests its default. */
  readonly gzipLevel?: number;
}

/** Construction-time monitoring reservation and initial policy. */
export interface MonitorOptions {
  /** Initial collection mode. */
  readonly collection: number;
  /** Reserved bounded event slots. */
  readonly eventCapacity?: number;
  /** Maximum events copied by one read. */
  readonly maxEventsPerRead?: number;
  /** Categories available to the initial policy. */
  readonly categories?: number;
  /** Whether signal notification resources are reserved. */
  readonly signalReserved?: boolean;
  /** Whether fixed latency buckets are reserved. */
  readonly fixedLatencyBuckets?: boolean;
}

/** One native-owned static tree. */
export interface StaticMountOptions {
  /** Encoded URL prefix. */
  readonly urlPrefix: string;
  /** Confined filesystem root. */
  readonly rootPath: string;
  /** Optional directory index file. */
  readonly indexFile?: string;
  /** Optional Cache-Control value. */
  readonly cacheControl?: string;
  /** Optional single-page-application fallback. */
  readonly spaFallbackFile?: string;
  /** Whether dot-prefixed paths may be served. */
  readonly includeDotfiles?: boolean;
}

/** One bounded root for application-selected file responses. */
export interface FileAuthorityOptions {
  /** Stable authority identity. */
  readonly id: UInt64;
  /** Confined filesystem root. */
  readonly rootPath: string;
  /** Maximum simultaneously active files. */
  readonly maxActiveFiles?: number;
  /** Maximum bytes served from one file. */
  readonly maxFileBytes?: UInt64;
}

/** Fluent single-use service builder. */
export class Builder {
  /** Select a bind host and port. */
  listen(host: string, port: number): this;
  /** Replace the listener declaration. */
  listener(options: ListenerOptions): this;
  /** Opt in to io_uring; disabled by default. */
  ioUring(enabled?: boolean): this;
  /** Replace construction-time ceilings. */
  limits(limits: Limits): this;
  /** Reserve and configure monitoring. */
  monitor(options: MonitorOptions): this;
  /** Configure bounded response compression. */
  compression(options: CompressionOptions): this;
  /** Add one immutable static tree. */
  staticMount(mount: StaticMountOptions): this;
  /** Add one application-file authority. */
  fileAuthority(authority: FileAuthorityOptions): this;
  /** Replace the outbound declaration. */
  outbound(options: Record<string, unknown>): this;
  /** Add one logical outbound target. */
  outboundTarget(target: Record<string, unknown>): this;
  /** Add one outbound trust generation. */
  outboundTrust(generation: UInt64, caPem: string): this;
  /** Add one outbound mutual-TLS identity generation. */
  outboundIdentity(generation: UInt64, certificateChainPem: string, privateKeyPem: string): this;
  /** Register an inline-body route. */
  route(method: string, pattern: string, handler: Handler, options?: RouteOptions): this;
  /** Register an incremental-body route. */
  routeStream(method: string, pattern: string, handler: StreamHandler, options?: RouteOptions): this;
  /** Register an inline GET route. */
  get(pattern: string, handler: Handler, options?: RouteOptions): this;
  /** Register an inline POST route. */
  post(pattern: string, handler: Handler, options?: RouteOptions): this;
  /** Register an inline PUT route. */
  put(pattern: string, handler: Handler, options?: RouteOptions): this;
  /** Register an inline PATCH route. */
  patch(pattern: string, handler: Handler, options?: RouteOptions): this;
  /** Register an inline DELETE route. */
  delete(pattern: string, handler: Handler, options?: RouteOptions): this;
  /** Register an incremental GET route. */
  getStream(pattern: string, handler: StreamHandler, options?: RouteOptions): this;
  /** Register an incremental POST route. */
  postStream(pattern: string, handler: StreamHandler, options?: RouteOptions): this;
  /** Register an incremental PUT route. */
  putStream(pattern: string, handler: StreamHandler, options?: RouteOptions): this;
  /** Register an incremental PATCH route. */
  patchStream(pattern: string, handler: StreamHandler, options?: RouteOptions): this;
  /** Register an incremental DELETE route. */
  deleteStream(pattern: string, handler: StreamHandler, options?: RouteOptions): this;
  /** Construct and start the service. */
  start(): Service;
}

/** Started HTTP service and its bounded control surfaces. */
export class Service {
  /** Pull an immutable Core route cut; unavailable inspection throws without local fallback. */
  readonly routes: RouteSnapshot;
  /** Validated capability plan. */
  readonly plan: ServicePlan;
  /** Actual bound port. */
  readonly port: number;
  /** Return requested and effective native transport facts. */
  runtimeInfo(): RuntimeInfo;
  /** Pull a coherent health snapshot. */
  health(): HealthSnapshot;
  /** Run a bounded active liveness probe. */
  probeLiveness(timeoutMillis?: number): HealthSnapshot;
  /** Pull the effective monitor configuration. */
  monitorConfig(): Readonly<Record<string, unknown>>;
  /** Pull aggregate monitoring and health truth. */
  monitorSnapshot(): Readonly<Record<string, unknown>>;
  /** Apply a generation-checked monitor policy. */
  monitorApply(expectedGeneration: UInt64, policy: Record<string, unknown>): Readonly<Record<string, unknown>>;
  /** Read a bounded page of monitor events. */
  monitorRead(afterSequence: UInt64, maximumEvents?: number): MonitorEventPage;
  /** Wait for monitor truth; false means timeout. */
  monitorWait(timeoutMillis: number): boolean;
  /** Interrupt the monitor waiter. */
  monitorInterrupt(): void;
  /** Pull a coherent route snapshot. */
  routeSnapshot(): RouteSnapshot;
  /** Submit one copied logical-target request. */
  outboundSubmit(request: Record<string, unknown>): GenerationId;
  /** Request cancellation of an outbound call. */
  outboundCancel(call: GenerationId): void;
  /** Interrupt the outbound completion reader. */
  interruptOutbound(): void;
  /** Asynchronously take one copied outbound completion. */
  takeOutbound(timeoutMillis?: number): Promise<OutboundTerminal | null>;
  /** Prepare an immutable inline-body handler binding. */
  prepareHandler(bindingId: UInt64, handler: Handler, options?: { readonly response?: ResponseKind }): void;
  /** Prepare an immutable incremental-body handler binding. */
  prepareStreamHandler(bindingId: UInt64, handler: StreamHandler, options?: { readonly response?: ResponseKind }): void;
  /** Switch one route to a prepared binding. */
  rebindHandler(request: RouteRebindRequest): RouteRebindOutcome;
  /** Publish a complete structural route generation. */
  publishRoutes(request: RoutePublicationRequest): RoutePublicationOutcome;
  /** Remove the oldest bounded handler diagnostic. */
  pollError(): Error | undefined;
  /** Drain and close. Refused shutdown preserves its owner for retry; CPU restoration can fail after close. */
  close(): Promise<void>;
}

/** One generation-checked native identity. */
export interface GenerationId { readonly slot: bigint; readonly generation: bigint }
/** Current bounded work gauges from one health snapshot. */
export interface ActivitySnapshot {
  /** Active inbound exchanges. */
  readonly activeRequests: number;
  /** Requests waiting for application work. */
  readonly pendingRequests: number;
  /** Retained transport connections. */
  readonly activeConnections: number;
  /** Active WebSocket sessions. */
  readonly webSocketSessions: number;
  /** Pending outbound calls. */
  readonly outboundPending: number;
}
/** One immutable health and liveness snapshot. */
export interface HealthSnapshot {
  /** Native lifecycle value. */
  readonly lifecycle: number;
  /** Snapshot sequence. */
  readonly snapshotSequence: bigint;
  /** Monotonic observation time. */
  readonly observedMonotonicNanos: bigint;
  /** Latest event-loop progress sequence. */
  readonly progressSequence: bigint;
  /** Monotonic time of the latest progress. */
  readonly progressMonotonicNanos: bigint;
  /** Latest acknowledged liveness probe. */
  readonly acknowledgedProbeSequence: bigint;
  /** Monotonic time of the latest probe acknowledgement. */
  readonly acknowledgedProbeMonotonicNanos: bigint;
  /** Effective structural route generation. */
  readonly routeGeneration: bigint;
  /** Effective binding-change sequence. */
  readonly bindingChangeSequence: bigint;
  /** Whether the service is ready. */
  readonly ready: boolean;
  /** Whether new work may be admitted. */
  readonly admissionOpen: boolean;
  /** Current bounded activity gauges. */
  readonly activity: ActivitySnapshot;
}
/** One copied bounded monitoring event. */
export interface MonitorEvent {
  /** Event sequence. */
  readonly sequence: bigint;
  /** Collection epoch containing the event. */
  readonly collectionEpoch: bigint;
  /** Monotonic observation time. */
  readonly observedMonotonicNanos: bigint;
  /** Stable monitoring category. */
  readonly category: number;
  /** Typed failure reason, or zero. */
  readonly failureReason: number;
  /** Queue family associated with pressure, or zero. */
  readonly queueScope: number;
  /** Observed queue depth. */
  readonly queueDepth: number;
  /** Configured queue capacity. */
  readonly queueCapacity: number;
  /** Associated exchange identity, or the zero identity. */
  readonly exchange: GenerationId;
}
/** One immutable page from the bounded monitoring journal. */
export interface MonitorEventPage {
  /** Copied events in sequence order. */
  readonly events: ReadonlyArray<MonitorEvent>;
  /** Oldest retained event sequence. */
  readonly oldestSequence: bigint;
  /** Latest assigned event sequence. */
  readonly latestSequence: bigint;
  /** Events overwritten before this read. */
  readonly overwrittenEvents: bigint;
  /** Events still available after this page. */
  readonly remainingEvents: bigint;
}
/** Core terminal causes; fields retain unknown numeric observations unchanged. */
export const OutboundReason: Readonly<{
  /** Complete HTTP response, including error status codes. */
  RESPONSE: 1;
  /** Transport provider failed admitted work. */
  PROVIDER_FAILURE: 2;
  /** Transport provider refused adoption. */
  PROVIDER_REJECTED: 3;
  /** Core observed cancellation. */
  CANCELLED: 4;
  /** Core deadline expired. */
  DEADLINE_EXCEEDED: 5;
  /** Core stopped the call. */
  STOPPED: 6;
  /** Response head exceeded its bound. */
  RESPONSE_HEAD_LIMIT: 7;
  /** Response body exceeded its bound. */
  RESPONSE_BODY_LIMIT: 8;
  /** Aggregate response retention exceeded its bound. */
  RESPONSE_AGGREGATE_LIMIT: 9;
  /** Allocation failed. */
  OUT_OF_MEMORY: 10;
  /** Required clock observation failed. */
  CLOCK_FAILURE: 11;
  /** Core rejected an invalid provider result. */
  INVALID_PROVIDER_RESULT: 12;
}>;
/** Core causal phase; never derived from HTTP status. */
export const OutboundPhase: Readonly<{
  /** Before transport adoption. */
  ADMISSION: 1;
  /** During transport adoption. */
  PROVIDER_ADOPTION: 2;
  /** During transport work. */
  TRANSPORT: 3;
  /** During response completion or validation. */
  RESPONSE: 4;
  /** During cancellation. */
  CANCELLATION: 5;
  /** During shutdown. */
  SHUTDOWN: 6;
}>;
/** Core disposition; application idempotency and retry budgets remain application policy. */
export const OutboundRetry: Readonly<{
  /** Do not retry this cause automatically. */
  NEVER: 1;
  /** Retry only if application semantics permit. */
  IF_SAFE: 2;
  /** Delivery is uncertain; require explicit application policy. */
  DELIVERY_UNCERTAIN: 3;
}>;
/** Core-issued delivery evidence, not a connector estimate. */
export const OutboundCertainty: Readonly<{
  /** No request bytes were sent. */
  NO_REQUEST_BYTES_SENT: 1;
  /** Core cannot certify request delivery. */
  REQUEST_UNCERTAIN: 2;
  /** Response head was observed. */
  RESPONSE_HEAD_OBSERVED: 3;
  /** A complete response was observed. */
  COMPLETE_RESPONSE: 4;
}>;
/** One copied terminal result from the outbound lane. */
export interface OutboundTerminal {
  /** Core cause; compare known OutboundReason names and preserve unknown uint32 values. */
  readonly reason: number;
  /** Completed call identity. */
  readonly call: GenerationId;
  /** Logical target selected at submission. */
  readonly logicalTarget: string;
  /** Effective target generation. */
  readonly targetGeneration: bigint;
  /** Selected endpoint label. */
  readonly selectedNodeId: string;
  /** Core causal phase; compare OutboundPhase, preserving unknown uint32 values. */
  readonly phase: number;
  /** Core disposition; compare OutboundRetry, not diagnostic text. */
  readonly retry: number;
  /** Core delivery evidence; compare OutboundCertainty without guessing. */
  readonly certainty: number;
  /** HTTP response status, or zero without a response. */
  readonly responseStatus: number;
  /** Provider-specific status code. */
  readonly providerCode: number;
  /** Copied response headers. */
  readonly headers: Headers;
  /** Copied response body. */
  readonly body: Uint8Array;
  /** Bounded operator-facing diagnostic. */
  readonly diagnostic: string;
}
/** One route and binding state entry. */
export interface RouteState {
  /** Stable route ID. */
  readonly routeId: bigint;
  /** Effective handler binding. */
  readonly handlerBindingId: bigint;
  /** Effective binding revision. */
  readonly bindingRevision: bigint;
}
/** Coherent immutable route-table cut. */
export interface RouteSnapshot {
  /** Structural route generation. */
  readonly routeGeneration: bigint;
  /** Monotonic binding-change sequence. */
  readonly bindingChangeSequence: bigint;
  /** Route and binding states. */
  readonly routes: ReadonlyArray<RouteState>;
}
/** Generation-checked handler rebind request. */
export interface RouteRebindRequest {
  /** Idempotency identity. */
  readonly activationId: UInt64;
  /** Expected structural generation. */
  readonly expectedRouteGeneration: UInt64;
  /** Stable route ID. */
  readonly routeId: UInt64;
  /** Expected handler revision. */
  readonly expectedBindingRevision: UInt64;
  /** Prepared replacement handler binding. */
  readonly newHandlerBindingId: UInt64;
}
/** Complete structural route publication request. */
export interface RoutePublicationRequest {
  /** Idempotency identity. */
  readonly activationId: UInt64;
  /** Expected structural generation. */
  readonly expectedRouteGeneration: UInt64;
  /** Expected binding-change sequence. */
  readonly expectedBindingChangeSequence: UInt64;
  /** Complete replacement route declaration. */
  readonly routes: ReadonlyArray<Record<string, unknown>>;
}
/** Effective state returned after one handler-only route switch. */
export interface RouteRebindOutcome {
  /** Core request-capture observation for this publication, not handler disposal permission. */
  readonly requestRetirement: RequestRetirement;
  /** Typed route-control result. */
  readonly code: number;
  /** Evaluated idempotency identity. */
  readonly activationId: bigint;
  /** Stable digest of the evaluated operation. */
  readonly operationDigest: bigint;
  /** Effective structural route generation. */
  readonly routeGeneration: bigint;
  /** Effective binding-change sequence. */
  readonly bindingChangeSequence: bigint;
  /** Evaluated route identity. */
  readonly routeId: bigint;
  /** Previous handler binding. */
  readonly previousHandlerBindingId: bigint;
  /** Previous binding revision. */
  readonly previousBindingRevision: bigint;
  /** Effective handler binding. */
  readonly effectiveHandlerBindingId: bigint;
  /** Effective binding revision. */
  readonly effectiveBindingRevision: bigint;
  /** Whether this call published a new binding. */
  readonly changed: boolean;
  /** Whether a retained outcome was replayed. */
  readonly replayed: boolean;
}
/** Effective state returned after one structural route publication. */
export interface RoutePublicationOutcome {
  /** Independent lifetime observation; exact retry observes the original cut without republishing it. */
  readonly requestRetirement: RequestRetirement;
  /** Typed route-control result. */
  readonly code: number;
  /** Evaluated idempotency identity. */
  readonly activationId: bigint;
  /** Stable digest of the evaluated operation. */
  readonly operationDigest: bigint;
  /** Structural generation before evaluation. */
  readonly previousRouteGeneration: bigint;
  /** Binding sequence before evaluation. */
  readonly previousBindingChangeSequence: bigint;
  /** Effective structural route generation. */
  readonly effectiveRouteGeneration: bigint;
  /** Effective binding-change sequence. */
  readonly effectiveBindingChangeSequence: bigint;
  /** Effective route count. */
  readonly routeCount: number;
  /** Rejected candidate index, or the native sentinel. */
  readonly rejectedRouteIndex: number;
  /** Whether this call published a new route generation. */
  readonly changed: boolean;
  /** Whether a retained outcome was replayed. */
  readonly replayed: boolean;
}

/** Result of complete connector capability validation. */
export interface ServicePlan {
  /** Whether every required capability is implemented. */
  readonly supported: boolean;
  /** Dependency-expanded required capabilities. */
  readonly requiredCapabilities: bigint;
  /** Capabilities implemented by this connector. */
  readonly adapterCapabilities: bigint;
  /** Required capabilities absent from the connector. */
  readonly missingCapabilities: bigint;
}

/** Immutable Core CPU snapshot captured at first scope entry, not a live probe. */
export interface CpuInfo {
  /** Requested named policy; Auto is the default. */
  readonly requestedPolicy: CpuPolicy;
  /** Core placement result (CpuPlacement); retain unknown future numeric values. */
  readonly placement: number;
  /** Initial allowed logical CPU count, not CPU-time quota; zero means unknown. */
  readonly availableCpuCount: number;
  /** Selected logical CPU count (one/two); zero means unsupported/unknown. */
  readonly selectedCpuCount: number;
  /** At most two selected logical CPU IDs; empty when placement is unsupported. */
  readonly selectedCpuIds: ReadonlyArray<number>;
}

/** Complete Core-accepted startup limits; uint64 quantities retain exact BigInt values. */
export interface EffectiveLimits {
  /** Accepted structural route capacity. */
  readonly maxRoutes: number;
  /** Accepted total path-segment capacity. */
  readonly maxTotalSegments: number;
  /** Accepted route storage bytes. */
  readonly maxRouteBytes: number;
  /** Accepted capture count per route. */
  readonly maxCapturesPerRoute: number;
  /** Accepted activation-history capacity. */
  readonly activationHistoryCapacity: number;
  /** Accepted simultaneous connection bound. */
  readonly maxConnections: number;
  /** Accepted active-exchange bound. */
  readonly maxActiveRequests: number;
  /** Accepted request queue capacity. */
  readonly requestQueueCapacity: number;
  /** Accepted completion queue capacity. */
  readonly completionQueueCapacity: number;
  /** Accepted completion processing batch bound. */
  readonly completionBatchSize: number;
  /** Accepted per-message header count. */
  readonly maxHeaderCount: number;
  /** Accepted per-message header bytes. */
  readonly maxHeaderBytes: number;
  /** Accepted request-stream chunk slots. */
  readonly requestStreamChunkSlots: number;
  /** Accepted retained request-stream item count. */
  readonly requestStreamMaxRetainedItems: number;
  /** Accepted response-stream chunk slots. */
  readonly responseStreamChunkSlots: number;
  /** Accepted retained response-stream item count. */
  readonly responseStreamMaxRetainedItems: number;
  /** Accepted route-control queue capacity. */
  readonly routeControlCapacity: number;
  /** Accepted route-control history capacity. */
  readonly routeControlHistoryCapacity: number;
  /** Accepted route commands per loop turn. */
  readonly routeControlMaxCommandsPerTurn: number;
  /** Accepted terminal-observation capacity. */
  readonly terminalQueueCapacity: number;
  /** Accepted deadline processing interval in milliseconds. */
  readonly deadlineTickMillis: number;
  /** Accepted connection-expiry processing batch bound. */
  readonly connectionTimeoutBatchSize: number;
  /** Core-resolved numeric request profile, never AUTO. */
  readonly requestNotificationProfile: number;
  /** Core-resolved numeric terminal profile, never AUTO. */
  readonly terminalNotificationProfile: number;
  /** Accepted request body byte ceiling. */
  readonly maxRequestBodyBytes: bigint;
  /** Accepted response body byte ceiling. */
  readonly maxResponseBodyBytes: bigint;
  /** Accepted keep-alive deadline in milliseconds. */
  readonly keepAliveTimeoutMillis: bigint;
  /** Accepted header deadline in milliseconds. */
  readonly headerTimeoutMillis: bigint;
  /** Accepted body reception deadline in milliseconds. */
  readonly bodyTimeoutMillis: bigint;
  /** Accepted handler deadline in milliseconds. */
  readonly handlerTimeoutMillis: bigint;
  /** Accepted idle deadline in milliseconds. */
  readonly idleTimeoutMillis: bigint;
  /** Accepted native drain deadline in milliseconds. */
  readonly drainTimeoutMillis: bigint;
  /** Accepted native stop deadline in milliseconds. */
  readonly stopTimeoutMillis: bigint;
  /** Accepted response-write deadline in milliseconds. */
  readonly responseWriteTimeoutMillis: bigint;
  /** Accepted bytes per request-stream chunk. */
  readonly requestStreamMaxChunkBytes: bigint;
  /** Accepted bytes in request-stream trailers. */
  readonly requestStreamMaxTrailerBytes: bigint;
  /** Accepted retained bytes per request stream. */
  readonly requestStreamMaxRetainedBytes: bigint;
  /** Accepted total retained request-stream bytes. */
  readonly requestStreamMaxTotalRetainedBytes: bigint;
  /** Accepted bytes per response-stream chunk. */
  readonly responseStreamMaxChunkBytes: bigint;
  /** Accepted bytes in response-stream trailers. */
  readonly responseStreamMaxTrailerBytes: bigint;
  /** Accepted retained bytes per response stream. */
  readonly responseStreamMaxRetainedBytes: bigint;
  /** Accepted total retained response-stream bytes. */
  readonly responseStreamMaxTotalRetainedBytes: bigint;
  /** Accepted loop mask; zero means inherited placement, not zero CPUs. */
  readonly eventLoopCpuMask: bigint;
}

/** Requested and effective native transport facts. */
export interface RuntimeInfo {
  /** Core-issued bounded owner sample; not CPU utilization, an OS thread census or a lifetime barrier. */
  readonly execution: ExecutionInfo;
  /** Immutable accepted startup limits issued by Core, not copied user input. */
  readonly limits: EffectiveLimits;
  /** Core-owned dispatcher placement; unrelated pre-existing workers are not constrained. */
  readonly cpu: CpuInfo;
  /** Public host ABI revision. */
  readonly abiVersion: number;
  /** Implemented runtime feature bits. */
  readonly features: bigint;
  /** Whether the binary contains io_uring support. */
  readonly ioUringCompiled: boolean;
  /** Whether the host supports the eligible io_uring path. */
  readonly ioUringSupported: boolean;
  /** Platform probe error, or zero. */
  readonly ioUringProbeError: number;
  /** Whether the connector requested io_uring. */
  readonly ioUringRequested: boolean;
  /** Whether io_uring is the effective backend. */
  readonly ioUringEffective: boolean;
  /** Whether an eligible platform probe ran. */
  readonly ioUringProbed: boolean;
  /** Stable native fallback reason. */
  readonly fallbackReason: number;
  /** Whether the service is started. */
  readonly serviceStarted: boolean;
  /** Effective HTTP/1 request notification cap. */
  readonly requestNotificationBatchSize: number;
  /** Effective terminal notification cap; terminal events are queued immediately. */
  readonly terminalNotificationBatchSize: number;
  /** Requested logical CPU mask; zero inherits OS placement. */
  readonly eventLoopCpuMask: bigint;
  /** Whether explicit loop placement is supported by this native build. */
  readonly eventLoopCpuMaskSupported: boolean;
  /** Whether an explicit mask was verified when the service started. */
  readonly eventLoopCpuMaskApplied: boolean;
}

/** Complete callback-free runtime construction input. */
export interface RuntimeConfiguration extends Record<string, unknown> {
  /** Optional bounded buffered compression; omission leaves it disabled in Core. */
  readonly compression?: CompressionOptions;
  /** Advanced native startup limits; CPU policy defaults to Auto in Core. */
  readonly limits?: Readonly<Record<string, unknown> & { readonly cpuPolicy?: CpuPolicy }>;
  /** Listener declaration, or `null` for outbound-only use. */
  readonly listener?: ListenerOptions | null;
  /** io_uring opt-in; defaults to false. */
  readonly ioUring?: boolean;
  /** Immutable startup route declaration. */
  readonly routes?: ReadonlyArray<Record<string, unknown>>;
}

/** Callback-free owner for advanced integration and complete feature access. */
export class Runtime {
  /** Complete implemented feature bits. */
  readonly features: bigint;
  /** Return requested and effective native transport facts. */
  runtimeInfo(): RuntimeInfo;
  /** Start all configured native facilities. */
  start(): this;
  /** Return the actual bound port. */
  port(): number;
  /** Close admission while permitting bounded drain. */
  drain(): void;
  /** Nonblocking native barrier observation; does not consume events or stop Core. */
  drainState(): DrainObservation;
  /** Async caller budget 0..2147483647ms. PENDING is returned, never relabeled EXPIRED. */
  waitDrained(timeoutMillis?: number): Promise<DrainObservation>;
  /** Stop within configured deadlines. */
  stop(): void;
  /** Interrupt the inbound reader. */
  interrupt(): void;
  /** Checked close. Failure with runtimeRetained=true preserves the native owner for retry. */
  close(): void;
  /** Take one copied inbound event or `null` on timeout. */
  takeEvent(timeoutMillis?: number): Readonly<Record<string, unknown>> | null;
  /** Return whether cancellation was observed. */
  exchangeCancelled(exchange: GenerationId): boolean;
  /** Complete with a buffered response. */
  respond(exchange: GenerationId, response: Response | Record<string, unknown>): void;
  /** Complete with a confined file response. */
  respondFile(exchange: GenerationId, response: Record<string, unknown>): void;
  /** Complete with a typed failure. */
  fail(exchange: GenerationId, failure: Record<string, unknown>): void;
  /** Start a response stream. */
  startResponseStream(exchange: GenerationId, head?: Record<string, unknown>): void;
  /** Start a server-sent-event response. */
  startSse(exchange: GenerationId, headers?: Headers | ReadonlyArray<Header>): void;
  /** Submit one response-stream chunk. */
  writeResponseStream(exchange: GenerationId, chunk: Bytes): void;
  /** Submit one server-sent event. */
  writeSse(exchange: GenerationId, event: Record<string, unknown>): void;
  /** Finish a response stream with optional trailers. */
  finishResponseStream(exchange: GenerationId, trailers?: Headers | ReadonlyArray<Header>): void;
  /** Accept a WebSocket upgrade. */
  acceptWebSocket(exchange: GenerationId, selectedSubprotocol?: string): void;
  /** Take one copied WebSocket event. */
  takeWebSocket(timeoutMillis?: number): Readonly<Record<string, unknown>> | null;
  /** Send one WebSocket frame. */
  sendWebSocket(session: GenerationId, kind: number, data?: Bytes): void;
  /** Start WebSocket close. */
  closeWebSocket(session: GenerationId, code?: number, reason?: string): void;
  /** Submit one copied logical-target request. */
  outboundSubmit(request: Record<string, unknown>): GenerationId;
  /** Request cancellation of an outbound call. */
  outboundCancel(call: GenerationId): void;
  /** Interrupt the outbound completion reader. */
  interruptOutbound(): void;
  /** Take one copied outbound completion. */
  takeOutbound(timeoutMillis?: number): OutboundTerminal | null;
  /** Switch one route to a new binding. */
  rebind(request: RouteRebindRequest): RouteRebindOutcome;
  /** Publish a complete route generation. */
  publishRoutes(request: RoutePublicationRequest): RoutePublicationOutcome;
  /** Pull a coherent route snapshot. */
  routeSnapshot(): RouteSnapshot;
  /** Pull a coherent health snapshot. */
  health(): HealthSnapshot;
  /** Run a bounded active liveness probe. */
  probeLiveness(timeoutMillis: number): HealthSnapshot;
  /** Pull the effective monitor configuration. */
  monitorConfig(): Readonly<Record<string, unknown>>;
  /** Pull aggregate monitor truth. */
  monitorSnapshot(): Readonly<Record<string, unknown>>;
  /** Apply a generation-checked monitor policy. */
  monitorApply(expectedGeneration: UInt64, policy: Record<string, unknown>): Readonly<Record<string, unknown>>;
  /** Read a bounded page of monitor events. */
  monitorRead(afterSequence: UInt64, maximumEvents?: number): MonitorEventPage;
  /** Wait for new monitor truth. */
  monitorWait(timeoutMillis: number): boolean;
  /** Interrupt the monitor waiter. */
  monitorInterrupt(): void;
}

/** Create a callback-free runtime owner from copied configuration. */
export function createRuntime(configuration?: RuntimeConfiguration): Runtime;
/** Validate a complete capability declaration. */
export function planService(requiredCapabilities: bigint, options?: { readonly adapterCapabilities?: bigint }): ServicePlan;

/** Implemented runtime capability bits. */
export const Capability: Readonly<Record<string, bigint>>;
/** Machine-readable causes retained on native operation errors. */
export const FailureReason: Readonly<{
  /** No causal failure was reported. */
  NONE: 0;
  /** Caller input was invalid. */
  INVALID_ARGUMENT: 1;
  /** The lifecycle state rejected the operation. */
  INVALID_STATE: 2;
  /** A configured resource ceiling was reached. */
  CAPACITY: 3;
  /** A monotonic deadline expired. */
  TIMEOUT: 4;
  /** The owner or lane was already closed. */
  CLOSED: 5;
  /** A native allocation was refused. */
  OUT_OF_MEMORY: 6;
  /** The installed image does not implement the capability. */
  UNSUPPORTED: 7;
  /** The HTTP listener could not start. */
  LISTENER_START: 8;
  /** Listener transport-security setup failed. */
  TRANSPORT_SECURITY: 9;
  /** I/O backend setup failed. */
  IO_BACKEND: 10;
  /** A native invariant failed. */
  INTERNAL: 11;
}>;
/** Listener protocol constants. */
export const ListenerProtocol: Readonly<{ HTTP_1_1: 1; HTTP_2: 2; HTTP_3: 3 }>;
/** Transport-security constants. */
export const TransportSecurity: Readonly<{ PLAINTEXT: 1; TLS: 2; MUTUAL_TLS: 3 }>;
/** Request-body delivery constants. */
export const BodyDelivery: Readonly<{ INLINE: 1; STREAM: 2 }>;
/** Response-compression constants. */
export const CompressionMode: Readonly<{ DISABLED: 1; GZIP: 2 }>;
/** io_uring fallback-reason constants. */
export const IoBackendFallbackReason: Readonly<{ NONE: 0; CONFIGURATION: 1; UNAVAILABLE: 2 }>;
/** Route-control result constants. */
export const RouteControlCode: Readonly<{
  /** Applied or replayed exactly. */
  APPLIED: 0;
  /** Invalid request. */
  INVALID_ARGUMENT: 1;
  /** Owner already closed. */
  CLOSED: 2;
  /** Activation identity reused for another command. */
  ACTIVATION_CONFLICT: 3;
  /** Activation identity predates retained history. */
  ACTIVATION_EXPIRED: 4;
  /** Activation ordering is invalid. */
  ACTIVATION_OUT_OF_ORDER: 5;
  /** Named route does not exist. */
  ROUTE_NOT_FOUND: 6;
  /** Structural generation does not match. */
  GENERATION_MISMATCH: 7;
  /** Binding revision does not match. */
  REVISION_MISMATCH: 8;
  /** Sequence space is exhausted. */
  SEQUENCE_EXHAUSTED: 9;
  /** Candidate was rejected. */
  REJECTED: 10;
  /** Native allocation failed. */
  OUT_OF_MEMORY: 11;
  /** Internal invariant failed. */
  INTERNAL: 12;
  /** Observation timed out; recover by retrying the exact activation and intent, not a new operation. */
  TIMEOUT: 13;
  /** Observation wakeup failed; publication is unresolved, not rejected. Retry the exact intent. */
  WAKEUP_FAILED: 14;
  /** Another activation is unresolved; this new operation was not submitted. */
  BUSY: 15;
}>;

/** Core request-owner observations; draining is a subset of active. */
export interface ExecutionInfo {
  /** Immutable Core construction decision; meaningful only when observed=true. */
  readonly selection: ExecutionSelection;
  /** Accepted reservation, stable before start and after stop. */
  readonly configuredEventLoops: number;
  /** Owners sampled running or draining; not a simultaneous cross-owner barrier. */
  readonly activeEventLoops: number;
  /** Owners sampled draining. */
  readonly drainingEventLoops: number;
  /** Owners currently sampled failed, not a historical failure total. */
  readonly failedEventLoops: number;
  /** Whether an instance was inspected; false does not certify measured zero activity. */
  readonly observed: boolean;
}

/** Core-issued immutable selection, not CPU utilization or live loop activity. */
export interface ExecutionSelection {
  /** Accepted mode, with unknown numeric values preserved. */
  readonly requestedMode: number;
  /** Connector preference count; zero only for Core's absent/default intent. */
  readonly requestedCount: number;
  /** Core's accepted loop reservation, unchanged across start/drain/stop. */
  readonly selectedCount: number;
  /** Core-issued reason, including unknown raw numeric values. */
  readonly reason: number;
}

/** Request-capture proof tied to one publication; never covers sessions, callbacks or JS references. */
export interface RequestRetirement {
  /** Raw Core state; unknown values remain visible and never authorize reclamation. */
  readonly state: number;
  /** Raw observation result, independent of the route-control result. */
  readonly code: number;
  /** Request owners that acknowledged this cut; partial counts do not imply quiescence. */
  readonly quiescentSources: number;
  /** Total participating request owners, not selected CPUs. */
  readonly sources: number;
}

/** Known request-capture states; preserved raw values may be outside this set. */
export const RequestRetirementState: Readonly<{
  /** No complete lifetime proof. */
  UNKNOWN: 0;
  /** A request still holds the retired identity. */
  CAPTURED: 1;
  /** All request owners acknowledged this cut; independent host/session lifetimes remain. */
  QUIESCENT: 2;
  /** Future routing can still capture this identity. */
  STILL_ROUTABLE: 3;
  /** This operation has no retired request identity. */
  NOT_APPLICABLE: 4;
}>;
/** Known observation results; unknown or expired never means safe to reclaim. */
export const RequestRetirementCode: Readonly<{
  /** No observation available. */
  UNAVAILABLE: 0;
  /** Core observed the request owners. */
  OBSERVED: 1;
  /** Invalid observation intent. */
  INVALID_ARGUMENT: 2;
  /** Unsupported observation. */
  UNSUPPORTED: 3;
  /** Native allocation failed. */
  OUT_OF_MEMORY: 4;
  /** Owner closed. */
  CLOSED: 5;
  /** Bounded observation capacity busy. */
  BUSY: 6;
  /** Publication identity conflicts. */
  CONFLICT: 7;
  /** Proof predates retained history. */
  EXPIRED: 8;
  /** Observation deadline elapsed. */
  TIMEOUT: 9;
  /** Owner wakeup failed. */
  WAKEUP_FAILED: 10;
  /** Publication did not establish a retirement cut. */
  PUBLICATION_FAILED: 11;
  /** Owner observation failed. */
  OBSERVATION_FAILED: 12;
  /** Identity not found. */
  NOT_FOUND: 13;
  /** Native system failure. */
  SYSTEM_ERROR: 14;
}>;
/** Monitor collection constants. */
export const MonitorCollection: Readonly<{
  /** Monitoring disabled. */
  DISABLED: 0;
  /** Aggregate counters only. */
  AGGREGATES: 1;
  /** Aggregate counters and bounded events. */
  AGGREGATES_AND_EVENTS: 2;
}>;
/** Monitor notification constants. */
export const MonitorNotification: Readonly<Record<string, number>>;
/** Monitor latency constants. */
export const MonitorLatency: Readonly<Record<string, number>>;
/** Monitor category bits. */
export const MonitorCategory: Readonly<{
  /** Lifecycle changes. */
  LIFECYCLE: 1;
  /** Exchange outcomes. */
  EXCHANGE: 2;
  /** Route and monitor controls. */
  CONTROL: 4;
  /** Request latency. */
  LATENCY: 8;
  /** Every implemented category. */
  ALL: 15;
}>;
/** Inbound event-kind constants. */
export const EventKind: Readonly<Record<string, number>>;
/** WebSocket event-kind constants. */
export const WebSocketEventKind: Readonly<Record<string, number>>;
