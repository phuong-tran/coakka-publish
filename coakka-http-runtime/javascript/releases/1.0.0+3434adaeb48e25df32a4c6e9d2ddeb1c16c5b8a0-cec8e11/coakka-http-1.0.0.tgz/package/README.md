# CoAkka HTTP for Node and Bun

GitHub release `1.0.0` provides one API for Node and Bun. It is not currently
mirrored to a package registry.

```javascript
import { Builder, Response } from "@coakka/http";

const service = await new Builder()
  .get("/customers/{id}", (request) => Response.json({ id: request.params.id }))
  .post("/customers", async (request) =>
    Response.json(await request.json(), { status: 201 }),
  )
  .start();

console.log(service.url);
```

Release `1.0.0` includes buffered and streaming requests and responses, server
events, WebSocket sessions, static and single-page application content,
outbound calls, TLS and protocol selection, form and multipart values, route
rebinding, health and inspection snapshots, cancellation, bounded capacity,
and finite shutdown.

`Service.close()` is idempotent. Application signal handling is opt-in through
`attachProcessShutdown(service)`. Requests, responses, stream chunks, headers,
connections, active handlers, outbound calls, WebSocket messages, retained
errors, routes, and static mounts all have explicit bounds and reject excess
work.

## Release Status

GitHub release `1.0.0`. Registry mirroring, performance claims, broader
sanitizer campaigns and long-running stress evidence remain separate work.
