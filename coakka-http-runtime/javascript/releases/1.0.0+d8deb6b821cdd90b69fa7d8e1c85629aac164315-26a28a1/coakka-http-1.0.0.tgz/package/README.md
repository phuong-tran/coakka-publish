# CoAkka HTTP for Node and Bun

Release `1.0.0` is available as a GitHub artifact. It is intentionally marked
private until the separate npm publication gate is opened.

The connector exposes a buffered `Builder`/`Service` convenience layer and the
complete callback-free `Core` surface. The packaged native Core owns listeners,
connections, protocols, TLS, files, routing, pressure, timeouts, outbound
transport, monitoring, and shutdown. JavaScript only translates owned values
and dispatches application work; neither Node nor Bun implements or substitutes
an HTTP server or client for Core.

```javascript
import { Builder, Response } from "@coakka/http";

const service = new Builder()
  .post("/echo", (request) => Response.bytes(request.bytes()))
  .start();

console.log(service.port);
await service.close();
```

Handlers are synchronous in this candidate. Each request and response is
buffered within configured limits and copied across the language boundary.

Advanced users can drive every capability advertised by the packaged Core:

```javascript
import { EventKind, Response, createCore } from "@coakka/http";

const core = createCore({
  routes: [{ method: "POST", pattern: "/echo" }],
});
core.start();

const event = core.takeEvent(5_000);
if (event?.kind === EventKind.REQUEST) {
  core.respond(event.exchange, Response.bytes(event.body));
}
core.close();
```

Each inbound, WebSocket, outbound, and monitor-event lane permits one reader per
`Core`. Do not overlap take/read/wait calls on the same lane. These methods are
synchronous; use zero-timeout polling or put a blocking reader in a dedicated
Worker so the JavaScript event loop remains responsive. `monitorConfig()` and
`monitorSnapshot()` are pointer-free multi-reader snapshots.

Every leased event, terminal, header, and body is copied into JavaScript-owned
storage before the addon releases the native lease. Applications therefore do
not retain or release Core pointers. `close()` is idempotent, interrupts blocked
readers, drains and stops Core, and must run only after application calls and
Workers have quiesced. Environment cleanup closes an owner that was not closed
explicitly.

The native bridge is split by ownership: one unit owns the JavaScript wrapper
and factory, one owns shared value conversion and lifecycle, and separate units
own configuration, protocol traffic, and health/monitor projection. Every
callback-free Core entrypoint that can allocate C++ storage catches failures at
the owning boundary and maps failure to a JavaScript exception; no C++
exception crosses Node-API.

One package contains target-specific Core and Node-API images for
`darwin-arm64`, `linux-arm64`, `linux-x64`, `win32-arm64`, and `win32-x64`.
The loader verifies their size and SHA-256 before loading. Core capability bits
are authoritative because optional protocol providers can differ by target.
