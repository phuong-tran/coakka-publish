/** Bytes accepted by a buffered response. */
export type Bytes = string | Uint8Array;

/** Construction options for one immutable response. */
export interface ResponseOptions {
  /** HTTP status code from 100 through 599. */
  readonly status?: number;
  /** Ordered response headers. */
  readonly headers?: Headers | ReadonlyArray<Header>;
}

/** Construction-time resource ceiling overrides. */
export interface LimitsOptions {
  /** Maximum accepted connections retained by Core. */
  readonly maxConnections?: number;
  /** Maximum concurrently active requests retained by Core. */
  readonly maxActiveRequests?: number;
  /** Maximum requests awaiting dispatch. */
  readonly requestQueueCapacity?: number;
  /** Maximum responses awaiting completion. */
  readonly responseQueueCapacity?: number;
  /** Maximum buffered bytes accepted for one request body. */
  readonly maxRequestBodyBytes?: number;
  /** Maximum buffered bytes accepted for one response body. */
  readonly maxResponseBodyBytes?: number;
  /** Monotonic timeout for one handler turn. */
  readonly requestTimeoutMillis?: number;
  /** Maximum drain time used by close. */
  readonly shutdownTimeoutMillis?: number;
}

/** One immutable HTTP header. */
export class Header {
  /** Create a validated name and value pair. */
  constructor(name: string, value: string);
  /** Validated HTTP field name. */
  readonly name: string;
  /** Validated HTTP field value. */
  readonly value: string;
}

/** Immutable ordered HTTP headers with case-insensitive lookup. */
export class Headers implements Iterable<Header> {
  /** Create a defensive immutable copy of `entries`. */
  constructor(entries?: Headers | ReadonlyArray<Header>);
  /** Number of entries, including duplicate names. */
  readonly size: number;
  /** Return the first value for `name`, or `null` when absent. */
  get(name: string): string | null;
  /** Return every value for `name` in declaration order. */
  getAll(name: string): string[];
  /** Iterate over immutable entries in declaration order. */
  [Symbol.iterator](): Iterator<Header>;
}

/** Construction-time resource ceilings copied into native Core. */
export class Limits implements Required<LimitsOptions> {
  /** Create a complete validated limit set from optional overrides. */
  constructor(options?: LimitsOptions);
  /** Maximum accepted connections retained by Core. */
  readonly maxConnections: number;
  /** Maximum concurrently active requests retained by Core. */
  readonly maxActiveRequests: number;
  /** Maximum requests awaiting handler dispatch. */
  readonly requestQueueCapacity: number;
  /** Maximum responses awaiting native completion. */
  readonly responseQueueCapacity: number;
  /** Maximum buffered bytes accepted for one request body. */
  readonly maxRequestBodyBytes: number;
  /** Maximum buffered bytes accepted for one response body. */
  readonly maxResponseBodyBytes: number;
  /** Monotonic timeout for one handler turn. */
  readonly requestTimeoutMillis: number;
  /** Maximum native drain time used by close. */
  readonly shutdownTimeoutMillis: number;
}

/** One immutable route registered in a started service. */
export class Route {
  /** Create an immutable route description. */
  constructor(id: number, method: string, pattern: string);
  /** Stable positive route identifier. */
  readonly id: number;
  /** Normalized HTTP method. */
  readonly method: string;
  /** Encoded absolute path pattern. */
  readonly pattern: string;
}

/** Immutable JavaScript-owned request passed to one handler invocation. */
export class Request {
  private constructor();
  /** Normalized HTTP method. */
  readonly method: string;
  /** Request scheme reported by Core. */
  readonly scheme: string;
  /** Request authority, including a port when present. */
  readonly authority: string;
  /** Encoded request target, including its query string. */
  readonly target: string;
  /** Immutable ordered request headers. */
  readonly headers: Headers;
  /** Stable route identifier selected by Core. */
  readonly routeId: number;
  /** Whether cancellation was visible when the request was copied. */
  readonly cancelled: boolean;
  /** Return a defensive copy of the buffered request body. */
  bytes(): Uint8Array;
  /** Decode the buffered request body as UTF-8. */
  text(): string;
}

/** Immutable buffered response returned by a request handler. */
export class Response {
  /** Create a response with a status, ordered headers, and copied body. */
  constructor(body?: Bytes, options?: ResponseOptions);
  /** HTTP status code. */
  readonly status: number;
  /** Ordered response headers. */
  readonly headers: ReadonlyArray<Readonly<{ name: string; value: string }>>;
  /** Defensive copy of the buffered response body. */
  readonly body: Uint8Array;
  /** Create a UTF-8 text response and add a content type when absent. */
  static text(body: string, options?: ResponseOptions): Response;
  /** Create a response that owns a copy of `body`. */
  static bytes(body: Uint8Array, options?: ResponseOptions): Response;
  /** Create an empty response with status 204 unless overridden. */
  static empty(options?: ResponseOptions): Response;
}

/** Synchronous request handler invoked on the JavaScript event loop. */
export type Handler = (request: Request) => Response;

/** Single-use builder for a native-owned HTTP service. */
export class Builder {
  /** Select the bind host and port; zero requests an available port. */
  listen(host: string, port: number): this;
  /** Select the fixed number of native request-handler workers. */
  concurrency(workers: number): this;
  /** Replace every construction-time resource ceiling. */
  limits(limits: Limits): this;
  /** Register a synchronous handler for one method and path pattern. */
  route(method: string, pattern: string, handler: Handler): this;
  /** Register a GET handler for `pattern`. */
  get(pattern: string, handler: Handler): this;
  /** Register a POST handler for `pattern`. */
  post(pattern: string, handler: Handler): this;
  /** Register a PUT handler for `pattern`. */
  put(pattern: string, handler: Handler): this;
  /** Register a PATCH handler for `pattern`. */
  patch(pattern: string, handler: Handler): this;
  /** Register a DELETE handler for `pattern`. */
  delete(pattern: string, handler: Handler): this;
  /** Create and start a service whose HTTP resources Core owns. */
  start(): Service;
}

/** Sole lifecycle owner for one started native HTTP server. */
export class Service {
  private constructor();
  /** Immutable route declarations copied during start. */
  readonly routes: ReadonlyArray<Route>;
  /** Actual bound port, including a selected ephemeral port. */
  readonly port: number;
  /** Remove and return the oldest bounded handler diagnostic. */
  pollError(): unknown | undefined;
  /** Stop admission, drain callbacks, and release all native state. */
  close(): Promise<void>;
}

/** JavaScript input accepted for an unsigned Core identifier or counter. */
export type UInt64 = number | bigint;

/** Names of capability bits returned by the packaged Core. */
export type CapabilityName =
  | "INBOUND"
  | "TLS"
  | "MUTUAL_TLS"
  | "GZIP"
  | "REQUEST_STREAM"
  | "RESPONSE_STREAM"
  | "RESPONSE_TRAILERS"
  | "RESPONSE_WRITE_TIMEOUT"
  | "SERVER_SENT_EVENTS"
  | "WEBSOCKET"
  | "HTTP_2"
  | "HTTP_3"
  | "STATIC_FILES"
  | "APPLICATION_FILES"
  | "OUTBOUND"
  | "ROUTE_REBIND"
  | "OUTBOUND_LOGICAL_TARGET"
  | "STATIC_FRONTEND"
  | "HEALTH"
  | "MONITOR";

/** Exact feature-bit table for the callback-free Core API. */
export const Capability: Readonly<Record<CapabilityName, bigint>>;

/** Listener protocol constants accepted by Core configuration. */
export const ListenerProtocol: Readonly<Record<"HTTP_1_1" | "HTTP_2" | "HTTP_3", number>>;

/** Transport-security constants accepted by listeners and outbound targets. */
export const TransportSecurity: Readonly<Record<"PLAINTEXT" | "TLS" | "MUTUAL_TLS", number>>;

/** Request-body delivery constants accepted by route declarations. */
export const BodyDelivery: Readonly<Record<"INLINE" | "STREAM", number>>;

/** Response-compression constants accepted by Core configuration. */
export const CompressionMode: Readonly<Record<"DISABLED" | "GZIP", number>>;

/** Native server I/O backend constants accepted by Core configuration. */
export const IoBackend: Readonly<Record<"PLATFORM_DEFAULT" | "IO_URING", number>>;

/** Connector wait-mode constants accepted by Core configuration. */
export const WaitMode: Readonly<Record<"BLOCKING" | "ADAPTIVE" | "BUSY_POLL", number>>;

/** Monitor collection constants accepted by Core configuration. */
export const MonitorCollection: Readonly<Record<"DISABLED" | "AGGREGATES" | "AGGREGATES_AND_EVENTS", number>>;

/** Inbound and completion event-kind constants returned by Core. */
export const EventKind: Readonly<Record<"REQUEST" | "REQUEST_DATA" | "REQUEST_TRAILERS" | "REQUEST_END" | "REQUEST_CANCELLED" | "RESPONSE_WRITABLE" | "TERMINAL", number>>;

/** WebSocket event-kind constants returned and accepted by Core. */
export const WebSocketEventKind: Readonly<Record<"OPEN" | "TEXT" | "BINARY" | "PING" | "PONG" | "WRITABLE" | "CLOSE" | "ACCEPT_FAILED", number>>;

/** Stable generation-checked identifier copied between JavaScript and Core. */
export interface CoreId {
  /** Slot selected by Core. */
  readonly slot: bigint;
  /** Generation preventing stale-slot reuse. */
  readonly generation: bigint;
}

/** Plain header accepted by the callback-free Core methods. */
export interface CoreHeader {
  /** Valid HTTP field name. */
  readonly name: string;
  /** Latin-1 HTTP field value. */
  readonly value: string;
}

/** One listener copied into Core during construction. */
export interface CoreListener {
  /** Stable positive listener identifier. */
  readonly id?: UInt64;
  /** Numeric bind address or host accepted by Core. */
  readonly host?: string;
  /** TCP or UDP port; zero requests an ephemeral port. */
  readonly port?: number;
  /** One `ListenerProtocol` value. */
  readonly protocol?: number;
  /** One `TransportSecurity` value. */
  readonly security?: number;
  /** Monotonic credential generation. */
  readonly credentialGeneration?: UInt64;
  /** Stable credential identifier. */
  readonly credentialId?: string;
  /** Certificate-chain file read and owned by Core. */
  readonly certificateChainFile?: string;
  /** Private-key file read and owned by Core. */
  readonly privateKeyFile?: string;
  /** Optional trust-root file used for mutual TLS. */
  readonly trustRootsFile?: string;
}

/** Per-route request-body admission policy. */
export interface CoreBodyPolicy {
  /** Enable media-type policy enforcement. */
  readonly enabled?: boolean;
  /** Admit requests without a content type. */
  readonly acceptAbsent?: boolean;
  /** Admit non-form media types. */
  readonly acceptOther?: boolean;
  /** Admit URL-encoded form bodies. */
  readonly acceptFormUrlencoded?: boolean;
  /** Admit multipart form bodies. */
  readonly acceptMultipartFormData?: boolean;
  /** Maximum admitted body bytes for this route. */
  readonly maxBodyBytes?: UInt64;
}

/** One route whose handler binding is selected by the connector. */
export interface CoreRoute {
  /** Stable positive route identifier. */
  readonly id?: UInt64;
  /** Stable positive connector handler-binding identifier. */
  readonly handlerBindingId?: UInt64;
  /** Optional request-capture profile identifier. */
  readonly requestCaptureProfileId?: UInt64;
  /** One `BodyDelivery` value. */
  readonly bodyDelivery?: number;
  /** Normalized HTTP method. */
  readonly method: string;
  /** Encoded absolute route pattern. */
  readonly pattern: string;
  /** Optional bounded request-body policy. */
  readonly bodyPolicy?: CoreBodyPolicy;
}

/** One Core-owned static frontend mount. */
export interface CoreStaticMount {
  /** Stable positive mount identifier. */
  readonly id: UInt64;
  /** Encoded URL prefix. */
  readonly urlPrefix: string;
  /** Filesystem root opened by Core. */
  readonly rootPath: string;
  /** Optional index filename. */
  readonly indexFile?: string;
  /** Optional response cache-control value. */
  readonly cacheControl?: string;
  /** Optional SPA fallback filename. */
  readonly spaFallbackFile?: string;
  /** Whether Core may serve dotfiles below this root. */
  readonly includeDotfiles?: boolean;
}

/** One authority from which Core may prepare application-selected files. */
export interface CoreFileAuthority {
  /** Stable positive authority identifier. */
  readonly id: UInt64;
  /** Filesystem root confined by Core. */
  readonly rootPath: string;
  /** Maximum simultaneously active file responses. */
  readonly maxActiveFiles?: number;
  /** Maximum size of one prepared file. */
  readonly maxFileBytes?: UInt64;
}

/** One logical outbound endpoint owned and dialed by Core. */
export interface CoreOutboundEndpoint {
  /** Stable endpoint identity within its target. */
  readonly nodeId: string;
  /** Host resolved or dialed by Core. */
  readonly connectHost: string;
  /** TCP port dialed by Core. */
  readonly connectPort: number;
  /** HTTP authority sent to the peer. */
  readonly httpAuthority: string;
  /** Positive weighted-routing value. */
  readonly weight?: number;
  /** One `TransportSecurity` value. */
  readonly security?: number;
  /** Whether new calls may select this endpoint. */
  readonly available?: boolean;
  /** TLS peer identity override. */
  readonly tlsPeerIdentity?: string;
  /** Core proxy-mode enum value. */
  readonly proxyMode?: number;
  /** Core protocol-policy enum value. */
  readonly protocolPolicy?: number;
  /** Core connection-strategy enum value. */
  readonly connectionStrategy?: number;
  /** Optional proxy identity. */
  readonly proxyIdentity?: string;
  /** Referenced trust-bundle generation. */
  readonly tlsTrustGeneration?: UInt64;
  /** Referenced client-identity generation. */
  readonly tlsClientIdentityGeneration?: UInt64;
  /** Connection-strategy generation. */
  readonly connectionStrategyGeneration?: UInt64;
  /** Core local-network policy identifier. */
  readonly localNetworkPolicyId?: UInt64;
}

/** One generation-checked logical outbound target. */
export interface CoreOutboundTarget {
  /** Logical target name used by requests. */
  readonly name: string;
  /** Positive target generation. */
  readonly generation: UInt64;
  /** Core egress-strategy enum value. */
  readonly strategy?: number;
  /** Bounded endpoints available to this target. */
  readonly endpoints: ReadonlyArray<CoreOutboundEndpoint>;
}

/** One outbound TLS trust bundle copied into Core. */
export interface CoreOutboundTrust {
  /** Positive trust generation. */
  readonly generation: UInt64;
  /** PEM-encoded CA bundle. */
  readonly caPem: string;
}

/** One outbound mutual-TLS identity copied into Core. */
export interface CoreOutboundIdentity {
  /** Positive identity generation. */
  readonly generation: UInt64;
  /** PEM-encoded client certificate chain. */
  readonly certificateChainPem: string;
  /** PEM-encoded client private key. */
  readonly privateKeyPem: string;
}

/** Complete outbound construction input; option groups map one-for-one to Core limits. */
export interface CoreOutboundConfiguration {
  /** Optional nested lane, transport, resolver, pool, TLS, and registry limits. */
  readonly options?: Readonly<Record<string, unknown>>;
  /** Logical target snapshots copied into Core. */
  readonly targets?: ReadonlyArray<CoreOutboundTarget>;
  /** Trust bundles copied into Core. */
  readonly trusts?: ReadonlyArray<CoreOutboundTrust>;
  /** Client identities copied into Core. */
  readonly identities?: ReadonlyArray<CoreOutboundIdentity>;
}

/** Complete callback-free Core construction input. */
export interface CoreConfiguration {
  /** Listener configuration, `null` for an outbound-only Core. */
  readonly listener?: CoreListener | null;
  /** Optional Core ceilings using the camel-case names documented by Core. */
  readonly limits?: Readonly<Record<string, UInt64>>;
  /** Routes copied into Core before start. */
  readonly routes?: ReadonlyArray<CoreRoute>;
  /** Static frontend mounts owned by Core. */
  readonly staticMounts?: ReadonlyArray<CoreStaticMount>;
  /** Application-file authorities owned by Core. */
  readonly fileAuthorities?: ReadonlyArray<CoreFileAuthority>;
  /** Optional response-compression policy. */
  readonly compression?: Readonly<Record<string, UInt64>>;
  /** Optional numeric Core I/O backend. */
  readonly ioBackend?: number;
  /** Optional connector wait policy. */
  readonly waitPolicy?: Readonly<Record<string, UInt64>>;
  /** Optional monitor reservation and initial policy. */
  readonly monitor?: Readonly<Record<string, UInt64 | boolean>>;
  /** Optional authenticated runtime-inspection configuration. */
  readonly inspection?: Readonly<Record<string, UInt64 | string | boolean>>;
  /** Optional native outbound client and topology. */
  readonly outbound?: CoreOutboundConfiguration;
}

/** Buffered response input copied synchronously by Core. */
export interface CoreResponse {
  /** HTTP status code from 100 through 599. */
  readonly status?: number;
  /** Ordered response headers. */
  readonly headers?: Headers | ReadonlyArray<CoreHeader>;
  /** Response body copied before the method returns. */
  readonly body?: Bytes;
}

/** A copied event from Core's sole-reader inbound lane. */
export interface CoreEvent {
  /** Numeric `EventKind` value. */
  readonly kind: number;
  /** Generation-checked exchange identifier. */
  readonly exchange: CoreId;
  /** Per-stream sequence where applicable. */
  readonly sequence: bigint;
  /** Connector-selected handler binding. */
  readonly handlerBindingId: bigint;
  /** Event data chunk for stream events. */
  readonly data?: Uint8Array;
  /** Buffered request body for request events. */
  readonly body?: Uint8Array;
  /** Additional typed fields projected for request, trailer, and terminal events. */
  readonly [name: string]: unknown;
}

/** A copied WebSocket event from Core's WebSocket lane. */
export interface CoreWebSocketEvent {
  /** Numeric `WebSocketEventKind` value. */
  readonly kind: number;
  /** Generation-checked WebSocket session identifier. */
  readonly session: CoreId;
  /** Exchange that created this session. */
  readonly originExchange: CoreId;
  /** Close status where applicable. */
  readonly closeCode: number;
  /** Copied frame payload. */
  readonly data: Uint8Array;
}

/** A copied terminal from Core's native outbound client. */
export interface CoreOutboundTerminal {
  /** Generation-checked outbound call identifier. */
  readonly call: CoreId;
  /** HTTP response status, or zero before a response head. */
  readonly responseStatus: number;
  /** Copied response headers. */
  readonly headers: ReadonlyArray<CoreHeader>;
  /** Copied response body. */
  readonly body: Uint8Array;
  /** Additional typed routing, retry, certainty, and diagnostic fields. */
  readonly [name: string]: unknown;
}

/** Pointer-free Core health snapshot with bigint counters. */
export type CoreHealth = Readonly<Record<string, bigint | number | boolean>>;

/** Pointer-free runtime-monitor configuration. */
export type CoreMonitorConfig = Readonly<Record<string, unknown>>;

/** Pointer-free runtime-monitor aggregate snapshot. */
export type CoreMonitorSnapshot = Readonly<Record<string, unknown>>;

/** Pointer-free bounded runtime-monitor event page. */
export type CoreMonitorPage = Readonly<Record<string, unknown>>;

/** Single owner of one callback-free native Core instance. */
export class Core {
  private constructor(owner: object);
  /** Exact feature bits implemented by the packaged Core. */
  readonly features: bigint;
  /** Start every configured native Core component. */
  start(): this;
  /** Return the bound server port after start. */
  port(): number;
  /** Close admission while allowing bounded in-flight work to drain. */
  drain(): void;
  /** Stop Core after its configured finite shutdown deadline. */
  stop(): void;
  /** Wake the sole inbound event reader without stopping Core. */
  interrupt(): void;
  /** Stop and release all native resources; repeated calls are harmless. */
  close(): void;
  /** Synchronously take one copied inbound event, or `null` on timeout. */
  takeEvent(timeoutMillis?: UInt64): CoreEvent | null;
  /** Report whether Core has observed cancellation for an exchange. */
  exchangeCancelled(exchange: CoreId): boolean;
  /** Complete an exchange with a buffered response copied by Core. */
  respond(exchange: CoreId, response: CoreResponse | Response): void;
  /** Complete an exchange from a configured Core file authority. */
  respondFile(exchange: CoreId, response: Readonly<{ head?: CoreResponse; authorityId: UInt64; encodedPath: string }>): void;
  /** Fail an exchange with a typed Core reason and bounded detail. */
  fail(exchange: CoreId, failure: Readonly<{ reason: number; detail: string }>): void;
  /** Start a response stream with a copied status and header block. */
  startResponseStream(exchange: CoreId, head?: CoreResponse): void;
  /** Start a server-sent-event response with copied headers. */
  startSse(exchange: CoreId, headers?: Headers | ReadonlyArray<CoreHeader>): void;
  /** Submit one copied response-stream chunk. */
  writeResponseStream(exchange: CoreId, chunk: Bytes): void;
  /** Submit one copied server-sent event. */
  writeSse(exchange: CoreId, event: Readonly<Record<string, UInt64 | string>>): void;
  /** Finish a response stream with an optional copied trailer block. */
  finishResponseStream(exchange: CoreId, trailers?: Headers | ReadonlyArray<CoreHeader>): void;
  /** Accept a WebSocket upgrade and select an optional subprotocol. */
  acceptWebSocket(exchange: CoreId, selectedSubprotocol?: string): void;
  /** Synchronously take one copied WebSocket event, or `null` on timeout. */
  takeWebSocket(timeoutMillis?: UInt64): CoreWebSocketEvent | null;
  /** Submit one copied WebSocket data or control frame. */
  sendWebSocket(session: CoreId, kind: number, data?: Bytes): void;
  /** Initiate a WebSocket close with a bounded UTF-8 reason. */
  closeWebSocket(session: CoreId, code?: number, reason?: string): void;
  /** Submit a buffered request through Core's logical-target client. */
  outboundSubmit(request: Readonly<Record<string, unknown>>): CoreId;
  /** Request cancellation of a previously submitted outbound call. */
  outboundCancel(call: CoreId): void;
  /** Synchronously take one copied outbound terminal, or `null` on timeout. */
  takeOutbound(timeoutMillis?: UInt64): CoreOutboundTerminal | null;
  /** Atomically replace a route's handler binding under generation checks. */
  rebind(request: Readonly<Record<string, UInt64>>, timeoutMillis: UInt64): Readonly<Record<string, UInt64 | number | boolean>>;
  /** Read a pointer-free snapshot of current Core health. */
  health(): CoreHealth;
  /** Run a bounded liveness probe and return the acknowledged health snapshot. */
  probeLiveness(timeoutMillis: UInt64): CoreHealth;
  /** Read the effective runtime-monitor reservation and live policy. */
  monitorConfig(): CoreMonitorConfig;
  /** Read a pointer-free aggregate monitor and health snapshot. */
  monitorSnapshot(): CoreMonitorSnapshot;
  /** Apply a live monitor policy under an expected-generation check. */
  monitorApply(expectedGeneration: UInt64, policy: Readonly<Record<string, UInt64>>): Readonly<Record<string, unknown>>;
  /** Read a bounded page of pointer-free runtime monitor events. */
  monitorRead(afterSequence: UInt64, maximumEvents?: number): CoreMonitorPage;
  /** Synchronously wait for newer monitor truth and return false on timeout. */
  monitorWait(timeoutMillis: UInt64): boolean;
  /** Wake the sole blocking monitor waiter without changing Core lifecycle. */
  monitorInterrupt(): void;
}

/** Create a callback-free Core owner from a defensively projected configuration. */
export function createCore(configuration?: CoreConfiguration): Core;
