import { loadNativeAddon } from "./native_loader.mjs";
import { Header, Headers, Response } from "./values.mjs";

const native = loadNativeAddon();
const CORE_OWNER = Symbol("CoAkka HTTP Core owner");

/** Bit flags returned by `Core.features`. */
export const Capability = Object.freeze({
  INBOUND: 1n,
  TLS: 2n,
  MUTUAL_TLS: 4n,
  GZIP: 8n,
  REQUEST_STREAM: 16n,
  RESPONSE_STREAM: 32n,
  RESPONSE_TRAILERS: 64n,
  RESPONSE_WRITE_TIMEOUT: 128n,
  SERVER_SENT_EVENTS: 256n,
  WEBSOCKET: 512n,
  HTTP_2: 1024n,
  HTTP_3: 2048n,
  STATIC_FILES: 4096n,
  APPLICATION_FILES: 8192n,
  OUTBOUND: 16384n,
  ROUTE_REBIND: 32768n,
  OUTBOUND_LOGICAL_TARGET: 65536n,
  STATIC_FRONTEND: 131072n,
  HEALTH: 262144n,
  MONITOR: 524288n,
});

/** Listener protocol values understood by Core. */
export const ListenerProtocol = Object.freeze({ HTTP_1_1: 1, HTTP_2: 2, HTTP_3: 3 });

/** Listener and outbound transport-security values understood by Core. */
export const TransportSecurity = Object.freeze({ PLAINTEXT: 1, TLS: 2, MUTUAL_TLS: 3 });

/** Request-body delivery modes selected per route. */
export const BodyDelivery = Object.freeze({ INLINE: 1, STREAM: 2 });

/** Response-compression modes selected at construction. */
export const CompressionMode = Object.freeze({ DISABLED: 1, GZIP: 2 });

/** Server I/O backends selected at construction. */
export const IoBackend = Object.freeze({ PLATFORM_DEFAULT: 1, IO_URING: 2 });

/** Connector event-wait policies selected at construction. */
export const WaitMode = Object.freeze({ BLOCKING: 1, ADAPTIVE: 2, BUSY_POLL: 3 });

/** Runtime monitor collection modes. */
export const MonitorCollection = Object.freeze({ DISABLED: 0, AGGREGATES: 1, AGGREGATES_AND_EVENTS: 2 });

/** Inbound, stream-writable, and terminal event kinds. */
export const EventKind = Object.freeze({
  REQUEST: 1,
  REQUEST_DATA: 2,
  REQUEST_TRAILERS: 3,
  REQUEST_END: 4,
  REQUEST_CANCELLED: 5,
  RESPONSE_WRITABLE: 6,
  TERMINAL: 7,
});

/** WebSocket event and outbound-frame kinds. */
export const WebSocketEventKind = Object.freeze({
  OPEN: 1,
  TEXT: 2,
  BINARY: 3,
  PING: 4,
  PONG: 5,
  WRITABLE: 6,
  CLOSE: 7,
  ACCEPT_FAILED: 8,
});

function headers(value = []) {
  const source = value instanceof Headers ? [...value] : value;
  if (!Array.isArray(source)) throw new TypeError("headers must be an array or Headers");
  return source.map((entry) => {
    const checked = entry instanceof Header ? entry : new Header(entry.name, entry.value);
    return { name: checked.name, value: checked.value };
  });
}

function buffer(value = new Uint8Array()) {
  if (typeof value === "string") return Buffer.from(value, "utf8");
  if (!(value instanceof Uint8Array)) throw new TypeError("body must be a string or Uint8Array");
  if (typeof SharedArrayBuffer !== "undefined" && value.buffer instanceof SharedArrayBuffer) {
    throw new TypeError("body must not use SharedArrayBuffer");
  }
  return Buffer.from(value);
}

function response(value, allowBody = true) {
  if (value instanceof Response) {
    return { status: value.status, headers: [...value.headers], body: allowBody ? value.body : Buffer.alloc(0) };
  }
  if (value === null || typeof value !== "object") throw new TypeError("response must be an object");
  return {
    status: value.status ?? 200,
    headers: headers(value.headers),
    body: allowBody ? buffer(value.body) : Buffer.alloc(0),
  };
}

function configuration(value = {}) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError("Core configuration must be an object");
  }
  const projected = { ...value };
  if (value.listener === undefined && value.outbound === undefined) {
    projected.listener = {};
  } else if (value.listener === null) {
    delete projected.listener;
  }
  if (projected.listener !== undefined) {
    projected.listener = {
      id: 1,
      host: "127.0.0.1",
      port: 0,
      protocol: ListenerProtocol.HTTP_1_1,
      security: TransportSecurity.PLAINTEXT,
      ...projected.listener,
    };
  }
  projected.routes = (value.routes ?? []).map((route, index) => ({
    id: index + 1,
    handlerBindingId: route.id ?? index + 1,
    requestCaptureProfileId: 0,
    bodyDelivery: BodyDelivery.INLINE,
    ...route,
  }));
  projected.staticMounts = value.staticMounts ?? [];
  projected.fileAuthorities = value.fileAuthorities ?? [];
  if (value.outbound !== undefined) {
    projected.outbound = {
      ...value.outbound,
      targets: (value.outbound.targets ?? []).map((target) => ({
        strategy: 1,
        ...target,
        endpoints: (target.endpoints ?? []).map((endpoint) => ({
          weight: 1,
          security: TransportSecurity.PLAINTEXT,
          available: true,
          proxyMode: 1,
          protocolPolicy: 1,
          connectionStrategy: 1,
          ...endpoint,
        })),
      })),
      trusts: value.outbound.trusts ?? [],
      identities: value.outbound.identities ?? [],
    };
  }
  return projected;
}

/** Single owner of one callback-free native Core instance. */
export class Core {
  #native;

  /** Adopt an internal native owner created from a copied configuration. */
  constructor(owner, token) {
    if (token !== CORE_OWNER) throw new TypeError("Core instances are created by createCore");
    this.#native = owner;
    Object.freeze(this);
  }

  /** Return the exact capability bits implemented by the packaged Core. */
  get features() {
    return native.coreFeatures();
  }

  /** Start every configured native Core component. */
  start() {
    this.#native.start();
    return this;
  }

  /** Return the bound server port after start. */
  port() {
    return this.#native.port();
  }

  /** Close admission while allowing bounded in-flight work to drain. */
  drain() {
    this.#native.drain();
  }

  /** Stop Core after its configured finite shutdown deadline. */
  stop() {
    this.#native.stop();
  }

  /** Wake the sole inbound event reader without stopping Core. */
  interrupt() {
    this.#native.interrupt();
  }

  /** Stop and release all native resources; repeated calls are harmless. */
  close() {
    this.#native.close();
  }

  /** Synchronously take one copied inbound event, or `null` on timeout. */
  takeEvent(timeoutMillis = 0) {
    return this.#native.takeEvent(timeoutMillis);
  }

  /** Report whether Core has observed cancellation for an exchange. */
  exchangeCancelled(exchange) {
    return this.#native.exchangeCancelled(exchange);
  }

  /** Complete an exchange with a buffered response copied by Core. */
  respond(exchange, value) {
    this.#native.respond(exchange, response(value));
  }

  /** Complete an exchange from a configured Core file authority. */
  respondFile(exchange, value) {
    this.#native.respondFile(exchange, { ...value, head: response(value.head ?? {}, false) });
  }

  /** Fail an exchange with a typed Core reason and bounded detail. */
  fail(exchange, failure) {
    this.#native.fail(exchange, failure);
  }

  /** Start a response stream with a copied status and header block. */
  startResponseStream(exchange, head = {}) {
    this.#native.startResponseStream(exchange, response(head, false));
  }

  /** Start a server-sent-event response with copied headers. */
  startSse(exchange, value = []) {
    this.#native.startSse(exchange, headers(value));
  }

  /** Submit one copied response-stream chunk. */
  writeResponseStream(exchange, chunk) {
    this.#native.writeResponseStream(exchange, buffer(chunk));
  }

  /** Submit one copied server-sent event. */
  writeSse(exchange, event) {
    this.#native.writeSse(exchange, event);
  }

  /** Finish a response stream with an optional copied trailer block. */
  finishResponseStream(exchange, trailers = []) {
    this.#native.finishResponseStream(exchange, headers(trailers));
  }

  /** Accept a WebSocket upgrade and select an optional subprotocol. */
  acceptWebSocket(exchange, selectedSubprotocol = "") {
    this.#native.acceptWebSocket(exchange, selectedSubprotocol);
  }

  /** Synchronously take one copied WebSocket event, or `null` on timeout. */
  takeWebSocket(timeoutMillis = 0) {
    return this.#native.takeWebSocket(timeoutMillis);
  }

  /** Submit one copied WebSocket data or control frame. */
  sendWebSocket(session, kind, data = new Uint8Array()) {
    this.#native.sendWebSocket(session, kind, buffer(data));
  }

  /** Initiate a WebSocket close with a bounded UTF-8 reason. */
  closeWebSocket(session, code = 1000, reason = "") {
    this.#native.closeWebSocket(session, code, reason);
  }

  /** Submit a buffered request through Core's logical-target client. */
  outboundSubmit(request) {
    return this.#native.outboundSubmit({
      timeoutMillis: 30_000,
      ...request,
      headers: headers(request.headers),
      body: buffer(request.body),
    });
  }

  /** Request cancellation of a previously submitted outbound call. */
  outboundCancel(call) {
    this.#native.outboundCancel(call);
  }

  /** Synchronously take one copied outbound terminal, or `null` on timeout. */
  takeOutbound(timeoutMillis = 0) {
    return this.#native.takeOutbound(timeoutMillis);
  }

  /** Atomically replace a route's handler binding under generation checks. */
  rebind(request, timeoutMillis) {
    return this.#native.rebind(request, timeoutMillis);
  }

  /** Read a pointer-free snapshot of current Core health. */
  health() {
    return this.#native.health();
  }

  /** Run a bounded liveness probe and return the acknowledged health snapshot. */
  probeLiveness(timeoutMillis) {
    return this.#native.probeLiveness(timeoutMillis);
  }

  /** Read the effective runtime-monitor reservation and live policy. */
  monitorConfig() {
    return this.#native.monitorConfig();
  }

  /** Read a pointer-free aggregate monitor and health snapshot. */
  monitorSnapshot() {
    return this.#native.monitorSnapshot();
  }

  /** Apply a live monitor policy under an expected-generation check. */
  monitorApply(expectedGeneration, policy) {
    return this.#native.monitorApply(expectedGeneration, policy);
  }

  /** Read a bounded page of pointer-free runtime monitor events. */
  monitorRead(afterSequence, maximumEvents = 64) {
    return this.#native.monitorRead(afterSequence, maximumEvents);
  }

  /** Synchronously wait for newer monitor truth and return false on timeout. */
  monitorWait(timeoutMillis) {
    return this.#native.monitorWait(timeoutMillis);
  }

  /** Wake the sole blocking monitor waiter without changing Core lifecycle. */
  monitorInterrupt() {
    this.#native.monitorInterrupt();
  }
}

/** Create a callback-free Core owner from a defensively projected configuration. */
export function createCore(value = {}) {
  return new Core(native.createCore(configuration(value)), CORE_OWNER);
}
