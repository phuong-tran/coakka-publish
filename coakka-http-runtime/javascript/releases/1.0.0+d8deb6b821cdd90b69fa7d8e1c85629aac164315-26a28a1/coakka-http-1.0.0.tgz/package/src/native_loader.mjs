import { createHash } from "node:crypto";
import { lstatSync, readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const MAXIMUM_NATIVE_BYTES = 64 << 20;
const require = createRequire(import.meta.url);
let loadedAddon;

/** Load the target-specific addon after verifying every packaged byte. */
export function loadNativeAddon() {
  if (loadedAddon !== undefined) return loadedAddon;
  const manifestPath = fileURLToPath(
    new URL(`../prebuilds/${process.platform}-${process.arch}/native.json`, import.meta.url),
  );
  const nativeDirectory = dirname(manifestPath);
  const manifest = JSON.parse(readBoundedFile(manifestPath, 16 << 10).toString("utf8"));
  if (
    manifest?.format !== 1 ||
    manifest.platform !== process.platform ||
    manifest.architecture !== process.arch
  ) {
    throw new Error("CoAkka HTTP native package targets another platform");
  }
  const addonPath = verifyEntry(nativeDirectory, manifest.addon, "coakka_http_javascript.node");
  verifyEntry(nativeDirectory, manifest.core, expectedCoreFile());
  const candidate = require(addonPath);
  if (
    candidate === null ||
    typeof candidate !== "object" ||
    typeof candidate.createService !== "function" ||
    typeof candidate.createCore !== "function" ||
    typeof candidate.coreFeatures !== "function"
  ) {
    throw new Error("CoAkka HTTP native addon has an incompatible surface");
  }
  loadedAddon = candidate;
  return loadedAddon;
}

function verifyEntry(nativeDirectory, entry, expectedFile) {
  if (
    entry === null ||
    typeof entry !== "object" ||
    entry.file !== expectedFile ||
    !Number.isSafeInteger(entry.size) ||
    entry.size <= 0 ||
    entry.size > MAXIMUM_NATIVE_BYTES ||
    !/^[0-9a-f]{64}$/u.test(entry.sha256)
  ) {
    throw new Error("CoAkka HTTP native manifest entry is invalid");
  }
  const path = join(nativeDirectory, expectedFile);
  const bytes = readBoundedFile(path, MAXIMUM_NATIVE_BYTES);
  if (bytes.byteLength !== entry.size || createHash("sha256").update(bytes).digest("hex") !== entry.sha256) {
    throw new Error("CoAkka HTTP native file failed integrity validation");
  }
  return path;
}

function readBoundedFile(path, maximum) {
  const details = lstatSync(path);
  if (!details.isFile() || details.isSymbolicLink() || details.size <= 0 || details.size > maximum) {
    throw new Error("CoAkka HTTP native file is outside its package bound");
  }
  return readFileSync(path);
}

function expectedCoreFile() {
  if (process.platform === "win32") return "coakka_http_runtime.dll";
  if (process.platform === "darwin") return "libcoakka_http_runtime.1.dylib";
  if (process.platform === "linux") return "libcoakka_http_runtime.so.1";
  throw new Error("CoAkka HTTP does not support this platform");
}
