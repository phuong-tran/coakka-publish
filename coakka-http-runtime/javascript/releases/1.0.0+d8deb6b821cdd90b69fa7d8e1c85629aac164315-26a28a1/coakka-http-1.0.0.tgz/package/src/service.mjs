import { loadNativeAddon } from "./native_loader.mjs";
import { Limits, Request, Response, Route } from "./values.mjs";

const METHODS = new Set(["GET", "POST", "PUT", "PATCH", "DELETE"]);

/** Single-use builder for a native-owned HTTP service. */
export class Builder {
  #host = "127.0.0.1";
  #port = 0;
  #workers = 1;
  #limits = new Limits();
  #routes = [];
  #started = false;

  /** Select the bind host and port; zero requests an available port. */
  listen(host, port) {
    this.#requireMutable();
    if (typeof host !== "string" || host.trim() === "" || !Number.isSafeInteger(port) || port < 0 || port > 65_535) {
      throw new TypeError("listener host or port is invalid");
    }
    this.#host = host;
    this.#port = port;
    return this;
  }

  /** Select the fixed number of native request-handler workers. */
  concurrency(workers) {
    this.#requireMutable();
    if (!Number.isSafeInteger(workers) || workers < 1 || workers > 16_384) {
      throw new RangeError("worker count is invalid");
    }
    this.#workers = workers;
    return this;
  }

  /** Replace every construction-time resource ceiling. */
  limits(limits) {
    this.#requireMutable();
    if (!(limits instanceof Limits)) throw new TypeError("limits must be a Limits value");
    this.#limits = limits;
    return this;
  }

  /** Register a synchronous `handler` for one method and path pattern. */
  route(method, pattern, handler) {
    this.#requireMutable();
    const normalized = String(method).trim().toUpperCase();
    if (!METHODS.has(normalized) || typeof pattern !== "string" || !pattern.startsWith("/") || typeof handler !== "function") {
      throw new TypeError("route declaration is invalid");
    }
    if (this.#routes.length >= 1_024) throw new RangeError("route count exceeds the native bound");
    this.#routes.push({ id: this.#routes.length + 1, method: normalized, pattern, handler });
    return this;
  }

  /** Register a GET handler for `pattern`. */
  get(pattern, handler) { return this.route("GET", pattern, handler); }

  /** Register a POST handler for `pattern`. */
  post(pattern, handler) { return this.route("POST", pattern, handler); }

  /** Register a PUT handler for `pattern`. */
  put(pattern, handler) { return this.route("PUT", pattern, handler); }

  /** Register a PATCH handler for `pattern`. */
  patch(pattern, handler) { return this.route("PATCH", pattern, handler); }

  /** Register a DELETE handler for `pattern`. */
  delete(pattern, handler) { return this.route("DELETE", pattern, handler); }

  /** Create and start a service whose HTTP resources Core owns. */
  start() {
    this.#requireMutable();
    if (this.#routes.length === 0) throw new RangeError("at least one route is required");
    this.#started = true;
    const errors = [];
    const routes = this.#routes.map((route) => ({
      id: route.id,
      method: route.method,
      pattern: route.pattern,
      handler: (value) => {
        try {
          const result = route.handler(new Request(value));
          if (result instanceof Promise || !(result instanceof Response)) {
            throw new TypeError("handler must return Response synchronously");
          }
          return result;
        } catch (error) {
          if (errors.length === 64) errors.shift();
          errors.push(error);
          return Response.text("internal server error", { status: 500 });
        }
      },
    }));
    const limits = this.#limits;
    const owner = loadNativeAddon().createService({
      host: this.#host,
      port: this.#port,
      workers: this.#workers,
      maxConnections: limits.maxConnections,
      maxActiveRequests: limits.maxActiveRequests,
      requestQueueCapacity: limits.requestQueueCapacity,
      responseQueueCapacity: limits.responseQueueCapacity,
      maxRequestBodyBytes: limits.maxRequestBodyBytes,
      maxResponseBodyBytes: limits.maxResponseBodyBytes,
      requestTimeoutMillis: limits.requestTimeoutMillis,
      shutdownTimeoutMillis: limits.shutdownTimeoutMillis,
      routes,
    });
    try {
      owner.start();
      return new Service(owner, errors, this.#routes.map((route) => new Route(route.id, route.method, route.pattern)));
    } catch (error) {
      void owner.close().catch(() => {});
      throw error;
    }
  }

  #requireMutable() {
    if (this.#started) throw new Error("builder can only be started once");
  }
}

/** Sole lifecycle owner for one started native HTTP server. */
export class Service {
  #owner;
  #errors;
  #closePromise;

  /** Adopt a started native owner and immutable route declarations. */
  constructor(owner, errors, routes) {
    this.#owner = owner;
    this.#errors = errors;
    this.routes = Object.freeze([...routes]);
    Object.freeze(this);
  }

  /** Return the actual bound port, including a selected ephemeral port. */
  get port() {
    if (this.#owner === undefined) throw new Error("service is closed");
    return this.#owner.port();
  }

  /** Remove and return the oldest bounded handler diagnostic. */
  pollError() {
    return this.#errors.shift();
  }

  /** Stop admission, drain callbacks, and release all native state. */
  close() {
    if (this.#closePromise !== undefined) return this.#closePromise;
    const owner = this.#owner;
    if (owner === undefined) return Promise.resolve();
    this.#closePromise = owner.close().then(() => {
      this.#owner = undefined;
    });
    return this.#closePromise;
  }
}
