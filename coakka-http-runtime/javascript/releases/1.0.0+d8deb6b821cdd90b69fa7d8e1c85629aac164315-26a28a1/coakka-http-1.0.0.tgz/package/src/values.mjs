const HEADER_NAME = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/u;

/** One immutable HTTP header. */
export class Header {
  /** Create a validated name and value pair. */
  constructor(name, value) {
    if (typeof name !== "string" || name.length === 0 || name.length > 256 || !HEADER_NAME.test(name)) {
      throw new TypeError("HTTP header name is invalid");
    }
    if (typeof value !== "string" || value.length > 8192 || [...value].some((character) => character.codePointAt(0) > 255) || /[\0\r\n]/u.test(value)) {
      throw new TypeError("HTTP header value is invalid");
    }
    this.name = name;
    this.value = value;
    Object.freeze(this);
  }
}

/** Immutable ordered HTTP headers with case-insensitive lookup. */
export class Headers {
  #entries;

  /** Create a defensive immutable copy of `entries`. */
  constructor(entries = []) {
    if (!Array.isArray(entries) && !(entries instanceof Headers)) {
      throw new TypeError("headers must be an array or Headers");
    }
    const values = entries instanceof Headers ? [...entries] : entries;
    if (values.some((entry) => !(entry instanceof Header))) {
      throw new TypeError("headers must contain Header values");
    }
    this.#entries = Object.freeze([...values]);
    Object.freeze(this);
  }

  /** Return the number of entries, including duplicate names. */
  get size() {
    return this.#entries.length;
  }

  /** Return the first value for `name`, or `null` when absent. */
  get(name) {
    const target = String(name).toLowerCase();
    return this.#entries.find((entry) => entry.name.toLowerCase() === target)?.value ?? null;
  }

  /** Return every value for `name` in declaration order. */
  getAll(name) {
    const target = String(name).toLowerCase();
    return this.#entries.filter((entry) => entry.name.toLowerCase() === target).map((entry) => entry.value);
  }

  /** Return an iterator over immutable entries in declaration order. */
  [Symbol.iterator]() {
    return this.#entries[Symbol.iterator]();
  }
}

/** Construction-time resource ceilings copied into native Core. */
export class Limits {
  /** Create a complete validated limit set from optional overrides. */
  constructor(options = {}) {
    Object.assign(this, {
      maxConnections: 128,
      maxActiveRequests: 64,
      requestQueueCapacity: 64,
      responseQueueCapacity: 64,
      maxRequestBodyBytes: 1_048_576,
      maxResponseBodyBytes: 4_194_304,
      requestTimeoutMillis: 30_000,
      shutdownTimeoutMillis: 5_000,
      ...options,
    });
    const positive = Object.values(this).every((value) => Number.isSafeInteger(value) && value > 0);
    if (
      !positive ||
      this.maxConnections > 65_536 ||
      this.maxActiveRequests > this.maxConnections ||
      this.requestQueueCapacity > this.maxActiveRequests ||
      this.responseQueueCapacity > this.maxActiveRequests
    ) {
      throw new RangeError("CoAkka HTTP limits are invalid");
    }
    Object.freeze(this);
  }
}

/** One immutable route registered in a started service. */
export class Route {
  /** Create an immutable route description. */
  constructor(id, method, pattern) {
    this.id = id;
    this.method = method;
    this.pattern = pattern;
    Object.freeze(this);
  }
}

/** Immutable JavaScript-owned request passed to one handler invocation. */
export class Request {
  /** Adopt the connector's already-copied request projection. */
  constructor(value) {
    this.method = value.method;
    this.scheme = value.scheme;
    this.authority = value.authority;
    this.target = value.target;
    this.headers = new Headers(value.headers.map((entry) => new Header(entry.name, entry.value)));
    this.routeId = value.routeId;
    this.cancelled = value.cancelled;
    this.#body = Buffer.from(value.body);
    Object.freeze(this);
  }

  #body;

  /** Return a defensive copy of the buffered request body. */
  bytes() {
    return Buffer.from(this.#body);
  }

  /** Decode the buffered request body as UTF-8. */
  text() {
    return this.#body.toString("utf8");
  }
}

/** Immutable buffered response returned by a request handler. */
export class Response {
  #body;

  /** Create a response with a status, ordered headers, and copied body. */
  constructor(body = new Uint8Array(), options = {}) {
    const status = options.status ?? 200;
    const headers = options.headers instanceof Headers ? options.headers : new Headers(options.headers ?? []);
    if (!Number.isSafeInteger(status) || status < 100 || status > 599 || headers.size > 100) {
      throw new RangeError("HTTP response status or header count is invalid");
    }
    this.status = status;
    this.headers = Object.freeze([...headers].map((entry) => Object.freeze({ name: entry.name, value: entry.value })));
    this.#body = Buffer.from(typeof body === "string" ? body : body);
    Object.freeze(this);
  }

  /** Return a defensive copy of the buffered response body. */
  get body() {
    return Buffer.from(this.#body);
  }

  /** Create a UTF-8 text response and add a content type when absent. */
  static text(body, options = {}) {
    if (typeof body !== "string") throw new TypeError("text response body must be a string");
    let headers = options.headers instanceof Headers ? options.headers : new Headers(options.headers ?? []);
    if (headers.get("content-type") === null) {
      headers = new Headers([...headers, new Header("content-type", "text/plain; charset=utf-8")]);
    }
    return new Response(body, { ...options, headers });
  }

  /** Create a response that owns a copy of `body`. */
  static bytes(body, options = {}) {
    return new Response(body, options);
  }

  /** Create an empty response with status 204 unless explicitly overridden. */
  static empty(options = {}) {
    return new Response(new Uint8Array(), { status: 204, ...options });
  }
}
