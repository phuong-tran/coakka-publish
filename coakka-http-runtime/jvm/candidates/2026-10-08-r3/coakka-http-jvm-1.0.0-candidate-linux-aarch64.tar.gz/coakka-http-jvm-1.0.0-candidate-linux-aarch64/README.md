# CoAkka HTTP JVM — local package candidate

Kotlin-first, Java-friendly HTTP runtime with host-inlined application handlers.
This is a local candidate, not a published Maven coordinate or a release.

Loop tuning is private to the JVM connector; neither service nor lower-level
configuration accepts a loop override. CPU policy and application concurrency
remain independent settings. `runtimeInfo().execution.selection` reports Core's
construction decision: requested mode/count, selected count and typed reason.
Unknown mode/reason bits remain available in `rawRequestedMode` and `rawReason`.
Core alone admits the complete configuration; the connector does not probe,
guess effective settings, or retry with a different topology. Live activity
counts are cold observations, not CPU utilization or permission to destroy a
request owner; use graceful drain outcomes for shutdown.

Choose the bundle matching the **JVM process architecture**, not merely the OS.
The managed JAR requires Java 8 or later. Kotlin consumers were compiled with
Kotlin 2.3.10; Java applications need no Kotlin compiler.

| Bundle | Native baseline |
| --- | --- |
| macos-aarch64 | macOS 11+, ARM64 JVM |
| linux-aarch64 | glibc 2.28+, ARM64 JVM |
| linux-x86_64 | glibc 2.28+, x86-64 JVM |
| windows-aarch64 | Windows ARM64 JVM; tested with Java 21 |
| windows-x86_64 | Windows x86-64 JVM; tested with Java 8 |

These are native compatibility baselines, not a claim that every OS/JDK patch
has been tested. No musl, Android, or macOS x86-64 artifact is included.

## Install into an application

Extract one bundle into a trusted, application-owned directory. Keep `native/`
intact, including its relative library links. No C/C++ compiler is needed.
The JAR does not download or extract executable files. It does not contain the
Kotlin standard library; declare that application dependency normally.

For a Gradle JVM application (replace the path with your extracted bundle):

```kotlin
dependencies {
    implementation(files("vendor/coakka-http/lib/coakka-http-jvm-1.0.0.jar"))
    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.3.10")
}
tasks.withType<JavaExec>().configureEach {
    jvmArgs("-Djava.library.path=" + file("vendor/coakka-http/native").absolutePath)
}
```

Set the native search path **at JVM startup**. On Windows also add that same
absolute `native` directory to the application's process `PATH`, so the system
loader can resolve the matching Core DLL. Do not add an untrusted directory.
Never mix Core/JVM binaries from different bundles or replace loaded libraries
inside a running process.

Alternatively set both startup properties `coakka.http.host.path` and
`coakka.http.bridge.path` to the absolute regular files in `native/`:

| OS | Core file | JVM adapter file |
| --- | --- | --- |
| macOS | `libcoakka_http_host.dylib` | `libcoakka_http_jvm.dylib` |
| Linux | `libcoakka_http_host.so` | `libcoakka_http_jvm.so` |
| Windows | `coakka_http_host.dll` | `coakka_http_jvm.dll` |

Supply both or neither; partial configuration is rejected. Explicit paths must
identify regular files, not symbolic links. Library load or ABI errors fail
startup; the connector never silently substitutes a different runtime.

## Kotlin

```kotlin
import coakka.http.Handler
import coakka.http.Responses
import coakka.http.ServiceBuilder

val service = ServiceBuilder()
    .listen("127.0.0.1", 8080)
    .get("/hello", Handler { Responses.text("hello") })
    .start()
// Retain service for the application's lifetime. During application shutdown:
// service.close()
```

## Java

```java
import coakka.http.Responses;
import coakka.http.Service;
import coakka.http.ServiceBuilder;

Service service = new ServiceBuilder()
    .listen("127.0.0.1", 8080)
    .get("/hello", request -> Responses.text("hello"))
    .start();
// Retain service; call service.close() during application shutdown.
```

Core owns accepted defaults, HTTP transport, deadlines and graceful drain.
`service.runtimeInfo()` reports Core-issued effective settings and observed
capabilities; a preference is not proof a capability was applied. Application
handlers remain in the JVM. Do not call blocking shutdown from a handler.
If a caller's close wait expires, retain the service and retry close; do not
start a replacement on the assumption that the old service has finished.

## Configuration and observation

`ServiceBuilder.compression(Compression(CompressionMode.GZIP))` requests bounded
compression of eligible buffered responses. Pass `null` to remove earlier
intent. Core validates the settings and negotiates response encoding; streaming
stays unbuffered and is not implicitly GZIP-encoded. A client that excludes
identity encoding can therefore receive a not-acceptable response for a stream.

Use `Limits(transportTimeouts = TransportTimeouts(headerTimeoutMillis = 5000))`
for grouped header/body/keep-alive/protocol-idle deadline intent. Omitted or zero
fields delegate to Core; `service.effectiveLimits()` reports accepted values.
The application-handler deadline remains `Limits.requestTimeoutMillis`.
These immutable values and builder methods also have Java-friendly constructors
and getters; no newer JVM runtime is required.

`service.routes` (Java: `service.getRoutes()`) pulls an immutable `RouteSnapshot`
directly from Core, including structural generation, binding-change sequence and
route/binding revisions. Monitoring need not be enabled. It does not return
handler objects or reconstruct effective state from registration declarations.
A rejected inspection throws rather than returning stale state.

Outbound terminals expose `reason`, `phase`, `retry` and `certainty` as named
enums. `rawReason`, `rawPhase`, `rawRetry` and `rawCertainty` retain unknown native
values; unknown values project as `UNRECOGNIZED`, never success. A complete HTTP
404/500 is still `OutboundReason.RESPONSE`; transport failure is separate from
HTTP status. Retry disposition is not permission to replay application work.

If your application applies another shrinker, retain the public API it uses
and honor `META-INF/proguard/coakka-http.pro` from this JAR for native lookup.
The supplied JAR is already shrunk/obfuscated. Native debug data and managed
mapping files are not part of the consumer bundle.

`SHA256SUMS` checks the bundle files. Preserve all supplied license and notice
files when redistributing the package. `PACKAGE-LICENSE.md` defines file scope.
