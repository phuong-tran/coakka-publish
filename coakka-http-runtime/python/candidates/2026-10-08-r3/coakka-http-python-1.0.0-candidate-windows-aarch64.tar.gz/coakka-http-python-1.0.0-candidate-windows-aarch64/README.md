# CoAkka HTTP for Python — local candidate

This archive is an offline package candidate, not a PyPI release. Use CPython
3.11 or newer and select the package for the interpreter process architecture.
Architecture availability is not proof of platform qualification; consult the
release evidence before deployment. No native compiler is needed.

Keep `python/coakka_http` intact, including its paired native library and
package metadata. Verify `SHA256SUMS` from the extracted bundle, then place the
bundle's `python/` directory on the application's Python path:

```sh
export PYTHONPATH=/absolute/path/to/extracted-bundle/python
python app.py
```

On Windows, set the same application-local `PYTHONPATH` using the shell's normal
environment syntax. Do not change the global system environment. The package
loads its own library; no runtime download, extraction or native-path setting
is needed. Do not mix package files or replace libraries while loaded.

```python
from coakka_http import Builder, Response

service = Builder().listen("127.0.0.1", 8080).get(
    "/hello", lambda request: Response(status=200, body=b"hello")
).start()
# Retain service while the application is running.
# In the application's shutdown path, call service.close() and handle failure.
```

Handlers run in Python. The HTTP runtime owns transport, validation, resource
bounds, timeouts, accepted configuration and operational information. Read
`service.runtime_info()` rather than inferring effective settings from inputs.
Await application work and handle shutdown failure; expiry is not graceful
success and does not authorize replacing a retained owner.

## Configuration and observations

`Builder.compression(Compression(CompressionMode.GZIP))` enables bounded
buffered-response compression. Core selects eligible responses and negotiates
their encoding. Streaming responses remain bounded identity streams; enabling
buffered compression does not buffer or compress them. Configure transport and
handler deadlines with `Limits`; zero-valued optional limits request Core's
defaults. Inspect accepted limits through `service.effective_limits()`.

HTTP-loop tuning is private to the connector; neither construction API accepts
loop-count overrides. `service.runtime_info().execution.selection` reports
Core's immutable decision, meaningful only when `execution.observed` is true.
Counts describe HTTP loops, not Python workers or CPU utilization. Core validates
the complete configuration and never disables a feature to admit a preference;
the connector does not probe eligibility or retry with a different topology.

`service.routes` returns an immutable `RouteSnapshot` pulled from Core, even
when monitoring is disabled. Its identity and entries describe one coherent
cut, not local handler declarations. Keep the expected generation and binding
revision for conditional route changes; inspection errors propagate rather
than returning cached guesses. A previously returned snapshot stays unchanged.

`service.take_outbound()` returns `OutboundTerminal` or `None` when its wait
expires. `OutboundReason`, `OutboundPhase`, `OutboundRetry` and
`OutboundCertainty` preserve Core's causal facts. An HTTP 404/500 received in a
complete response is `OutboundReason.RESPONSE`, not a transport failure.
Unknown values retain their numeric identity through `int(value)`; application
retry policy must not assume an unknown value permits retry. Do not expose
operator diagnostic text automatically in an HTTP response.

Annotations, public names and docstrings remain available for normal Python
inspection and typed tooling. Package shrinking is not native compilation and
does not claim to conceal all Python implementation. The native HTTP library
remains a closed shared library. Preserve all license and notice files.

For deliberate development use only, `COAKKA_HTTP_HOST_PATH` overrides the
library with an absolute regular file. An invalid override or damaged package
fails instead of silently loading another library.
