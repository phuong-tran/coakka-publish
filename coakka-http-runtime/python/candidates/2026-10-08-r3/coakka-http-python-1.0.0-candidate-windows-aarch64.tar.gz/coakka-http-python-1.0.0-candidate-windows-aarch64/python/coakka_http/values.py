'Python-owned values for the public CoAkka HTTP host-inlined surface.'
from __future__ import annotations
import io
from collections.abc import Iterable,Iterator,Mapping
from dataclasses import dataclass,field
from enum import IntEnum,IntFlag
from itertools import islice
from types import MappingProxyType
from typing import Final
ABI_VERSION:Final=9
TIMEOUT_FOREVER:Final=(1<<64)-1
MONITOR_MAX_FAILURE_COUNTS:Final=48
MONITOR_FIXED_LATENCY_BUCKETS:Final=16
MONITOR_MAX_EVENTS_PER_READ:Final=64
_MAX_HEADER_COUNT:Final=100
class Capability(IntFlag):'Capabilities implemented by the installed native runtime.';INBOUND=1;TLS=2;MUTUAL_TLS=4;GZIP=8;REQUEST_STREAM=16;RESPONSE_STREAM=32;RESPONSE_TRAILERS=64;RESPONSE_WRITE_TIMEOUT=128;SERVER_SENT_EVENTS=256;WEBSOCKET=512;HTTP_2=1024;HTTP_3=2048;STATIC_FILES=4096;APPLICATION_FILES=8192;OUTBOUND=16384;ROUTE_REBIND=32768;OUTBOUND_LOGICAL_TARGET=65536;STATIC_FRONTEND=131072;HEALTH=262144;MONITOR=524288;ROUTE_PUBLICATION=1048576;ALL=2097151
class ResultCode(IntEnum):'Statuses returned by the native host surface.';OK=0;INVALID_ARGUMENT=1;INVALID_METHOD=2;INVALID_PATTERN=3;CAPACITY_EXHAUSTED=4;AMBIGUOUS=5;OUT_OF_MEMORY=6;DUPLICATE_ROUTE_ID=7;DUPLICATE_BINDING_ID=8;UNSUPPORTED=9;CLOSED=10;TIMEOUT=11;NOT_FOUND=12;IO_ERROR=13;STALE_EXCHANGE=14;UNKNOWN=127
class NotificationProfile(IntEnum):'Startup notification bounds; AUTO delegates selection to Core.\n\n    Profiles never delay a partial turn to fill a batch. Request and terminal\n    lanes resolve independently; runtime information reports their actual caps.\n    ';AUTO=0;SMALL=1;MEDIUM=4;LARGE=8;XLARGE=16;XXLARGE=32;ULTRA=64
class DrainState(IntEnum):"Core's native drain outcome, distinct from a caller's wait deadline.";NOT_STARTED=0;PENDING=1;COMPLETE=2;EXPIRED=3;ABORTED=4;FAILED=5;UNSUPPORTED=6
class CpuPolicy(IntEnum):'Core dispatcher placement intent; not Python concurrency or a CPU quota.';AUTO=0;SINGLE=1
class CpuPlacement(IntEnum):"Core's entry-time result, not a connector platform guess.";APPLIED=0;SINGLE_AVAILABLE=1;UNSUPPORTED=2
@dataclass(frozen=True,slots=True)
class CpuInfo:"Immutable Core-issued placement facts for this service's owner thread.\n\n    ``requested_policy`` retains user intent. ``placement`` distinguishes exact\n    placement, a one-CPU constraint and unsupported AUTO. ``available_cpu_count``\n    is logical affinity, not cgroup quota; zero means unknown on unsupported\n    hosts. ``selected_cpu_ids`` lists only Core-selected CPUs (at most two).\n    Children inherit the placement; existing application threads are unchanged.\n    ";requested_policy:CpuPolicy|int;placement:CpuPlacement|int;available_cpu_count:int;selected_cpu_count:int;selected_cpu_ids:tuple[int,...]
@dataclass(frozen=True,slots=True)
class DrainOutcome:'One native wait result; PENDING means only the observation wait ended.\n\n    ``status`` and ``state`` retain unknown numeric values. COMPLETE certifies\n    native quiescence, not Python handler completion or successful delivery.\n    ';status:int;state:DrainState|int
class FailureReason(IntEnum):'Known machine-readable causes retained on native operation errors.';NONE=0;INVALID_ARGUMENT=1;INVALID_STATE=2;CAPACITY=3;TIMEOUT=4;CLOSED=5;OUT_OF_MEMORY=6;UNSUPPORTED=7;LISTENER_START=8;TRANSPORT_SECURITY=9;IO_BACKEND=10;INTERNAL=11
class ListenerProtocol(IntEnum):'Wire protocol selected for the native listener.';HTTP_1_1=1;HTTP_2=2;HTTP_3=3
class TransportSecurity(IntEnum):'Transport security mode for listeners and outbound endpoints.';PLAINTEXT=1;TLS=2;MUTUAL_TLS=3
class BodyDelivery(IntEnum):'How one admitted request body is delivered.';INLINE=1;STREAM=2
class CompressionMode(IntEnum):'Construction-time response compression mode.';DISABLED=1;GZIP=2
class IoBackend(IntEnum):'Optional native I/O backend request.';PLATFORM_DEFAULT=1;IO_URING=2
class IoBackendFallbackReason(IntEnum):'Why an opted-in runtime instance uses the platform default.';NONE=0;CONFIGURATION=1;UNAVAILABLE=2
class EventKind(IntEnum):'Kinds returned by the inbound event lane.';REQUEST=1;REQUEST_DATA=2;REQUEST_TRAILERS=3;REQUEST_END=4;REQUEST_CANCELLED=5;RESPONSE_WRITABLE=6;TERMINAL=7
class WebSocketEventKind(IntEnum):'WebSocket receive and send kinds.';OPEN=1;TEXT=2;BINARY=3;PING=4;PONG=5;WRITABLE=6;CLOSE=7;ACCEPT_FAILED=8
class OutboundStrategy(IntEnum):'Endpoint selection strategy for a logical outbound target.';SINGLE_OWNER=1;WEIGHTED_ROUND_ROBIN=2
class MonitorCollection(IntEnum):'Amount of monitoring truth retained by the runtime.';DISABLED=0;AGGREGATES=1;AGGREGATES_AND_EVENTS=2
class MonitorNotification(IntEnum):'How a monitor reader waits for newer truth.';POLL=0;SIGNAL=1
class MonitorLatency(IntEnum):'Latency histogram collection mode.';NONE=0;FIXED=1
class MonitorCategory(IntFlag):'Native monitor category bits.';LIFECYCLE=1;EXCHANGE=2;CONTROL=4;LATENCY=8;ALL=15
class MonitorApplyReason(IntEnum):'Typed result of applying a live monitor policy.';APPLIED=0;INVALID_ARGUMENT=1;INVALID_ENUM=2;UNSUPPORTED_CATEGORY=3;INVALID_CATEGORY_RELATIONSHIP=4;RESOURCE_RESERVATION_EXCEEDED=5;SIGNAL_NOT_RESERVED=6;GENERATION_CONFLICT=7;INVALID_LIFECYCLE=8;SEQUENCE_EXHAUSTED=9;INTERNAL=10
class MonitorEventKind(IntEnum):'Kinds of bounded operational monitor events.';LIFECYCLE_CHANGED=1;POLICY_APPLIED=2;POLICY_REJECTED=3;EXCHANGE_COMPLETED=4;EXCHANGE_FAILED=5;EXCHANGE_TIMED_OUT=6;EXCHANGE_DISCONNECTED=7;EXCHANGE_CANCELLED=8
class _CoreCode(IntEnum):
	'Preserve unknown uint32 observations without caching arbitrary values.'
	@classmethod
	def _missing_(cls,value:object)->_CoreCode|None:
		if type(value)is not int or not 0<=value<=4294967295:return None
		member=int.__new__(cls,value);member._name_=f"UNKNOWN_{value}";member._value_=value;return member
class OutboundReason(_CoreCode):"Core's causal result; unknown uint32 values stay intact without a cache.";RESPONSE=1;PROVIDER_FAILURE=2;PROVIDER_REJECTED=3;CANCELLED=4;DEADLINE_EXCEEDED=5;STOPPED=6;RESPONSE_HEAD_LIMIT=7;RESPONSE_BODY_LIMIT=8;RESPONSE_AGGREGATE_LIMIT=9;OUT_OF_MEMORY=10;CLOCK_FAILURE=11;INVALID_PROVIDER_RESULT=12
class OutboundPhase(_CoreCode):'Core-issued causal phase, never inferred from status or error text.';ADMISSION=1;PROVIDER_ADOPTION=2;TRANSPORT=3;RESPONSE=4;CANCELLATION=5;SHUTDOWN=6
class OutboundRetry(_CoreCode):'Core disposition; application idempotency/retry budgets remain application policy.';NEVER=1;IF_SAFE=2;DELIVERY_UNCERTAIN=3
class OutboundCertainty(_CoreCode):'Observed delivery evidence copied from Core, not a connector estimate.';NO_REQUEST_BYTES_SENT=1;REQUEST_UNCERTAIN=2;RESPONSE_HEAD_OBSERVED=3;COMPLETE_RESPONSE=4
class ControlCode(_CoreCode):'Core publication outcome; timeout/wakeup failure is not rejection.\n\n    Retry the exact activation and intent to resolve those outcomes. BUSY\n    means another unresolved activation prevented submission. Unknown numeric\n    values stay intact; none are silently treated as APPLIED.\n    ';APPLIED=0;INVALID_ARGUMENT=1;CLOSED=2;ACTIVATION_CONFLICT=3;ACTIVATION_EXPIRED=4;ACTIVATION_OUT_OF_ORDER=5;ROUTE_NOT_FOUND=6;GENERATION_MISMATCH=7;REVISION_MISMATCH=8;SEQUENCE_EXHAUSTED=9;REJECTED=10;OUT_OF_MEMORY=11;INTERNAL=12;TIMEOUT=13;WAKEUP_FAILED=14;BUSY=15
RouteRebindCode=ControlCode
RoutePublicationCode=ControlCode
class RequestRetirementState(_CoreCode):'Core request-capture state; unknown never permits handler disposal.';UNKNOWN=0;CAPTURED=1;QUIESCENT=2;STILL_ROUTABLE=3;NOT_APPLICABLE=4
class RequestRetirementCode(_CoreCode):'Core observation outcome, separate from publication success.';UNAVAILABLE=0;OBSERVED=1;INVALID_ARGUMENT=2;UNSUPPORTED=3;OUT_OF_MEMORY=4;CLOSED=5;BUSY=6;CONFLICT=7;EXPIRED=8;TIMEOUT=9;WAKEUP_FAILED=10;PUBLICATION_FAILED=11;OBSERVATION_FAILED=12;NOT_FOUND=13;SYSTEM_ERROR=14
@dataclass(frozen=True,slots=True)
class RequestRetirement:'Core proof tied to one publication, refreshed by its exact retry.\n\n    ``state`` describes captures; ``code`` describes observation success.\n    ``quiescent_sources`` counts acknowledging Core owners out of ``sources``,\n    not CPUs/workers. Even QUIESCENT does not retire Python callbacks, sessions\n    or application references. Republishing an identity starts a new lifetime.\n    ';state:RequestRetirementState;code:RequestRetirementCode;quiescent_sources:int;sources:int
class ExecutionMode(_CoreCode):'Core-issued construction mode, for observation only; unknowns preserved.';DEFAULT=0;EXACT=1;PREFER_SUPPORTED=2
class ExecutionReason(_CoreCode):"Core's selection explanation, never a connector eligibility decision.";DEFAULTED=0;EXACT_SELECTED=1;PREFERRED_SELECTED=2;FACILITY_RESTRICTED=3;BUDGET_RESTRICTED=4;CPU_RESTRICTED=5;CPU_UNOBSERVED=6
@dataclass(frozen=True,slots=True)
class ExecutionSelection:"Core's immutable construction decision; meaningful only when observed.\n\n    ``requested_mode`` and ``requested_count`` identify accepted intent; the\n    count is zero only for DEFAULT. ``selected_count`` is Core's reservation,\n    stable across start/drain/stop, not CPU utilization or live activity.\n    ``reason`` is Core-issued and retains unknown uint32 observations.\n    ";requested_mode:ExecutionMode;requested_count:int;selected_count:int;reason:ExecutionReason
@dataclass(frozen=True,slots=True)
class ExecutionInfo:"Core's cold loop observation, independent of CPU placement and workers.\n\n    ``configured_event_loops`` is the accepted reservation, stable across stop\n    or failed start. ``active_event_loops`` counts running/draining kernels;\n    ``draining_event_loops`` is its draining subset. ``failed_event_loops`` is\n    the current failed count, not history. ``observed`` distinguishes an actual\n    instance observation from unknown. The bounded atomic sampling is not a\n    simultaneous barrier and never grants permission to release request leases.\n    ``selection`` groups the immutable Core construction decision; it is not\n    application input and is meaningful only with ``observed=True``.\n    ";configured_event_loops:int;active_event_loops:int;draining_event_loops:int;failed_event_loops:int;observed:bool;selection:ExecutionSelection
@dataclass(frozen=True,slots=True)
class ServicePlan:'Immutable result of checking a complete service declaration.';supported:bool;required_capabilities:Capability;adapter_capabilities:Capability;missing_capabilities:Capability
@dataclass(frozen=True,slots=True)
class RuntimeInfo:"Copied native startup truth for one runtime instance.\n\n    ``request_notification_batch_size`` is Core's effective HTTP/1 cap.\n    ``event_loop_cpu_mask`` is the requested CPU set, and its supported and\n    applied flags describe the startup decision, not live OS affinity.\n    ";abi_version:int;io_uring_requested:bool;io_uring_effective:bool;io_uring_compiled:bool;io_uring_probed:bool;io_uring_supported:bool;service_started:bool;fallback_reason:IoBackendFallbackReason;io_uring_probe_error:int;request_notification_batch_size:int;event_loop_cpu_mask:int;event_loop_cpu_mask_supported:bool;event_loop_cpu_mask_applied:bool;terminal_notification_batch_size:int;execution:ExecutionInfo;cpu:CpuInfo|None=None
@dataclass(frozen=True,slots=True)
class RuntimeInspection:"Global Core image/probe facts; no service or CPU placement is implied.\n\n    ``features`` is the loaded image's mask. ``io_uring_probed`` distinguishes\n    unknown support from an actual negative probe; inspection may probe once.\n    ";abi_version:int;features:Capability;io_uring_compiled:bool;io_uring_probed:bool;io_uring_supported:bool;io_uring_probe_error:int
@dataclass(frozen=True,slots=True)
class Header:
	'One immutable text field; Core validates HTTP syntax on submission.\n\n    Python checks text types here and byte representability at projection.\n    Constructing this value is not a certificate of native HTTP admission.\n    ';name:str;value:str
	def __post_init__(self)->None:
		if not isinstance(self.name,str)or not isinstance(self.value,str):raise TypeError('header name and value must be str')
	@classmethod
	def _from_native(cls,name:str,value:str)->Header:'Adopt decoded header text already validated by inbound Core I/O.';header=object.__new__(cls);object.__setattr__(header,'name',name);object.__setattr__(header,'value',value);return header
class _HeadersProjectionOwner:'Lazy private header view, excluded from dataclass value/copy fields.';__slots__='_native_headers',;_native_headers:object
def _header_index(entries:tuple[Header,...])->Mapping[str,tuple[str,...]]:
	'Build a complete read-only index before any owner can observe it.';index:dict[str,list[str]]={}
	for entry in entries:index.setdefault(entry.name.casefold(),[]).append(entry.value)
	return MappingProxyType({name:tuple(items)for(name,items)in index.items()})
@dataclass(frozen=True,slots=True,init=False,eq=False)
class Headers(_HeadersProjectionOwner):
	'Immutable ordered headers with average O(1) indexed name lookup.\n\n    Core-origin headers build their bounded index on first name lookup; that\n    first lookup costs O(n) for n fields. Iteration preserves wire order and\n    never builds the index. Caller-created collections validate/index eagerly.\n    ';_entries:tuple[Header,...];_index:Mapping[str,tuple[str,...]]|None
	def __init__(self,entries:Iterable[Header]=())->None:
		'Validate entries and build the immutable case-folded lookup index.';values=tuple(islice(entries,_MAX_HEADER_COUNT+1))
		if len(values)>_MAX_HEADER_COUNT:raise ValueError('header count exceeds the native bound')
		if any(not isinstance(entry,Header)for entry in values):raise TypeError('headers must contain Header values')
		object.__setattr__(self,'_entries',values);object.__setattr__(self,'_index',_header_index(values))
	@classmethod
	def _from_native(cls,entries:tuple[Header,...])->Headers:'Adopt privately owned, bounded, decoded Core fields without rescans.';value=object.__new__(cls);object.__setattr__(value,'_entries',entries);object.__setattr__(value,'_index',None);return value
	def _lookup(self)->Mapping[str,tuple[str,...]]:
		'Publish only a complete immutable index; failed builds are retryable.';index=self._index
		if index is None:index=_header_index(self._entries);object.__setattr__(self,'_index',index)
		return index
	def __len__(self)->int:'Return the number of fields, including duplicates.';return len(self._entries)
	def __iter__(self)->Iterator[Header]:'Iterate fields in their original wire or declaration order.';return iter(self._entries)
	def __getitem__(self,name:str)->str:
		'Return the first case-insensitive value for ``name``.';index=self._index
		if index is None:index=self._lookup()
		values=index.get(name.casefold())
		if not values:raise KeyError(name)
		return values[0]
	def get(self,name:str,default:str|None=None)->str|None:
		'Return the first value or ``default`` when the name is absent.';index=self._index
		if index is None:index=self._lookup()
		values=index.get(name.casefold());return values[0]if values else default
	def get_all(self,name:str)->tuple[str,...]:
		'Return all case-insensitive matches in original order.';index=self._index
		if index is None:index=self._lookup()
		return index.get(name.casefold(),())
_EMPTY_HEADERS:Final=Headers()
@dataclass(frozen=True,slots=True)
class ExchangeId:'Generation-checked inbound exchange handle.';slot:int;generation:int
@dataclass(frozen=True,slots=True)
class WebSocketId:'Generation-checked WebSocket session handle.';slot:int;generation:int
@dataclass(frozen=True,slots=True)
class OutboundId:'Generation-checked outbound call handle.';slot:int;generation:int
@dataclass(frozen=True,slots=True)
class Listener:'Native-owned listener and optional file-backed TLS identity.';bind_address:str='127.0.0.1';port:int=0;protocol:ListenerProtocol=ListenerProtocol.HTTP_1_1;security:TransportSecurity=TransportSecurity.PLAINTEXT;credential_generation:int=0;credential_id:str='';certificate_chain_file:str='';private_key_file:str='';trust_roots_file:str=''
@dataclass(frozen=True,slots=True)
class BodyPolicy:'Optional route body-admission policy enforced natively.';enabled:bool=False;accept_absent:bool=False;accept_other:bool=False;accept_form_urlencoded:bool=False;accept_multipart_form_data:bool=False;max_body_bytes:int=0
@dataclass(frozen=True,slots=True)
class Route:'Construction-copied route and application binding identity.';id:int;method:str;pattern:str;handler_binding_id:int=0;body_delivery:BodyDelivery=BodyDelivery.INLINE;body_policy:BodyPolicy=field(default_factory=BodyPolicy);websocket:bool=False
@dataclass(frozen=True,slots=True)
class Limits:'Finite native resource ceilings; zero selects a bounded default.';max_routes:int=0;max_total_route_segments:int=0;max_route_bytes:int=0;max_captures_per_route:int=0;activation_history_capacity:int=0;max_connections:int=0;max_active_requests:int=0;request_queue_capacity:int=0;completion_queue_capacity:int=0;completion_batch_size:int=0;max_header_count:int=0;max_header_bytes:int=0;request_stream_chunk_slots:int=0;request_stream_max_retained_items:int=0;response_stream_chunk_slots:int=0;response_stream_max_retained_items:int=0;route_control_capacity:int=0;route_control_history_capacity:int=0;route_control_max_commands_per_turn:int=0;terminal_queue_capacity:int=0;deadline_tick_ms:int=0;connection_timeout_batch_size:int=0;request_notification_profile:NotificationProfile|int=NotificationProfile.AUTO;terminal_notification_profile:NotificationProfile|int=NotificationProfile.AUTO;event_loop_cpu_mask:int=0;max_request_body_bytes:int=0;max_response_body_bytes:int=0;keep_alive_timeout_ms:int=0;header_timeout_ms:int=0;body_timeout_ms:int=0;handler_timeout_ms:int=0;idle_timeout_ms:int=0;drain_timeout_ms:int=0;stop_timeout_ms:int=0;response_write_timeout_ms:int=0;request_stream_max_chunk_bytes:int=0;request_stream_max_trailer_bytes:int=0;request_stream_max_retained_bytes:int=0;request_stream_max_total_retained_bytes:int=0;response_stream_max_chunk_bytes:int=0;response_stream_max_trailer_bytes:int=0;response_stream_max_retained_bytes:int=0;response_stream_max_total_retained_bytes:int=0
@dataclass(frozen=True,slots=True)
class StaticMount:'Trusted static tree with optional index and SPA fallback.';url_prefix:str;root_path:str;index_file:str='';cache_control:str='';spa_fallback_file:str='';include_dotfiles:bool=False
@dataclass(frozen=True,slots=True)
class FileAuthority:'Approved root for application-selected file responses.';authority_id:int;root_path:str;max_file_bytes:int=0;max_active_files:int=0
@dataclass(frozen=True,slots=True)
class Compression:'Bounded response-compression policy.';mode:CompressionMode=CompressionMode.DISABLED;minimum_body_bytes:int=0;maximum_body_bytes:int=0;maximum_encoded_bytes:int=0;workspace_bytes:int=0;gzip_level:int=0
@dataclass(frozen=True,slots=True)
class OutboundEndpoint:'One copied endpoint for a logical outbound target.';node_id:str;connect_host:str;connect_port:int;http_authority:str;weight:int=1;security:TransportSecurity=TransportSecurity.PLAINTEXT;available:bool=True;tls_peer_identity:str='';tls_trust_generation:int=0;tls_client_identity_generation:int=0
@dataclass(frozen=True,slots=True)
class OutboundTarget:'Logical target with one immutable endpoint generation.';name:str;generation:int;endpoints:tuple[OutboundEndpoint,...];strategy:OutboundStrategy=OutboundStrategy.SINGLE_OWNER
@dataclass(frozen=True,slots=True)
class OutboundTrust:'Generation-keyed outbound CA material.';generation:int;ca_pem:bytes
@dataclass(frozen=True,slots=True)
class OutboundIdentity:'Generation-keyed outbound mutual-TLS identity.';generation:int;certificate_chain_pem:bytes;private_key_pem:bytes
@dataclass(frozen=True,slots=True)
class MonitorOptions:'Construction-time monitoring reservation and initial policy.';collection:MonitorCollection=MonitorCollection.DISABLED;event_capacity:int=0;max_events_per_read:int=0;categories:MonitorCategory=MonitorCategory(0);signal_reserved:bool=False;fixed_latency_buckets:bool=False
@dataclass(frozen=True,slots=True)
class RuntimeConfig:'Complete copied declaration for one runtime instance.';listener:Listener=field(default_factory=Listener);routes:tuple[Route,...]=();limits:Limits=field(default_factory=Limits);static_mounts:tuple[StaticMount,...]=();max_total_static_assets:int=0;file_authorities:tuple[FileAuthority,...]=();compression:Compression=field(default_factory=Compression);io_backend:IoBackend=IoBackend.PLATFORM_DEFAULT;monitor:MonitorOptions=field(default_factory=MonitorOptions);outbound_targets:tuple[OutboundTarget,...]=();outbound_trusts:tuple[OutboundTrust,...]=();outbound_identities:tuple[OutboundIdentity,...]=();reserve_websocket:bool=False;omit_buffered_success_events:bool=False
@dataclass(frozen=True,slots=True)
class PathParameter:'Route capture name and still-encoded value.';name:str;encoded_value:str
@dataclass(frozen=True,slots=True)
class QueryParameter:'Ordered encoded query item preserving absent versus empty.';encoded_key:str;encoded_value:str;has_value:bool
@dataclass(frozen=True,slots=True)
class Request:
	'Python-owned copy of one inbound request event.';exchange:ExchangeId;method:str;scheme:str;authority:str;target:str;headers:Headers;body:bytes;body_delivery:BodyDelivery;route_id:int;route_generation:int;binding_revision:int;handler_binding_id:int;path_parameters:tuple[PathParameter,...];query_parameters:tuple[QueryParameter,...];trailers:Headers;cancelled:bool=False;body_reader:io.BufferedIOBase|io.RawIOBase=field(init=False,repr=False,compare=False)
	def __post_init__(self)->None:object.__setattr__(self,'body_reader',io.BytesIO(self.body))
	def text(self,encoding:str='utf-8')->str:'Decode the copied body using strict error handling.';return self.body.decode(encoding,errors='strict')
	def _attach_body_reader(self,reader:io.BufferedIOBase|io.RawIOBase)->None:
		if self.body_delivery is not BodyDelivery.STREAM:raise RuntimeError('request does not use streamed body delivery')
		object.__setattr__(self,'body_reader',reader)
	def _set_stream_trailers(self,trailers:Headers)->None:object.__setattr__(self,'trailers',trailers)
@dataclass(frozen=True,slots=True)
class Event:'Copied event; data holds only REQUEST_DATA chunks, never private storage.\n\n    REQUEST carries its typed request; trailers carry typed headers. All values\n    outlive the native lease without retaining an extra raw event copy.\n    ';kind:EventKind;exchange:ExchangeId;sequence:int;handler_binding_id:int;data:bytes=b'';request:Request|None=None;stream_trailers:Headers=_EMPTY_HEADERS
class _ResponseProjectionOwner:'Private memo storage, excluded from dataclass value/copy semantics.\n\n    A projection belongs to its immutable response, never to a global cache or\n    exchange. The slot is absent until first submission. Dataclass copies start\n    without it, so native pointer owners never become serialized value fields.\n    ';__slots__='_native_projection',;_native_projection:object
@dataclass(frozen=True,slots=True)
class Response(_ResponseProjectionOwner):
	'Buffered response copied synchronously by Core on every submission.\n\n    Reusing an immutable value also reuses its private boundary projection;\n    this does not cache HTTP outcomes or borrow data after the native call.\n    ';status:int=200;headers:Headers=_EMPTY_HEADERS;body:bytes=b''
	@classmethod
	def text(cls,body:str,*,status:int=200,headers:Headers|Iterable[Header]=())->Response:
		'Create a UTF-8 response with a default content type.';values=headers if isinstance(headers,Headers)else Headers(headers)
		if values.get('content-type')is None:values=Headers((*values,Header('content-type','text/plain; charset=utf-8')))
		return cls(status=status,headers=values,body=body.encode())
@dataclass(frozen=True,slots=True)
class FileResponse:'Application-selected file under a configured authority.';authority_id:int;encoded_path:str;status:int=200;headers:Headers=_EMPTY_HEADERS
@dataclass(frozen=True,slots=True)
class SseEvent:'One typed server-sent event write.';data:bytes;event_type:bytes|None=None;id:bytes|None=None;retry_ms:int|None=None
@dataclass(frozen=True,slots=True)
class Failure:'Typed failure reason and bounded operator-facing detail.';reason:int;detail:bytes=b''
@dataclass(frozen=True,slots=True)
class WebSocketEvent:'Python-owned copy of one WebSocket event.';kind:WebSocketEventKind;session:WebSocketId;origin_exchange:ExchangeId;close_code:int;data:bytes
@dataclass(frozen=True,slots=True)
class OutboundRequest:'Copied logical-target outbound HTTP request.';logical_target:str;method:str;target:str;headers:Headers=_EMPTY_HEADERS;body:bytes=b'';timeout_ms:int=30000
@dataclass(frozen=True,slots=True)
class OutboundTerminal:'Python-owned copy of one outbound terminal event.';reason:OutboundReason;call:OutboundId;logical_target:str;target_generation:int;selected_node_id:str;phase:OutboundPhase;retry:OutboundRetry;certainty:OutboundCertainty;response_status:int;provider_code:int;response_headers:Headers;response_body:bytes;diagnostic:str
@dataclass(frozen=True,slots=True)
class Activity:'Finite current-work gauges from a health snapshot.';active_requests:int;pending_requests:int;active_connections:int;websocket_sessions:int;outbound_pending:int
@dataclass(frozen=True,slots=True)
class Health:'Pointer-free native health snapshot safe to retain.';lifecycle:int;snapshot_sequence:int;observed_monotonic_ns:int;progress_sequence:int;progress_monotonic_ns:int;acknowledged_probe_sequence:int;acknowledged_probe_monotonic_ns:int;route_generation:int;binding_change_sequence:int;ready:bool;admission_open:bool;activity:Activity
@dataclass(frozen=True,slots=True)
class RouteIdentity:'Coherent route-generation identity.';route_count:int;route_generation:int;binding_change_sequence:int
@dataclass(frozen=True,slots=True)
class RouteState:"One route's effective binding state.";route_id:int;handler_binding_id:int;binding_revision:int
@dataclass(frozen=True,slots=True)
class RouteSnapshot:'One coherent route-table and binding-table cut.';identity:RouteIdentity;routes:tuple[RouteState,...]
@dataclass(frozen=True,slots=True)
class RouteRebind:'Generation-checked handler-binding command.';activation_id:int;expected_route_generation:int;route_id:int;expected_binding_revision:int;new_handler_binding_id:int
@dataclass(frozen=True,slots=True)
class RouteRebindOutcome:'Effective state returned after a handler rebind attempt.';code:ControlCode;activation_id:int;operation_digest:int;route_generation:int;binding_change_sequence:int;route_id:int;previous_handler_binding_id:int;previous_binding_revision:int;effective_handler_binding_id:int;effective_binding_revision:int;changed:bool;replayed:bool;request_retirement:RequestRetirement
@dataclass(frozen=True,slots=True)
class RoutePublication:'Complete structural route replacement; never a delta.';activation_id:int;expected_route_generation:int;expected_binding_change_sequence:int;routes:tuple[Route,...]
@dataclass(frozen=True,slots=True)
class RoutePublicationOutcome:'Effective state returned after structural publication.';code:ControlCode;activation_id:int;operation_digest:int;previous_route_generation:int;previous_binding_change_sequence:int;effective_route_generation:int;effective_binding_change_sequence:int;route_count:int;rejected_route_index:int;changed:bool;replayed:bool;request_retirement:RequestRetirement
@dataclass(frozen=True,slots=True)
class MonitorPolicy:'Live monitor policy constrained by startup reservations.';collection:MonitorCollection;notification:MonitorNotification=MonitorNotification.POLL;latency:MonitorLatency=MonitorLatency.NONE;active_event_capacity:int=0;aggregate_categories:MonitorCategory=MonitorCategory(0);event_categories:MonitorCategory=MonitorCategory(0)
@dataclass(frozen=True,slots=True)
class MonitorConfig:'Effective pointer-free monitor configuration.';generation:int;collection_epoch:int;change_sequence:int;epoch_started_monotonic_ns:int;policy_applied_monotonic_ns:int;supported_categories:MonitorCategory;reserved_event_capacity:int;max_events_per_read:int;signal_reserved:bool;fixed_latency_buckets:bool;policy:MonitorPolicy
@dataclass(frozen=True,slots=True)
class MonitorApplyOutcome:'Applied or typed-rejected monitor policy result.';reason:MonitorApplyReason;actual:int;limit:int;changed:bool;effective:MonitorConfig
@dataclass(frozen=True,slots=True)
class MonitorFailureCount:'Count for one stable native failure reason.';reason:int;count:int
@dataclass(frozen=True,slots=True)
class MonitorLatencyBucket:'Fixed upper-bound latency bucket and count.';upper_bound_ns:int;count:int
@dataclass(frozen=True,slots=True)
class MonitorSnapshot:'Bounded aggregate and health snapshot.';collecting:bool;stale:bool;partial:bool;snapshot_sequence:int;observed_monotonic_ns:int;collected_change_sequence:int;admitted_requests:int;request_bytes:int;exchange_completed:int;exchange_failed:int;exchange_timed_out:int;exchange_disconnected:int;exchange_cancelled:int;response_status_family:tuple[int,int,int,int,int];retained_events:int;overwritten_events:int;dropped_events:int;signal_notifications:int;coalesced_signals:int;signal_failures:int;config:MonitorConfig;health:Health;failure_counts:tuple[MonitorFailureCount,...];latency_buckets:tuple[MonitorLatencyBucket,...]
@dataclass(frozen=True,slots=True)
class MonitorEvent:'One copied payload-free operational event.';kind:MonitorEventKind;sequence:int;change_sequence:int;config_generation:int;collection_epoch:int;observed_monotonic_ns:int;category:MonitorCategory;failure_reason:int;queue_scope:int;queue_depth:int;queue_capacity:int;exchange:ExchangeId
@dataclass(frozen=True,slots=True)
class MonitorEventPage:'Bounded monitor page plus loss and continuation metadata.';events:tuple[MonitorEvent,...];oldest_available_sequence:int;latest_sequence:int;overwritten_events:int;remaining_events:int
