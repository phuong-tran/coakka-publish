"""Private, exhaustive ``ctypes`` projection of the public Core ABI."""

from __future__ import annotations

import ctypes
import hashlib
import importlib.resources
import json
import os
import platform
import stat
import sys
import sysconfig
from pathlib import Path
from typing import Final

ABI_VERSION: Final = 2
RESULT_OK: Final = 0
RESULT_INVALID_ARGUMENT: Final = 1
RESULT_INVALID_STATE: Final = 2
RESULT_LIMIT_EXCEEDED: Final = 3
RESULT_QUEUE_FULL: Final = 4
RESULT_TIMEOUT: Final = 5
RESULT_CLOSED: Final = 6
RESULT_CANCELLED: Final = 7
RESULT_OUT_OF_MEMORY: Final = 8
RESULT_UNSUPPORTED: Final = 9
RESULT_SYSTEM_ERROR: Final = 10
RESULT_INTERNAL: Final = 11
RESULT_NOT_FOUND: Final = 12
RESULT_UNAVAILABLE: Final = 13

TERMINAL_DETAIL_CAPACITY: Final = 1024
MONITOR_FAILURE_COUNTS: Final = 48
MONITOR_LATENCY_BUCKETS: Final = 16
MONITOR_EVENT_DETAIL_BYTES: Final = 128
MONITOR_EVENTS_PER_READ: Final = 64
MAX_NATIVE_LIBRARY_BYTES: Final = 64 << 20


class CoreError(RuntimeError):
    """A stable native Core failure with optional resource-bound evidence."""

    def __init__(self, code: int, message: str, actual: int, limit: int) -> None:
        """Retain the native result code, detail, actual value, and limit."""
        super().__init__(message)
        self.code = code
        self.actual = actual
        self.limit = limit


class _Result(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("code", ctypes.c_uint32),
        ("actual", ctypes.c_uint64),
        ("limit", ctypes.c_uint64),
        ("detail", ctypes.c_char * 192),
    ]


class _Bytes(ctypes.Structure):
    _fields_ = [
        ("data", ctypes.POINTER(ctypes.c_uint8)),
        ("size", ctypes.c_uint64),
    ]


class _Header(ctypes.Structure):
    _fields_ = [("name", _Bytes), ("value", _Bytes)]


class _Response(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("status_code", ctypes.c_uint32),
        ("headers", ctypes.POINTER(_Header)),
        ("header_count", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("body", _Bytes),
    ]


class _ExchangeId(ctypes.Structure):
    _fields_ = [("slot", ctypes.c_uint64), ("generation", ctypes.c_uint64)]


class _WebSocketId(ctypes.Structure):
    _fields_ = [("slot", ctypes.c_uint64), ("generation", ctypes.c_uint64)]


class _OutboundId(ctypes.Structure):
    _fields_ = [("slot", ctypes.c_uint64), ("generation", ctypes.c_uint64)]


class _Listener(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("protocol", ctypes.c_uint32),
        ("listener_id", ctypes.c_uint64),
        ("bind_address", _Bytes),
        ("port", ctypes.c_uint16),
        ("reserved0", ctypes.c_uint16),
        ("security", ctypes.c_uint32),
        ("reserved1", ctypes.c_uint32),
        ("credential_generation", ctypes.c_uint64),
        ("credential_id", _Bytes),
        ("certificate_chain_file", _Bytes),
        ("private_key_file", _Bytes),
        ("trust_roots_file", _Bytes),
    ]


class _BodyPolicy(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("enabled", ctypes.c_uint8),
        ("accept_absent", ctypes.c_uint8),
        ("accept_other", ctypes.c_uint8),
        ("accept_form_urlencoded", ctypes.c_uint8),
        ("accept_multipart_form_data", ctypes.c_uint8),
        ("reserved0", ctypes.c_uint8 * 3),
        ("max_body_bytes", ctypes.c_uint64),
    ]


class _CoreRoute(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("body_delivery", ctypes.c_uint32),
        ("route_id", ctypes.c_uint64),
        ("request_capture_profile_id", ctypes.c_uint64),
        ("handler_binding_id", ctypes.c_uint64),
        ("method", _Bytes),
        ("path", _Bytes),
        ("body_policy", _BodyPolicy),
    ]


_CORE_LIMIT_U32_FIELDS = (
    "event_loop_threads",
    "max_listeners",
    "max_connections",
    "max_active_exchanges",
    "request_queue_depth",
    "completion_queue_depth",
    "completion_batch_size",
    "max_header_count",
    "max_header_bytes",
    "max_routes",
    "max_route_segments",
    "max_captures_per_route",
    "request_stream_chunk_slots",
    "request_stream_max_retained_items",
    "response_stream_chunk_slots",
    "response_stream_max_retained_items",
    "max_static_mounts",
    "max_total_static_files",
    "max_file_authorities",
    "route_rebind_command_capacity",
    "route_rebind_history_capacity",
    "route_rebind_max_commands_per_turn",
    "terminal_observation_queue_depth",
    "deadline_tick_ms",
    "connection_timeout_batch_size",
)
_CORE_LIMIT_U64_FIELDS = (
    "max_request_body_bytes",
    "max_response_body_bytes",
    "max_serialized_request_bytes",
    "max_serialized_response_bytes",
    "max_total_request_body_bytes",
    "max_total_response_body_bytes",
    "max_total_serialized_request_bytes",
    "max_total_serialized_response_bytes",
    "keep_alive_timeout_ms",
    "header_timeout_ms",
    "body_timeout_ms",
    "app_host_timeout_ms",
    "idle_timeout_ms",
    "drain_timeout_ms",
    "stop_timeout_ms",
    "response_write_timeout_ms",
    "request_stream_max_chunk_bytes",
    "request_stream_max_trailer_bytes",
    "request_stream_max_retained_bytes",
    "request_stream_max_total_retained_bytes",
    "response_stream_max_chunk_bytes",
    "response_stream_max_trailer_bytes",
    "response_stream_max_retained_bytes",
    "response_stream_max_total_retained_bytes",
    "max_route_manifest_bytes",
    "max_total_route_metadata_bytes",
    "max_serialized_terminal_observation_bytes",
    "max_total_serialized_terminal_observation_bytes",
)


class _CoreLimits(ctypes.Structure):
    _fields_ = (
        [("struct_size", ctypes.c_uint32)]
        + [(name, ctypes.c_uint32) for name in _CORE_LIMIT_U32_FIELDS]
        + [(name, ctypes.c_uint64) for name in _CORE_LIMIT_U64_FIELDS]
    )


class _StaticMount(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("mount_id", ctypes.c_uint64),
        ("url_prefix", _Bytes),
        ("root_path", _Bytes),
        ("index_file", _Bytes),
        ("cache_control", _Bytes),
        ("spa_fallback_file", _Bytes),
        ("include_dotfiles", ctypes.c_uint8),
        ("has_index_file", ctypes.c_uint8),
        ("has_cache_control", ctypes.c_uint8),
        ("has_spa_fallback_file", ctypes.c_uint8),
    ]


class _FileAuthority(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("max_active_files", ctypes.c_uint32),
        ("authority_id", ctypes.c_uint64),
        ("root_path", _Bytes),
        ("max_file_bytes", ctypes.c_uint64),
    ]


class _Compression(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("mode", ctypes.c_uint32),
        ("minimum_body_bytes", ctypes.c_uint64),
        ("maximum_body_bytes", ctypes.c_uint64),
        ("maximum_encoded_bytes", ctypes.c_uint64),
        ("workspace_bytes", ctypes.c_uint64),
        ("gzip_level", ctypes.c_int32),
        ("reserved0", ctypes.c_uint32),
    ]


class _WaitPolicy(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("mode", ctypes.c_uint32),
        ("spin_iterations", ctypes.c_uint32),
        ("yield_iterations", ctypes.c_uint32),
    ]


class _OutboundLaneLimits(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("call_capacity", ctypes.c_uint32),
        ("target_profile_capacity", ctypes.c_uint32),
        ("work_batch", ctypes.c_uint32),
        ("max_method_bytes", ctypes.c_uint32),
        ("max_origin_target_bytes", ctypes.c_uint32),
        ("max_profile_component_bytes", ctypes.c_uint32),
        ("max_total_profile_bytes", ctypes.c_uint64),
        ("max_header_count", ctypes.c_uint32),
        ("max_header_name_bytes", ctypes.c_uint32),
        ("max_header_value_bytes", ctypes.c_uint32),
        ("max_header_bytes", ctypes.c_uint32),
        ("max_request_body_bytes", ctypes.c_uint64),
        ("max_total_request_bytes", ctypes.c_uint64),
        ("max_response_head_bytes", ctypes.c_uint64),
        ("max_response_body_bytes", ctypes.c_uint64),
        ("max_total_response_bytes", ctypes.c_uint64),
        ("deadline_tick_ms", ctypes.c_uint32),
        ("stop_timeout_ms", ctypes.c_uint32),
    ]


class _OutboundTransportLimits(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("active_call_capacity", ctypes.c_uint32),
        ("max_response_header_count", ctypes.c_uint32),
        ("max_response_header_name_bytes", ctypes.c_uint32),
        ("max_response_header_value_bytes", ctypes.c_uint32),
        ("max_response_head_bytes", ctypes.c_uint64),
        ("max_response_body_bytes", ctypes.c_uint64),
        ("max_total_buffer_bytes", ctypes.c_uint64),
        ("max_serialized_url_bytes", ctypes.c_uint32),
        ("max_resolve_entry_bytes", ctypes.c_uint32),
    ]


class _OutboundResolver(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("max_resolved_addresses", ctypes.c_uint32),
        ("server_endpoint", _Bytes),
        ("socket_capacity", ctypes.c_uint32),
        ("timeout_ms", ctypes.c_uint32),
        ("tries", ctypes.c_uint32),
    ]


class _OutboundPoolLimits(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("key_capacity", ctypes.c_uint32),
        ("max_connections_per_key", ctypes.c_uint32),
        ("max_waiting_per_key", ctypes.c_uint32),
        ("max_idle_seconds", ctypes.c_uint32),
        ("max_lifetime_seconds", ctypes.c_uint32),
    ]


class _OutboundTlsLimits(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("trust_capacity", ctypes.c_uint32),
        ("client_identity_capacity", ctypes.c_uint32),
        ("max_trust_bundle_bytes", ctypes.c_uint64),
        ("max_client_certificate_bytes", ctypes.c_uint64),
        ("max_client_private_key_bytes", ctypes.c_uint64),
        ("max_total_bytes", ctypes.c_uint64),
    ]


class _OutboundRegistryLimits(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("target_capacity", ctypes.c_uint32),
        ("endpoint_capacity", ctypes.c_uint32),
        ("max_endpoints_per_target", ctypes.c_uint32),
        ("max_target_name_bytes", ctypes.c_uint32),
        ("max_node_id_bytes", ctypes.c_uint32),
        ("max_total_bytes", ctypes.c_uint64),
    ]


class _OutboundOptions(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("resolver_enabled", ctypes.c_uint8),
        ("pool_enabled", ctypes.c_uint8),
        ("reserved0", ctypes.c_uint8 * 2),
        ("lane", _OutboundLaneLimits),
        ("transport", _OutboundTransportLimits),
        ("resolver", _OutboundResolver),
        ("pool", _OutboundPoolLimits),
        ("tls", _OutboundTlsLimits),
        ("registry", _OutboundRegistryLimits),
    ]


class _InspectionOptions(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("allow_plaintext_loopback", ctypes.c_uint8),
        ("reserved0", ctypes.c_uint8 * 3),
        ("runtime_instance_id", ctypes.c_uint64),
        ("runtime_generation", ctypes.c_uint64),
        ("bearer_file", _Bytes),
        ("max_bearer_token_bytes", ctypes.c_uint32),
        ("call_capacity", ctypes.c_uint32),
        ("max_entries_per_turn", ctypes.c_uint32),
        ("snapshot_deadline_ms", ctypes.c_uint32),
        ("max_bytes_per_turn", ctypes.c_uint64),
        ("max_response_bytes", ctypes.c_uint64),
        ("max_total_response_bytes", ctypes.c_uint64),
    ]


class _OutboundEndpoint(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("weight", ctypes.c_uint32),
        ("node_id", _Bytes),
        ("connect_host", _Bytes),
        ("connect_port", ctypes.c_uint16),
        ("reserved0", ctypes.c_uint16),
        ("http_authority", _Bytes),
        ("security", ctypes.c_uint32),
        ("available", ctypes.c_uint32),
        ("tls_peer_identity", _Bytes),
        ("proxy_mode", ctypes.c_uint32),
        ("protocol_policy", ctypes.c_uint32),
        ("connection_strategy", ctypes.c_uint32),
        ("reserved1", ctypes.c_uint32),
        ("proxy_identity", _Bytes),
        ("tls_trust_generation", ctypes.c_uint64),
        ("tls_client_identity_generation", ctypes.c_uint64),
        ("connection_strategy_generation", ctypes.c_uint64),
        ("local_network_policy_id", ctypes.c_uint64),
    ]


class _OutboundTarget(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("strategy", ctypes.c_uint32),
        ("name", _Bytes),
        ("generation", ctypes.c_uint64),
        ("endpoints", ctypes.POINTER(_OutboundEndpoint)),
        ("endpoint_count", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
    ]


class _MonitorOptions(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("collection", ctypes.c_uint32),
        ("event_capacity", ctypes.c_uint32),
        ("max_events_per_read", ctypes.c_uint32),
        ("detail_bytes_per_event", ctypes.c_uint32),
        ("latency_bucket_count", ctypes.c_uint32),
        ("aggregate_categories", ctypes.c_uint64),
        ("event_categories", ctypes.c_uint64),
        ("signal_reserved", ctypes.c_uint8),
        ("runtime_safe_detail", ctypes.c_uint8),
        ("fixed_latency_buckets", ctypes.c_uint8),
        ("reserved0", ctypes.c_uint8),
    ]


class _Event(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("kind", ctypes.c_uint32),
        ("exchange", _ExchangeId),
        ("sequence", ctypes.c_uint64),
        ("handler_binding_id", ctypes.c_uint64),
        ("data", ctypes.POINTER(ctypes.c_uint8)),
        ("data_size", ctypes.c_uint64),
        ("private_lease", ctypes.c_uint64),
        ("private_owner", ctypes.c_void_p),
        ("private_state", ctypes.c_void_p),
        ("private_layout_version", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
    ]


class _TerminalSummary(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("outcome", ctypes.c_uint32),
        ("response_status", ctypes.c_uint32),
        ("failure_domain", ctypes.c_uint32),
        ("failure_phase", ctypes.c_uint32),
        ("failure_reason", ctypes.c_uint32),
        ("retry_disposition", ctypes.c_uint32),
        ("http_status_hint", ctypes.c_uint32),
        ("has_response", ctypes.c_uint8),
        ("has_failure", ctypes.c_uint8),
        ("has_http_status_hint", ctypes.c_uint8),
        ("detail_truncated", ctypes.c_uint8),
        ("has_admitted_time", ctypes.c_uint8),
        ("has_dispatched_time", ctypes.c_uint8),
        ("has_response_accepted_time", ctypes.c_uint8),
        ("has_completed_time", ctypes.c_uint8),
        ("admitted_monotonic_ns", ctypes.c_uint64),
        ("dispatched_monotonic_ns", ctypes.c_uint64),
        ("response_accepted_monotonic_ns", ctypes.c_uint64),
        ("completed_monotonic_ns", ctypes.c_uint64),
        ("detail_size", ctypes.c_uint64),
        ("stored_detail_size", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("detail", ctypes.c_char * TERMINAL_DETAIL_CAPACITY),
    ]


class _PathParameter(ctypes.Structure):
    _fields_ = [("name", _Bytes), ("encoded_value", _Bytes)]


class _QueryParameter(ctypes.Structure):
    _fields_ = [
        ("encoded_key", _Bytes),
        ("encoded_value", _Bytes),
        ("has_value", ctypes.c_uint8),
        ("reserved0", ctypes.c_uint8 * 7),
    ]


class _FileResponse(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("head", _Response),
        ("authority_id", ctypes.c_uint64),
        ("encoded_path", _Bytes),
    ]


class _SseEvent(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("data", _Bytes),
        ("event_type", _Bytes),
        ("id", _Bytes),
        ("retry_ms", ctypes.c_uint64),
        ("has_event_type", ctypes.c_uint8),
        ("has_id", ctypes.c_uint8),
        ("has_retry", ctypes.c_uint8),
        ("reserved1", ctypes.c_uint8 * 5),
    ]


class _Failure(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("reason", ctypes.c_uint32),
        ("detail", _Bytes),
    ]


class _SocketEvent(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("kind", ctypes.c_uint32),
        ("session", _WebSocketId),
        ("origin_exchange", _ExchangeId),
        ("close_code", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("data", ctypes.POINTER(ctypes.c_uint8)),
        ("data_size", ctypes.c_uint64),
        ("private_lease", ctypes.c_uint64),
        ("private_owner", ctypes.c_void_p),
    ]


class _ClientRequest(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("timeout_ms", ctypes.c_uint32),
        ("logical_target", _Bytes),
        ("method", _Bytes),
        ("target", _Bytes),
        ("headers", ctypes.POINTER(_Header)),
        ("header_count", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("body", _Bytes),
    ]


class _ClientTerminal(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("reason", ctypes.c_uint32),
        ("call", _OutboundId),
        ("logical_target", _Bytes),
        ("target_generation", ctypes.c_uint64),
        ("selected_node_id", _Bytes),
        ("phase", ctypes.c_uint32),
        ("retry", ctypes.c_uint32),
        ("certainty", ctypes.c_uint32),
        ("response_status", ctypes.c_uint16),
        ("reserved0", ctypes.c_uint16),
        ("provider_code", ctypes.c_int32),
        ("response_header_count", ctypes.c_uint32),
        ("response_body", _Bytes),
        ("diagnostic", _Bytes),
        ("private_lease", ctypes.c_uint64),
        ("private_owner", ctypes.c_void_p),
    ]


class _Health(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("lifecycle", ctypes.c_uint32),
        ("snapshot_sequence", ctypes.c_uint64),
        ("change_sequence", ctypes.c_uint64),
        ("lifecycle_generation", ctypes.c_uint64),
        ("observed_monotonic_ns", ctypes.c_uint64),
        ("progress_sequence", ctypes.c_uint64),
        ("progress_monotonic_ns", ctypes.c_uint64),
        ("acknowledged_probe_sequence", ctypes.c_uint64),
        ("acknowledged_probe_monotonic_ns", ctypes.c_uint64),
        ("configured_components", ctypes.c_uint32),
        ("running_components", ctypes.c_uint32),
        ("failed_components", ctypes.c_uint32),
        ("startup", ctypes.c_uint32),
        ("liveness", ctypes.c_uint32),
        ("readiness", ctypes.c_uint32),
        ("admission_open", ctypes.c_uint8),
        ("partial", ctypes.c_uint8),
        ("reserved0", ctypes.c_uint8 * 6),
        ("server_active_exchanges", ctypes.c_uint32),
        ("client_active_calls", ctypes.c_uint32),
        ("client_ready_terminals", ctypes.c_uint32),
        ("client_outstanding_terminal_leases", ctypes.c_uint32),
        ("client_retained_request_bytes", ctypes.c_uint64),
        ("client_retained_target_profile_bytes", ctypes.c_uint64),
        ("client_retained_response_bytes", ctypes.c_uint64),
        ("client_admitted_calls", ctypes.c_uint64),
        ("client_terminal_calls", ctypes.c_uint64),
        ("client_stale_provider_terminals", ctypes.c_uint64),
    ]


class _MonitorPolicy(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("collection", ctypes.c_uint32),
        ("notification", ctypes.c_uint32),
        ("latency", ctypes.c_uint32),
        ("detail", ctypes.c_uint32),
        ("active_event_capacity", ctypes.c_uint32),
        ("active_detail_bytes", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("aggregate_categories", ctypes.c_uint64),
        ("event_categories", ctypes.c_uint64),
    ]


class _MonitorConfig(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("provenance", ctypes.c_uint32),
        ("generation", ctypes.c_uint64),
        ("collection_epoch", ctypes.c_uint64),
        ("change_sequence", ctypes.c_uint64),
        ("epoch_started_monotonic_ns", ctypes.c_uint64),
        ("policy_applied_monotonic_ns", ctypes.c_uint64),
        ("supported_categories", ctypes.c_uint64),
        ("reserved_event_capacity", ctypes.c_uint32),
        ("max_events_per_read", ctypes.c_uint32),
        ("reserved_detail_bytes_per_event", ctypes.c_uint32),
        ("reserved_latency_bucket_count", ctypes.c_uint32),
        ("signal_reserved", ctypes.c_uint8),
        ("reserved0", ctypes.c_uint8 * 7),
        ("policy", _MonitorPolicy),
    ]


class _MonitorApplyOutcome(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("reason", ctypes.c_uint32),
        ("actual", ctypes.c_uint64),
        ("limit", ctypes.c_uint64),
        ("changed", ctypes.c_uint8),
        ("reserved0", ctypes.c_uint8 * 7),
        ("effective", _MonitorConfig),
    ]


class _MonitorFailureCount(ctypes.Structure):
    _fields_ = [
        ("reason", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("count", ctypes.c_uint64),
    ]


class _MonitorLatencyBucket(ctypes.Structure):
    _fields_ = [("upper_bound_ns", ctypes.c_uint64), ("count", ctypes.c_uint64)]


class _MonitorSnapshot(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("failure_count", ctypes.c_uint32),
        ("latency_bucket_count", ctypes.c_uint32),
        ("collecting", ctypes.c_uint8),
        ("stale", ctypes.c_uint8),
        ("partial", ctypes.c_uint8),
        ("reserved0", ctypes.c_uint8),
        ("snapshot_sequence", ctypes.c_uint64),
        ("observed_monotonic_ns", ctypes.c_uint64),
        ("collected_change_sequence", ctypes.c_uint64),
        ("inbound_admitted_requests", ctypes.c_uint64),
        ("inbound_request_bytes", ctypes.c_uint64),
        ("exchange_completed", ctypes.c_uint64),
        ("exchange_failed", ctypes.c_uint64),
        ("exchange_timed_out", ctypes.c_uint64),
        ("exchange_disconnected", ctypes.c_uint64),
        ("exchange_cancelled", ctypes.c_uint64),
        ("response_status_family", ctypes.c_uint64 * 5),
        ("retained_events", ctypes.c_uint64),
        ("event_overwrite_count", ctypes.c_uint64),
        ("event_drop_count", ctypes.c_uint64),
        ("signal_notify_count", ctypes.c_uint64),
        ("signal_coalesced_count", ctypes.c_uint64),
        ("signal_failure_count", ctypes.c_uint64),
        ("config", _MonitorConfig),
        ("health", _Health),
        ("failure_counts", _MonitorFailureCount * MONITOR_FAILURE_COUNTS),
        ("latency_buckets", _MonitorLatencyBucket * MONITOR_LATENCY_BUCKETS),
    ]


class _MonitorEvent(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("kind", ctypes.c_uint32),
        ("sequence", ctypes.c_uint64),
        ("change_sequence", ctypes.c_uint64),
        ("config_generation", ctypes.c_uint64),
        ("collection_epoch", ctypes.c_uint64),
        ("observed_monotonic_ns", ctypes.c_uint64),
        ("category", ctypes.c_uint64),
        ("failure_reason", ctypes.c_uint32),
        ("queue_scope", ctypes.c_uint32),
        ("queue_depth", ctypes.c_uint32),
        ("queue_capacity", ctypes.c_uint32),
        ("exchange", _ExchangeId),
        ("detail_size", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("detail", ctypes.c_char * MONITOR_EVENT_DETAIL_BYTES),
    ]


class _MonitorEventPage(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("count", ctypes.c_uint32),
        ("oldest_available_sequence", ctypes.c_uint64),
        ("latest_sequence", ctypes.c_uint64),
        ("missed_events", ctypes.c_uint64),
        ("remaining_events", ctypes.c_uint64),
    ]


class _RouteRebind(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
        ("activation_id", ctypes.c_uint64),
        ("expected_route_generation", ctypes.c_uint64),
        ("route_id", ctypes.c_uint64),
        ("expected_binding_revision", ctypes.c_uint64),
        ("new_handler_binding_id", ctypes.c_uint64),
    ]


class _RouteRebindOutcome(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("code", ctypes.c_uint32),
        ("activation_id", ctypes.c_uint64),
        ("operation_digest", ctypes.c_uint64),
        ("route_generation", ctypes.c_uint64),
        ("route_id", ctypes.c_uint64),
        ("previous_handler_binding_id", ctypes.c_uint64),
        ("previous_binding_revision", ctypes.c_uint64),
        ("effective_handler_binding_id", ctypes.c_uint64),
        ("effective_binding_revision", ctypes.c_uint64),
        ("binding_change_sequence", ctypes.c_uint64),
        ("retained_previous_exchanges", ctypes.c_uint32),
        ("previous_effective_route_references", ctypes.c_uint32),
        ("changed", ctypes.c_uint8),
        ("replayed", ctypes.c_uint8),
        ("reserved0", ctypes.c_uint8 * 2),
    ]


def _bind(
    library: ctypes.CDLL, name: str, arguments: list[object], result: object
) -> None:
    function = getattr(library, name)
    function.argtypes = arguments
    function.restype = result


class _Library:
    def __init__(self, path: Path) -> None:
        """Load one verified native image and bind the complete ABI2 surface."""
        self.library = ctypes.CDLL(str(path))
        _bind(self.library, "coakka_http_abi_version", [], ctypes.c_uint32)
        if self.library.coakka_http_abi_version() != ABI_VERSION:
            raise RuntimeError("CoAkka HTTP ABI version is incompatible")
        self._bind_all()

    def _bind_all(self) -> None:
        library = self.library
        _bind(library, "coakka_http_abi_version", [], ctypes.c_uint32)
        _bind(library, "coakka_http_features", [], ctypes.c_uint64)
        _bind(
            library, "coakka_http_result_code_name", [ctypes.c_uint32], ctypes.c_char_p
        )
        initializers = {
            "coakka_http_result_init": _Result,
            "coakka_http_response_init": _Response,
            "coakka_http_listener_init": _Listener,
            "coakka_http_body_policy_init": _BodyPolicy,
            "coakka_http_core_route_init": _CoreRoute,
            "coakka_http_core_limits_init": _CoreLimits,
            "coakka_http_static_mount_init": _StaticMount,
            "coakka_http_file_authority_init": _FileAuthority,
            "coakka_http_compression_init": _Compression,
            "coakka_http_wait_policy_init": _WaitPolicy,
            "coakka_http_outbound_options_init": _OutboundOptions,
            "coakka_http_inspection_options_init": _InspectionOptions,
            "coakka_http_outbound_endpoint_init": _OutboundEndpoint,
            "coakka_http_outbound_target_init": _OutboundTarget,
            "coakka_http_monitor_options_init": _MonitorOptions,
            "coakka_http_event_init": _Event,
            "coakka_http_terminal_summary_init": _TerminalSummary,
            "coakka_http_file_response_init": _FileResponse,
            "coakka_http_sse_event_init": _SseEvent,
            "coakka_http_failure_init": _Failure,
            "coakka_http_outbound_request_init": _ClientRequest,
            "coakka_http_outbound_terminal_init": _ClientTerminal,
            "coakka_http_health_init": _Health,
            "coakka_http_monitor_policy_view_init": _MonitorPolicy,
            "coakka_http_monitor_config_view_init": _MonitorConfig,
            "coakka_http_monitor_apply_outcome_init": _MonitorApplyOutcome,
            "coakka_http_monitor_snapshot_view_init": _MonitorSnapshot,
            "coakka_http_monitor_event_view_init": _MonitorEvent,
            "coakka_http_monitor_event_page_init": _MonitorEventPage,
            "coakka_http_route_rebind_init": _RouteRebind,
            "coakka_http_route_rebind_outcome_init": _RouteRebindOutcome,
        }
        for name, value_type in initializers.items():
            _bind(library, name, [ctypes.POINTER(value_type)], None)

        handle = ctypes.c_void_p
        handle_pointer = ctypes.POINTER(handle)
        _bind(library, "coakka_http_configuration_create", [handle_pointer], _Result)
        _bind(library, "coakka_http_configuration_destroy", [handle_pointer], _Result)
        _bind(
            library,
            "coakka_http_configuration_set_limits",
            [handle, ctypes.POINTER(_CoreLimits)],
            _Result,
        )
        for name, value_type in (
            ("coakka_http_configuration_add_listener", _Listener),
            ("coakka_http_configuration_add_route", _CoreRoute),
            ("coakka_http_configuration_add_static_mount", _StaticMount),
            ("coakka_http_configuration_add_file_authority", _FileAuthority),
            ("coakka_http_configuration_set_compression", _Compression),
            ("coakka_http_configuration_set_wait_policy", _WaitPolicy),
            ("coakka_http_configuration_set_monitor", _MonitorOptions),
            ("coakka_http_configuration_set_inspection", _InspectionOptions),
            ("coakka_http_configuration_set_outbound", _OutboundOptions),
            ("coakka_http_configuration_add_outbound_target", _OutboundTarget),
        ):
            _bind(library, name, [handle, ctypes.POINTER(value_type)], _Result)
        _bind(
            library,
            "coakka_http_configuration_set_io_backend",
            [handle, ctypes.c_uint32],
            _Result,
        )
        _bind(library, "coakka_http_configuration_enable_outbound", [handle], _Result)
        _bind(
            library,
            "coakka_http_configuration_add_outbound_trust",
            [handle, ctypes.c_uint64, _Bytes],
            _Result,
        )
        _bind(
            library,
            "coakka_http_configuration_add_outbound_identity",
            [handle, ctypes.c_uint64, _Bytes, _Bytes],
            _Result,
        )

        _bind(library, "coakka_http_core_create", [handle, handle_pointer], _Result)
        for name in (
            "coakka_http_core_start",
            "coakka_http_core_drain",
            "coakka_http_core_stop",
            "coakka_http_core_interrupt",
            "coakka_http_core_monitor_interrupt",
        ):
            _bind(library, name, [handle], _Result)
        _bind(library, "coakka_http_core_destroy", [handle_pointer], _Result)
        _bind(
            library,
            "coakka_http_core_bound_port",
            [handle, ctypes.POINTER(ctypes.c_uint16)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_take_event",
            [handle, ctypes.c_uint64, ctypes.POINTER(_Event)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_release_event",
            [handle, ctypes.POINTER(_Event)],
            _Result,
        )
        for name in (
            "coakka_http_event_request_method",
            "coakka_http_event_request_scheme",
            "coakka_http_event_request_authority",
            "coakka_http_event_request_target",
            "coakka_http_event_request_body",
        ):
            _bind(library, name, [ctypes.POINTER(_Event)], _Bytes)
        for name in (
            "coakka_http_event_request_body_delivery",
            "coakka_http_event_request_header_count",
            "coakka_http_event_request_path_parameter_count",
            "coakka_http_event_request_query_parameter_count",
            "coakka_http_event_request_trailer_count",
            "coakka_http_event_stream_trailer_count",
        ):
            _bind(library, name, [ctypes.POINTER(_Event)], ctypes.c_uint32)
        for name in (
            "coakka_http_event_request_route_id",
            "coakka_http_event_request_route_generation",
            "coakka_http_event_request_binding_revision",
        ):
            _bind(library, name, [ctypes.POINTER(_Event)], ctypes.c_uint64)
        for name in (
            "coakka_http_event_request_header",
            "coakka_http_event_request_trailer",
            "coakka_http_event_stream_trailer",
        ):
            _bind(
                library,
                name,
                [ctypes.POINTER(_Event), ctypes.c_uint32, ctypes.POINTER(_Header)],
                ctypes.c_uint8,
            )
        _bind(
            library,
            "coakka_http_event_request_path_parameter",
            [ctypes.POINTER(_Event), ctypes.c_uint32, ctypes.POINTER(_PathParameter)],
            ctypes.c_uint8,
        )
        _bind(
            library,
            "coakka_http_event_request_query_parameter",
            [ctypes.POINTER(_Event), ctypes.c_uint32, ctypes.POINTER(_QueryParameter)],
            ctypes.c_uint8,
        )
        _bind(
            library,
            "coakka_http_event_terminal_summary",
            [ctypes.POINTER(_Event), ctypes.POINTER(_TerminalSummary)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_exchange_cancelled",
            [handle, _ExchangeId, ctypes.POINTER(ctypes.c_uint8)],
            _Result,
        )
        for name, value_type in (
            ("coakka_http_core_respond", _Response),
            ("coakka_http_core_respond_file", _FileResponse),
            ("coakka_http_core_fail", _Failure),
            ("coakka_http_core_start_response_stream", _Response),
        ):
            _bind(
                library,
                name,
                [handle, _ExchangeId, ctypes.POINTER(value_type)],
                _Result,
            )
        _bind(
            library,
            "coakka_http_core_start_sse",
            [handle, _ExchangeId, ctypes.POINTER(_Header), ctypes.c_uint32],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_write_response_stream",
            [handle, _ExchangeId, _Bytes],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_write_sse",
            [handle, _ExchangeId, ctypes.POINTER(_SseEvent)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_finish_response_stream",
            [handle, _ExchangeId, ctypes.POINTER(_Header), ctypes.c_uint32],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_accept_websocket",
            [handle, _ExchangeId, _Bytes],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_take_websocket",
            [handle, ctypes.c_uint64, ctypes.POINTER(_SocketEvent)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_release_websocket",
            [handle, ctypes.POINTER(_SocketEvent)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_send_websocket",
            [handle, _WebSocketId, ctypes.c_uint32, _Bytes],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_close_websocket",
            [handle, _WebSocketId, ctypes.c_uint32, _Bytes],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_outbound_submit",
            [handle, ctypes.POINTER(_ClientRequest), ctypes.POINTER(_OutboundId)],
            _Result,
        )
        _bind(
            library, "coakka_http_core_outbound_cancel", [handle, _OutboundId], _Result
        )
        _bind(
            library,
            "coakka_http_core_take_outbound",
            [handle, ctypes.c_uint64, ctypes.POINTER(_ClientTerminal)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_outbound_header",
            [
                handle,
                ctypes.POINTER(_ClientTerminal),
                ctypes.c_uint32,
                ctypes.POINTER(_Header),
            ],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_release_outbound",
            [handle, ctypes.POINTER(_ClientTerminal)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_rebind",
            [
                handle,
                ctypes.POINTER(_RouteRebind),
                ctypes.c_uint64,
                ctypes.POINTER(_RouteRebindOutcome),
            ],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_health",
            [handle, ctypes.POINTER(_Health)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_probe_liveness",
            [handle, ctypes.c_uint64, ctypes.POINTER(_Health)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_monitor_config",
            [handle, ctypes.POINTER(_MonitorConfig)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_monitor_snapshot",
            [handle, ctypes.POINTER(_MonitorSnapshot)],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_monitor_apply",
            [
                handle,
                ctypes.c_uint64,
                ctypes.POINTER(_MonitorPolicy),
                ctypes.POINTER(_MonitorApplyOutcome),
            ],
            _Result,
        )
        _bind(
            library,
            "coakka_http_core_monitor_read",
            [
                handle,
                ctypes.c_uint64,
                ctypes.c_uint32,
                ctypes.POINTER(_MonitorEvent),
                ctypes.c_uint32,
                ctypes.POINTER(_MonitorEventPage),
            ],
            _Result,
        )
        _bind(
            library, "coakka_http_core_monitor_wait", [handle, ctypes.c_uint64], _Result
        )


def check(result: _Result) -> None:
    """Raise :class:`CoreError` when a native operation did not succeed."""
    if result.code == RESULT_OK:
        return
    message = bytes(result.detail).split(b"\0", 1)[0].decode("utf-8", "replace")
    if not message:
        name = LIBRARY.library.coakka_http_result_code_name(result.code)
        label = name.decode("ascii", "replace") if name else str(result.code)
        message = f"CoAkka HTTP operation failed: {label}"
    raise CoreError(int(result.code), message, int(result.actual), int(result.limit))


def read_bytes(value: _Bytes, *, maximum: int | None = None) -> bytes:
    """Copy a bounded borrowed native byte range into Python-owned storage."""
    size = int(value.size)
    if size == 0:
        return b""
    effective_maximum = sys.maxsize if maximum is None else maximum
    if not value.data or size > effective_maximum:
        raise RuntimeError("native byte range is invalid or exceeds its bound")
    return ctypes.string_at(value.data, size)


def byte_view(value: bytes) -> tuple[_Bytes, ctypes.Array[ctypes.c_char] | None]:
    """Create a native byte view together with its required owning buffer."""
    if not value:
        return _Bytes(None, 0), None
    owner = ctypes.create_string_buffer(value, len(value))
    pointer = ctypes.cast(owner, ctypes.POINTER(ctypes.c_uint8))
    return _Bytes(pointer, len(value)), owner


def _windows_platform_id(process_target: str) -> str:
    windows_targets = {
        "win-arm64": "windows-aarch64",
        "win-amd64": "windows-x86_64",
    }
    try:
        return windows_targets[process_target.lower().replace("_", "-")]
    except KeyError as error:
        raise RuntimeError("unsupported Windows process architecture") from error


def _platform_id() -> str:
    system = platform.system()
    if system == "Windows":
        # platform.machine() reports the host OS architecture under Windows
        # emulation. sysconfig records the CPython process target and therefore
        # selects the only native image that this interpreter can load.
        return _windows_platform_id(sysconfig.get_platform())

    targets = {
        ("Darwin", "arm64"): "macos-aarch64",
        ("Linux", "arm64"): "linux-aarch64",
        ("Linux", "aarch64"): "linux-aarch64",
        ("Linux", "x86_64"): "linux-x86_64",
    }
    try:
        return targets[(system, platform.machine())]
    except KeyError as error:
        raise RuntimeError("unsupported operating system or architecture") from error


def _library_path() -> Path:
    override = os.environ.get("COAKKA_HTTP_CORE_PATH")
    if override:
        supplied = Path(override).absolute()
        if supplied.is_symlink():
            raise RuntimeError("native Core override must not be a symbolic link")
        candidate = supplied.resolve(strict=True)
        details = candidate.stat()
        if (
            not stat.S_ISREG(details.st_mode)
            or not 0 < details.st_size <= MAX_NATIVE_LIBRARY_BYTES
        ):
            raise RuntimeError("native Core override is not a bounded regular file")
        return candidate

    target = _platform_id()
    root = importlib.resources.files("coakka_http").joinpath("_native", target)
    manifest = json.loads(root.joinpath("native.json").read_text("utf-8"))
    if manifest.get("format") != 1 or manifest.get("platform") != target:
        raise RuntimeError("native Core manifest identity is invalid")
    name = manifest.get("library")
    size = manifest.get("size")
    digest = manifest.get("sha256")
    if (
        not isinstance(name, str)
        or Path(name).name != name
        or not isinstance(size, int)
        or not 0 < size <= MAX_NATIVE_LIBRARY_BYTES
        or not isinstance(digest, str)
        or len(digest) != 64
    ):
        raise RuntimeError("native Core manifest entry is invalid")
    resource = root.joinpath(name)
    if not isinstance(resource, Path):
        raise RuntimeError("native Core requires an unpacked wheel installation")
    packaged = resource
    if packaged.is_symlink():
        raise RuntimeError("packaged native Core must not be a symbolic link")
    candidate = packaged.resolve(strict=True)
    details = candidate.stat()
    if not stat.S_ISREG(details.st_mode) or details.st_size != size:
        raise RuntimeError("packaged native Core is not the declared regular file")
    payload = candidate.read_bytes()
    if len(payload) != size or hashlib.sha256(payload).hexdigest() != digest:
        raise RuntimeError("native Core package integrity check failed")
    return candidate


LIBRARY = _Library(_library_path())
