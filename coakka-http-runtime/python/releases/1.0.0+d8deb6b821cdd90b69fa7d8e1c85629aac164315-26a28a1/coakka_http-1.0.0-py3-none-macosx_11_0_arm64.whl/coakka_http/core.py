"""Typed low-level ownership API for callback-free CoAkka HTTP Core ABI 2."""

from __future__ import annotations

import ctypes
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import fields
from typing import Any, Self, cast

from ._core import (
    LIBRARY,
    MONITOR_EVENT_DETAIL_BYTES,
    MONITOR_EVENTS_PER_READ,
    RESULT_TIMEOUT,
    TERMINAL_DETAIL_CAPACITY,
    CoreError as CoreError,
    _CORE_LIMIT_U32_FIELDS,
    _CORE_LIMIT_U64_FIELDS,
    _Bytes,
    _ClientRequest,
    _ClientTerminal,
    _Compression,
    _CoreLimits,
    _CoreRoute,
    _Event,
    _ExchangeId,
    _Failure,
    _FileAuthority,
    _FileResponse,
    _Header,
    _Health,
    _InspectionOptions,
    _Listener,
    _MonitorApplyOutcome,
    _MonitorConfig,
    _MonitorEvent,
    _MonitorEventPage,
    _MonitorOptions,
    _MonitorPolicy,
    _MonitorSnapshot,
    _OutboundEndpoint,
    _OutboundId,
    _OutboundOptions,
    _OutboundTarget,
    _PathParameter,
    _QueryParameter,
    _Response,
    _RouteRebind,
    _RouteRebindOutcome,
    _SocketEvent,
    _SseEvent,
    _StaticMount,
    _TerminalSummary,
    _WaitPolicy,
    _WebSocketId,
    byte_view,
    check,
    read_bytes,
)
from .values import (
    BodyDelivery,
    Capability,
    Compression,
    EventKind,
    ExchangeId,
    ExchangeOutcome,
    Failure,
    FileAuthority,
    FileResponse,
    Header,
    Headers,
    Health,
    InspectionOptions,
    IoBackend,
    Limits,
    Listener,
    MonitorApplyOutcome,
    MonitorApplyReason,
    MonitorCategory,
    MonitorCollection,
    MonitorConfig,
    MonitorDetail,
    MonitorEvent,
    MonitorEventKind,
    MonitorEventPage,
    MonitorFailureCount,
    MonitorLatencyBucket,
    MonitorLatency,
    MonitorNotification,
    MonitorOptions,
    MonitorPolicy,
    MonitorSnapshot,
    OutboundEndpoint,
    OutboundId,
    OutboundOptions,
    OutboundRequest,
    OutboundTarget,
    OutboundTerminal,
    PathParameter,
    QueryParameter,
    Request,
    Response,
    Route,
    RouteRebind,
    RouteRebindOutcome,
    SseEvent,
    StaticMount,
    TerminalSummary,
    WaitPolicy,
    WebSocketEvent,
    WebSocketEventKind,
    WebSocketId,
)


def features() -> Capability:
    """Return feature bits implemented by the loaded native Core image."""
    return Capability(int(LIBRARY.library.coakka_http_features()))


def _integer(value: int, name: str, maximum: int, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{name} must be an integer")
    if not minimum <= value <= maximum:
        raise ValueError(f"{name} is outside its native integer range")
    return value


def _u16(value: int, name: str) -> int:
    return _integer(value, name, (1 << 16) - 1)


def _u32(value: int, name: str) -> int:
    return _integer(value, name, (1 << 32) - 1)


def _u64(value: int, name: str) -> int:
    return _integer(value, name, (1 << 64) - 1)


def _i32(value: int, name: str) -> int:
    return _integer(value, name, (1 << 31) - 1, -(1 << 31))


def _encoded(value: str, name: str, encoding: str = "utf-8") -> bytes:
    if not isinstance(value, str):
        raise TypeError(f"{name} must be text")
    result = value.encode(encoding, errors="strict")
    if b"\0" in result:
        raise ValueError(f"{name} contains NUL")
    return result


def _owned_view(value: bytes, owners: list[object]) -> _Bytes:
    view, owner = byte_view(value)
    if owner is not None:
        owners.append(owner)
    return view


def _native_headers(headers: Headers, owners: list[object]) -> Any:
    if not isinstance(headers, Headers):
        raise TypeError("headers must be a Headers value")
    values = tuple(headers)
    _u32(len(values), "header count")
    if not values:
        return None
    result = (_Header * len(values))()
    owners.append(result)
    for index, header in enumerate(values):
        result[index].name = _owned_view(header.name.encode("ascii"), owners)
        result[index].value = _owned_view(header.value.encode("latin-1"), owners)
    return result


def _native_response(value: Response, owners: list[object]) -> _Response:
    if not isinstance(value, Response):
        raise TypeError("response must be a Response value")
    native = _Response()
    LIBRARY.library.coakka_http_response_init(ctypes.byref(native))
    native.status_code = _u32(value.status, "response status")
    headers = _native_headers(value.headers, owners)
    native.headers = headers
    native.header_count = len(value.headers)
    native.body = _owned_view(bytes(value.body), owners)
    return native


def _native_exchange(value: ExchangeId) -> _ExchangeId:
    if not isinstance(value, ExchangeId):
        raise TypeError("exchange must be an ExchangeId")
    return _ExchangeId(
        _u64(value.slot, "exchange slot"), _u64(value.generation, "exchange generation")
    )


def _native_websocket(value: WebSocketId) -> _WebSocketId:
    if not isinstance(value, WebSocketId):
        raise TypeError("session must be a WebSocketId")
    return _WebSocketId(
        _u64(value.slot, "session slot"), _u64(value.generation, "session generation")
    )


def _native_outbound(value: OutboundId) -> _OutboundId:
    if not isinstance(value, OutboundId):
        raise TypeError("call must be an OutboundId")
    return _OutboundId(
        _u64(value.slot, "call slot"), _u64(value.generation, "call generation")
    )


def _copy_numeric_structure(target: Any, source: Any) -> None:
    native_types = {item[0]: item[1] for item in type(target)._fields_}
    for item in fields(source):
        field_type = native_types.get(item.name)
        value = getattr(source, item.name)
        if field_type is ctypes.c_uint32:
            checked = _u32(value, item.name)
        elif field_type is ctypes.c_uint64:
            checked = _u64(value, item.name)
        else:
            raise RuntimeError(f"unsupported numeric native field: {item.name}")
        setattr(target, item.name, checked)


def _headers_from_event(event: _Event, count_name: str, item_name: str) -> Headers:
    library = LIBRARY.library
    count = int(getattr(library, count_name)(ctypes.byref(event)))
    result: list[Header] = []
    for index in range(count):
        item = _Header()
        if not getattr(library, item_name)(
            ctypes.byref(event), index, ctypes.byref(item)
        ):
            raise RuntimeError("Core failed to project a declared header")
        result.append(
            Header(
                read_bytes(item.name).decode("ascii", "strict"),
                read_bytes(item.value).decode("latin-1", "strict"),
            )
        )
    return Headers(result)


class Configuration:
    """Single-owner mutable Core configuration whose inputs are copied."""

    __slots__ = ("_handle", "_lock", "_sealed")

    def __init__(self) -> None:
        """Allocate an empty native configuration without opening resources."""
        self._handle = ctypes.c_void_p()
        self._lock = threading.Lock()
        self._sealed = False
        check(
            LIBRARY.library.coakka_http_configuration_create(ctypes.byref(self._handle))
        )
        if not self._handle.value:
            raise RuntimeError("Core returned an empty configuration handle")

    def _open_handle(self) -> ctypes.c_void_p:
        if not self._handle.value:
            raise RuntimeError("configuration is closed")
        if self._sealed:
            raise RuntimeError("configuration is sealed after Core creation begins")
        return self._handle

    def set_limits(self, value: Limits) -> Self:
        """Replace every nonzero Core resource ceiling."""
        if not isinstance(value, Limits):
            raise TypeError("limits must be a Limits value")
        native = _CoreLimits()
        LIBRARY.library.coakka_http_core_limits_init(ctypes.byref(native))
        for name in _CORE_LIMIT_U32_FIELDS:
            setattr(native, name, _u32(getattr(value, name), name))
        for name in _CORE_LIMIT_U64_FIELDS:
            setattr(native, name, _u64(getattr(value, name), name))
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_set_limits(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def add_listener(self, value: Listener) -> Self:
        """Copy one listener including protocol and optional file-backed TLS."""
        if not isinstance(value, Listener):
            raise TypeError("listener must be a Listener value")
        native = _Listener()
        owners: list[object] = []
        LIBRARY.library.coakka_http_listener_init(ctypes.byref(native))
        native.listener_id = _u64(value.listener_id, "listener_id")
        native.bind_address = _owned_view(
            _encoded(value.bind_address, "bind_address"), owners
        )
        native.port = _u16(value.port, "port")
        native.protocol = _u32(int(value.protocol), "protocol")
        native.security = _u32(int(value.security), "security")
        native.credential_generation = _u64(
            value.credential_generation, "credential_generation"
        )
        native.credential_id = _owned_view(
            _encoded(value.credential_id, "credential_id"), owners
        )
        native.certificate_chain_file = _owned_view(
            _encoded(value.certificate_chain_file, "certificate_chain_file"), owners
        )
        native.private_key_file = _owned_view(
            _encoded(value.private_key_file, "private_key_file"), owners
        )
        native.trust_roots_file = _owned_view(
            _encoded(value.trust_roots_file, "trust_roots_file"), owners
        )
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_add_listener(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def add_route(self, value: Route) -> Self:
        """Copy one route, body policy, and handler binding identity."""
        if not isinstance(value, Route):
            raise TypeError("route must be a Route value")
        native = _CoreRoute()
        owners: list[object] = []
        LIBRARY.library.coakka_http_core_route_init(ctypes.byref(native))
        native.route_id = _u64(value.id, "route id")
        native.request_capture_profile_id = _u64(
            value.request_capture_profile_id, "request_capture_profile_id"
        )
        native.handler_binding_id = _u64(value.handler_binding_id, "handler_binding_id")
        native.method = _owned_view(_encoded(value.method, "method", "ascii"), owners)
        native.path = _owned_view(_encoded(value.pattern, "pattern"), owners)
        native.body_delivery = _u32(int(value.body_delivery), "body_delivery")
        policy = value.body_policy
        native.body_policy.enabled = int(policy.enabled)
        native.body_policy.accept_absent = int(policy.accept_absent)
        native.body_policy.accept_other = int(policy.accept_other)
        native.body_policy.accept_form_urlencoded = int(policy.accept_form_urlencoded)
        native.body_policy.accept_multipart_form_data = int(
            policy.accept_multipart_form_data
        )
        native.body_policy.max_body_bytes = _u64(
            policy.max_body_bytes, "max_body_bytes"
        )
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_add_route(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def add_static_mount(self, value: StaticMount) -> Self:
        """Copy a trusted static tree and optional SPA policy."""
        if not isinstance(value, StaticMount):
            raise TypeError("mount must be a StaticMount value")
        native = _StaticMount()
        owners: list[object] = []
        LIBRARY.library.coakka_http_static_mount_init(ctypes.byref(native))
        native.mount_id = _u64(value.mount_id, "mount_id")
        native.url_prefix = _owned_view(
            _encoded(value.url_prefix, "url_prefix"), owners
        )
        native.root_path = _owned_view(_encoded(value.root_path, "root_path"), owners)
        for name in ("index_file", "cache_control", "spa_fallback_file"):
            item = cast(str | None, getattr(value, name))
            if item is not None:
                setattr(native, name, _owned_view(_encoded(item, name), owners))
                setattr(native, f"has_{name}", 1)
        native.include_dotfiles = int(value.include_dotfiles)
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_add_static_mount(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def add_file_authority(self, value: FileAuthority) -> Self:
        """Copy an approved root for application-selected file responses."""
        if not isinstance(value, FileAuthority):
            raise TypeError("authority must be a FileAuthority value")
        native = _FileAuthority()
        owners: list[object] = []
        LIBRARY.library.coakka_http_file_authority_init(ctypes.byref(native))
        native.authority_id = _u64(value.authority_id, "authority_id")
        native.root_path = _owned_view(_encoded(value.root_path, "root_path"), owners)
        native.max_file_bytes = _u64(value.max_file_bytes, "max_file_bytes")
        native.max_active_files = _u32(value.max_active_files, "max_active_files")
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_add_file_authority(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def set_compression(self, value: Compression) -> Self:
        """Set the construction-fixed bounded response compression policy."""
        if not isinstance(value, Compression):
            raise TypeError("compression must be a Compression value")
        native = _Compression()
        LIBRARY.library.coakka_http_compression_init(ctypes.byref(native))
        native.mode = _u32(int(value.mode), "compression mode")
        for name in (
            "minimum_body_bytes",
            "maximum_body_bytes",
            "maximum_encoded_bytes",
            "workspace_bytes",
        ):
            setattr(native, name, _u64(getattr(value, name), name))
        native.gzip_level = _i32(value.gzip_level, "gzip_level")
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_set_compression(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def set_io_backend(self, value: IoBackend) -> Self:
        """Select the platform-default or explicitly supported I/O backend."""
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_set_io_backend(
                    self._open_handle(), _u32(int(value), "I/O backend")
                )
            )
        return self

    def set_wait_policy(self, value: WaitPolicy) -> Self:
        """Set the construction-fixed connector lane wait policy."""
        if not isinstance(value, WaitPolicy):
            raise TypeError("wait policy must be a WaitPolicy value")
        native = _WaitPolicy()
        LIBRARY.library.coakka_http_wait_policy_init(ctypes.byref(native))
        native.mode = _u32(int(value.mode), "wait mode")
        native.spin_iterations = _u32(value.spin_iterations, "spin_iterations")
        native.yield_iterations = _u32(value.yield_iterations, "yield_iterations")
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_set_wait_policy(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def set_monitor(self, value: MonitorOptions) -> Self:
        """Reserve bounded monitor storage and set its initial policy."""
        if not isinstance(value, MonitorOptions):
            raise TypeError("monitor must be a MonitorOptions value")
        native = _MonitorOptions()
        LIBRARY.library.coakka_http_monitor_options_init(ctypes.byref(native))
        native.collection = _u32(int(value.collection), "collection")
        for name in (
            "event_capacity",
            "max_events_per_read",
            "detail_bytes_per_event",
            "latency_bucket_count",
        ):
            setattr(native, name, _u32(getattr(value, name), name))
        native.aggregate_categories = _u64(
            int(value.aggregate_categories), "aggregate_categories"
        )
        native.event_categories = _u64(int(value.event_categories), "event_categories")
        native.signal_reserved = int(value.signal_reserved)
        native.runtime_safe_detail = int(value.runtime_safe_detail)
        native.fixed_latency_buckets = int(value.fixed_latency_buckets)
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_set_monitor(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def set_inspection(self, value: InspectionOptions) -> Self:
        """Enable Core-owned authenticated target-runtime inspection."""
        if not isinstance(value, InspectionOptions):
            raise TypeError("inspection must be an InspectionOptions value")
        native = _InspectionOptions()
        owners: list[object] = []
        LIBRARY.library.coakka_http_inspection_options_init(ctypes.byref(native))
        native.allow_plaintext_loopback = int(value.allow_plaintext_loopback)
        native.runtime_instance_id = _u64(
            value.runtime_instance_id, "runtime_instance_id"
        )
        native.runtime_generation = _u64(value.runtime_generation, "runtime_generation")
        native.bearer_file = _owned_view(
            _encoded(value.bearer_file, "bearer_file"), owners
        )
        for name in (
            "max_bearer_token_bytes",
            "call_capacity",
            "max_entries_per_turn",
            "snapshot_deadline_ms",
        ):
            setattr(native, name, _u32(getattr(value, name), name))
        for name in (
            "max_bytes_per_turn",
            "max_response_bytes",
            "max_total_response_bytes",
        ):
            setattr(native, name, _u64(getattr(value, name), name))
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_set_inspection(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def set_outbound(self, value: OutboundOptions) -> Self:
        """Replace all outbound resource reservations with ``value``."""
        if not isinstance(value, OutboundOptions):
            raise TypeError("outbound options must be an OutboundOptions value")
        native = _OutboundOptions()
        owners: list[object] = []
        LIBRARY.library.coakka_http_outbound_options_init(ctypes.byref(native))
        native.resolver_enabled = int(value.resolver_enabled)
        native.pool_enabled = int(value.pool_enabled)
        for source, target in (
            (value.lane, native.lane),
            (value.transport, native.transport),
            (value.pool, native.pool),
            (value.tls, native.tls),
            (value.registry, native.registry),
        ):
            _copy_numeric_structure(target, source)
        resolver = value.resolver
        for name in (
            "max_resolved_addresses",
            "socket_capacity",
            "timeout_ms",
            "tries",
        ):
            setattr(native.resolver, name, _u32(getattr(resolver, name), name))
        native.resolver.server_endpoint = _owned_view(
            _encoded(resolver.server_endpoint, "server_endpoint"), owners
        )
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_set_outbound(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def enable_outbound(self) -> Self:
        """Enable outbound using Core's conservative default reservations."""
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_enable_outbound(
                    self._open_handle()
                )
            )
        return self

    def add_outbound_target(self, value: OutboundTarget) -> Self:
        """Copy one logical outbound target and all of its endpoints."""
        if not isinstance(value, OutboundTarget):
            raise TypeError("target must be an OutboundTarget value")
        native = _OutboundTarget()
        owners: list[object] = []
        LIBRARY.library.coakka_http_outbound_target_init(ctypes.byref(native))
        native.name = _owned_view(_encoded(value.name, "target name"), owners)
        native.generation = _u64(value.generation, "target generation")
        native.strategy = _u32(int(value.strategy), "outbound strategy")
        endpoints = (_OutboundEndpoint * len(value.endpoints))()
        owners.append(endpoints)
        for index, endpoint in enumerate(value.endpoints):
            if not isinstance(endpoint, OutboundEndpoint):
                raise TypeError("endpoints must contain OutboundEndpoint values")
            item = endpoints[index]
            LIBRARY.library.coakka_http_outbound_endpoint_init(ctypes.byref(item))
            item.weight = _u32(endpoint.weight, "endpoint weight")
            item.node_id = _owned_view(_encoded(endpoint.node_id, "node_id"), owners)
            item.connect_host = _owned_view(
                _encoded(endpoint.connect_host, "connect_host"), owners
            )
            item.connect_port = _u16(endpoint.connect_port, "connect_port")
            item.http_authority = _owned_view(
                _encoded(endpoint.http_authority, "http_authority"), owners
            )
            item.security = _u32(int(endpoint.security), "endpoint security")
            item.available = int(endpoint.available)
            item.tls_peer_identity = _owned_view(
                _encoded(endpoint.tls_peer_identity, "tls_peer_identity"), owners
            )
            for name in ("proxy_mode", "protocol_policy", "connection_strategy"):
                setattr(item, name, _u32(getattr(endpoint, name), name))
            item.proxy_identity = _owned_view(
                _encoded(endpoint.proxy_identity, "proxy_identity"), owners
            )
            for name in (
                "tls_trust_generation",
                "tls_client_identity_generation",
                "connection_strategy_generation",
                "local_network_policy_id",
            ):
                setattr(item, name, _u64(getattr(endpoint, name), name))
        native.endpoints = endpoints
        native.endpoint_count = _u32(len(value.endpoints), "endpoint count")
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_add_outbound_target(
                    self._open_handle(), ctypes.byref(native)
                )
            )
        return self

    def add_outbound_trust(self, generation: int, ca_pem: bytes) -> Self:
        """Copy one generation-scoped outbound CA trust bundle."""
        owners: list[object] = []
        value = _owned_view(bytes(ca_pem), owners)
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_add_outbound_trust(
                    self._open_handle(), _u64(generation, "generation"), value
                )
            )
        return self

    def add_outbound_identity(
        self, generation: int, certificate_chain_pem: bytes, private_key_pem: bytes
    ) -> Self:
        """Copy one generation-scoped outbound mutual-TLS identity."""
        owners: list[object] = []
        certificate = _owned_view(bytes(certificate_chain_pem), owners)
        private_key = _owned_view(bytes(private_key_pem), owners)
        with self._lock:
            check(
                LIBRARY.library.coakka_http_configuration_add_outbound_identity(
                    self._open_handle(),
                    _u64(generation, "generation"),
                    certificate,
                    private_key,
                )
            )
        return self

    def create_core(self) -> Core:
        """Create a Core that owns a complete copy of this configuration."""
        return Core(self)

    def _new_core_handle(self) -> ctypes.c_void_p:
        with self._lock:
            result = ctypes.c_void_p()
            handle = self._open_handle()
            self._sealed = True
            check(LIBRARY.library.coakka_http_core_create(handle, ctypes.byref(result)))
            if not result.value:
                raise RuntimeError("Core returned an empty runtime handle")
            return result

    def close(self) -> None:
        """Destroy this builder; already-created Core instances remain valid."""
        with self._lock:
            if not self._handle.value:
                return
            check(
                LIBRARY.library.coakka_http_configuration_destroy(
                    ctypes.byref(self._handle)
                )
            )

    def __enter__(self) -> Self:
        """Return this configuration for synchronous scoped ownership."""
        return self

    def __exit__(self, _type: object, _value: object, _traceback: object) -> None:
        """Destroy this configuration on scope exit."""
        self.close()


class Core:
    """Sole lifecycle owner for one callback-free native Core instance."""

    __slots__ = (
        "_active_calls",
        "_event_reader",
        "_handle",
        "_leases",
        "_lifecycle",
        "_lock",
        "_monitor_waiter",
        "_outbound_reader",
        "_started",
        "_stopped",
        "_websocket_reader",
    )

    def __init__(self, configuration: Configuration) -> None:
        """Copy ``configuration`` into a created but not started Core."""
        if not isinstance(configuration, Configuration):
            raise TypeError("configuration must be a Configuration")
        self._handle = configuration._new_core_handle()
        self._lock = threading.RLock()
        self._lifecycle = threading.Lock()
        self._event_reader = threading.Lock()
        self._websocket_reader = threading.Lock()
        self._outbound_reader = threading.Lock()
        self._monitor_waiter = threading.Lock()
        self._active_calls = 0
        self._leases = 0
        self._started = False
        self._stopped = False

    @property
    def capabilities(self) -> Capability:
        """Return feature bits implemented by the loaded Core image."""
        return features()

    @contextmanager
    def _borrow(self) -> Iterator[ctypes.c_void_p]:
        with self._lock:
            if not self._handle.value:
                raise RuntimeError("Core is closed")
            self._active_calls += 1
            handle = self._handle
        try:
            yield handle
        finally:
            with self._lock:
                self._active_calls -= 1

    def _register_lease(self) -> None:
        with self._lock:
            if not self._handle.value:
                raise RuntimeError("Core closed while admitting a lease")
            self._leases += 1

    def _released_lease(self) -> None:
        with self._lock:
            if self._leases <= 0:
                raise RuntimeError("Core lease accounting underflow")
            self._leases -= 1

    def start(self) -> Self:
        """Bind configured resources and open request admission once."""
        with self._lifecycle:
            with self._borrow() as handle:
                check(LIBRARY.library.coakka_http_core_start(handle))
            self._started = True
            self._stopped = False
        return self

    @property
    def port(self) -> int:
        """Return the bound port for a started single-listener Core."""
        value = ctypes.c_uint16()
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_bound_port(handle, ctypes.byref(value))
            )
        return int(value.value)

    def drain(self) -> None:
        """Close admission and begin bounded graceful drain."""
        with self._lifecycle:
            with self._borrow() as handle:
                check(LIBRARY.library.coakka_http_core_drain(handle))

    def stop(self) -> None:
        """Stop Core using its configured monotonic shutdown bound."""
        with self._lifecycle:
            with self._borrow() as handle:
                check(LIBRARY.library.coakka_http_core_stop(handle))
            self._stopped = True

    def interrupt(self) -> None:
        """Wake the sole inbound event reader without fabricating an event."""
        with self._lock:
            if not self._handle.value:
                raise RuntimeError("Core is closed")
            check(LIBRARY.library.coakka_http_core_interrupt(self._handle))

    def close(self) -> None:
        """Stop and destroy Core after all calls and leases have ended.

        The operation fails closed while a native call or event lease remains.
        Owners must interrupt and join readers, then release every lease first.
        """
        with self._lifecycle:
            with self._lock:
                if not self._handle.value:
                    return
                if self._active_calls != 0:
                    raise RuntimeError("Core has active native calls")
                if self._leases != 0:
                    raise RuntimeError("Core has outstanding event leases")
                if self._started and not self._stopped:
                    check(LIBRARY.library.coakka_http_core_stop(self._handle))
                    self._stopped = True
                check(
                    LIBRARY.library.coakka_http_core_destroy(ctypes.byref(self._handle))
                )

    def __enter__(self) -> Self:
        """Return this Core for synchronous scoped ownership."""
        return self

    def __exit__(self, _type: object, _value: object, _traceback: object) -> None:
        """Stop and destroy Core on scope exit."""
        self.close()

    def take_event(self, timeout_ms: int) -> EventLease | None:
        """Take one inbound/stream/terminal lease, or ``None`` on timeout.

        Only one thread may call this method at a time. The returned lease must
        be released explicitly or used as a context manager before Core closes.
        """
        if not self._event_reader.acquire(blocking=False):
            raise RuntimeError("Core already has an inbound event reader")
        try:
            native = _Event()
            LIBRARY.library.coakka_http_event_init(ctypes.byref(native))
            with self._borrow() as handle:
                result = LIBRARY.library.coakka_http_core_take_event(
                    handle, _u64(timeout_ms, "timeout_ms"), ctypes.byref(native)
                )
                if result.code == RESULT_TIMEOUT:
                    return None
                check(result)
                self._register_lease()
            try:
                return EventLease(self, native)
            except BaseException:
                self._release_event(native)
                raise
        finally:
            self._event_reader.release()

    def _release_event(self, event: _Event) -> None:
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_release_event(
                    handle, ctypes.byref(event)
                )
            )
        self._released_lease()

    def _copy_request(self, event: _Event, binding_id: int) -> Request:
        library = LIBRARY.library
        with self._borrow() as handle:
            headers = _headers_from_event(
                event,
                "coakka_http_event_request_header_count",
                "coakka_http_event_request_header",
            )
            trailers = _headers_from_event(
                event,
                "coakka_http_event_request_trailer_count",
                "coakka_http_event_request_trailer",
            )
            path_count = int(
                library.coakka_http_event_request_path_parameter_count(
                    ctypes.byref(event)
                )
            )
            query_count = int(
                library.coakka_http_event_request_query_parameter_count(
                    ctypes.byref(event)
                )
            )
            paths: list[PathParameter] = []
            for index in range(path_count):
                path_item = _PathParameter()
                if not library.coakka_http_event_request_path_parameter(
                    ctypes.byref(event), index, ctypes.byref(path_item)
                ):
                    raise RuntimeError("Core failed to project a path parameter")
                paths.append(
                    PathParameter(
                        read_bytes(path_item.name).decode("utf-8", "strict"),
                        read_bytes(path_item.encoded_value).decode("utf-8", "strict"),
                    )
                )
            queries: list[QueryParameter] = []
            for index in range(query_count):
                query_item = _QueryParameter()
                if not library.coakka_http_event_request_query_parameter(
                    ctypes.byref(event), index, ctypes.byref(query_item)
                ):
                    raise RuntimeError("Core failed to project a query parameter")
                queries.append(
                    QueryParameter(
                        read_bytes(query_item.encoded_key).decode("utf-8", "strict"),
                        read_bytes(query_item.encoded_value).decode("utf-8", "strict"),
                        bool(query_item.has_value),
                    )
                )
            cancelled = ctypes.c_uint8()
            exchange = ExchangeId(
                int(event.exchange.slot), int(event.exchange.generation)
            )
            check(
                library.coakka_http_core_exchange_cancelled(
                    handle, _native_exchange(exchange), ctypes.byref(cancelled)
                )
            )
            body_delivery_value = int(
                library.coakka_http_event_request_body_delivery(ctypes.byref(event))
            )
            body_delivery = (
                None if body_delivery_value == 0 else BodyDelivery(body_delivery_value)
            )
            return Request(
                exchange=exchange,
                method=read_bytes(
                    library.coakka_http_event_request_method(ctypes.byref(event))
                ).decode("ascii", "strict"),
                scheme=read_bytes(
                    library.coakka_http_event_request_scheme(ctypes.byref(event))
                ).decode("ascii", "strict"),
                authority=read_bytes(
                    library.coakka_http_event_request_authority(ctypes.byref(event))
                ).decode("utf-8", "strict"),
                target=read_bytes(
                    library.coakka_http_event_request_target(ctypes.byref(event))
                ).decode("utf-8", "strict"),
                headers=headers,
                body=read_bytes(
                    library.coakka_http_event_request_body(ctypes.byref(event))
                ),
                body_delivery=body_delivery,
                route_id=int(
                    library.coakka_http_event_request_route_id(ctypes.byref(event))
                ),
                route_generation=int(
                    library.coakka_http_event_request_route_generation(
                        ctypes.byref(event)
                    )
                ),
                binding_revision=int(
                    library.coakka_http_event_request_binding_revision(
                        ctypes.byref(event)
                    )
                ),
                handler_binding_id=binding_id,
                path_parameters=tuple(paths),
                query_parameters=tuple(queries),
                trailers=trailers,
                cancelled=bool(cancelled.value),
            )

    def _stream_trailers(self, event: _Event) -> Headers:
        with self._borrow():
            return _headers_from_event(
                event,
                "coakka_http_event_stream_trailer_count",
                "coakka_http_event_stream_trailer",
            )

    def _terminal_summary(self, event: _Event) -> TerminalSummary:
        native = _TerminalSummary()
        LIBRARY.library.coakka_http_terminal_summary_init(ctypes.byref(native))
        with self._borrow():
            check(
                LIBRARY.library.coakka_http_event_terminal_summary(
                    ctypes.byref(event), ctypes.byref(native)
                )
            )
        stored = int(native.stored_detail_size)
        if stored > TERMINAL_DETAIL_CAPACITY:
            raise RuntimeError("Core terminal detail exceeds its public buffer")
        detail = ctypes.string_at(
            ctypes.addressof(native) + _TerminalSummary.detail.offset, stored
        ).decode("utf-8", "replace")
        return TerminalSummary(
            outcome=ExchangeOutcome(int(native.outcome)),
            response_status=int(native.response_status)
            if native.has_response
            else None,
            failure_domain=int(native.failure_domain) if native.has_failure else None,
            failure_phase=int(native.failure_phase) if native.has_failure else None,
            failure_reason=int(native.failure_reason) if native.has_failure else None,
            retry_disposition=(
                int(native.retry_disposition) if native.has_failure else None
            ),
            http_status_hint=(
                int(native.http_status_hint) if native.has_http_status_hint else None
            ),
            detail=detail,
            detail_size=int(native.detail_size),
            detail_truncated=bool(native.detail_truncated),
            admitted_monotonic_ns=(
                int(native.admitted_monotonic_ns) if native.has_admitted_time else None
            ),
            dispatched_monotonic_ns=(
                int(native.dispatched_monotonic_ns)
                if native.has_dispatched_time
                else None
            ),
            response_accepted_monotonic_ns=(
                int(native.response_accepted_monotonic_ns)
                if native.has_response_accepted_time
                else None
            ),
            completed_monotonic_ns=(
                int(native.completed_monotonic_ns)
                if native.has_completed_time
                else None
            ),
        )

    def exchange_cancelled(self, exchange: ExchangeId) -> bool:
        """Return whether Core has observed cancellation for ``exchange``."""
        cancelled = ctypes.c_uint8()
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_exchange_cancelled(
                    handle, _native_exchange(exchange), ctypes.byref(cancelled)
                )
            )
        return bool(cancelled.value)

    def respond(self, exchange: ExchangeId, response: Response) -> None:
        """Copy and submit one buffered terminal response."""
        owners: list[object] = []
        native = _native_response(response, owners)
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_respond(
                    handle, _native_exchange(exchange), ctypes.byref(native)
                )
            )

    def respond_file(self, exchange: ExchangeId, response: FileResponse) -> None:
        """Submit one file below a configured Core-owned authority."""
        if not isinstance(response, FileResponse):
            raise TypeError("response must be a FileResponse")
        owners: list[object] = []
        native = _FileResponse()
        LIBRARY.library.coakka_http_file_response_init(ctypes.byref(native))
        head = _native_response(
            Response(response.status, response.headers, b""), owners
        )
        native.head = head
        native.authority_id = _u64(response.authority_id, "authority_id")
        native.encoded_path = _owned_view(
            _encoded(response.encoded_path, "encoded_path"), owners
        )
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_respond_file(
                    handle, _native_exchange(exchange), ctypes.byref(native)
                )
            )

    def fail(self, exchange: ExchangeId, failure: Failure) -> None:
        """Submit one copied terminal failure for ``exchange``."""
        if not isinstance(failure, Failure):
            raise TypeError("failure must be a Failure")
        owners: list[object] = []
        native = _Failure()
        LIBRARY.library.coakka_http_failure_init(ctypes.byref(native))
        native.reason = _u32(failure.reason, "failure reason")
        native.detail = _owned_view(bytes(failure.detail), owners)
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_fail(
                    handle, _native_exchange(exchange), ctypes.byref(native)
                )
            )

    def start_response_stream(self, exchange: ExchangeId, head: Response) -> None:
        """Copy a streaming response head; ``head.body`` must be empty."""
        if head.body:
            raise ValueError("streaming response head must not contain a body")
        owners: list[object] = []
        native = _native_response(head, owners)
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_start_response_stream(
                    handle, _native_exchange(exchange), ctypes.byref(native)
                )
            )

    def start_sse(self, exchange: ExchangeId, headers: Headers = Headers()) -> None:
        """Start an identity-coded Core-owned server-sent event stream."""
        owners: list[object] = []
        native_headers = _native_headers(headers, owners)
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_start_sse(
                    handle,
                    _native_exchange(exchange),
                    native_headers,
                    len(headers),
                )
            )

    def write_response_stream(self, exchange: ExchangeId, data: bytes) -> None:
        """Copy one bounded response-stream chunk."""
        owners: list[object] = []
        chunk = _owned_view(bytes(data), owners)
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_write_response_stream(
                    handle, _native_exchange(exchange), chunk
                )
            )

    def write_sse(self, exchange: ExchangeId, event: SseEvent) -> None:
        """Copy one structured server-sent event into an active SSE stream."""
        if not isinstance(event, SseEvent):
            raise TypeError("event must be an SseEvent")
        owners: list[object] = []
        native = _SseEvent()
        LIBRARY.library.coakka_http_sse_event_init(ctypes.byref(native))
        native.data = _owned_view(bytes(event.data), owners)
        if event.event_type is not None:
            native.event_type = _owned_view(bytes(event.event_type), owners)
            native.has_event_type = 1
        if event.id is not None:
            native.id = _owned_view(bytes(event.id), owners)
            native.has_id = 1
        if event.retry_ms is not None:
            native.retry_ms = _u64(event.retry_ms, "retry_ms")
            native.has_retry = 1
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_write_sse(
                    handle, _native_exchange(exchange), ctypes.byref(native)
                )
            )

    def finish_response_stream(
        self, exchange: ExchangeId, trailers: Headers = Headers()
    ) -> None:
        """Finish an active response stream with copied optional trailers."""
        owners: list[object] = []
        native_trailers = _native_headers(trailers, owners)
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_finish_response_stream(
                    handle,
                    _native_exchange(exchange),
                    native_trailers,
                    len(trailers),
                )
            )

    def accept_websocket(
        self, exchange: ExchangeId, selected_subprotocol: bytes = b""
    ) -> None:
        """Accept a WebSocket upgrade with a copied selected subprotocol."""
        owners: list[object] = []
        protocol = _owned_view(bytes(selected_subprotocol), owners)
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_accept_websocket(
                    handle, _native_exchange(exchange), protocol
                )
            )

    def take_websocket(self, timeout_ms: int) -> WebSocketLease | None:
        """Take one WebSocket event lease, or ``None`` on timeout."""
        if not self._websocket_reader.acquire(blocking=False):
            raise RuntimeError("Core already has a WebSocket event reader")
        try:
            native = _SocketEvent()
            native.struct_size = ctypes.sizeof(native)
            with self._borrow() as handle:
                result = LIBRARY.library.coakka_http_core_take_websocket(
                    handle, _u64(timeout_ms, "timeout_ms"), ctypes.byref(native)
                )
                if result.code == RESULT_TIMEOUT:
                    return None
                check(result)
                self._register_lease()
            try:
                return WebSocketLease(self, native)
            except BaseException:
                self._release_websocket(native)
                raise
        finally:
            self._websocket_reader.release()

    def _release_websocket(self, event: _SocketEvent) -> None:
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_release_websocket(
                    handle, ctypes.byref(event)
                )
            )
        self._released_lease()

    def send_websocket(
        self, session: WebSocketId, kind: WebSocketEventKind, data: bytes
    ) -> None:
        """Copy one serialized WebSocket send for a live session."""
        owners: list[object] = []
        payload = _owned_view(bytes(data), owners)
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_send_websocket(
                    handle, _native_websocket(session), _u32(int(kind), "kind"), payload
                )
            )

    def close_websocket(
        self, session: WebSocketId, code: int = 1000, reason: bytes = b""
    ) -> None:
        """Copy a bounded close reason and begin WebSocket close."""
        owners: list[object] = []
        native_reason = _owned_view(bytes(reason), owners)
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_close_websocket(
                    handle,
                    _native_websocket(session),
                    _u32(code, "close code"),
                    native_reason,
                )
            )

    def outbound_submit(self, request: OutboundRequest) -> OutboundId:
        """Copy and submit one logical-target outbound HTTP request."""
        if not isinstance(request, OutboundRequest):
            raise TypeError("request must be an OutboundRequest")
        owners: list[object] = []
        native = _ClientRequest()
        LIBRARY.library.coakka_http_outbound_request_init(ctypes.byref(native))
        native.timeout_ms = _u32(request.timeout_ms, "timeout_ms")
        native.logical_target = _owned_view(
            _encoded(request.logical_target, "logical_target"), owners
        )
        native.method = _owned_view(_encoded(request.method, "method", "ascii"), owners)
        native.target = _owned_view(_encoded(request.target, "target"), owners)
        native.headers = _native_headers(request.headers, owners)
        native.header_count = len(request.headers)
        native.body = _owned_view(bytes(request.body), owners)
        call = _OutboundId()
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_outbound_submit(
                    handle, ctypes.byref(native), ctypes.byref(call)
                )
            )
        return OutboundId(int(call.slot), int(call.generation))

    def outbound_cancel(self, call: OutboundId) -> None:
        """Request cancellation of one admitted outbound call."""
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_outbound_cancel(
                    handle, _native_outbound(call)
                )
            )

    def take_outbound(self, timeout_ms: int) -> OutboundLease | None:
        """Take one outbound terminal lease, or ``None`` on timeout."""
        if not self._outbound_reader.acquire(blocking=False):
            raise RuntimeError("Core already has an outbound terminal reader")
        try:
            native = _ClientTerminal()
            LIBRARY.library.coakka_http_outbound_terminal_init(ctypes.byref(native))
            with self._borrow() as handle:
                result = LIBRARY.library.coakka_http_core_take_outbound(
                    handle, _u64(timeout_ms, "timeout_ms"), ctypes.byref(native)
                )
                if result.code == RESULT_TIMEOUT:
                    return None
                check(result)
                self._register_lease()
            try:
                return OutboundLease(self, native, self._copy_outbound(native))
            except BaseException:
                self._release_outbound(native)
                raise
        finally:
            self._outbound_reader.release()

    def _copy_outbound(self, native: _ClientTerminal) -> OutboundTerminal:
        headers: list[Header] = []
        with self._borrow() as handle:
            for index in range(int(native.response_header_count)):
                item = _Header()
                check(
                    LIBRARY.library.coakka_http_core_outbound_header(
                        handle, ctypes.byref(native), index, ctypes.byref(item)
                    )
                )
                headers.append(
                    Header(
                        read_bytes(item.name).decode("ascii", "strict"),
                        read_bytes(item.value).decode("latin-1", "strict"),
                    )
                )
        return OutboundTerminal(
            reason=int(native.reason),
            call=OutboundId(int(native.call.slot), int(native.call.generation)),
            logical_target=read_bytes(native.logical_target).decode("utf-8", "strict"),
            target_generation=int(native.target_generation),
            selected_node_id=read_bytes(native.selected_node_id).decode(
                "utf-8", "strict"
            ),
            phase=int(native.phase),
            retry=int(native.retry),
            certainty=int(native.certainty),
            response_status=int(native.response_status),
            provider_code=int(native.provider_code),
            response_headers=Headers(headers),
            response_body=read_bytes(native.response_body),
            diagnostic=read_bytes(native.diagnostic).decode("utf-8", "replace"),
        )

    def _release_outbound(self, terminal: _ClientTerminal) -> None:
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_release_outbound(
                    handle, ctypes.byref(terminal)
                )
            )
        self._released_lease()

    def rebind(self, request: RouteRebind, timeout_ms: int) -> RouteRebindOutcome:
        """Apply or replay one generation-checked handler rebinding command."""
        if not isinstance(request, RouteRebind):
            raise TypeError("request must be a RouteRebind")
        native = _RouteRebind()
        outcome = _RouteRebindOutcome()
        LIBRARY.library.coakka_http_route_rebind_init(ctypes.byref(native))
        LIBRARY.library.coakka_http_route_rebind_outcome_init(ctypes.byref(outcome))
        for item in fields(request):
            setattr(native, item.name, _u64(getattr(request, item.name), item.name))
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_rebind(
                    handle,
                    ctypes.byref(native),
                    _u64(timeout_ms, "timeout_ms"),
                    ctypes.byref(outcome),
                )
            )
        return RouteRebindOutcome(
            code=int(outcome.code),
            activation_id=int(outcome.activation_id),
            operation_digest=int(outcome.operation_digest),
            route_generation=int(outcome.route_generation),
            route_id=int(outcome.route_id),
            previous_handler_binding_id=int(outcome.previous_handler_binding_id),
            previous_binding_revision=int(outcome.previous_binding_revision),
            effective_handler_binding_id=int(outcome.effective_handler_binding_id),
            effective_binding_revision=int(outcome.effective_binding_revision),
            binding_change_sequence=int(outcome.binding_change_sequence),
            retained_previous_exchanges=int(outcome.retained_previous_exchanges),
            previous_effective_route_references=int(
                outcome.previous_effective_route_references
            ),
            changed=bool(outcome.changed),
            replayed=bool(outcome.replayed),
        )

    def health(self) -> Health:
        """Return a pointer-free health snapshot safe to retain."""
        native = _Health()
        LIBRARY.library.coakka_http_health_init(ctypes.byref(native))
        with self._borrow() as handle:
            check(LIBRARY.library.coakka_http_core_health(handle, ctypes.byref(native)))
        return _health(native)

    def probe_liveness(self, timeout_ms: int) -> Health:
        """Require runtime-loop progress and return the resulting health view."""
        native = _Health()
        LIBRARY.library.coakka_http_health_init(ctypes.byref(native))
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_probe_liveness(
                    handle, _u64(timeout_ms, "timeout_ms"), ctypes.byref(native)
                )
            )
        return _health(native)

    def monitor_config(self) -> MonitorConfig:
        """Return the effective pointer-free monitor configuration."""
        native = _MonitorConfig()
        LIBRARY.library.coakka_http_monitor_config_view_init(ctypes.byref(native))
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_monitor_config(
                    handle, ctypes.byref(native)
                )
            )
        return _monitor_config(native)

    def monitor_snapshot(self) -> MonitorSnapshot:
        """Return a bounded aggregate monitor snapshot safe to retain."""
        native = _MonitorSnapshot()
        LIBRARY.library.coakka_http_monitor_snapshot_view_init(ctypes.byref(native))
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_monitor_snapshot(
                    handle, ctypes.byref(native)
                )
            )
        failure_count = int(native.failure_count)
        latency_count = int(native.latency_bucket_count)
        if failure_count > len(native.failure_counts):
            raise RuntimeError("Core monitor failure count exceeds its public buffer")
        if latency_count > len(native.latency_buckets):
            raise RuntimeError("Core monitor latency count exceeds its public buffer")
        return MonitorSnapshot(
            collecting=bool(native.collecting),
            stale=bool(native.stale),
            partial=bool(native.partial),
            snapshot_sequence=int(native.snapshot_sequence),
            observed_monotonic_ns=int(native.observed_monotonic_ns),
            collected_change_sequence=int(native.collected_change_sequence),
            inbound_admitted_requests=int(native.inbound_admitted_requests),
            inbound_request_bytes=int(native.inbound_request_bytes),
            exchange_completed=int(native.exchange_completed),
            exchange_failed=int(native.exchange_failed),
            exchange_timed_out=int(native.exchange_timed_out),
            exchange_disconnected=int(native.exchange_disconnected),
            exchange_cancelled=int(native.exchange_cancelled),
            response_status_family=cast(
                tuple[int, int, int, int, int],
                tuple(int(item) for item in native.response_status_family),
            ),
            retained_events=int(native.retained_events),
            event_overwrite_count=int(native.event_overwrite_count),
            event_drop_count=int(native.event_drop_count),
            signal_notify_count=int(native.signal_notify_count),
            signal_coalesced_count=int(native.signal_coalesced_count),
            signal_failure_count=int(native.signal_failure_count),
            config=_monitor_config(native.config),
            health=_health(native.health),
            failure_counts=tuple(
                MonitorFailureCount(
                    int(native.failure_counts[index].reason),
                    int(native.failure_counts[index].count),
                )
                for index in range(failure_count)
            ),
            latency_buckets=tuple(
                MonitorLatencyBucket(
                    int(native.latency_buckets[index].upper_bound_ns),
                    int(native.latency_buckets[index].count),
                )
                for index in range(latency_count)
            ),
        )

    def monitor_apply(
        self, expected_generation: int, policy: MonitorPolicy
    ) -> MonitorApplyOutcome:
        """Apply a live policy and return its typed applied/rejected outcome."""
        native_policy = _native_monitor_policy(policy)
        native_outcome = _MonitorApplyOutcome()
        LIBRARY.library.coakka_http_monitor_apply_outcome_init(
            ctypes.byref(native_outcome)
        )
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_monitor_apply(
                    handle,
                    _u64(expected_generation, "expected_generation"),
                    ctypes.byref(native_policy),
                    ctypes.byref(native_outcome),
                )
            )
        return MonitorApplyOutcome(
            reason=MonitorApplyReason(int(native_outcome.reason)),
            actual=int(native_outcome.actual),
            limit=int(native_outcome.limit),
            changed=bool(native_outcome.changed),
            effective=_monitor_config(native_outcome.effective),
        )

    def monitor_read(
        self, after_sequence: int, maximum_events: int
    ) -> MonitorEventPage:
        """Copy at most 64 newer operational events and page metadata."""
        capacity = _integer(
            maximum_events, "maximum_events", MONITOR_EVENTS_PER_READ, 1
        )
        native_events = (_MonitorEvent * capacity)()
        for event in native_events:
            LIBRARY.library.coakka_http_monitor_event_view_init(ctypes.byref(event))
        page = _MonitorEventPage()
        LIBRARY.library.coakka_http_monitor_event_page_init(ctypes.byref(page))
        with self._borrow() as handle:
            check(
                LIBRARY.library.coakka_http_core_monitor_read(
                    handle,
                    _u64(after_sequence, "after_sequence"),
                    capacity,
                    native_events,
                    capacity,
                    ctypes.byref(page),
                )
            )
        count = int(page.count)
        if count > capacity:
            raise RuntimeError("Core monitor page exceeds supplied event capacity")
        events = tuple(_monitor_event(native_events[index]) for index in range(count))
        return MonitorEventPage(
            events=events,
            oldest_available_sequence=int(page.oldest_available_sequence),
            latest_sequence=int(page.latest_sequence),
            missed_events=int(page.missed_events),
            remaining_events=int(page.remaining_events),
        )

    def monitor_wait(self, timeout_ms: int) -> bool:
        """Wait as the sole monitor waiter; return false only on timeout."""
        if not self._monitor_waiter.acquire(blocking=False):
            raise RuntimeError("Core already has a monitor waiter")
        try:
            with self._borrow() as handle:
                result = LIBRARY.library.coakka_http_core_monitor_wait(
                    handle, _u64(timeout_ms, "timeout_ms")
                )
                if result.code == RESULT_TIMEOUT:
                    return False
                check(result)
                return True
        finally:
            self._monitor_waiter.release()

    def monitor_interrupt(self) -> None:
        """Wake the sole blocking monitor waiter."""
        with self._lock:
            if not self._handle.value:
                raise RuntimeError("Core is closed")
            check(LIBRARY.library.coakka_http_core_monitor_interrupt(self._handle))


class EventLease:
    """Exactly one Core event lease with explicit context-manager release."""

    __slots__ = (
        "_closed",
        "_core",
        "_lock",
        "_native",
        "exchange",
        "handler_binding_id",
        "kind",
        "sequence",
    )

    def __init__(self, core: Core, native: _Event) -> None:
        """Adopt one successful native event take."""
        self._core = core
        self._native = native
        self._lock = threading.Lock()
        self._closed = False
        self.kind = EventKind(int(native.kind))
        self.exchange = ExchangeId(
            int(native.exchange.slot), int(native.exchange.generation)
        )
        self.sequence = int(native.sequence)
        self.handler_binding_id = int(native.handler_binding_id)

    @property
    def closed(self) -> bool:
        """Return whether the native lease was released."""
        return self._closed

    @property
    def data(self) -> bytes:
        """Copy event-specific borrowed bytes while this lease is open."""
        with self._lock:
            self._ensure_open()
            return read_bytes(_Bytes(self._native.data, self._native.data_size))

    def request(self) -> Request:
        """Copy all request accessors from a leased REQUEST event."""
        with self._lock:
            self._ensure_open()
            if self.kind is not EventKind.REQUEST:
                raise RuntimeError("event is not a request")
            return self._core._copy_request(self._native, self.handler_binding_id)

    def stream_trailers(self) -> Headers:
        """Copy trailers from a leased REQUEST_TRAILERS event."""
        with self._lock:
            self._ensure_open()
            if self.kind is not EventKind.REQUEST_TRAILERS:
                raise RuntimeError("event does not contain request trailers")
            return self._core._stream_trailers(self._native)

    def terminal_summary(self) -> TerminalSummary:
        """Copy the public-safe summary from a leased TERMINAL event."""
        with self._lock:
            self._ensure_open()
            if self.kind is not EventKind.TERMINAL:
                raise RuntimeError("event is not terminal")
            return self._core._terminal_summary(self._native)

    def release(self) -> None:
        """Release the exact native event lease once; repeated calls are safe."""
        with self._lock:
            if self._closed:
                return
            self._core._release_event(self._native)
            self._closed = True

    def _ensure_open(self) -> None:
        if self._closed:
            raise RuntimeError("event lease is released")

    def __enter__(self) -> Self:
        """Return this open event lease."""
        self._ensure_open()
        return self

    def __exit__(self, _type: object, _value: object, _traceback: object) -> None:
        """Release the event lease on scope exit."""
        self.release()


class WebSocketLease:
    """Exactly one leased WebSocket event plus a stable copied projection."""

    __slots__ = ("_closed", "_core", "_lock", "_native", "event")

    def __init__(self, core: Core, native: _SocketEvent) -> None:
        """Adopt and copy one successful WebSocket event take."""
        self._core = core
        self._native = native
        self._lock = threading.Lock()
        self._closed = False
        self.event = WebSocketEvent(
            kind=WebSocketEventKind(int(native.kind)),
            session=WebSocketId(
                int(native.session.slot), int(native.session.generation)
            ),
            origin_exchange=ExchangeId(
                int(native.origin_exchange.slot), int(native.origin_exchange.generation)
            ),
            close_code=int(native.close_code),
            data=read_bytes(_Bytes(native.data, native.data_size)),
        )

    @property
    def closed(self) -> bool:
        """Return whether the native event lease was released."""
        return self._closed

    def release(self) -> None:
        """Release the exact WebSocket lease once; repeated calls are safe."""
        with self._lock:
            if self._closed:
                return
            self._core._release_websocket(self._native)
            self._closed = True

    def __enter__(self) -> Self:
        """Return this open WebSocket lease."""
        if self._closed:
            raise RuntimeError("WebSocket lease is released")
        return self

    def __exit__(self, _type: object, _value: object, _traceback: object) -> None:
        """Release the WebSocket lease on scope exit."""
        self.release()


class OutboundLease:
    """Exactly one outbound terminal lease plus a stable copied result."""

    __slots__ = ("_closed", "_core", "_lock", "_native", "terminal")

    def __init__(
        self, core: Core, native: _ClientTerminal, terminal: OutboundTerminal
    ) -> None:
        """Adopt one successful outbound terminal take."""
        self._core = core
        self._native = native
        self._lock = threading.Lock()
        self._closed = False
        self.terminal = terminal

    @property
    def closed(self) -> bool:
        """Return whether the native terminal lease was released."""
        return self._closed

    def release(self) -> None:
        """Release the exact outbound lease once; repeated calls are safe."""
        with self._lock:
            if self._closed:
                return
            self._core._release_outbound(self._native)
            self._closed = True

    def __enter__(self) -> Self:
        """Return this open outbound terminal lease."""
        if self._closed:
            raise RuntimeError("outbound lease is released")
        return self

    def __exit__(self, _type: object, _value: object, _traceback: object) -> None:
        """Release the outbound terminal lease on scope exit."""
        self.release()


def _health(native: _Health) -> Health:
    return Health(
        lifecycle=int(native.lifecycle),
        snapshot_sequence=int(native.snapshot_sequence),
        change_sequence=int(native.change_sequence),
        lifecycle_generation=int(native.lifecycle_generation),
        observed_monotonic_ns=int(native.observed_monotonic_ns),
        progress_sequence=int(native.progress_sequence),
        progress_monotonic_ns=int(native.progress_monotonic_ns),
        acknowledged_probe_sequence=int(native.acknowledged_probe_sequence),
        acknowledged_probe_monotonic_ns=int(native.acknowledged_probe_monotonic_ns),
        configured_components=int(native.configured_components),
        running_components=int(native.running_components),
        failed_components=int(native.failed_components),
        startup=int(native.startup),
        liveness=int(native.liveness),
        readiness=int(native.readiness),
        admission_open=bool(native.admission_open),
        partial=bool(native.partial),
        server_active_exchanges=int(native.server_active_exchanges),
        client_active_calls=int(native.client_active_calls),
        client_ready_terminals=int(native.client_ready_terminals),
        client_outstanding_terminal_leases=int(
            native.client_outstanding_terminal_leases
        ),
        client_retained_request_bytes=int(native.client_retained_request_bytes),
        client_retained_target_profile_bytes=int(
            native.client_retained_target_profile_bytes
        ),
        client_retained_response_bytes=int(native.client_retained_response_bytes),
        client_admitted_calls=int(native.client_admitted_calls),
        client_terminal_calls=int(native.client_terminal_calls),
        client_stale_provider_terminals=int(native.client_stale_provider_terminals),
    )


def _native_monitor_policy(value: MonitorPolicy) -> _MonitorPolicy:
    if not isinstance(value, MonitorPolicy):
        raise TypeError("policy must be a MonitorPolicy")
    native = _MonitorPolicy()
    LIBRARY.library.coakka_http_monitor_policy_view_init(ctypes.byref(native))
    native.collection = _u32(int(value.collection), "collection")
    native.notification = _u32(int(value.notification), "notification")
    native.latency = _u32(int(value.latency), "latency")
    native.detail = _u32(int(value.detail), "detail")
    native.active_event_capacity = _u32(
        value.active_event_capacity, "active_event_capacity"
    )
    native.active_detail_bytes = _u32(value.active_detail_bytes, "active_detail_bytes")
    native.aggregate_categories = _u64(
        int(value.aggregate_categories), "aggregate_categories"
    )
    native.event_categories = _u64(int(value.event_categories), "event_categories")
    return native


def _monitor_policy(native: _MonitorPolicy) -> MonitorPolicy:
    return MonitorPolicy(
        collection=MonitorCollection(int(native.collection)),
        notification=MonitorNotification(int(native.notification)),
        latency=MonitorLatency(int(native.latency)),
        detail=MonitorDetail(int(native.detail)),
        active_event_capacity=int(native.active_event_capacity),
        active_detail_bytes=int(native.active_detail_bytes),
        aggregate_categories=MonitorCategory(int(native.aggregate_categories)),
        event_categories=MonitorCategory(int(native.event_categories)),
    )


def _monitor_config(native: _MonitorConfig) -> MonitorConfig:
    return MonitorConfig(
        provenance=int(native.provenance),
        generation=int(native.generation),
        collection_epoch=int(native.collection_epoch),
        change_sequence=int(native.change_sequence),
        epoch_started_monotonic_ns=int(native.epoch_started_monotonic_ns),
        policy_applied_monotonic_ns=int(native.policy_applied_monotonic_ns),
        supported_categories=MonitorCategory(int(native.supported_categories)),
        reserved_event_capacity=int(native.reserved_event_capacity),
        max_events_per_read=int(native.max_events_per_read),
        reserved_detail_bytes_per_event=int(native.reserved_detail_bytes_per_event),
        reserved_latency_bucket_count=int(native.reserved_latency_bucket_count),
        signal_reserved=bool(native.signal_reserved),
        policy=_monitor_policy(native.policy),
    )


def _monitor_event(native: _MonitorEvent) -> MonitorEvent:
    size = int(native.detail_size)
    if size > MONITOR_EVENT_DETAIL_BYTES:
        raise RuntimeError("Core monitor detail exceeds its public buffer")
    detail = ctypes.string_at(
        ctypes.addressof(native) + _MonitorEvent.detail.offset, size
    ).decode("utf-8", "replace")
    return MonitorEvent(
        kind=MonitorEventKind(int(native.kind)),
        sequence=int(native.sequence),
        change_sequence=int(native.change_sequence),
        config_generation=int(native.config_generation),
        collection_epoch=int(native.collection_epoch),
        observed_monotonic_ns=int(native.observed_monotonic_ns),
        category=MonitorCategory(int(native.category)),
        failure_reason=int(native.failure_reason),
        queue_scope=int(native.queue_scope),
        queue_depth=int(native.queue_depth),
        queue_capacity=int(native.queue_capacity),
        exchange=ExchangeId(int(native.exchange.slot), int(native.exchange.generation)),
        detail=detail,
    )
