"""Bounded buffered service facade over the callback-free Core ABI."""

from __future__ import annotations

import queue
import threading
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, replace
from typing import Final, Self

from .core import Configuration, Core, CoreError
from .values import (
    BodyDelivery,
    BodyPolicy,
    EventKind,
    Health,
    Limits,
    Listener,
    Request,
    Response,
    Route,
    TIMEOUT_FOREVER,
)

Handler = Callable[[Request], Response]

_METHOD_BYTES: Final = frozenset(
    b"!#$%&'*+-.^_`|~0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
)
_DEFAULT_WORKERS: Final = 1
_DEFAULT_QUEUE_CAPACITY: Final = 256
_DEFAULT_RETAINED_BYTES: Final = 8 << 20
_DEFAULT_CLOSE_TIMEOUT_MS: Final = 30_000
_MAX_WORKERS: Final = 1_024
_MAX_ROUTES: Final = 65_536
_ERROR_CAPACITY: Final = 64
_WAIT_SLICE_SECONDS: Final = 0.01
_ERROR_DETAIL_BYTES: Final = 1_024


class ServiceError(RuntimeError):
    """Bounded Python-owned diagnostic retained by :class:`Service`."""

    def __init__(self, original_type: str, detail: str) -> None:
        """Create a traceback-free diagnostic from bounded copied text."""
        self.original_type = original_type
        self.detail = detail
        super().__init__(f"{original_type}: {detail}" if detail else original_type)


@dataclass(frozen=True, slots=True)
class _WorkItem:
    handler: Handler
    request: Request
    retained_bytes: int


class Builder:
    """Single-use builder for one buffered native-owned HTTP service.

    The facade copies a leased request into Python-owned values, releases the
    native lease, and then admits the request to a finite Python worker queue.
    Streaming, WebSocket, outbound, rebind, and monitor users should use the
    typed :class:`coakka_http.Core` surface directly.
    """

    __slots__ = (
        "_close_timeout_ms",
        "_handlers",
        "_limits",
        "_listener",
        "_max_retained_bytes",
        "_next_route_id",
        "_queue_capacity",
        "_routes",
        "_started",
        "_workers",
    )

    def __init__(self) -> None:
        """Create a loopback HTTP/1.1 builder with finite dispatch defaults."""
        self._listener = Listener()
        self._limits = Limits()
        self._workers = _DEFAULT_WORKERS
        self._queue_capacity = _DEFAULT_QUEUE_CAPACITY
        self._max_retained_bytes = _DEFAULT_RETAINED_BYTES
        self._close_timeout_ms = _DEFAULT_CLOSE_TIMEOUT_MS
        self._routes: list[Route] = []
        self._handlers: dict[int, Handler] = {}
        self._next_route_id = 1
        self._started = False

    def listener(self, listener: Listener) -> Self:
        """Set the complete listener declaration, including TLS fields."""
        self._ensure_mutable()
        if not isinstance(listener, Listener):
            raise TypeError("listener must be a Listener value")
        self._listener = listener
        return self

    def listen(self, host: str, port: int) -> Self:
        """Replace only the bind address and port of the current listener."""
        self._ensure_mutable()
        if not isinstance(host, str) or not host.strip() or "\0" in host:
            raise ValueError("listener host is invalid")
        if (
            isinstance(port, bool)
            or not isinstance(port, int)
            or not 0 <= port <= 65_535
        ):
            raise ValueError("listener port is invalid")
        self._listener = replace(self._listener, bind_address=host, port=port)
        return self

    def concurrency(self, workers: int) -> Self:
        """Set the finite number of Python handler worker threads."""
        self._ensure_mutable()
        if (
            isinstance(workers, bool)
            or not isinstance(workers, int)
            or not 1 <= workers <= _MAX_WORKERS
        ):
            raise ValueError("worker count is invalid")
        self._workers = workers
        return self

    def dispatch_queue(self, capacity: int) -> Self:
        """Set the bounded copied-request queue capacity."""
        self._ensure_mutable()
        if (
            isinstance(capacity, bool)
            or not isinstance(capacity, int)
            or not 1 <= capacity <= (1 << 31) - 1
        ):
            raise ValueError("dispatch queue capacity is invalid")
        self._queue_capacity = capacity
        return self

    def dispatch_bytes(self, maximum: int) -> Self:
        """Set the aggregate byte ceiling for queued and running requests."""
        self._ensure_mutable()
        if (
            isinstance(maximum, bool)
            or not isinstance(maximum, int)
            or not 1 <= maximum <= (1 << 63) - 1
        ):
            raise ValueError("dispatch byte capacity is invalid")
        self._max_retained_bytes = maximum
        return self

    def close_timeout(self, timeout_ms: int) -> Self:
        """Set the monotonic facade drain/join timeout in milliseconds."""
        self._ensure_mutable()
        if (
            isinstance(timeout_ms, bool)
            or not isinstance(timeout_ms, int)
            or timeout_ms < 1
        ):
            raise ValueError("close timeout is invalid")
        self._close_timeout_ms = timeout_ms
        return self

    def limits(self, limits: Limits) -> Self:
        """Replace the complete construction-time Core resource ceilings."""
        self._ensure_mutable()
        if not isinstance(limits, Limits):
            raise TypeError("limits must be a Limits value")
        self._limits = limits
        return self

    def add_route(self, route: Route, handler: Handler) -> Self:
        """Register an explicit inline route and its Python handler binding."""
        self._ensure_mutable()
        if not isinstance(route, Route):
            raise TypeError("route must be a Route value")
        if route.body_delivery is not BodyDelivery.INLINE:
            raise ValueError("buffered Service accepts only inline-body routes")
        if not callable(handler):
            raise TypeError("route handler is not callable")
        if len(self._routes) >= _MAX_ROUTES:
            raise ValueError("route count exceeds the facade bound")
        binding_id = route.handler_binding_id or route.id
        if binding_id <= 0 or binding_id in self._handlers:
            raise ValueError("handler binding identity is invalid or duplicated")
        if any(existing.id == route.id for existing in self._routes):
            raise ValueError("route identity is duplicated")
        effective = replace(route, handler_binding_id=binding_id)
        self._routes.append(effective)
        self._handlers[binding_id] = handler
        self._next_route_id = max(self._next_route_id, route.id + 1)
        return self

    def route(
        self,
        method: str,
        pattern: str,
        handler: Handler,
        *,
        body_policy: BodyPolicy | None = None,
        request_capture_profile_id: int = 0,
    ) -> Self:
        """Register a generated-identity buffered route and handler."""
        self._ensure_mutable()
        normalized = method.strip().upper() if isinstance(method, str) else ""
        try:
            method_bytes = normalized.encode("ascii", "strict")
        except UnicodeEncodeError as error:
            raise ValueError("route method is invalid") from error
        if not method_bytes or any(byte not in _METHOD_BYTES for byte in method_bytes):
            raise ValueError("route method is invalid")
        if (
            not isinstance(pattern, str)
            or not pattern.startswith("/")
            or "\0" in pattern
        ):
            raise ValueError("route pattern is invalid")
        policy = BodyPolicy() if body_policy is None else body_policy
        if not isinstance(policy, BodyPolicy):
            raise TypeError("body_policy must be a BodyPolicy value")
        route = Route(
            id=self._next_route_id,
            method=normalized,
            pattern=pattern,
            handler_binding_id=self._next_route_id,
            request_capture_profile_id=request_capture_profile_id,
            body_policy=policy,
        )
        return self.add_route(route, handler)

    def get(self, pattern: str, handler: Handler) -> Self:
        """Register a buffered GET route."""
        return self.route("GET", pattern, handler)

    def post(self, pattern: str, handler: Handler) -> Self:
        """Register a buffered POST route."""
        return self.route("POST", pattern, handler)

    def put(self, pattern: str, handler: Handler) -> Self:
        """Register a buffered PUT route."""
        return self.route("PUT", pattern, handler)

    def patch(self, pattern: str, handler: Handler) -> Self:
        """Register a buffered PATCH route."""
        return self.route("PATCH", pattern, handler)

    def delete(self, pattern: str, handler: Handler) -> Self:
        """Register a buffered DELETE route."""
        return self.route("DELETE", pattern, handler)

    def start(self) -> Service:
        """Create Core, start native admission, and start bounded dispatch."""
        self._ensure_mutable()
        if not self._routes:
            raise ValueError("at least one route is required")
        self._started = True
        configuration = Configuration()
        core: Core | None = None
        try:
            configuration.set_limits(self._limits)
            configuration.add_listener(self._listener)
            for route in self._routes:
                configuration.add_route(route)
            core = configuration.create_core()
        finally:
            configuration.close()
        try:
            core.start()
            return Service(
                core,
                dict(self._handlers),
                tuple(self._routes),
                worker_count=self._workers,
                queue_capacity=self._queue_capacity,
                max_retained_bytes=self._max_retained_bytes,
                close_timeout_ms=self._close_timeout_ms,
            )
        except BaseException:
            if core is not None:
                core.close()
            raise

    def _ensure_mutable(self) -> None:
        if self._started:
            raise RuntimeError("builder has already started a service")


class Service:
    """Lifecycle owner for a Core plus one reader and finite worker set."""

    __slots__ = (
        "_active_by_binding",
        "_close_lock",
        "_close_timeout_ms",
        "_closed",
        "_core",
        "_error_lock",
        "_errors",
        "_handlers",
        "_pending",
        "_pending_condition",
        "_queue",
        "_reader",
        "_retained_byte_capacity",
        "_retained_bytes",
        "_routes",
        "_stopping",
        "_unbound_active",
        "_workers",
    )

    def __init__(
        self,
        core: Core,
        handlers: dict[int, Handler],
        routes: tuple[Route, ...],
        *,
        worker_count: int,
        queue_capacity: int,
        max_retained_bytes: int,
        close_timeout_ms: int,
    ) -> None:
        """Adopt a started Core and start its sole inbound reader."""
        self._core = core
        self._handlers = handlers
        self._routes = routes
        self._queue: queue.Queue[_WorkItem | None] = queue.Queue(queue_capacity)
        self._stopping = threading.Event()
        self._close_lock = threading.Lock()
        self._error_lock = threading.Lock()
        self._pending_condition = threading.Condition()
        self._errors: deque[ServiceError] = deque(maxlen=_ERROR_CAPACITY)
        # One scalar per finite route avoids retaining request identities while
        # still proving that every app-owned terminal lease has been drained.
        self._active_by_binding = {binding: 0 for binding in handlers}
        self._unbound_active = 0
        self._pending = 0
        self._retained_bytes = 0
        self._retained_byte_capacity = max_retained_bytes
        self._closed = False
        self._close_timeout_ms = close_timeout_ms
        self._reader = threading.Thread(
            target=self._read_events,
            name="coakka-http-events",
        )
        self._workers = tuple(
            threading.Thread(
                target=self._run_worker,
                name=f"coakka-http-handler-{index}",
            )
            for index in range(worker_count)
        )
        started: list[threading.Thread] = []
        try:
            for worker in self._workers:
                worker.start()
                started.append(worker)
            self._reader.start()
            started.append(self._reader)
        except BaseException:
            self._stopping.set()
            worker_count = sum(thread is not self._reader for thread in started)
            for _worker in range(worker_count):
                self._queue.put(None)
            if self._reader in started:
                self._core.interrupt()
            for thread in started:
                thread.join()
            raise

    @property
    def port(self) -> int:
        """Return the actual bound port of the native listener."""
        with self._close_lock:
            if self._closed:
                raise RuntimeError("service is closed")
            return self._core.port

    @property
    def routes(self) -> tuple[Route, ...]:
        """Return the immutable routes installed by this facade."""
        return self._routes

    def health(self) -> Health:
        """Copy the current Core health snapshot."""
        with self._close_lock:
            if self._closed:
                raise RuntimeError("service is closed")
            return self._core.health()

    def poll_error(self) -> ServiceError | None:
        """Remove the oldest bounded reader, handler, or submission error."""
        with self._error_lock:
            return self._errors.popleft() if self._errors else None

    def close(self, timeout_ms: int | None = None) -> None:
        """Drain, join readers and workers, then stop and destroy Core.

        Drain includes matching every copied app request with its consumed
        terminal lease. A timeout fails closed without destroying resources
        still reachable by a Python handler. The owner may retry later.
        """
        timeout = self._close_timeout_ms if timeout_ms is None else timeout_ms
        if isinstance(timeout, bool) or not isinstance(timeout, int) or timeout < 1:
            raise ValueError("close timeout is invalid")
        deadline = time.monotonic() + (timeout / 1_000)
        with self._close_lock:
            if self._closed:
                return
            self._core.drain()
            self._wait_for_drain(deadline)
            self._stopping.set()
            self._core.interrupt()
            self._join(self._reader, deadline, "Core event reader")
            alive_workers = tuple(
                worker for worker in self._workers if worker.is_alive()
            )
            for _worker in alive_workers:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError("timed out stopping Python handler workers")
                try:
                    self._queue.put(None, timeout=remaining)
                except queue.Full as error:
                    raise TimeoutError(
                        "timed out stopping Python handler workers"
                    ) from error
            for worker in alive_workers:
                self._join(worker, deadline, "Python handler worker")
            self._core.stop()
            self._core.close()
            self._closed = True

    def __enter__(self) -> Self:
        """Return this running service for scoped ownership."""
        with self._close_lock:
            if self._closed:
                raise RuntimeError("service is closed")
            return self

    def __exit__(self, _type: object, _value: object, _traceback: object) -> None:
        """Drain and destroy this service on scope exit."""
        self.close()

    def _record(self, error: BaseException) -> None:
        original_type = type(error).__name__[:128]
        try:
            encoded = str(error).encode("utf-8", "replace")[:_ERROR_DETAIL_BYTES]
            detail = encoded.decode("utf-8", "replace")
        except BaseException:  # noqa: BLE001
            detail = "diagnostic conversion failed"
        with self._error_lock:
            self._errors.append(ServiceError(original_type, detail))

    def _read_events(self) -> None:
        while not self._stopping.is_set():
            try:
                lease = self._core.take_event(TIMEOUT_FOREVER)
                if lease is None:
                    continue
                request: Request | None = None
                with lease:
                    if lease.kind is EventKind.REQUEST:
                        request = lease.request()
                        self._track_request(request.handler_binding_id)
                    elif lease.kind is EventKind.TERMINAL:
                        self._track_terminal(lease.handler_binding_id)
                if request is not None:
                    self._admit(request)
            except CoreError as error:
                if self._stopping.is_set():
                    return
                self._fail_reader(error)
                return
            except BaseException as error:  # noqa: BLE001
                self._fail_reader(error)
                return

    def _track_request(self, binding_id: int) -> None:
        with self._pending_condition:
            if binding_id in self._active_by_binding:
                self._active_by_binding[binding_id] += 1
            else:
                self._unbound_active += 1

    def _track_terminal(self, binding_id: int) -> None:
        with self._pending_condition:
            active = self._active_by_binding.get(binding_id)
            if active is not None and active > 0:
                self._active_by_binding[binding_id] = active - 1
            elif active is None and self._unbound_active > 0:
                self._unbound_active -= 1
            self._pending_condition.notify_all()

    def _fail_reader(self, error: BaseException) -> None:
        self._record(error)
        try:
            # A dead sole reader cannot safely leave new admission open.
            self._core.drain()
        except BaseException as drain_error:  # noqa: BLE001
            self._record(drain_error)

    def _admit(self, request: Request) -> None:
        handler = self._handlers.get(request.handler_binding_id)
        if handler is None:
            self._reject(request, RuntimeError("request has no Python handler"))
            return
        retained_bytes = _request_bytes(request)
        with self._pending_condition:
            if (
                retained_bytes > self._retained_byte_capacity
                or self._retained_bytes > self._retained_byte_capacity - retained_bytes
            ):
                overloaded = True
            else:
                overloaded = False
                self._retained_bytes += retained_bytes
                self._pending += 1
        if overloaded:
            self._reject(
                request, RuntimeError("Python dispatch byte capacity is full"), 503
            )
            return
        work = _WorkItem(handler, request, retained_bytes)
        try:
            self._queue.put_nowait(work)
        except queue.Full:
            with self._pending_condition:
                self._pending -= 1
                self._retained_bytes -= retained_bytes
                self._pending_condition.notify_all()
            self._reject(request, RuntimeError("Python dispatch queue is full"), 503)

    def _reject(
        self, request: Request, error: BaseException, status: int = 500
    ) -> None:
        self._record(error)
        try:
            detail = (
                b"service unavailable" if status == 503 else b"internal server error"
            )
            self._core.respond(request.exchange, Response(status=status, body=detail))
        except BaseException as submission_error:  # noqa: BLE001
            self._record(submission_error)

    def _run_worker(self) -> None:
        while True:
            work = self._queue.get()
            if work is None:
                return
            try:
                try:
                    response = work.handler(work.request)
                    if not isinstance(response, Response):
                        raise TypeError("a CoAkka HTTP handler must return Response")
                except BaseException as error:  # noqa: BLE001
                    self._reject(work.request, error)
                else:
                    try:
                        self._core.respond(work.request.exchange, response)
                    except BaseException as error:  # noqa: BLE001
                        self._record(error)
            finally:
                with self._pending_condition:
                    self._pending -= 1
                    self._retained_bytes -= work.retained_bytes
                    self._pending_condition.notify_all()

    def _wait_for_drain(self, deadline: float) -> None:
        while True:
            with self._pending_condition:
                pending = self._pending
                active = self._unbound_active + sum(self._active_by_binding.values())
            health = self._core.health()
            if pending == 0 and active == 0 and health.server_active_exchanges == 0:
                return
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("timed out draining Python service")
            with self._pending_condition:
                self._pending_condition.wait(min(remaining, _WAIT_SLICE_SECONDS))

    @staticmethod
    def _join(thread: threading.Thread, deadline: float, owner: str) -> None:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(f"timed out joining {owner}")
        thread.join(remaining)
        if thread.is_alive():
            raise TimeoutError(f"timed out joining {owner}")


def _request_bytes(request: Request) -> int:
    """Return retained application bytes; item count bounds object overhead."""
    total = len(request.method.encode("ascii"))
    total += len(request.scheme.encode("ascii"))
    total += len(request.authority.encode("utf-8"))
    total += len(request.target.encode("utf-8")) + len(request.body)
    for header in (*request.headers, *request.trailers):
        total += len(header.name.encode("ascii"))
        total += len(header.value.encode("latin-1"))
    for path_parameter in request.path_parameters:
        total += len(path_parameter.name.encode("utf-8"))
        total += len(path_parameter.encoded_value.encode("utf-8"))
    for query_parameter in request.query_parameters:
        total += len(query_parameter.encoded_key.encode("utf-8"))
        total += len(query_parameter.encoded_value.encode("utf-8"))
    return total
