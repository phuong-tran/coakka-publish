"""Typed, Python-owned values for the public CoAkka HTTP Core ABI."""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from dataclasses import dataclass, field
from enum import IntEnum, IntFlag
from typing import Final

_HEADER_NAME_BYTES: Final = frozenset(
    b"!#$%&'*+-.^_`|~0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
)

# Exact scalar bounds exported by the installed public C header.
ABI_VERSION: Final = 2
RESULT_DETAIL_CAPACITY: Final = 192
TERMINAL_DETAIL_CAPACITY: Final = 1_024
TIMEOUT_FOREVER: Final = (1 << 64) - 1
MONITOR_MAX_FAILURE_COUNTS: Final = 48
MONITOR_FIXED_LATENCY_BUCKETS: Final = 16
MONITOR_MAX_EVENT_DETAIL_BYTES: Final = 128
MONITOR_MAX_EVENTS_PER_READ: Final = 64


class Capability(IntFlag):
    """Feature bits implemented by the loaded Core image."""

    INBOUND = 1
    TLS = 2
    MUTUAL_TLS = 4
    GZIP = 8
    REQUEST_STREAM = 16
    RESPONSE_STREAM = 32
    RESPONSE_TRAILERS = 64
    RESPONSE_WRITE_TIMEOUT = 128
    SERVER_SENT_EVENTS = 256
    WEBSOCKET = 512
    HTTP_2 = 1024
    HTTP_3 = 2048
    STATIC_FILES = 4096
    APPLICATION_FILES = 8192
    OUTBOUND = 16384
    ROUTE_REBIND = 32768
    OUTBOUND_LOGICAL_TARGET = 65536
    STATIC_FRONTEND = 131072
    HEALTH = 262144
    MONITOR = 524288


class ResultCode(IntEnum):
    """Stable result codes returned by fallible Core operations."""

    OK = 0
    INVALID_ARGUMENT = 1
    INVALID_STATE = 2
    LIMIT_EXCEEDED = 3
    QUEUE_FULL = 4
    TIMEOUT = 5
    CLOSED = 6
    CANCELLED = 7
    OUT_OF_MEMORY = 8
    UNSUPPORTED = 9
    SYSTEM_ERROR = 10
    INTERNAL = 11
    NOT_FOUND = 12
    UNAVAILABLE = 13


class ListenerProtocol(IntEnum):
    """Application protocol selected for one native listener."""

    HTTP_1_1 = 1
    HTTP_2 = 2
    HTTP_3 = 3


class TransportSecurity(IntEnum):
    """Transport security mode for listeners and outbound endpoints."""

    PLAINTEXT = 1
    TLS = 2
    MUTUAL_TLS = 3


class BodyDelivery(IntEnum):
    """How Core delivers one admitted request body."""

    INLINE = 1
    STREAM = 2


class CompressionMode(IntEnum):
    """Construction-time response compression mode."""

    DISABLED = 1
    GZIP = 2


class IoBackend(IntEnum):
    """Native I/O backend selection."""

    PLATFORM_DEFAULT = 1
    IO_URING = 2


class WaitMode(IntEnum):
    """Native connector-lane wait strategy."""

    BLOCKING = 1
    ADAPTIVE = 2
    BUSY_POLL = 3


class EventKind(IntEnum):
    """Inbound and terminal event kinds returned by ``Core.take_event``."""

    REQUEST = 1
    REQUEST_DATA = 2
    REQUEST_TRAILERS = 3
    REQUEST_END = 4
    REQUEST_CANCELLED = 5
    RESPONSE_WRITABLE = 6
    TERMINAL = 7


class ExchangeOutcome(IntEnum):
    """Stable final outcome for an inbound exchange."""

    COMPLETED = 1
    TIMED_OUT = 2
    DISCONNECTED = 3
    CANCELLED = 4
    FAILED = 5
    STOPPED = 6


class WebSocketEventKind(IntEnum):
    """WebSocket event or copied-send kind."""

    OPEN = 1
    TEXT = 2
    BINARY = 3
    PING = 4
    PONG = 5
    WRITABLE = 6
    CLOSE = 7
    ACCEPT_FAILED = 8


class OutboundStrategy(IntEnum):
    """Selection strategy for a logical outbound target."""

    SINGLE_OWNER = 1
    WEIGHTED_ROUND_ROBIN = 2


class MonitorCollection(IntEnum):
    """Amount of monitoring truth retained by Core."""

    DISABLED = 0
    AGGREGATES = 1
    AGGREGATES_AND_EVENTS = 2


class MonitorNotification(IntEnum):
    """How monitor readers learn that newer truth exists."""

    POLL = 0
    SIGNAL = 1


class MonitorLatency(IntEnum):
    """Latency collection mode."""

    NONE = 0
    FIXED = 1


class MonitorDetail(IntEnum):
    """Bounded diagnostic detail policy."""

    NONE = 0
    RUNTIME_SAFE = 1


class MonitorCategory(IntFlag):
    """Aggregate and event category selection bits."""

    LIFECYCLE = 1 << 0
    CONFIG = 1 << 1
    CONNECTION = 1 << 2
    TRAFFIC = 1 << 3
    HTTP = 1 << 4
    EXCHANGE = 1 << 5
    QUEUE = 1 << 6
    FAILURE = 1 << 7
    TLS = 1 << 8
    CONNECTOR = 1 << 9
    RESPONSE = 1 << 10
    LATENCY = 1 << 11


class MonitorApplyReason(IntEnum):
    """Typed outcome of applying a live monitor policy."""

    APPLIED = 0
    INVALID_ARGUMENT = 1
    INVALID_ENUM = 2
    UNSUPPORTED_CATEGORY = 3
    INVALID_CATEGORY_RELATIONSHIP = 4
    RESOURCE_RESERVATION_EXCEEDED = 5
    SIGNAL_NOT_RESERVED = 6
    GENERATION_CONFLICT = 7
    INVALID_LIFECYCLE = 8
    SEQUENCE_EXHAUSTED = 9
    INTERNAL = 10


class MonitorEventKind(IntEnum):
    """Kinds of bounded operational monitor events."""

    LIFECYCLE_CHANGED = 1
    POLICY_APPLIED = 2
    POLICY_REJECTED = 3
    EXCHANGE_COMPLETED = 4
    EXCHANGE_FAILED = 5
    EXCHANGE_TIMED_OUT = 6
    EXCHANGE_DISCONNECTED = 7
    EXCHANGE_CANCELLED = 8


@dataclass(frozen=True, slots=True)
class Header:
    """One immutable HTTP header with bounded byte-representable fields."""

    name: str
    value: str

    def __post_init__(self) -> None:
        """Reject malformed fields before they cross the native boundary."""
        try:
            encoded_name = self.name.encode("ascii")
            encoded_value = self.value.encode("latin-1")
        except UnicodeEncodeError as error:
            raise ValueError("HTTP header is not byte representable") from error
        if not encoded_name or any(
            byte not in _HEADER_NAME_BYTES for byte in encoded_name
        ):
            raise ValueError("HTTP header name is invalid")
        if b"\x00" in encoded_value or b"\r" in encoded_value or b"\n" in encoded_value:
            raise ValueError("HTTP header value is invalid")


class Headers:
    """Immutable ordered HTTP headers with case-insensitive lookup."""

    __slots__ = ("_entries",)

    def __init__(self, entries: Iterable[Header] = ()) -> None:
        """Own a validated tuple while preserving order and duplicates."""
        values = tuple(entries)
        if any(not isinstance(entry, Header) for entry in values):
            raise TypeError("headers must contain Header values")
        self._entries = values

    def __len__(self) -> int:
        """Return the number of entries, including duplicate names."""
        return len(self._entries)

    def __iter__(self) -> Iterator[Header]:
        """Iterate in declaration or wire order."""
        return iter(self._entries)

    def __getitem__(self, name: str) -> str:
        """Return the first value for ``name`` using ASCII-insensitive lookup."""
        lowered = name.lower()
        for entry in self._entries:
            if entry.name.lower() == lowered:
                return entry.value
        raise KeyError(name)

    def get(self, name: str, default: str | None = None) -> str | None:
        """Return the first value for ``name`` or ``default`` when absent."""
        try:
            return self[name]
        except KeyError:
            return default

    def get_all(self, name: str) -> tuple[str, ...]:
        """Return every value for ``name`` in wire order."""
        lowered = name.lower()
        return tuple(
            entry.value for entry in self._entries if entry.name.lower() == lowered
        )


@dataclass(frozen=True, slots=True)
class ExchangeId:
    """Stable generation-checked identity for one inbound exchange."""

    slot: int
    generation: int


@dataclass(frozen=True, slots=True)
class WebSocketId:
    """Stable generation-checked identity for one WebSocket session."""

    slot: int
    generation: int


@dataclass(frozen=True, slots=True)
class OutboundId:
    """Stable generation-checked identity for one outbound call."""

    slot: int
    generation: int


@dataclass(frozen=True, slots=True)
class Listener:
    """Construction-copied listener, protocol, and TLS declaration."""

    listener_id: int = 1
    bind_address: str = "127.0.0.1"
    port: int = 0
    protocol: ListenerProtocol = ListenerProtocol.HTTP_1_1
    security: TransportSecurity = TransportSecurity.PLAINTEXT
    credential_generation: int = 0
    credential_id: str = ""
    certificate_chain_file: str = ""
    private_key_file: str = ""
    trust_roots_file: str = ""


@dataclass(frozen=True, slots=True)
class BodyPolicy:
    """Optional route body admission policy enforced by Core."""

    enabled: bool = False
    accept_absent: bool = False
    accept_other: bool = False
    accept_form_urlencoded: bool = False
    accept_multipart_form_data: bool = False
    max_body_bytes: int = 0


@dataclass(frozen=True, slots=True)
class Route:
    """Construction-copied route and connector binding identity."""

    id: int
    method: str
    pattern: str
    handler_binding_id: int = 0
    request_capture_profile_id: int = 0
    body_delivery: BodyDelivery = BodyDelivery.INLINE
    body_policy: BodyPolicy = field(default_factory=BodyPolicy)


@dataclass(frozen=True, slots=True)
class Limits:
    """Complete Core resource ceilings; zero selects a Core-owned default."""

    event_loop_threads: int = 0
    max_listeners: int = 0
    max_connections: int = 0
    max_active_exchanges: int = 0
    request_queue_depth: int = 0
    completion_queue_depth: int = 0
    completion_batch_size: int = 0
    max_header_count: int = 0
    max_header_bytes: int = 0
    max_routes: int = 0
    max_route_segments: int = 0
    max_captures_per_route: int = 0
    request_stream_chunk_slots: int = 0
    request_stream_max_retained_items: int = 0
    response_stream_chunk_slots: int = 0
    response_stream_max_retained_items: int = 0
    max_static_mounts: int = 0
    max_total_static_files: int = 0
    max_file_authorities: int = 0
    route_rebind_command_capacity: int = 0
    route_rebind_history_capacity: int = 0
    route_rebind_max_commands_per_turn: int = 0
    terminal_observation_queue_depth: int = 0
    deadline_tick_ms: int = 0
    connection_timeout_batch_size: int = 0
    max_request_body_bytes: int = 0
    max_response_body_bytes: int = 0
    max_serialized_request_bytes: int = 0
    max_serialized_response_bytes: int = 0
    max_total_request_body_bytes: int = 0
    max_total_response_body_bytes: int = 0
    max_total_serialized_request_bytes: int = 0
    max_total_serialized_response_bytes: int = 0
    keep_alive_timeout_ms: int = 0
    header_timeout_ms: int = 0
    body_timeout_ms: int = 0
    app_host_timeout_ms: int = 0
    idle_timeout_ms: int = 0
    drain_timeout_ms: int = 0
    stop_timeout_ms: int = 0
    response_write_timeout_ms: int = 0
    request_stream_max_chunk_bytes: int = 0
    request_stream_max_trailer_bytes: int = 0
    request_stream_max_retained_bytes: int = 0
    request_stream_max_total_retained_bytes: int = 0
    response_stream_max_chunk_bytes: int = 0
    response_stream_max_trailer_bytes: int = 0
    response_stream_max_retained_bytes: int = 0
    response_stream_max_total_retained_bytes: int = 0
    max_route_manifest_bytes: int = 0
    max_total_route_metadata_bytes: int = 0
    max_serialized_terminal_observation_bytes: int = 0
    max_total_serialized_terminal_observation_bytes: int = 0


@dataclass(frozen=True, slots=True)
class StaticMount:
    """Trusted static tree and optional SPA fallback owned by Core."""

    mount_id: int
    url_prefix: str
    root_path: str
    index_file: str | None = None
    cache_control: str | None = None
    spa_fallback_file: str | None = None
    include_dotfiles: bool = False


@dataclass(frozen=True, slots=True)
class FileAuthority:
    """Approved root for application-selected file responses."""

    authority_id: int
    root_path: str
    max_file_bytes: int = 0
    max_active_files: int = 0


@dataclass(frozen=True, slots=True)
class Compression:
    """Construction-fixed bounded response compression policy."""

    mode: CompressionMode = CompressionMode.DISABLED
    minimum_body_bytes: int = 0
    maximum_body_bytes: int = 0
    maximum_encoded_bytes: int = 0
    workspace_bytes: int = 0
    gzip_level: int = 0


@dataclass(frozen=True, slots=True)
class WaitPolicy:
    """Construction-fixed event lane wait strategy."""

    mode: WaitMode = WaitMode.BLOCKING
    spin_iterations: int = 0
    yield_iterations: int = 0


@dataclass(frozen=True, slots=True)
class OutboundLaneLimits:
    """Outbound admission, retention, and terminal queue ceilings."""

    call_capacity: int = 0
    target_profile_capacity: int = 0
    work_batch: int = 0
    max_method_bytes: int = 0
    max_origin_target_bytes: int = 0
    max_profile_component_bytes: int = 0
    max_total_profile_bytes: int = 0
    max_header_count: int = 0
    max_header_name_bytes: int = 0
    max_header_value_bytes: int = 0
    max_header_bytes: int = 0
    max_request_body_bytes: int = 0
    max_total_request_bytes: int = 0
    max_response_head_bytes: int = 0
    max_response_body_bytes: int = 0
    max_total_response_bytes: int = 0
    deadline_tick_ms: int = 0
    stop_timeout_ms: int = 0


@dataclass(frozen=True, slots=True)
class OutboundTransportLimits:
    """Native outbound transport connection and buffer ceilings."""

    active_call_capacity: int = 0
    max_response_header_count: int = 0
    max_response_header_name_bytes: int = 0
    max_response_header_value_bytes: int = 0
    max_response_head_bytes: int = 0
    max_response_body_bytes: int = 0
    max_total_buffer_bytes: int = 0
    max_serialized_url_bytes: int = 0
    max_resolve_entry_bytes: int = 0


@dataclass(frozen=True, slots=True)
class OutboundResolver:
    """Optional bounded DNS resolver configuration."""

    max_resolved_addresses: int = 0
    server_endpoint: str = ""
    socket_capacity: int = 0
    timeout_ms: int = 0
    tries: int = 0


@dataclass(frozen=True, slots=True)
class OutboundPoolLimits:
    """Optional outbound connection-pool ceilings."""

    key_capacity: int = 0
    max_connections_per_key: int = 0
    max_waiting_per_key: int = 0
    max_idle_seconds: int = 0
    max_lifetime_seconds: int = 0


@dataclass(frozen=True, slots=True)
class OutboundTlsLimits:
    """Outbound trust and client-identity retention ceilings."""

    trust_capacity: int = 0
    client_identity_capacity: int = 0
    max_trust_bundle_bytes: int = 0
    max_client_certificate_bytes: int = 0
    max_client_private_key_bytes: int = 0
    max_total_bytes: int = 0


@dataclass(frozen=True, slots=True)
class OutboundRegistryLimits:
    """Logical-target and endpoint registry ceilings."""

    target_capacity: int = 0
    endpoint_capacity: int = 0
    max_endpoints_per_target: int = 0
    max_target_name_bytes: int = 0
    max_node_id_bytes: int = 0
    max_total_bytes: int = 0


@dataclass(frozen=True, slots=True)
class OutboundOptions:
    """Complete construction-time outbound client reservations."""

    resolver_enabled: bool = False
    pool_enabled: bool = False
    lane: OutboundLaneLimits = field(default_factory=OutboundLaneLimits)
    transport: OutboundTransportLimits = field(default_factory=OutboundTransportLimits)
    resolver: OutboundResolver = field(default_factory=OutboundResolver)
    pool: OutboundPoolLimits = field(default_factory=OutboundPoolLimits)
    tls: OutboundTlsLimits = field(default_factory=OutboundTlsLimits)
    registry: OutboundRegistryLimits = field(default_factory=OutboundRegistryLimits)


@dataclass(frozen=True, slots=True)
class InspectionOptions:
    """Opt-in authenticated target-runtime inspection limits."""

    runtime_instance_id: int
    runtime_generation: int
    bearer_file: str
    allow_plaintext_loopback: bool = False
    max_bearer_token_bytes: int = 0
    call_capacity: int = 0
    max_entries_per_turn: int = 0
    snapshot_deadline_ms: int = 0
    max_bytes_per_turn: int = 0
    max_response_bytes: int = 0
    max_total_response_bytes: int = 0


@dataclass(frozen=True, slots=True)
class OutboundEndpoint:
    """One construction-copied endpoint for a logical outbound target."""

    node_id: str
    connect_host: str
    connect_port: int
    http_authority: str
    weight: int = 1
    security: TransportSecurity = TransportSecurity.PLAINTEXT
    available: bool = True
    tls_peer_identity: str = ""
    proxy_mode: int = 1
    protocol_policy: int = 1
    connection_strategy: int = 1
    proxy_identity: str = ""
    tls_trust_generation: int = 0
    tls_client_identity_generation: int = 0
    connection_strategy_generation: int = 0
    local_network_policy_id: int = 0


@dataclass(frozen=True, slots=True)
class OutboundTarget:
    """Logical outbound target with a generation and bounded endpoint set."""

    name: str
    generation: int
    endpoints: tuple[OutboundEndpoint, ...]
    strategy: OutboundStrategy = OutboundStrategy.SINGLE_OWNER


@dataclass(frozen=True, slots=True)
class MonitorOptions:
    """Construction-time monitor reservations and initial collection policy."""

    collection: MonitorCollection = MonitorCollection.DISABLED
    event_capacity: int = 0
    max_events_per_read: int = 0
    detail_bytes_per_event: int = 0
    latency_bucket_count: int = 0
    aggregate_categories: MonitorCategory = MonitorCategory(0)
    event_categories: MonitorCategory = MonitorCategory(0)
    signal_reserved: bool = False
    runtime_safe_detail: bool = False
    fixed_latency_buckets: bool = False


@dataclass(frozen=True, slots=True)
class PathParameter:
    """Route capture name and still-encoded value."""

    name: str
    encoded_value: str


@dataclass(frozen=True, slots=True)
class QueryParameter:
    """Still-encoded query pair preserving absent versus empty values."""

    encoded_key: str
    encoded_value: str
    has_value: bool


@dataclass(frozen=True, slots=True)
class Request:
    """Python-owned copy of one leased inbound request projection."""

    exchange: ExchangeId
    method: str
    scheme: str
    authority: str
    target: str
    headers: Headers
    body: bytes
    body_delivery: BodyDelivery | None
    route_id: int
    route_generation: int
    binding_revision: int
    handler_binding_id: int
    path_parameters: tuple[PathParameter, ...]
    query_parameters: tuple[QueryParameter, ...]
    trailers: Headers
    cancelled: bool

    def text(self, encoding: str = "utf-8") -> str:
        """Decode the copied request body with strict error handling."""
        return self.body.decode(encoding, errors="strict")


@dataclass(frozen=True, slots=True)
class Response:
    """Buffered response copied synchronously by Core on success."""

    status: int = 200
    headers: Headers = field(default_factory=Headers)
    body: bytes = b""

    @classmethod
    def text(
        cls,
        body: str,
        *,
        status: int = 200,
        headers: Headers | Iterable[Header] = (),
    ) -> Response:
        """Create a UTF-8 response with a default text content type."""
        values = headers if isinstance(headers, Headers) else Headers(headers)
        if values.get("content-type") is None:
            values = Headers(
                (*values, Header("content-type", "text/plain; charset=utf-8"))
            )
        return cls(status=status, headers=values, body=body.encode("utf-8"))


@dataclass(frozen=True, slots=True)
class FileResponse:
    """Application-selected file under a configured Core authority."""

    authority_id: int
    encoded_path: str
    status: int = 200
    headers: Headers = field(default_factory=Headers)


@dataclass(frozen=True, slots=True)
class SseEvent:
    """One copied server-sent event write."""

    data: bytes
    event_type: bytes | None = None
    id: bytes | None = None
    retry_ms: int | None = None


@dataclass(frozen=True, slots=True)
class Failure:
    """Typed failure reason and bounded diagnostic submitted to Core."""

    reason: int
    detail: bytes = b""


@dataclass(frozen=True, slots=True)
class TerminalSummary:
    """Python-owned public-safe summary of a terminal observation."""

    outcome: ExchangeOutcome
    response_status: int | None
    failure_domain: int | None
    failure_phase: int | None
    failure_reason: int | None
    retry_disposition: int | None
    http_status_hint: int | None
    detail: str
    detail_size: int
    detail_truncated: bool
    admitted_monotonic_ns: int | None
    dispatched_monotonic_ns: int | None
    response_accepted_monotonic_ns: int | None
    completed_monotonic_ns: int | None


@dataclass(frozen=True, slots=True)
class WebSocketEvent:
    """Python-owned copy of one leased WebSocket event."""

    kind: WebSocketEventKind
    session: WebSocketId
    origin_exchange: ExchangeId
    close_code: int
    data: bytes


@dataclass(frozen=True, slots=True)
class OutboundRequest:
    """Copied logical-target outbound HTTP request."""

    logical_target: str
    method: str
    target: str
    headers: Headers = field(default_factory=Headers)
    body: bytes = b""
    timeout_ms: int = 30_000


@dataclass(frozen=True, slots=True)
class OutboundTerminal:
    """Python-owned copy of one leased outbound terminal result."""

    reason: int
    call: OutboundId
    logical_target: str
    target_generation: int
    selected_node_id: str
    phase: int
    retry: int
    certainty: int
    response_status: int
    provider_code: int
    response_headers: Headers
    response_body: bytes
    diagnostic: str


@dataclass(frozen=True, slots=True)
class Health:
    """Pointer-free Core health snapshot safe to retain."""

    lifecycle: int
    snapshot_sequence: int
    change_sequence: int
    lifecycle_generation: int
    observed_monotonic_ns: int
    progress_sequence: int
    progress_monotonic_ns: int
    acknowledged_probe_sequence: int
    acknowledged_probe_monotonic_ns: int
    configured_components: int
    running_components: int
    failed_components: int
    startup: int
    liveness: int
    readiness: int
    admission_open: bool
    partial: bool
    server_active_exchanges: int
    client_active_calls: int
    client_ready_terminals: int
    client_outstanding_terminal_leases: int
    client_retained_request_bytes: int
    client_retained_target_profile_bytes: int
    client_retained_response_bytes: int
    client_admitted_calls: int
    client_terminal_calls: int
    client_stale_provider_terminals: int


@dataclass(frozen=True, slots=True)
class RouteRebind:
    """Generation-checked handler-binding activation command."""

    activation_id: int
    expected_route_generation: int
    route_id: int
    expected_binding_revision: int
    new_handler_binding_id: int


@dataclass(frozen=True, slots=True)
class RouteRebindOutcome:
    """Stable result of one route rebinding activation."""

    code: int
    activation_id: int
    operation_digest: int
    route_generation: int
    route_id: int
    previous_handler_binding_id: int
    previous_binding_revision: int
    effective_handler_binding_id: int
    effective_binding_revision: int
    binding_change_sequence: int
    retained_previous_exchanges: int
    previous_effective_route_references: int
    changed: bool
    replayed: bool


@dataclass(frozen=True, slots=True)
class MonitorPolicy:
    """Live monitor policy constrained by construction-time reservations."""

    collection: MonitorCollection
    notification: MonitorNotification = MonitorNotification.POLL
    latency: MonitorLatency = MonitorLatency.NONE
    detail: MonitorDetail = MonitorDetail.NONE
    active_event_capacity: int = 0
    active_detail_bytes: int = 0
    aggregate_categories: MonitorCategory = MonitorCategory(0)
    event_categories: MonitorCategory = MonitorCategory(0)


@dataclass(frozen=True, slots=True)
class MonitorConfig:
    """Effective pointer-free monitor configuration."""

    provenance: int
    generation: int
    collection_epoch: int
    change_sequence: int
    epoch_started_monotonic_ns: int
    policy_applied_monotonic_ns: int
    supported_categories: MonitorCategory
    reserved_event_capacity: int
    max_events_per_read: int
    reserved_detail_bytes_per_event: int
    reserved_latency_bucket_count: int
    signal_reserved: bool
    policy: MonitorPolicy


@dataclass(frozen=True, slots=True)
class MonitorApplyOutcome:
    """Applied or typed-rejected monitor policy result."""

    reason: MonitorApplyReason
    actual: int
    limit: int
    changed: bool
    effective: MonitorConfig


@dataclass(frozen=True, slots=True)
class MonitorFailureCount:
    """Count for one stable native failure reason."""

    reason: int
    count: int


@dataclass(frozen=True, slots=True)
class MonitorLatencyBucket:
    """Fixed upper-bound latency bucket and observation count."""

    upper_bound_ns: int
    count: int


@dataclass(frozen=True, slots=True)
class MonitorSnapshot:
    """Bounded aggregate monitoring snapshot safe to retain."""

    collecting: bool
    stale: bool
    partial: bool
    snapshot_sequence: int
    observed_monotonic_ns: int
    collected_change_sequence: int
    inbound_admitted_requests: int
    inbound_request_bytes: int
    exchange_completed: int
    exchange_failed: int
    exchange_timed_out: int
    exchange_disconnected: int
    exchange_cancelled: int
    response_status_family: tuple[int, int, int, int, int]
    retained_events: int
    event_overwrite_count: int
    event_drop_count: int
    signal_notify_count: int
    signal_coalesced_count: int
    signal_failure_count: int
    config: MonitorConfig
    health: Health
    failure_counts: tuple[MonitorFailureCount, ...]
    latency_buckets: tuple[MonitorLatencyBucket, ...]


@dataclass(frozen=True, slots=True)
class MonitorEvent:
    """One copied, payload-free operational monitor event."""

    kind: MonitorEventKind
    sequence: int
    change_sequence: int
    config_generation: int
    collection_epoch: int
    observed_monotonic_ns: int
    category: MonitorCategory
    failure_reason: int
    queue_scope: int
    queue_depth: int
    queue_capacity: int
    exchange: ExchangeId
    detail: str


@dataclass(frozen=True, slots=True)
class MonitorEventPage:
    """Bounded monitor event page plus loss and continuation metadata."""

    events: tuple[MonitorEvent, ...]
    oldest_available_sequence: int
    latest_sequence: int
    missed_events: int
    remaining_events: int
