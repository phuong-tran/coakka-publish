from __future__ import annotations

import asyncio

import httpx

from .values import ClientError, ClientFailure, ClientRequest, ClientResponse


class HttpClient:
    __slots__ = (
        "_client",
        "_closed",
        "_completed",
        "_lock",
        "_max_body",
        "_max_pending",
        "_pending",
        "_rejected",
    )

    def __init__(self, *, max_pending: int, max_body: int) -> None:
        self._client = httpx.AsyncClient(http2=True, follow_redirects=False)
        self._max_pending = max_pending
        self._max_body = max_body
        self._pending = 0
        self._completed = 0
        self._rejected = 0
        self._closed = False
        self._lock = asyncio.Lock()

    @property
    def pending(self) -> int:
        return self._pending

    @property
    def completed(self) -> int:
        return self._completed

    @property
    def rejected(self) -> int:
        return self._rejected

    async def execute(self, request: ClientRequest) -> ClientResponse:
        if not request.method or not request.url or request.timeout <= 0:
            raise ValueError("outbound request is invalid")
        if len(request.body) > self._max_body:
            raise ClientError(
                ClientFailure.CAPACITY, "outbound request body exceeds its bound"
            )
        async with self._lock:
            if self._closed:
                raise ClientError(ClientFailure.CANCELLED, "outbound client is closed")
            if self._pending >= self._max_pending:
                self._rejected += 1
                raise ClientError(
                    ClientFailure.CAPACITY, "outbound request capacity exhausted"
                )
            self._pending += 1
        try:
            timeout = httpx.Timeout(request.timeout)
            async with self._client.stream(
                request.method,
                request.url,
                headers=request.headers,
                content=request.body,
                timeout=timeout,
            ) as response:
                chunks: list[bytes] = []
                size = 0
                async for chunk in response.aiter_bytes():
                    size += len(chunk)
                    if size > self._max_body:
                        raise ClientError(
                            ClientFailure.RESPONSE_TOO_LARGE,
                            "outbound response body exceeds its bound",
                        )
                    chunks.append(chunk)
                result = ClientResponse(
                    status=response.status_code,
                    headers=tuple(
                        (name.encode("ascii"), value.encode("latin-1"))
                        for name, value in response.headers.multi_items()
                    ),
                    body=b"".join(chunks),
                    protocol=response.http_version,
                )
            self._completed += 1
            return result
        except asyncio.CancelledError:
            raise
        except ClientError:
            raise
        except httpx.TimeoutException as error:
            raise ClientError(
                ClientFailure.TIMEOUT, "outbound request timed out"
            ) from error
        except httpx.ConnectError as error:
            raise ClientError(
                ClientFailure.CONNECTION, "outbound connection failed"
            ) from error
        except httpx.HTTPError as error:
            raise ClientError(
                ClientFailure.PROTOCOL, "outbound protocol failed"
            ) from error
        finally:
            async with self._lock:
                self._pending -= 1

    async def close(self) -> None:
        async with self._lock:
            if self._closed:
                return
            await self._client.aclose()
            self._closed = True
