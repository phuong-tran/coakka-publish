from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, replace
from types import MappingProxyType
from urllib.parse import unquote_to_bytes

from .values import EMPTY_PATH_PARAMS, Request

Handler = Callable[[Request], Awaitable[object]]


@dataclass(frozen=True, slots=True)
class Route:
    route_id: int
    method: str
    pattern: str
    handler: Handler
    streaming_request: bool = False
    revision: int = 1
    websocket: bool = False

    def rebind(self, handler: Handler) -> Route:
        return replace(self, handler=handler, revision=self.revision + 1)


@dataclass(frozen=True, slots=True)
class _Segment:
    literal: str | None
    capture: str | None


@dataclass(frozen=True, slots=True)
class _CompiledRoute:
    segments: tuple[_Segment, ...]
    route: Route


class Router:
    __slots__ = ("_exact", "_generic")

    def __init__(self, routes: tuple[Route, ...]) -> None:
        exact: dict[str, dict[bytes, Route]] = {}
        generic: dict[str, list[_CompiledRoute]] = {}
        for route in routes:
            pattern_bytes = route.pattern.encode("utf-8")
            if b"{" not in pattern_bytes and b"%" not in pattern_bytes:
                exact.setdefault(route.method, {})[pattern_bytes] = route
            compiled = _CompiledRoute(_compile_segments(route.pattern), route)
            generic.setdefault(route.method, []).append(compiled)
        self._exact = exact
        self._generic = {method: tuple(items) for method, items in generic.items()}

    def match(
        self, method: str, raw_path: bytes
    ) -> tuple[Route, Mapping[str, str]] | None:
        exact = self._exact.get(method)
        if exact is not None:
            route = exact.get(raw_path)
            if route is not None:
                return route, EMPTY_PATH_PARAMS
        try:
            segments = _decode_segments(raw_path)
        except UnicodeDecodeError:
            return None
        for compiled in self._generic.get(method, ()):
            if len(compiled.segments) != len(segments):
                continue
            captures = None
            for expected, actual in zip(compiled.segments, segments):
                if expected.capture is not None:
                    if actual == "":
                        break
                    if captures is None:
                        captures = {}
                    captures[expected.capture] = actual
                elif expected.literal != actual:
                    break
            else:
                params = (
                    EMPTY_PATH_PARAMS
                    if captures is None
                    else MappingProxyType(captures)
                )
                return compiled.route, params
        return None


def admissible_raw_path(raw_path: bytes) -> bool:
    if not raw_path.startswith(b"/") or b"//" in raw_path:
        return False
    percent = raw_path.find(b"%")
    while percent >= 0:
        escape = raw_path[percent + 1 : percent + 3]
        if percent + 2 >= len(raw_path) or not all(
            value in b"0123456789abcdefABCDEF" for value in escape
        ):
            return False
        percent = raw_path.find(b"%", percent + 3)
    return not (
        raw_path.endswith((b"/.", b"/..")) or b"/./" in raw_path or b"/../" in raw_path
    )


def _compile_segments(pattern: str) -> tuple[_Segment, ...]:
    if pattern == "/":
        return ()
    result = []
    for segment in pattern[1:].split("/"):
        if len(segment) >= 2 and segment[0] == "{" and segment[-1] == "}":
            result.append(_Segment(None, segment[1:-1]))
        else:
            result.append(_Segment(unquote_to_bytes(segment).decode("utf-8"), None))
    return tuple(result)


def _decode_segments(raw_path: bytes) -> tuple[str, ...]:
    if raw_path == b"/":
        return ()
    return tuple(
        unquote_to_bytes(segment).decode("utf-8")
        for segment in raw_path[1:].split(b"/")
    )
