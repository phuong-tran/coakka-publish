from __future__ import annotations

import asyncio
import contextlib
import inspect
import mimetypes
import ssl
from collections import deque
from collections.abc import AsyncIterable, Awaitable, Callable
from dataclasses import dataclass
from email import policy
from email.parser import BytesParser
from email.utils import formatdate, parsedate_to_datetime
from time import monotonic
from typing import Any, cast
from urllib.parse import parse_qsl, unquote

from hypercorn.asyncio.run import worker_serve
from hypercorn.config import Config, Sockets
from hypercorn.utils import wrap_app

from .client import HttpClient
from .routing import Handler, Route, Router, admissible_raw_path
from .validator import validate_routes
from .values import (
    Cancellation,
    EventResponse,
    FormField,
    Health,
    Headers,
    HttpProtocol,
    Inspection,
    MultipartPart,
    Request,
    RequestBody,
    RequestBodyLimitError,
    Response,
    RouteBinding,
    ServerEvent,
    Snapshot,
    StaticContent,
    StreamResponse,
    TlsConfiguration,
)

SUPPORTED_METHODS = frozenset(("GET", "POST", "PUT", "PATCH", "DELETE"))
_MISSING_HANDLER = object()
Message = dict[str, Any]
Receive = Callable[[], Awaitable[Message]]
Send = Callable[[Message], Awaitable[None]]
Scope = dict[str, Any]


class _ResponseCommitted(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class Bounds:
    max_routes: int = 1024
    max_static_mounts: int = 32
    max_active_handlers: int = 256
    max_connections: int = 256
    backlog: int = 256
    max_request_target: int = 8 << 10
    max_request_headers: int = 100
    max_request_header_bytes: int = 1 << 20
    max_request_body: int = 1 << 20
    max_request_chunks: int = 4096
    max_request_chunk_bytes: int = 256 << 10
    max_response_headers: int = 100
    max_response_header_bytes: int = 1 << 20
    max_response_bytes: int = 8 << 20
    max_response_chunks: int = 4096
    max_response_chunk_bytes: int = 256 << 10
    max_form_fields: int = 1024
    max_multipart_parts: int = 128
    max_websocket_message_bytes: int = 1 << 20
    max_outbound_requests: int = 256
    max_outbound_body: int = 8 << 20
    max_errors: int = 64
    shutdown_timeout: float = 5.0

    def validate(self) -> None:
        integers = (
            self.max_routes,
            self.max_static_mounts,
            self.max_active_handlers,
            self.max_connections,
            self.backlog,
            self.max_request_target,
            self.max_request_headers,
            self.max_request_header_bytes,
            self.max_request_body,
            self.max_request_chunks,
            self.max_request_chunk_bytes,
            self.max_response_headers,
            self.max_response_header_bytes,
            self.max_response_bytes,
            self.max_response_chunks,
            self.max_response_chunk_bytes,
            self.max_form_fields,
            self.max_multipart_parts,
            self.max_websocket_message_bytes,
            self.max_outbound_requests,
            self.max_outbound_body,
            self.max_errors,
        )
        if any(value <= 0 for value in integers) or self.shutdown_timeout <= 0:
            raise ValueError("CoAkka HTTP bounds must be positive")
        if any(
            value > 16384
            for value in (
                self.max_routes,
                self.max_active_handlers,
                self.max_connections,
                self.backlog,
                self.max_request_chunks,
                self.max_response_chunks,
            )
        ):
            raise ValueError("CoAkka HTTP concurrency or route bound exceeds 16384")


class Builder:
    __slots__ = (
        "_bounds",
        "_host",
        "_port",
        "_protocols",
        "_routes",
        "_started",
        "_static",
        "_tls",
    )

    def __init__(self) -> None:
        self._host = "127.0.0.1"
        self._port = 0
        self._routes: list[Route] = []
        self._static: list[StaticContent] = []
        self._bounds = Bounds()
        self._protocols: tuple[HttpProtocol, ...] = (
            HttpProtocol.HTTP_1_1,
            HttpProtocol.HTTP_2,
        )
        self._tls: TlsConfiguration | None = None
        self._started = False

    def listen(self, host: str, port: int) -> Builder:
        self._ensure_mutable()
        if not host or not 0 <= port <= 65535:
            raise ValueError("CoAkka HTTP listen address is invalid")
        self._host = host
        self._port = port
        return self

    def bounds(self, value: Bounds) -> Builder:
        self._ensure_mutable()
        value.validate()
        self._bounds = value
        return self

    def protocols(self, *values: HttpProtocol) -> Builder:
        self._ensure_mutable()
        if (
            not values
            or any(not isinstance(value, HttpProtocol) for value in values)
            or len(set(values)) != len(values)
        ):
            raise ValueError("CoAkka HTTP protocol selection is invalid")
        self._protocols = tuple(values)
        return self

    def tls(self, value: TlsConfiguration) -> Builder:
        self._ensure_mutable()
        self._tls = value
        return self

    def route(
        self,
        method: str,
        pattern: str,
        handler: Handler,
        *,
        streaming_request: bool = False,
    ) -> Builder:
        self._ensure_mutable()
        method = method.upper()
        self._validate_route(method, pattern, handler)
        if len(self._routes) >= self._bounds.max_routes:
            raise ValueError("CoAkka HTTP route capacity exhausted")
        self._routes.append(
            Route(
                route_id=len(self._routes) + 1,
                method=method,
                pattern=pattern,
                handler=handler,
                streaming_request=streaming_request,
            )
        )
        return self

    def route_streaming(self, method: str, pattern: str, handler: Handler) -> Builder:
        return self.route(method, pattern, handler, streaming_request=True)

    def websocket(
        self,
        pattern: str,
        handler: Callable[[WebSocketSession, Request], Awaitable[None]],
    ) -> Builder:
        self._ensure_mutable()
        self._validate_route("GET", pattern, handler)
        if len(self._routes) >= self._bounds.max_routes:
            raise ValueError("CoAkka HTTP route capacity exhausted")
        self._routes.append(
            Route(
                route_id=len(self._routes) + 1,
                method="GET",
                pattern=pattern,
                handler=handler,  # type: ignore[arg-type]
                websocket=True,
            )
        )
        return self

    def static(self, content: StaticContent) -> Builder:
        self._ensure_mutable()
        if len(self._static) >= self._bounds.max_static_mounts:
            raise ValueError("CoAkka HTTP static mount capacity exhausted")
        prefix = content.url_prefix
        if not prefix.startswith("/") or (prefix != "/" and prefix.endswith("/")):
            raise ValueError("CoAkka HTTP static URL prefix is invalid")
        root = content.directory.expanduser().resolve()
        if not root.is_dir():
            raise ValueError("CoAkka HTTP static directory is missing")
        if any(item.url_prefix == prefix for item in self._static):
            raise ValueError("CoAkka HTTP static URL prefix is duplicated")
        index = (root / content.index_file).resolve()
        if not index.is_relative_to(root):
            raise ValueError("CoAkka HTTP static index is invalid")
        if "\r" in content.cache_control or "\n" in content.cache_control:
            raise ValueError("CoAkka HTTP static cache control is invalid")
        if content.spa_fallback is not None:
            fallback = (root / content.spa_fallback).resolve()
            if not fallback.is_file() or not fallback.is_relative_to(root):
                raise ValueError("CoAkka HTTP SPA fallback is invalid")
        self._static.append(
            StaticContent(
                prefix,
                root,
                content.spa_fallback,
                content.index_file,
                content.cache_control,
            )
        )
        return self

    def _verb(
        self, method: str, pattern: str, handler: object = _MISSING_HANDLER
    ) -> Any:
        if handler is _MISSING_HANDLER:

            def register(candidate: Handler) -> Handler:
                self.route(method, pattern, candidate)
                return candidate

            return register
        return self.route(method, pattern, handler)  # type: ignore[arg-type]

    def get(self, pattern: str, handler: object = _MISSING_HANDLER) -> Any:
        return self._verb("GET", pattern, handler)

    def post(self, pattern: str, handler: object = _MISSING_HANDLER) -> Any:
        return self._verb("POST", pattern, handler)

    def put(self, pattern: str, handler: object = _MISSING_HANDLER) -> Any:
        return self._verb("PUT", pattern, handler)

    def patch(self, pattern: str, handler: object = _MISSING_HANDLER) -> Any:
        return self._verb("PATCH", pattern, handler)

    def delete(self, pattern: str, handler: object = _MISSING_HANDLER) -> Any:
        return self._verb("DELETE", pattern, handler)

    async def start(self) -> Service:
        if self._started:
            raise RuntimeError("CoAkka HTTP builder can start only once")
        self._started = True
        self._bounds.validate()
        if not self._routes and not self._static:
            raise ValueError("CoAkka HTTP requires at least one route or static mount")
        routes = tuple(self._routes)
        validate_routes(routes)
        tls = self._validate_tls()
        application = _Application(
            self._host,
            routes,
            tuple(self._static),
            self._bounds,
            self._protocols,
            tls is not None,
        )
        config = _server_config(
            self._host,
            self._port,
            self._bounds,
            self._protocols,
            tls,
        )
        sockets = config.create_sockets()
        all_sockets = [*sockets.secure_sockets, *sockets.insecure_sockets]
        if len(all_sockets) != 1 or sockets.quic_sockets:
            _close_sockets(sockets)
            raise RuntimeError("CoAkka HTTP expected exactly one TCP listener")
        port = int(all_sockets[0].getsockname()[1])
        shutdown = asyncio.Event()
        task = asyncio.create_task(
            worker_serve(
                wrap_app(cast(Any, application), config.wsgi_max_body_size, "asgi"),
                config,
                sockets=sockets,
                shutdown_trigger=shutdown.wait,
            )
        )
        try:
            await _wait_started(application, task)
            return Service(
                application, task, shutdown, port, self._bounds.shutdown_timeout
            )
        except BaseException:
            shutdown.set()
            with contextlib.suppress(BaseException):
                await task
            _close_sockets(sockets)
            await application.client.close()
            raise

    def _validate_tls(self) -> TlsConfiguration | None:
        if self._tls is None:
            return None
        certificate = self._tls.certificate.expanduser().resolve()
        key = self._tls.private_key.expanduser().resolve()
        if not certificate.is_file() or not key.is_file():
            raise ValueError("CoAkka HTTP TLS certificate or private key is missing")
        ca = self._tls.ca_certificate
        if self._tls.require_client_certificate and ca is None:
            raise ValueError(
                "CoAkka HTTP client certificate verification requires a CA file"
            )
        resolved_ca = None if ca is None else ca.expanduser().resolve()
        if resolved_ca is not None and not resolved_ca.is_file():
            raise ValueError("CoAkka HTTP TLS CA certificate is missing")
        return TlsConfiguration(
            certificate,
            key,
            resolved_ca,
            self._tls.require_client_certificate,
        )

    def _validate_route(self, method: str, pattern: str, handler: object) -> None:
        if method not in SUPPORTED_METHODS:
            raise ValueError(f"CoAkka HTTP method {method!r} is unsupported")
        if not isinstance(pattern, str) or not pattern.startswith("/"):
            raise ValueError("CoAkka HTTP route pattern is invalid")
        if not inspect.iscoroutinefunction(handler):
            raise TypeError("CoAkka HTTP handlers must be async functions")

    def _ensure_mutable(self) -> None:
        if self._started:
            raise RuntimeError("CoAkka HTTP builder is frozen")


class Service:
    __slots__ = (
        "_app",
        "_close_lock",
        "_closed",
        "_port",
        "_shutdown",
        "_task",
        "_timeout",
    )

    def __init__(
        self,
        app: _Application,
        task: asyncio.Task[None],
        shutdown: asyncio.Event,
        port: int,
        timeout: float,
    ) -> None:
        self._app = app
        self._task = task
        self._shutdown = shutdown
        self._port = port
        self._timeout = timeout
        self._close_lock = asyncio.Lock()
        self._closed = False

    @property
    def port(self) -> int:
        return self._port

    @property
    def client(self) -> HttpClient:
        return self._app.client

    def snapshot(self) -> Snapshot:
        return self._app.snapshot(not self._task.done() and not self._closed)

    def health(self) -> Health:
        running = not self._task.done() and not self._closed
        return Health(
            "ready" if running and self._app.accepting else "stopped",
            running,
            self._app.accepting,
        )

    def inspect(self) -> Inspection:
        return self._app.inspect(self._port)

    def routes(self) -> tuple[RouteBinding, ...]:
        return self._app.bindings()

    def poll_error(self) -> BaseException | None:
        return self._app.poll_error()

    async def rebind(
        self,
        route_id: int,
        expected_revision: int,
        handler: Handler,
    ) -> RouteBinding:
        if not inspect.iscoroutinefunction(handler):
            raise TypeError("CoAkka HTTP handlers must be async functions")
        if self._closed or self._task.done():
            raise RuntimeError("CoAkka HTTP service is not running")
        return await self._app.rebind(route_id, expected_revision, handler)

    async def __aenter__(self) -> Service:
        if self._closed or self._task.done():
            raise RuntimeError("CoAkka HTTP service is not running")
        return self

    async def __aexit__(
        self, _type: object, _value: object, _traceback: object
    ) -> None:
        await self.close()

    async def wait(self) -> None:
        try:
            await asyncio.shield(self._task)
        finally:
            if self._task.done():
                await self._app.client.close()
                self._closed = True

    async def close(self, timeout: float | None = None) -> None:
        limit = self._timeout if timeout is None else timeout
        if limit <= 0:
            raise ValueError("CoAkka HTTP close timeout must be positive")
        async with self._close_lock:
            if self._closed:
                return
            self._app.accepting = False
            self._shutdown.set()
            deadline = monotonic() + limit
            await asyncio.wait_for(
                asyncio.shield(self._task), max(0.001, deadline - monotonic())
            )
            await asyncio.wait_for(
                self._app.client.close(), max(0.001, deadline - monotonic())
            )
            self._closed = True


class WebSocketSession:
    __slots__ = (
        "_accepted",
        "_cancel",
        "_closed",
        "_max_message",
        "_offered",
        "_receive",
        "_send",
    )

    def __init__(
        self,
        scope: Scope,
        receive: Receive,
        send: Send,
        maximum: int,
        cancellation: Cancellation,
    ) -> None:
        self._receive = receive
        self._send = send
        self._max_message = maximum
        self._offered = tuple(scope.get("subprotocols", ()))
        self._accepted = False
        self._closed = False
        self._cancel = cancellation

    @property
    def cancellation(self) -> Cancellation:
        return self._cancel

    async def accept(
        self, subprotocol: str | None = None, headers: Headers = ()
    ) -> None:
        if self._accepted or self._closed:
            raise RuntimeError("WebSocket session cannot be accepted")
        if subprotocol is not None and subprotocol not in self._offered:
            raise ValueError("WebSocket subprotocol was not offered")
        await self._send(
            {
                "type": "websocket.accept",
                "subprotocol": subprotocol,
                "headers": list(headers),
            }
        )
        self._accepted = True

    async def receive(self) -> str | bytes | None:
        message = await self._receive()
        kind = message.get("type")
        if kind == "websocket.disconnect":
            self._closed = True
            self._cancel._cancel()
            return None
        if kind != "websocket.receive":
            raise ValueError("WebSocket event is invalid")
        value = message.get("bytes")
        if value is None:
            value = message.get("text", "")
            size = len(value.encode("utf-8"))
        else:
            value = bytes(value)
            size = len(value)
        if size > self._max_message:
            await self.close(1009)
            raise ValueError("WebSocket message exceeds its bound")
        if not isinstance(value, (str, bytes)):
            raise ValueError("WebSocket message is invalid")
        return value

    async def send_text(self, value: str) -> None:
        if len(value.encode("utf-8")) > self._max_message:
            raise ValueError("WebSocket message exceeds its bound")
        await self._require_open()
        await self._send({"type": "websocket.send", "text": value})

    async def send_bytes(self, value: bytes | bytearray | memoryview) -> None:
        owned = bytes(value)
        if len(owned) > self._max_message:
            raise ValueError("WebSocket message exceeds its bound")
        await self._require_open()
        await self._send({"type": "websocket.send", "bytes": owned})

    async def close(self, code: int = 1000) -> None:
        if self._closed:
            return
        await self._send({"type": "websocket.close", "code": code})
        self._closed = True
        self._cancel._cancel()

    async def _require_open(self) -> None:
        if not self._accepted or self._closed:
            raise RuntimeError("WebSocket session is not open")


class _Application:
    __slots__ = (
        "_active_connections",
        "_bounds",
        "_dispatched",
        "_dropped_errors",
        "_errors",
        "_failed",
        "_host",
        "_pending",
        "_protocols",
        "_rebind_lock",
        "_rejected",
        "_route_generation",
        "_router",
        "_routes",
        "_secure",
        "_started",
        "_static",
        "_websocket_sessions",
        "accepting",
        "client",
    )

    def __init__(
        self,
        host: str,
        routes: tuple[Route, ...],
        static: tuple[StaticContent, ...],
        bounds: Bounds,
        protocols: tuple[HttpProtocol, ...],
        secure: bool,
    ) -> None:
        self._host = host
        self._routes = routes
        self._router = Router(routes)
        self._static = static
        self._bounds = bounds
        self._protocols = protocols
        self._secure = secure
        self._rebind_lock = asyncio.Lock()
        self._started = asyncio.Event()
        self._errors: deque[BaseException] = deque(maxlen=bounds.max_errors)
        self._route_generation = 1
        self._dispatched = 0
        self._rejected = 0
        self._failed = 0
        self._pending = 0
        self._active_connections = 0
        self._websocket_sessions = 0
        self._dropped_errors = 0
        self.accepting = True
        self.client = HttpClient(
            max_pending=bounds.max_outbound_requests,
            max_body=bounds.max_outbound_body,
        )

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        kind = scope.get("type")
        if kind == "lifespan":
            await self._lifespan(receive, send)
        elif kind == "http":
            await self._http(scope, receive, send)
        elif kind == "websocket":
            await self._websocket(scope, receive, send)

    async def _lifespan(self, receive: Receive, send: Send) -> None:
        while True:
            message = await receive()
            if message["type"] == "lifespan.startup":
                self._started.set()
                await send({"type": "lifespan.startup.complete"})
            elif message["type"] == "lifespan.shutdown":
                await send({"type": "lifespan.shutdown.complete"})
                return

    async def _http(self, scope: Scope, receive: Receive, send: Send) -> None:
        if not self.accepting:
            await _send_buffered(send, 503, (), b"service stopping")
            return
        if self._active_connections >= self._bounds.max_connections:
            self._rejected += 1
            await _send_buffered(send, 503, (), b"service busy")
            return
        self._active_connections += 1
        try:
            await self._dispatch_http(scope, receive, send)
        finally:
            self._active_connections -= 1

    async def _dispatch_http(self, scope: Scope, receive: Receive, send: Send) -> None:
        method = str(scope.get("method", ""))
        raw_path = bytes(
            scope.get("raw_path", str(scope.get("path", "")).encode("utf-8"))
        )
        query = bytes(scope.get("query_string", b""))
        target = raw_path if not query else raw_path + b"?" + query
        if len(target) > self._bounds.max_request_target or not admissible_raw_path(
            raw_path
        ):
            self._rejected += 1
            await _send_buffered(send, 414, (), b"request target rejected")
            return
        headers = tuple(
            (bytes(name), bytes(value)) for name, value in scope.get("headers", ())
        )
        if not _headers_within_bounds(
            headers,
            self._bounds.max_request_headers,
            self._bounds.max_request_header_bytes,
        ):
            self._rejected += 1
            await _send_buffered(send, 431, (), b"request headers too large")
            return
        match = self._router.match(method, raw_path)
        if match is None:
            static = await self._static_response(method, raw_path, headers)
            if static is None:
                await _send_buffered(send, 404, (), b"not found")
            else:
                await self._write_response(send, static)
            return
        route, path_params = match
        if route.websocket:
            await _send_buffered(send, 426, (), b"WebSocket upgrade required")
            return
        if self._pending >= self._bounds.max_active_handlers:
            self._rejected += 1
            await _send_buffered(send, 503, (), b"service busy")
            return
        cancellation = Cancellation()
        body_stream = RequestBody(
            receive,
            cancellation,
            max_bytes=self._bounds.max_request_body,
            max_chunk_bytes=self._bounds.max_request_chunk_bytes,
            max_chunks=self._bounds.max_request_chunks,
        )
        body = b""
        form: tuple[FormField, ...] = ()
        multipart: tuple[MultipartPart, ...] = ()
        if not route.streaming_request:
            try:
                body = await body_stream.read()
                form, multipart = _parse_body_values(headers, body, self._bounds)
            except (RequestBodyLimitError, ValueError):
                self._rejected += 1
                await _send_buffered(send, 413, (), b"request body rejected")
                return
            if cancellation.cancelled:
                return
        request = Request(
            method=method,
            target=target,
            raw_path=raw_path,
            path=str(scope.get("path", "")),
            query_string=query,
            headers=headers,
            body=body,
            path_params=path_params,
            body_stream=body_stream if route.streaming_request else None,
            form=form,
            multipart=multipart,
            cancellation=cancellation,
        )
        self._pending += 1
        self._dispatched += 1
        try:
            handler_task: asyncio.Future[object] = asyncio.ensure_future(
                route.handler(request)
            )
            if not route.streaming_request:
                disconnect_task = asyncio.create_task(
                    _watch_disconnect(receive, cancellation)
                )
                done, _pending = await asyncio.wait(
                    (handler_task, disconnect_task),
                    return_when=asyncio.FIRST_COMPLETED,
                )
                if disconnect_task in done and cancellation.cancelled:
                    handler_task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await handler_task
                    return
                disconnect_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await disconnect_task
            result = await handler_task
            await self._write_response(send, result)
        except _ResponseCommitted as error:
            self._failed += 1
            self._record_error(error.__cause__ or error)
        except asyncio.CancelledError:
            cancellation._cancel()
            raise
        except BaseException as error:
            self._failed += 1
            self._record_error(error)
            await _send_buffered(send, 500, (), b"internal server error")
        finally:
            self._pending -= 1

    async def _write_response(self, send: Send, result: object) -> None:
        if isinstance(result, Response):
            headers = _validate_headers(result.headers, self._bounds)
            if (
                not 200 <= result.status <= 599
                or len(result.body) > self._bounds.max_response_bytes
            ):
                raise ValueError("response is outside its configured bound")
            await _send_buffered(send, result.status, headers, result.body)
            return
        if isinstance(result, StreamResponse):
            await self._send_stream(send, result.status, result.headers, result.body)
            return
        if isinstance(result, EventResponse):
            headers = _with_default_header(
                result.headers,
                b"content-type",
                b"text/event-stream; charset=utf-8",
            )

            async def encoded() -> AsyncIterable[bytes]:
                async for event in result.events:
                    if not isinstance(event, ServerEvent):
                        raise TypeError("server event stream yielded an invalid value")
                    yield event.encode()

            await self._send_stream(send, result.status, headers, encoded())
            return
        raise TypeError("handler must return a CoAkka HTTP response")

    async def _send_stream(
        self, send: Send, status: int, headers: Headers, body: AsyncIterable[bytes]
    ) -> None:
        if not 200 <= status <= 599:
            raise ValueError("response status is invalid")
        normalized = _validate_headers(headers, self._bounds)
        await send(
            {
                "type": "http.response.start",
                "status": status,
                "headers": list(normalized),
            }
        )
        try:
            count = 0
            total = 0
            async for value in body:
                chunk = bytes(value)
                count += 1
                total += len(chunk)
                if (
                    len(chunk) > self._bounds.max_response_chunk_bytes
                    or count > self._bounds.max_response_chunks
                    or total > self._bounds.max_response_bytes
                ):
                    raise ValueError("response stream exceeds its configured bound")
                await send(
                    {"type": "http.response.body", "body": chunk, "more_body": True}
                )
            await send({"type": "http.response.body", "body": b"", "more_body": False})
        except asyncio.CancelledError:
            raise
        except BaseException as error:
            with contextlib.suppress(BaseException):
                await send(
                    {"type": "http.response.body", "body": b"", "more_body": False}
                )
            raise _ResponseCommitted("response stream failed after headers") from error

    async def _static_response(
        self, method: str, raw_path: bytes, headers: Headers
    ) -> Response | None:
        if method not in ("GET", "HEAD"):
            return None
        try:
            decoded = unquote(raw_path.decode("ascii"), errors="strict")
        except (UnicodeDecodeError, ValueError):
            return None
        for content in sorted(
            self._static, key=lambda item: len(item.url_prefix), reverse=True
        ):
            if decoded != content.url_prefix and not decoded.startswith(
                content.url_prefix + "/"
            ):
                continue
            relative = decoded[len(content.url_prefix) :].lstrip("/")
            root = content.directory
            candidate = (root / relative).resolve()
            if not candidate.is_relative_to(root):
                return Response.text("not found", status=404)
            if candidate.is_dir():
                candidate = candidate / content.index_file
            accepts_html = (
                b"text/html" in (_first_header(headers, b"accept") or b"").lower()
            )
            if (
                not candidate.is_file()
                and content.spa_fallback is not None
                and accepts_html
            ):
                candidate = (root / content.spa_fallback).resolve()
            if not candidate.is_file() or not candidate.is_relative_to(root):
                return Response.text("not found", status=404)
            stat = candidate.stat()
            size = stat.st_size
            if size > self._bounds.max_response_bytes:
                return Response.text("file too large", status=413)
            modified_seconds = int(stat.st_mtime)
            etag = f'"{size:x}-{modified_seconds * 1000:x}"'.encode("ascii")
            content_type = (
                mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
            )
            response_headers: Headers = (
                (b"etag", etag),
                (
                    b"last-modified",
                    formatdate(modified_seconds, usegmt=True).encode("ascii"),
                ),
                (b"cache-control", content.cache_control.encode("latin-1")),
                (b"accept-ranges", b"bytes"),
                (b"content-type", content_type.encode("ascii")),
            )
            if _first_header(headers, b"if-none-match") == etag or _not_modified(
                _first_header(headers, b"if-modified-since"), modified_seconds
            ):
                return Response(status=304, headers=response_headers)
            body = await asyncio.to_thread(candidate.read_bytes)
            if len(body) != size or len(body) > self._bounds.max_response_bytes:
                raise RuntimeError("static file changed while it was being read")
            range_value = _first_header(headers, b"range")
            parsed_range = _parse_range(range_value, len(body))
            if range_value is not None and parsed_range is None:
                return Response(
                    status=416,
                    headers=(
                        *response_headers,
                        (b"content-range", f"bytes */{size}".encode("ascii")),
                    ),
                )
            start, end = parsed_range or (None, None)
            status = 200
            if start is not None and end is not None:
                status = 206
                response_headers += (
                    (
                        b"content-range",
                        f"bytes {start}-{end}/{len(body)}".encode("ascii"),
                    ),
                )
                body = body[start : end + 1]
            if method == "HEAD":
                response_headers += (
                    (b"content-length", str(len(body)).encode("ascii")),
                )
                body = b""
            return Response(status=status, headers=response_headers, body=body)
        return None

    async def _websocket(self, scope: Scope, receive: Receive, send: Send) -> None:
        raw_path = bytes(
            scope.get("raw_path", str(scope.get("path", "")).encode("utf-8"))
        )
        match = self._router.match("GET", raw_path)
        if match is None or not match[0].websocket or not self.accepting:
            await send({"type": "websocket.close", "code": 1008})
            return
        if self._websocket_sessions + self._pending >= self._bounds.max_active_handlers:
            self._rejected += 1
            await send({"type": "websocket.close", "code": 1013})
            return
        first = await receive()
        if first.get("type") != "websocket.connect":
            await send({"type": "websocket.close", "code": 1002})
            return
        route, path_params = match
        cancellation = Cancellation()
        request = Request(
            method="GET",
            target=raw_path,
            raw_path=raw_path,
            path=str(scope.get("path", "")),
            query_string=bytes(scope.get("query_string", b"")),
            headers=tuple((bytes(a), bytes(b)) for a, b in scope.get("headers", ())),
            path_params=path_params,
            cancellation=cancellation,
        )
        session = WebSocketSession(
            scope,
            receive,
            send,
            self._bounds.max_websocket_message_bytes,
            cancellation,
        )
        self._websocket_sessions += 1
        self._dispatched += 1
        try:
            await route.handler(session, request)  # type: ignore[call-arg, arg-type]
            await session.close()
        except BaseException as error:
            self._failed += 1
            self._record_error(error)
            with contextlib.suppress(BaseException):
                await session.close(1011)
        finally:
            cancellation._cancel()
            self._websocket_sessions -= 1

    def bindings(self) -> tuple[RouteBinding, ...]:
        return tuple(
            RouteBinding(route.route_id, route.method, route.pattern, route.revision)
            for route in self._routes
        )

    async def rebind(
        self, route_id: int, expected_revision: int, handler: Handler
    ) -> RouteBinding:
        async with self._rebind_lock:
            index = next(
                (
                    i
                    for i, route in enumerate(self._routes)
                    if route.route_id == route_id
                ),
                -1,
            )
            if index < 0:
                raise ValueError("route id is unknown")
            previous = self._routes[index]
            if previous.websocket:
                raise ValueError("WebSocket routes cannot be rebound as HTTP handlers")
            if previous.revision != expected_revision:
                raise RuntimeError("route binding revision is stale")
            updated = previous.rebind(handler)
            routes = list(self._routes)
            routes[index] = updated
            self._routes = tuple(routes)
            self._router = Router(self._routes)
            self._route_generation += 1
            return RouteBinding(
                updated.route_id, updated.method, updated.pattern, updated.revision
            )

    def snapshot(self, running: bool) -> Snapshot:
        return Snapshot(
            running=running,
            dispatched=self._dispatched,
            rejected=self._rejected,
            failed=self._failed,
            pending=self._pending,
            max_active_handlers=self._bounds.max_active_handlers,
            active_connections=self._active_connections,
            outbound_pending=self.client.pending,
            outbound_completed=self.client.completed,
            outbound_rejected=self.client.rejected,
            websocket_sessions=self._websocket_sessions,
            route_generation=self._route_generation,
            dropped_errors=self._dropped_errors,
        )

    def inspect(self, port: int) -> Inspection:
        return Inspection(
            host=self._host,
            port=port,
            protocols=self._protocols,
            secure=self._secure,
            routes=self.bindings(),
            static_prefixes=tuple(item.url_prefix for item in self._static),
        )

    def poll_error(self) -> BaseException | None:
        return self._errors.popleft() if self._errors else None

    def _record_error(self, error: BaseException) -> None:
        if len(self._errors) == self._errors.maxlen:
            self._dropped_errors += 1
        self._errors.append(error)


def _server_config(
    host: str,
    port: int,
    bounds: Bounds,
    protocols: tuple[HttpProtocol, ...],
    tls: TlsConfiguration | None,
) -> Config:
    config = Config()
    config.bind = [f"{host}:{port}"]
    config.backlog = bounds.backlog
    config.graceful_timeout = bounds.shutdown_timeout
    config.keep_alive_timeout = 30.0
    config.max_app_queue_size = min(bounds.max_request_chunks, 1024)
    config.websocket_max_message_size = bounds.max_websocket_message_bytes
    config.alpn_protocols = [value.value for value in protocols]
    config.accesslog = None
    config.errorlog = None
    if tls is not None:
        config.certfile = str(tls.certificate)
        config.keyfile = str(tls.private_key)
        if tls.ca_certificate is not None:
            config.ca_certs = str(tls.ca_certificate)
        if tls.require_client_certificate:
            config.verify_mode = ssl.CERT_REQUIRED
    return config


async def _wait_started(application: _Application, task: asyncio.Task[None]) -> None:
    started = asyncio.create_task(application._started.wait())
    done, _pending = await asyncio.wait(
        (started, task), return_when=asyncio.FIRST_COMPLETED
    )
    if task in done:
        started.cancel()
        await task
        raise RuntimeError("CoAkka HTTP server stopped during startup")
    await started
    await asyncio.sleep(0)
    if task.done():
        await task


def _close_sockets(sockets: Sockets) -> None:
    for value in (
        *sockets.secure_sockets,
        *sockets.insecure_sockets,
        *sockets.quic_sockets,
    ):
        with contextlib.suppress(OSError):
            value.close()


def _headers_within_bounds(
    headers: Headers, maximum_count: int, maximum_bytes: int
) -> bool:
    return (
        len(headers) <= maximum_count
        and sum(len(name) + len(value) for name, value in headers) <= maximum_bytes
    )


def _validate_headers(headers: Headers, bounds: Bounds) -> Headers:
    owned = tuple((bytes(name), bytes(value)) for name, value in headers)
    if not _headers_within_bounds(
        owned,
        bounds.max_response_headers,
        bounds.max_response_header_bytes,
    ):
        raise ValueError("response headers exceed their configured bound")
    for name, value in owned:
        if (
            not name
            or any(byte <= 32 or byte >= 127 for byte in name)
            or b"\r" in value
            or b"\n" in value
        ):
            raise ValueError("response header is invalid")
    return owned


async def _send_buffered(
    send: Send, status: int, headers: Headers, body: bytes
) -> None:
    normalized = tuple(headers)
    if not any(name.lower() == b"content-length" for name, _value in normalized):
        normalized += ((b"content-length", str(len(body)).encode("ascii")),)
    await send(
        {"type": "http.response.start", "status": status, "headers": list(normalized)}
    )
    await send({"type": "http.response.body", "body": body, "more_body": False})


async def _watch_disconnect(receive: Receive, cancellation: Cancellation) -> None:
    while True:
        message = await receive()
        if message.get("type") == "http.disconnect":
            cancellation._cancel()
            return
        await asyncio.sleep(0)


def _with_default_header(headers: Headers, name: bytes, value: bytes) -> Headers:
    owned = tuple(headers)
    if any(candidate.lower() == name for candidate, _value in owned):
        return owned
    return (*owned, (name, value))


def _first_header(headers: Headers, name: bytes) -> bytes | None:
    return next(
        (value for candidate, value in headers if candidate.lower() == name), None
    )


def _parse_body_values(
    headers: Headers, body: bytes, bounds: Bounds
) -> tuple[tuple[FormField, ...], tuple[MultipartPart, ...]]:
    content_type_value = _first_header(headers, b"content-type")
    if content_type_value is None:
        return (), ()
    content_type = content_type_value.decode("latin-1")
    if content_type.lower().startswith("application/x-www-form-urlencoded"):
        fields = parse_qsl(
            body.decode("utf-8"),
            keep_blank_values=True,
            strict_parsing=True,
            max_num_fields=bounds.max_form_fields,
        )
        return tuple(FormField(name, value) for name, value in fields), ()
    if not content_type.lower().startswith("multipart/form-data"):
        return (), ()
    message = BytesParser(policy=policy.default).parsebytes(
        b"Content-Type: " + content_type_value + b"\r\nMIME-Version: 1.0\r\n\r\n" + body
    )
    if not message.is_multipart():
        raise ValueError("multipart body is invalid")
    parts: list[MultipartPart] = []
    for part in message.iter_parts():
        if len(parts) >= bounds.max_multipart_parts:
            raise ValueError("multipart part capacity exhausted")
        name = part.get_param("name", header="content-disposition")
        if not isinstance(name, str) or not name:
            raise ValueError("multipart part name is invalid")
        payload = part.get_payload(decode=True)
        data = b"" if payload is None else bytes(payload)
        if len(data) > bounds.max_request_body:
            raise ValueError("multipart part exceeds its bound")
        parts.append(
            MultipartPart(
                name=name,
                data=data,
                filename=part.get_filename(),
                content_type=part.get_content_type(),
            )
        )
    return (), tuple(parts)


def _parse_range(value: bytes | None, size: int) -> tuple[int, int] | None:
    if value is None:
        return None
    try:
        text = value.decode("ascii")
        if not text.startswith("bytes=") or "," in text:
            return None
        first, last = text[6:].split("-", 1)
        if size == 0 or (first == "" and last == ""):
            return None
        if first == "":
            suffix = int(last)
            if suffix <= 0:
                return None
            start = max(0, size - suffix)
            end = size - 1
        else:
            start = int(first)
            end = size - 1 if last == "" else int(last)
        if start < 0 or start >= size or end < start or end >= size:
            return None
        return start, end
    except (UnicodeDecodeError, ValueError):
        return None


def _not_modified(value: bytes | None, modified_seconds: int) -> bool:
    if value is None:
        return False
    try:
        parsed = parsedate_to_datetime(value.decode("ascii"))
        return int(parsed.timestamp()) >= modified_seconds
    except (UnicodeDecodeError, ValueError, TypeError, OverflowError):
        return False
