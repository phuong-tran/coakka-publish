from __future__ import annotations

import ctypes
import hashlib
import json
import os
import platform
import sysconfig
from dataclasses import dataclass
from importlib.resources import files
from pathlib import Path

from .routing import Route

CORE_ABI_VERSION = 1
CORE_MAX_ROUTES = 1024
CORE_FAILED_INDEX_NONE = 0xFFFFFFFF
_MAX_MANIFEST_BYTES = 16 << 10
_MAX_LIBRARY_BYTES = 64 << 20


class _NativeRoute(ctypes.Structure):
    _fields_ = [
        ("route_id", ctypes.c_uint64),
        ("method", ctypes.POINTER(ctypes.c_uint8)),
        ("method_size", ctypes.c_size_t),
        ("encoded_path_pattern", ctypes.POINTER(ctypes.c_uint8)),
        ("encoded_path_pattern_size", ctypes.c_size_t),
    ]


@dataclass(frozen=True, slots=True)
class RouteValidationError(ValueError):
    status: int
    index: int
    status_name: str

    def __str__(self) -> str:
        if self.index == CORE_FAILED_INDEX_NONE:
            return f"CoAkka HTTP route validation failed: {self.status_name}"
        return f"CoAkka HTTP route {self.index} validation failed: {self.status_name}"


def resolve_core_library() -> Path:
    override = os.environ.get("COAKKA_HTTP_CORE_LIBRARY")
    if override:
        path = Path(override).expanduser().absolute()
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"CoAkka HTTP Core library is missing: {path}")
        return path

    target = _platform_id()
    root = files("coakka_http").joinpath("_native", target)
    manifest_resource = root.joinpath("native.json")
    raw = manifest_resource.read_bytes()
    if len(raw) > _MAX_MANIFEST_BYTES:
        raise ValueError("CoAkka HTTP native manifest exceeds its bound")
    manifest = json.loads(raw)
    if set(manifest) != {"format", "platform", "library", "size", "sha256"}:
        raise ValueError("CoAkka HTTP native manifest shape is invalid")
    if manifest["format"] != 1 or manifest["platform"] != target:
        raise ValueError("CoAkka HTTP native manifest identity is invalid")
    name = manifest["library"]
    if not isinstance(name, str) or Path(name).name != name:
        raise ValueError("CoAkka HTTP native library name is invalid")
    library = Path(str(root.joinpath(name)))
    size = library.stat().st_size
    if size <= 0 or size > _MAX_LIBRARY_BYTES or size != manifest["size"]:
        raise ValueError("CoAkka HTTP native library size is invalid")
    digest = hashlib.sha256(library.read_bytes()).hexdigest()
    if digest != manifest["sha256"]:
        raise ValueError("CoAkka HTTP native library hash is invalid")
    return library


def validate_routes(
    routes: tuple[Route, ...], library_path: Path | None = None
) -> None:
    if len(routes) > CORE_MAX_ROUTES:
        raise ValueError("CoAkka HTTP supports at most 1024 routes")
    path = resolve_core_library() if library_path is None else library_path
    library = ctypes.CDLL(str(path))
    abi_version = library.coakka_http_core_abi_version
    abi_version.argtypes = []
    abi_version.restype = ctypes.c_uint32
    if int(abi_version()) != CORE_ABI_VERSION:
        raise RuntimeError("CoAkka HTTP Core ABI version is unsupported")
    if not routes:
        return
    validate = library.coakka_http_core_validate_routes
    validate.argtypes = [
        ctypes.POINTER(_NativeRoute),
        ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32),
    ]
    validate.restype = ctypes.c_int32
    status_name = library.coakka_http_core_status_name
    status_name.argtypes = [ctypes.c_int32]
    status_name.restype = ctypes.c_char_p

    projected_type = _NativeRoute * len(routes)
    projected = projected_type()
    buffers: list[object] = []
    for index, route in enumerate(routes):
        method = route.method.encode("ascii")
        pattern = route.pattern.encode("utf-8")
        method_buffer = ctypes.create_string_buffer(method)
        pattern_buffer = ctypes.create_string_buffer(pattern)
        buffers.extend((method_buffer, pattern_buffer))
        projected[index] = _NativeRoute(
            route.route_id,
            ctypes.cast(method_buffer, ctypes.POINTER(ctypes.c_uint8)),
            len(method),
            ctypes.cast(pattern_buffer, ctypes.POINTER(ctypes.c_uint8)),
            len(pattern),
        )
    failed_index = ctypes.c_uint32(CORE_FAILED_INDEX_NONE)
    status = int(validate(projected, len(routes), ctypes.byref(failed_index)))
    if status != 0:
        raw_name = status_name(status)
        name = raw_name.decode("ascii") if raw_name else "unknown"
        raise RouteValidationError(status, failed_index.value, name)


def _platform_id() -> str:
    system = platform.system().lower()
    if system == "windows":
        interpreter_platform = sysconfig.get_platform().lower().replace("-", "_")
        machine = {
            "win_amd64": "x86_64",
            "win_arm64": "aarch64",
        }.get(interpreter_platform, interpreter_platform)
    else:
        machine = platform.machine().lower()
    os_name = {"darwin": "macos", "linux": "linux", "windows": "windows"}.get(system)
    architecture = {
        "arm64": "aarch64",
        "aarch64": "aarch64",
        "amd64": "x86_64",
        "x86_64": "x86_64",
    }.get(machine)
    if os_name is None or architecture is None:
        raise RuntimeError(f"unsupported CoAkka HTTP platform: {system}-{machine}")
    return f"{os_name}-{architecture}"
