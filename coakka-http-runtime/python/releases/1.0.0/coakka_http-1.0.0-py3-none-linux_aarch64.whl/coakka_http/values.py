from __future__ import annotations

import asyncio
import builtins
import json as _json
from collections.abc import AsyncIterable, AsyncIterator, Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from types import MappingProxyType
from typing import Any

Headers = tuple[tuple[bytes, bytes], ...]
EMPTY_PATH_PARAMS: Mapping[str, str] = MappingProxyType({})


class HttpProtocol(str, Enum):
    HTTP_1_1 = "http/1.1"
    HTTP_2 = "h2"


class Cancellation:
    __slots__ = ("_event",)

    def __init__(self) -> None:
        self._event = asyncio.Event()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    async def wait(self) -> None:
        await self._event.wait()

    def _cancel(self) -> None:
        self._event.set()


class RequestBody:
    __slots__ = (
        "_cancel",
        "_chunks",
        "_complete",
        "_consuming",
        "_max_bytes",
        "_max_chunk_bytes",
        "_max_chunks",
        "_receive",
        "_total",
    )

    def __init__(
        self,
        receive: Callable[[], Awaitable[dict[str, Any]]],
        cancellation: Cancellation,
        *,
        max_bytes: int,
        max_chunk_bytes: int,
        max_chunks: int,
    ) -> None:
        self._receive = receive
        self._cancel = cancellation
        self._max_bytes = max_bytes
        self._max_chunk_bytes = max_chunk_bytes
        self._max_chunks = max_chunks
        self._total = 0
        self._chunks = 0
        self._complete = False
        self._consuming = False

    @property
    def complete(self) -> bool:
        return self._complete

    def __aiter__(self) -> AsyncIterator[bytes]:
        if self._consuming:
            raise RuntimeError("request body can be consumed only once")
        self._consuming = True
        return self._iterate()

    async def _iterate(self) -> AsyncIterator[bytes]:
        while not self._complete:
            message = await self._receive()
            message_type = message.get("type")
            if message_type == "http.disconnect":
                self._cancel._cancel()
                self._complete = True
                return
            if message_type != "http.request":
                raise ValueError("request body event is invalid")
            chunk = builtins.bytes(message.get("body", b""))
            self._chunks += 1
            self._total += len(chunk)
            if (
                len(chunk) > self._max_chunk_bytes
                or self._chunks > self._max_chunks
                or self._total > self._max_bytes
            ):
                raise RequestBodyLimitError("request body exceeds its configured bound")
            if chunk:
                yield chunk
            if not message.get("more_body", False):
                self._complete = True

    async def read(self) -> bytes:
        chunks = [chunk async for chunk in self]
        return b"".join(chunks)


class RequestBodyLimitError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class FormField:
    name: str
    value: str


@dataclass(frozen=True, slots=True)
class MultipartPart:
    name: str
    data: bytes
    filename: str | None = None
    content_type: str | None = None


@dataclass(frozen=True, slots=True)
class Request:
    method: str
    target: bytes
    raw_path: bytes
    path: str
    query_string: bytes
    headers: Headers
    body: bytes = b""
    path_params: Mapping[str, str] = field(default_factory=lambda: EMPTY_PATH_PARAMS)
    body_stream: RequestBody | None = None
    form: tuple[FormField, ...] = ()
    multipart: tuple[MultipartPart, ...] = ()
    cancellation: Cancellation = field(default_factory=Cancellation)

    def bytes(self) -> bytes:
        return self.body

    def text(self, encoding: str = "utf-8") -> str:
        return self.body.decode(encoding)

    def json(self) -> Any:
        return _json.loads(self.body)

    def stream(self) -> AsyncIterator[builtins.bytes]:
        if self.body_stream is not None:
            return self.body_stream.__aiter__()

        async def buffered() -> AsyncIterator[builtins.bytes]:
            if self.body:
                yield self.body

        return buffered()


@dataclass(frozen=True, slots=True)
class Response:
    status: int = 200
    headers: Headers = ()
    body: bytes = b""

    @classmethod
    def empty(cls, *, status: int = 204, headers: Headers = ()) -> Response:
        return cls(status=status, headers=tuple(headers), body=b"")

    @classmethod
    def bytes(
        cls,
        body: builtins.bytes | bytearray | memoryview,
        *,
        status: int = 200,
        headers: Headers = (),
    ) -> Response:
        return cls(status=status, headers=tuple(headers), body=builtins.bytes(body))

    @classmethod
    def text(cls, body: str, *, status: int = 200, headers: Headers = ()) -> Response:
        return cls(
            status=status,
            headers=_with_default_content_type(headers, b"text/plain; charset=utf-8"),
            body=body.encode("utf-8"),
        )

    @classmethod
    def json(cls, body: Any, *, status: int = 200, headers: Headers = ()) -> Response:
        encoded = _json.dumps(
            body,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        ).encode("utf-8")
        return cls(
            status=status,
            headers=_with_default_content_type(
                headers, b"application/json; charset=utf-8"
            ),
            body=encoded,
        )


@dataclass(frozen=True, slots=True)
class StreamResponse:
    body: AsyncIterable[bytes]
    status: int = 200
    headers: Headers = ()


@dataclass(frozen=True, slots=True)
class ServerEvent:
    data: str
    event: str | None = None
    event_id: str | None = None
    retry_millis: int | None = None

    def encode(self) -> bytes:
        lines: list[str] = []
        if self.event is not None:
            lines.append(f"event: {self.event}")
        if self.event_id is not None:
            lines.append(f"id: {self.event_id}")
        if self.retry_millis is not None:
            if self.retry_millis < 0:
                raise ValueError("server event retry must be non-negative")
            lines.append(f"retry: {self.retry_millis}")
        lines.extend(f"data: {line}" for line in self.data.splitlines() or [""])
        return ("\n".join(lines) + "\n\n").encode("utf-8")


@dataclass(frozen=True, slots=True)
class EventResponse:
    events: AsyncIterable[ServerEvent]
    status: int = 200
    headers: Headers = ()


@dataclass(frozen=True, slots=True)
class StaticContent:
    url_prefix: str
    directory: Path
    spa_fallback: str | None = None
    index_file: str = "index.html"
    cache_control: str = "public, max-age=60"


@dataclass(frozen=True, slots=True)
class TlsConfiguration:
    certificate: Path
    private_key: Path
    ca_certificate: Path | None = None
    require_client_certificate: bool = False


@dataclass(frozen=True, slots=True)
class RouteBinding:
    route_id: int
    method: str
    pattern: str
    revision: int


@dataclass(frozen=True, slots=True)
class Snapshot:
    running: bool
    dispatched: int
    rejected: int
    failed: int
    pending: int
    max_active_handlers: int
    active_connections: int
    outbound_pending: int
    outbound_completed: int
    outbound_rejected: int
    websocket_sessions: int
    route_generation: int
    dropped_errors: int


@dataclass(frozen=True, slots=True)
class Health:
    status: str
    ready: bool
    accepting_requests: bool


@dataclass(frozen=True, slots=True)
class Inspection:
    host: str
    port: int
    protocols: tuple[HttpProtocol, ...]
    secure: bool
    routes: tuple[RouteBinding, ...]
    static_prefixes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ClientRequest:
    method: str
    url: str
    headers: Headers = ()
    body: bytes = b""
    timeout: float = 10.0


@dataclass(frozen=True, slots=True)
class ClientResponse:
    status: int
    headers: Headers
    body: bytes
    protocol: str


class ClientFailure(str, Enum):
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"
    CONNECTION = "connection"
    PROTOCOL = "protocol"
    CAPACITY = "capacity"
    RESPONSE_TOO_LARGE = "response_too_large"


class ClientError(RuntimeError):
    def __init__(self, failure: ClientFailure, message: str) -> None:
        super().__init__(message)
        self.failure = failure


def _with_default_content_type(headers: Headers, content_type: bytes) -> Headers:
    owned = tuple(headers)
    if any(name.lower() == b"content-type" for name, _value in owned):
        return owned
    return (*owned, (b"content-type", content_type))
