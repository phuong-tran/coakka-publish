# Consuming The Mojo 3.2.1 Preview Source Package

Use Mojo 1.0.0b2.dev2026052115 and a matching C compiler. The preview was
exercised on macOS ARM64 and Raspberry Pi 5 (Linux ARM64). See the
[qualified host scope](README.md#scope-and-evidence).
Compare the archive SHA-256 with the catalog before unpacking. Choose an
existing absolute work directory for generated files.

On macOS use the SDK selected by Xcode for the preview build:

~~~sh
export SDKROOT="$(xcrun --sdk macosx --show-sdk-path)"
export MACOSX_DEPLOYMENT_TARGET=13.0
~~~

~~~sh
shasum -a 256 coakka-runtime-mojo-3.2.1-source.tar.gz
tar -xzf coakka-runtime-mojo-3.2.1-source.tar.gz
cd coakka-runtime-mojo-3.2.1-source
export COAKKA_CONNECTOR_WORK_ROOT="/absolute/existing-work"
bash scripts/verify-native-payload.sh
bash scripts/smoke.sh
~~~

The payload verifier checks all five Core files. The smoke uses the bundled
Core and exercises startup, request/reply, cancellation and route-miss
deadletter. See [archive verification](RELEASE.md) for additional checks.
