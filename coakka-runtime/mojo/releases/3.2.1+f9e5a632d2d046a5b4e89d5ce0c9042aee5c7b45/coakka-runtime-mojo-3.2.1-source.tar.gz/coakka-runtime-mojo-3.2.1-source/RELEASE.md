# Verify The Mojo 3.2.1 Preview Source Package

Confirm the archive SHA-256 against the distribution catalog, then use the
commands in [Consuming](CONSUMING.md) from the extracted archive.
`scripts/verify-native-payload.sh` checks the five bundled Core 3.2 images.
`scripts/smoke.sh` builds and runs a consumer using the matching bundled image.

Mojo preview also ships `scripts/file-lane-smoke.sh` and
`scripts/stream-lane-smoke.sh`. For these checks, point
`COAKKA_FILE_LANE_RUNTIME_LIB` and `COAKKA_STREAM_LANE_RUNTIME_LIB`,
respectively, at the absolute path to the matching bundled Core image.

The optional `scripts/check-platform-source.sh` uses Zig to check the package
sources for Linux ARM64 and Windows x86-64. It does not execute on those
targets. The [README](README.md#scope-and-evidence) records execution scope.
