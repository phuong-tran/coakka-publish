# Mojo Runtime Configuration And Ownership

This guide covers the 3.2.1 source distribution. Mojo's current entrypoint calls a C smoke
boundary; it does not expose a stable high-level application connector API.

The smoke omits CPU, connection, I/O and monitor groups during native startup.
Core selects AUTO, MULTIPLEXED and monitor OFF; the shim reads accepted settings
instead of guessing from input or descriptors. Construction refusal has no
effective instance to report. Separate checks exercise explicit rejection and
the unchanged active configuration after an immutable-state apply attempt.

One Core ask owner serves the complete runtime lifetime. The Core request reader
returns an owned frame whose byte view is borrowed only during one synchronous
reply-builder call. Every frame/ticket/reader retires before its owner; no pointer
escapes into Mojo. The complete FFI call is synchronous and owns shutdown.

COAKKA_TLS_FIXTURE_ROOT enables explicit fixture credential/reload checks. The
caller owns credentials, rotation and retry policy. See
[TLS/mTLS](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/reference/tls-and-mtls.md)
and [Runtime Monitoring](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/operations/runtime-monitoring.md).
