#!/usr/bin/env bash
set -euo pipefail

: "${COAKKA_CONNECTOR_WORK_ROOT:?set an existing absolute connector work directory}"
[[ "${COAKKA_CONNECTOR_WORK_ROOT}" == /* && -d "${COAKKA_CONNECTOR_WORK_ROOT}" && ! -L "${COAKKA_CONNECTOR_WORK_ROOT}" ]] || exit 2
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
root="$(cd "${script_dir}/.." && pwd)"
runtime="${COAKKA_STREAM_LANE_RUNTIME_LIB:?COAKKA_STREAM_LANE_RUNTIME_LIB is required}"
tmp="$(mktemp -d "${COAKKA_CONNECTOR_WORK_ROOT}/coakka-mojo-stream-lane.XXXXXX")"
trap 'rm -rf "${tmp}"' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
export TMPDIR="${tmp}"
case "$(uname -s)" in
  Darwin) shim="${tmp}/libcoakka_mojo_stream_lane.dylib"; cc -std=c11 -Wall -Wextra -Werror -dynamiclib "${root}/src/stream_lane_shim.c" "${runtime}" -o "${shim}"; DYLD_LIBRARY_PATH="$(dirname "${runtime}"):${tmp}" mojo "${root}/src/stream_lane_smoke.mojo" "${shim}" ;;
  Linux) shim="${tmp}/libcoakka_mojo_stream_lane.so"; cc -std=c11 -Wall -Wextra -Werror -shared -fPIC "${root}/src/stream_lane_shim.c" "${runtime}" -o "${shim}"; LD_LIBRARY_PATH="$(dirname "${runtime}"):${tmp}" mojo "${root}/src/stream_lane_smoke.mojo" "${shim}" ;;
  *) exit 64 ;;
esac
