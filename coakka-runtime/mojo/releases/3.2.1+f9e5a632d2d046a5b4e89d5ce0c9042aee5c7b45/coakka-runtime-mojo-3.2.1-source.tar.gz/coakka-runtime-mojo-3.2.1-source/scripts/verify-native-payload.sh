#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mojo_root="$(cd "${script_dir}/.." && pwd)"
native_root="${mojo_root}/native"

sha256_file() {
  if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print $1}';
  else sha256sum "$1" | awk '{print $1}'; fi
}

verify() {
  local relative="$1" expected="$2" format="$3"
  local path="${native_root}/${relative}"
  [[ -f "${path}" ]] || { echo "[mojo-verify-native] missing ${relative}" >&2; exit 1; }
  [[ "$(sha256_file "${path}")" == "${expected}" ]] || {
    echo "[mojo-verify-native] digest mismatch ${relative}" >&2; exit 1;
  }
  file "${path}" | grep -Eq "${format}" || {
    echo "[mojo-verify-native] format mismatch ${relative}" >&2; exit 1;
  }
}

verify "macos-aarch64/libcoakka_runtime_v2.dylib" \
  "c05e2be0be725e0868e7ebf7387319b040da84794d22b6c1d50e506164dadbfa" \
  "Mach-O 64-bit.*arm64"
verify "linux-aarch64/libcoakka_runtime_v2.so" \
  "c78b08f0b4cd62e9fb7276ffdb7cb95d8fd9a46ce327600ba45e85c5d4fe2d55" \
  "ELF 64-bit LSB shared object, ARM aarch64"
verify "linux-x86_64/libcoakka_runtime_v2.so" \
  "666f6e00c63b0b24414d515e1365281ac1e59084871f3a7e7d2c5551383c68d6" \
  "ELF 64-bit LSB shared object, x86-64"
verify "windows-aarch64/libcoakka_runtime_v2.dll" \
  "d7fcb3a3c17e722cdb2bec5696fd7bd4bf75526bb24e8e41784390b4c18145fe" \
  "PE32\\+ executable.*\\(DLL\\).*(Aarch64|ARM64)"
verify "windows-x86_64/libcoakka_runtime_v2.dll" \
  "5418962956871fc82cc830b3614163941970bfb656df96436e03f0a777ac514c" \
  "PE32\\+ executable.*\\(DLL\\).*x86-64"

count="$(find "${native_root}" -type f \( -name '*.dylib' -o -name '*.so' -o -name '*.dll' \) | wc -l | tr -d ' ')"
[[ "${count}" == "5" ]] || { echo "[mojo-verify-native] expected 5 natives, got ${count}" >&2; exit 1; }
echo "[mojo-verify-native] exact payload ok (macOS/Linux/Windows); publisher signing absent"
