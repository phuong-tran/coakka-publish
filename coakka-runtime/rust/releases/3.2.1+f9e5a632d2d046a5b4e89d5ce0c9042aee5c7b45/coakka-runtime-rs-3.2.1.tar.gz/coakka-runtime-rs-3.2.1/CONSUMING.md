# Consuming CoAkka Rust 3.2.1

The crate declares Rust 1.77.2 as its minimum. It embeds Core 3.2, ABI 1,
with five native images. See [qualification](RELEASE.md) for tested host
and toolchain scope.

Verify the archive SHA-256 against the distribution checksum before unpacking.
The package manifest records each member's digest and byte count. The native
manifest identifies the bundled Core images and records publisher signing as
absent.

After unpacking, use the crate as a normal path dependency:

```toml
[dependencies]
coakka-runtime-rs = { path = "../coakka-runtime-rs-3.2.1" }
```

The build-only helper verifies an unchanged source package:

```sh
python3 tools/package_tools.py verify .
```

Keep Cargo output outside the installed source package using `CARGO_TARGET_DIR`.
Use `--locked`; an offline build additionally needs the normal Cargo cache.
Rust itself has no external crate dependency. The optional intent adapter has
its own locked Rust dependencies. Neither requires a separately installed Core.

## Run the packaged smoke

Run from the root of the extracted Rust archive, using a fresh absolute
build directory outside that archive. This example selects macOS ARM64:

```sh
export CARGO_TARGET_DIR="/absolute/fresh-build-directory"
cargo build --locked --release --bins
python3 tools/package_tools.py deploy . "$CARGO_TARGET_DIR/release/coakka-rust-smoke" macos-aarch64
"$CARGO_TARGET_DIR/release/coakka-rust-smoke"
COAKKA_RUNTIME_LIB="$CARGO_TARGET_DIR/release/native/macos-aarch64/libcoakka_runtime_v2.dylib" \
  "$CARGO_TARGET_DIR/release/coakka-rust-transport-smoke"
```

The first program checks request/reply and route-miss deadletter with the
installed image. The transport program takes an explicit image path and
checks the transport ABI and accepted configuration. The bundled profile's
smoke reports `tls_executed=false`.

## Application resources

Cargo compiles Rust code; it does not deploy a dependency's native resources.
Bundle the selected image with your executable before starting the application.
The build-only helper copies Core and its required legal/provenance files:

```sh
python3 tools/package_tools.py deploy . "$APP_EXECUTABLE" macos-aarch64
```

Use `linux-aarch64`, `linux-x86_64`, `windows-aarch64` or `windows-x86_64` for
those compiler targets. The helper requires an existing executable outside the
source package and a fresh `native/<target>` resource directory. It refuses
damaged inputs, links and existing target directories; it never overwrites an
application's resources. The app must be stopped while its layout is assembled.
Python is a packaging tool only, not an application runtime dependency. Build
systems may copy the same verified files and legal material directly instead.

Default discovery is relative to the canonical executable directory, not the
source crate, working directory or machine build cache. Move the executable
and its `native` directory together. A framework-owned resource bundle can
instead supply its exact path to `RuntimeHost::start_with_runtime_lib`.
An explicit path takes precedence, followed by a present `COAKKA_RUNTIME_LIB`,
then the installed layout. Empty environment overrides, missing images, wrong
ABI and incompatible process module identity fail without fallback.

## Release application build

Use the application's release profile with thin LTO, one codegen unit and
`strip = "symbols"`. Preserve `panic = "unwind"` if relying on handler-panic
isolation. Remap actual application/dependency cache source roots during
compilation, then inspect the resulting executable; stripping alone does not
remove all compiler diagnostic strings. Private test executables are not part
of this source archive or a full application privacy qualification.

On Windows MSVC, build the application for the explicit process target with
`RUSTFLAGS="-C target-feature=+crt-static"` and
`--target x86_64-pc-windows-msvc`
(combine any path-remapping flags in the same `RUSTFLAGS`). Verify imports
afterward; do not require consumers to install a separate C runtime. Do not
apply that x64 recipe to the separately qualified Windows ARM64 toolchain. See the
official [Rust linkage contract](https://doc.rust-lang.org/reference/linkage.html#static-and-dynamic-c-runtimes).

On Linux, inspect the final application's required GLIBC versions as well as
the bundled Core; a newer app build must not silently raise the product floor.
Do not disable Gatekeeper, Windows trust prompts or organizational policy.
Use the recorded publisher-signing status for the selected archive.

`RuntimeInfo.delivery_backend` copies Core's selected delivery label; use Core
capability bits and effective snapshots for program decisions, not label text.
AUTO execution and MULTIPLEXING remain Core defaults. See [README](README.md)
for ownership, cancellation and callback restrictions, and
[Transport Configuration](TRANSPORT_CONFIGURATION.md) for advanced intent.
