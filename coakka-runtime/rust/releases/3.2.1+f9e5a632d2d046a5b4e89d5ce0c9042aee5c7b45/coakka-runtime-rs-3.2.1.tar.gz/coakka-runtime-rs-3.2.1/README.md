# CoAkka Rust Runtime Connector

<p align="center">
  <img src="https://raw.githubusercontent.com/phuong-tran/coakka-samples/main/docs/common/assets/brand/coakka-logo.png" alt="CoAkka" width="480">
</p>

This is the Rust connector in the polyglot, multi-language, multi-platform
CoAkka runtime ecosystem. CoAkka is not Rust-only: Rust services can share the
same runtime semantics with JVM, Node/Bun, Python, Go, C#, Swift, Zig, Mojo, and
native C/C++ applications.

The **Rust 3.2.1 source package** bundles Runtime Core 3.2, ABI 1, build
`f9e5a632d2d046a5b4e89d5ce0c9042aee5c7b45`. The final digit is the connector
revision. The package is distributed as a Cargo path dependency. See
[Consuming](CONSUMING.md) for installation and [qualification](RELEASE.md)
for tested hosts.

Common guidance:

- [CoAkka documentation and samples](https://github.com/phuong-tran/coakka-samples/blob/main/docs/README.md)
- [Connection strategies](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/reference/connection-strategies.md)
- [TLS and mTLS](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/reference/tls-and-mtls.md)
- [Troubleshooting](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/operations/troubleshooting.md)
- [Contact and support](https://github.com/phuong-tran/coakka-samples/blob/main/docs/common/contact-and-support.md): `gabrielgun1983@gmail.com`
- [Rust transport API](TRANSPORT_CONFIGURATION.md)

The connector proves it can:

- resolve and compile the OS-specific native loader path for current packaged
  macOS, Linux, and Windows lanes; native execution evidence is stated below
- start one local `RuntimeHost`
- apply one route snapshot
- register a local handler
- send one request/reply call
- surface a route-miss deadletter
- delegate delivered-request selection and reading to Core
- discover effective capabilities before optional-mode selection
- pass connection intent at construction and copy Core's startup facts
- retain one native module identity for process lifetime and retire handles
  through Core exactly once

The current package keeps the API synchronous and local-first.

`ConnectorStartSpec::new(...)` defaults `separate_delivered_request_lane` to
`true`. Most request/reply services should leave it alone so inbound handler
work stays separate from reply/deadletter matching. Set it to `false` only for
advanced, measured, mostly one-way hosts.

Absent execution and connection intent selects Core's `AUTO` and
`MULTIPLEXING` defaults. Inspect `runtime_startup_config()` for accepted facts;
Rust does not probe support or reconstruct native state. Core owns framing,
matching, monotonic deadlines, cancellation and descriptor operations. Rust
owns values, scheduling and dynamic-library/FFI lifetime safety.

Startup values are intent. System/node text and route/endpoint bytes are passed
without whitespace normalization. Core decides queue, route and network
acceptance; `queue_capacity = 0` delegates default selection, rather than
copying a queue-size table into Rust. Inspect `runtime_startup_config()` for
the accepted queue and flags. `new()` requests strict no-drop and constructs
an initial generation-one snapshot; these are explicit application choices,
not inferred effective state.

`monitor: Option<RuntimeMonitorOptions>` preserves omitted, explicit false and
explicit true. `network: Option<RuntimeNetworkConfig>` distinguishes omitted
Core-default participation from an explicitly selected mode. Read
`runtime_network_config()` for Core's accepted endpoints and `explicit_policy`;
never infer them from routes or the input spec. A network-node constructor
preserves both supplied ports, including zero, so Core can refuse incomplete
intent. C-string inputs still reject embedded NUL for boundary safety.
The 3.2.1 connector uses a presence-bearing monitor group in place of the
earlier `enable_monitor` bool. Tauri's Rust host projects the same network getter.

Nonzero native results retain `CoAkkaError::Core { operation, status }`, while
successful calls with malformed outputs are host contract failures. Core's
terminal deadletter and an ask-admission refusal remain distinct. The documented
ask deadline result maps to `Timeout` only when Core await returns `WOULD_BLOCK`.

Envelope enum values preserve `Unspecified` and `Unknown(i32)` rather than
turning missing or future values into request/success/default-routing facts.
Use `value()` for the exact number and `from_value()` for a lossless projection;
do not cast the Rust enum layout. Core still decides acceptance. Signed timeout
hints, empty metadata keys/values and length-bearing text (including NUL) are
preserved. C-string boundary checks remain separate.

Deadletters expose the exact `reason_code`, Core's `endpoint_attempt_count` and
`transport_failure_metadata`. Unknown reason numbers have the diagnostic name
`DEADLETTER_REASON_UNKNOWN`; their numeric cause is not discarded. Attempt
count is delivery evidence, not a connector retry count.

The Rust wire boundary caps each input/output frame at 64 MiB; Core can impose
smaller admission limits. Malformed lengths/tags/varints and invalid text fail
with `WireCodec`. Unknown ordinary fields are skipped without copying, while
deprecated nested groups are unsupported and rejected. Unknown field bytes
are not retained for transparent proxying. Decoding is synchronous and returned
values own their storage; the connector does not retain borrowed input spans.
Encoding refusal publishes no partial frame. This is a boundary storage limit,
not a replacement for Core configuration or a whole-process memory budget.

Handlers run synchronously on the Rust reader and must return promptly.
`register_handler` keeps exact target keys, with a Rust-owned registration
budget of 256 keys and 64 KiB of total target text. Replacement reuses that
budget; `unregister_handler` releases a key and returns whether it existed.
These bounds limit retained Rust callback registrations, not Core routes or
the memory reachable from application captures. An already selected callback
may finish after replacement/removal. Capture destructors run outside registry
locks, including on refusal.

Ordinary handler unwinds are isolated: the panic hook still runs,
`client_stats().handler_panics` increases, and no reply or Core failure is
fabricated. Core's request deadline remains authoritative. `panic=abort`,
nonreturning handlers and panicking destructors retain normal process behavior.
Use weak host references in captures; strong `Arc` cycles are not collected.

Dropping a host externally joins its reader before native retirement. If the
last host is dropped from its own callback, admission closes immediately and
the existing worker retains native ownership until that callback returns;
native retirement then follows without a cleanup thread or self-join. This is
not a promise that Drop finishes while a callback blocks indefinitely.

## Run

From the extracted archive, verify the package and build the smoke programs
as shown in [Consuming](CONSUMING.md#run-the-packaged-smoke). A deployed
application bundles Core under the executable directory:

```text
application/
  my-service
  native/macos-aarch64/libcoakka_runtime_v2.dylib
```

Linux uses `native/linux-aarch64/libcoakka_runtime_v2.so` or
`native/linux-x86_64/libcoakka_runtime_v2.so`. Windows uses
`native/windows-aarch64/libcoakka_runtime_v2.dll` or
`native/windows-x86_64/libcoakka_runtime_v2.dll` alongside the executable.
Move the complete layout together; consumers do not install Core dependencies
separately. The app packager supplies this layout, not Cargo's dependency
compiler. Framework-specific resource bundles can instead supply their exact
image path to `RuntimeHost::start_with_runtime_lib`.

The resolver selects a nonempty explicit `runtime_lib_path`, otherwise a
present `COAKKA_RUNTIME_LIB`, otherwise exactly the canonical executable directory's
`native/<compile-target>/<product filename>`. A present empty environment
override or an invalid selected path fails; it never falls back to a source
crate, sibling connector, working directory, old filename or system library.
The default canonical image must remain inside the canonical executable
directory. Debug and release builds follow the same rule; no build-machine
directory is embedded for resource discovery.

ABI admission precedes every other native ABI call and process publication.
Rejected ABI, missing required symbols and invalid images do not reserve the
process identity: a later valid image can still load. After successful
admission, one immutable symbol table and module are retained for process
lifetime. The same canonical path reuses them; a different canonical path
fails even if its bytes match. Runtime and capability facts still come from
Core, not this resident table.

Resource lookup does not verify a package signature. Installation directories
must be trusted and stable while loading; containment checks do not protect
against a concurrent hostile replacement. Only load trusted native code: ABI
validation does not sandbox library initializers. The installed smoke runs from a relocated directory with the packaged native
image. See [qualification](RELEASE.md) for platform and signing scope.

## File Lane

In 3.2.1, File and Stream snapshot terminal flags come
from Core's terminal transition timestamp, not the numeric ordering of states.
File `PAUSED` is retryable and nonterminal; cancel can make it terminal. Success
also requires a recognized completed/ended state and an `OK` result. Core may
allow forgetting an inactive paused transfer separately: that permission does
not make `PAUSED` terminal. Do not wait for a paused transfer to complete without
choosing resume, cancel, or another Core-supported action.

`FileLane::open(...)` exposes a `Send + Sync` independent native bulk-transfer
lane with checked ABI snapshot projection and draining `Drop`. See the shared
[file-lane contract](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/guides/runtime-file-transfer.md).

File and Stream configuration values are intent, not effective settings. Core
validates them, resolves defaults and reports accepted values through its
snapshots. Rust retains only its language/FFI safety checks, including embedded
NUL refusal; it does not duplicate Core's capacity, worker or owner policy.
For example, read `stats().capacity` after Stream construction instead of
assuming the requested capacity was applied unchanged.

Match `CoAkkaError::Core { operation, status }` for an actual nonzero Core
result. `CoAkkaStatus` preserves the numeric value, including unknown values;
do not parse error text or infer retry/timeout meaning without the operation's
contract. Host loading/lifetime/projection failures remain distinct. Core also
decides whether a lane may issue a grant; an unowned grant request is not
reclassified by Rust constructor bookkeeping.

## Stream Lane

The source package includes the Stream Lane surface. Keep package/native
identities exact and follow the public
[streaming contract](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/guides/runtime-streaming.md).

Rust retains each accepted callback through Core's use. Callback storage is
bounded by Core's reported record capacity plus one staged admission; Core
record absence, successful replacement/forget, or completed stop determines
retirement. Callback capture sizes remain the application's responsibility.
Native acceptance commits callback ownership before copied grant projection.
User destructors run after the connector releases its locks and native borrows.

Callbacks must remain bounded and must not close or release the last owner of
their own lane on a native worker. `close()` rejects that self-join before
calling Core; close from the controlling application thread after callbacks
return. Explicit close is recommended. A forbidden last-owner drop from its
callback conservatively retains live native state instead of freeing a context
still in use; it is not a supported resource-retirement path. Closure panics
are contained at the FFI boundary; application destructor panics unwind only
after native borrowing and owner locks have ended.

Replica owners use `FileLane::open_owned`/`StreamLane::open_owned` and
`prepare_receive_grant`/`prepare_publish_grant`. Use the explicit
`from_control_plane` constructors after deserialization; `Debug` keeps tokens
redacted. Derive jobs with `to_send_spec`/`to_subscribe_spec` and follow the
[owner-grant ONE/ALL sample](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/reference/runtime-lane-owner-grants.md).
Reconstruction checks C-string representability, not Core acceptance, endpoint
reachability or authorization. Opaque tokens keep their exact UTF-8 bytes,
including spaces. Core validates the submitted intent. Native copied outputs
are decoded only inside their declared fixed-size buffers; malformed output
fails rather than reading beyond that boundary.

## AI-Assisted Integration

Before generating application code, use the selected connector README together
with the public [AI-assisted integration guide](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/guides/ai-assisted-integration.md).
It requires an exact package coordinate, platform evidence, the runnable
language sample, and the feature-specific lifecycle contract. Do not translate
API identifiers from another language by analogy.


## License

**Free for application use, including commercial and production use.**

Connector source, generated bindings, type declarations, examples, and package
documentation use the [Apache License, Version 2.0](https://github.com/phuong-tran/coakka-samples/blob/main/LICENSE).
Bundled Native Core files use the [CoAkka Native Artifact License 1.2](https://github.com/phuong-tran/coakka-samples/blob/main/NATIVE-LICENSE.md).
Those native terms permit ordinary application and SaaS use but require a
separate agreement to sell or offer CoAkka itself as managed runtime or
infrastructure.

See [CoAkka Package Licensing](https://github.com/phuong-tran/coakka-samples/blob/main/docs/common/package-licensing.md)
for the file-scope map. The package also carries offline `LICENSE`,
`NATIVE-LICENSE.md`, `PACKAGE-LICENSE.md`, and `NOTICE` copies.
