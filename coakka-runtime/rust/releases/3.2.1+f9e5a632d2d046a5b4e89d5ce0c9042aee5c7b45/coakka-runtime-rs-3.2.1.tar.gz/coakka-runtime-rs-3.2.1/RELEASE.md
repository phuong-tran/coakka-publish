# Rust 3.2.1 qualification

This source archive embeds Runtime Core 3.2, ABI 1, commit
`f9e5a632d2d046a5b4e89d5ce0c9042aee5c7b45`. Use the distribution checksum to
verify the archive and [Consuming](CONSUMING.md) to run it.

| Target | Application execution evidence |
| --- | --- |
| macOS ARM64 | Installed runtime and transport smoke. |
| Linux ARM64 | Installed Rust smoke on physical Raspberry Pi 5. |
| Linux x86-64 | Installed Rust smoke under WSL2. |
| Windows x86-64 | Installed Rust smoke on native Windows. |
| Windows ARM64 | Cross-built application executed in a Windows ARM64 UTM guest. |

Rust 1.77.2 is the declared crate minimum. The Pi, WSL2 and Windows x64
smoke receipts used Cargo 1.77.2. The macOS archive smoke used Rust 1.95.0.
The sample runner covers macOS ARM64, Linux ARM64 and Windows x64.
The evidence covers those specific execution environments. Publisher signing
is absent and the bundled profile's transport smoke leaves TLS unexercised.

The Tauri aggregate has its own application and WebView evidence. Bundle
the selected Core image and legal files with the executable as described in
[Consuming](CONSUMING.md).
