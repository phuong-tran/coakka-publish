# Rust Runtime Transport Configuration

The public CoAkka C ABI remains the semantic authority. The Rust connector
copies capability, configuration, validation, apply-result, and TLS identity
data into owned Rust values. It never retains native snapshot pointers or
returns credential paths, PEM material, private keys, or provider tokens.

## Startup

Set `connection_strategy` and `security` on `ConnectorStartSpec`. The connector
asks Core to validate explicit connection intent and passes that intent to
construction. Security applies while the runtime is `CREATED`, then Core
exports handles, routes apply, and the runtime starts. Absent intent selects
Core's `AUTO` and `MULTIPLEXING` defaults. Connection validation can return
`CoAkkaError::TcpConnectionValidation`; security refusal returns
`CoAkkaError::TcpSecurityApply`, preserving Core's copied structured result.
Failed startup releases the partial runtime and retires handles through Core.

`monitor` and `network` are optional intent groups. `None` is not reconstructed
as explicit false or embedded mode. For example,
`spec.monitor = Some(RuntimeMonitorOptions { enabled: false })` explicitly
disables collection, whereas `None` preserves Core's default provenance.
`spec.network = Some(RuntimeNetworkConfig::outbound_only())` requests client-only
participation. A network node must supply both actual ports; Rust does not
substitute its bind port for an advertised zero. `runtime_network_config()`
returns Core's accepted mode, explicit-policy fact and copied endpoints.

```rust
let mut spec = ConnectorStartSpec::new("orders", "orders-1");
spec.security = Some(TcpSecuritySpec::new(TcpSecurityMode::PLAINTEXT));
let runtime = RuntimeHost::start(spec)?;
let accepted = runtime.runtime_startup_config()?;
assert_eq!(accepted.execution.requested_policy, 0); // Core AUTO
assert_eq!(accepted.connection.mode, TcpConnectionMode::MULTIPLEXING);
```

## Public Functions

| Function | Purpose, parameters, defaults | Ownership, thread safety, blocking, lifecycle, atomicity, errors, edition |
| --- | --- | --- |
| `RuntimeHost::read_runtime_capabilities(path)` | Resolves one runtime library; empty path uses resolver order. | Synchronous and process-safe. The first module identity stays loaded; a different later path is rejected. All editions. |
| `capabilities.supports(bits)` | Requires every requested effective bit. `NONE` is true. | Pure copied-value operation; never infers support from a profile or package name. |
| `TcpConnectionStrategySpec::new(mode)` | Selects a mode and leaves all tuning absent. | Caller owns the value. Optional tuning is only sent when `Some`; core validates applicability and edition/capability. |
| `TcpSecuritySpec::new(mode)` | Selects a mode with graceful reload, generation zero, and empty credentials. | Caller owns strings and secret-file lifecycle. TLS/mTLS requires explicit file fields, ID, and positive generation. |
| `RuntimeHost::start` / `start_with_runtime_lib` | Starts one host; omitted groups select Core defaults. | Connection intent enters construction; security applies before handle export/start. Credential loading may block. Rejection releases runtime/handle ownership. |
| `runtime.runtime_startup_config()` | Copies Core's accepted execution, connection, I/O and monitor facts. | No OS probe or connector default table. |
| `runtime.runtime_delivery_config()` | Copies Core's selected request/response delivery composition. | No backend or descriptor inference. |
| `runtime.runtime_network_config()` | Copies accepted listener mode, endpoints and explicit-policy fact. | Runtime-owned strings are copied while the host is borrowed; no connector probing or inferred network state. |
| `runtime.runtime_capabilities()` | Copies capability truth through the active host. | Serialized with transport apply; open host only; all editions. |
| `runtime.tcp_connection_config()` | Copies mode, tuning, and explicit/default provenance. | Synchronous, serialized, open host only; optional modes follow effective capabilities. |
| `runtime.tcp_security_info()` | Copies active non-secret TLS/mTLS state and certificate identity. | Synchronous and serialized. No secret/path borrowing escapes the call; TLS fields are capability-gated. |
| `runtime.startup_tcp_connection_config()` | Returns Core's accepted explicit startup configuration. | `None` when omitted; returns an owned clone, not a reconstructed apply result. |
| `runtime.startup_tcp_security_result()` | Returns the explicit startup result. | `None` when omitted; returns an owned non-secret clone. |
| `runtime.apply_tcp_connection_strategy(spec)` | Attempts an atomic connection apply. | Serialized. Connection mode is startup-only, so a started host normally returns `BAD_STATE` and the unchanged active config. |
| `runtime.apply_tcp_security(spec)` | Applies startup-shaped security or same-mode newer-generation reload. | Strings are borrowed only for the synchronous call; file I/O may block. Invalid/stale reload preserves the active immutable context. |
| `result.applied()` | Tests whether native status is `OK`. | Pure copied-value operation; successful no-op and `changed == false` are distinct. |
| `RuntimeTransportAbi::sizes()` | Reports Rust sizes for eleven C ABI blocks. | Layout diagnostic only. It does not prove runtime execution on another OS or CPU. |

All transport methods preserve unknown numeric C ABI values in transparent Rust
newtypes. The binding does not remap an unsupported request into another mode.

## TLS Reload

The Core 3.2 profile bundled in this archive does not advertise TCP TLS.
Its qualification covers the typed unsupported refusal and unchanged active
state, not a successful TLS reload. The following API shape applies only to a
Core build that actually advertises that capability.

```rust
let mut reload = TcpSecuritySpec::new(TcpSecurityMode::TLS);
reload.credential_generation = 2;
reload.credential_id = "orders-2026-08".into();
reload.ca_certificate_file = "/run/secrets/coakka/ca.pem".into();
reload.identity_certificate_file = "/run/secrets/coakka/tls.pem".into();
reload.private_key_file = "/run/secrets/coakka/tls.key".into();
let result = runtime.apply_tcp_security(&reload)?;
```

The runtime loads and validates the files synchronously, then atomically
publishes a private immutable TLS context. A rejected mismatch or stale
generation leaves the previous context active. See the canonical
[TLS/mTLS guide](https://github.com/phuong-tran/coakka-publish/blob/main/docs/coakka-runtime/reference/tls-and-mtls.md)
for Kubernetes ingress/service mesh, controlled networks, LAN/edge, RPi,
BeagleBone, bare metal, industrial Android, and rotation semantics.

## Platforms And Troubleshooting

Private gates stage a digest-pinned matching-host native artifact. Payload
presence and cross-platform source builds are not matching-host execution
evidence. Use [common troubleshooting](https://github.com/phuong-tran/coakka-publish/blob/main/docs/coakka-runtime/operations/troubleshooting.md)
for loader/CPU mismatch, dependencies, certificates, Gatekeeper, Authenticode,
checksums, and the currently absent publisher signature. Signing is deferred
and is not a connector gate. Contact `gabrielgun1983@gmail.com` or the public
issue tracker.
