//! Causal Core status is distinct from host projection/loading/lifetime errors.
use crate::{
    Result, RuntimeDeadletter, TcpConnectionApplyResult, TcpConnectionValidation,
    TcpSecurityApplyResult,
};
use std::fmt;

/// Stable status returned by the runtime C ABI; unknown values are preserved.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(transparent)]
pub struct CoAkkaStatus(pub i32);

impl CoAkkaStatus {
    /// Operation completed successfully.
    pub const OK: Self = Self(0);
    /// One or more arguments violate the operation contract.
    pub const INVALID_ARGUMENT: Self = Self(-1);
    /// Required bounded storage could not be allocated.
    pub const NO_MEMORY: Self = Self(-2);
    /// Operation is not valid in the current lifecycle state.
    pub const BAD_STATE: Self = Self(-3);
    /// Requested generation is not newer than active state.
    pub const STALE_GENERATION: Self = Self(-4);
    /// Transport or operating-system I/O failed.
    pub const IO: Self = Self(-5);
    /// Non-blocking observation has no new value.
    pub const WOULD_BLOCK: Self = Self(-6);
    /// Runtime or lane has closed.
    pub const CLOSED: Self = Self(-7);
    /// Loaded build does not implement the requested capability.
    pub const FEATURE_UNAVAILABLE: Self = Self(-8);
    /// Loaded distribution does not entitle the requested capability.
    pub const FEATURE_NOT_ENTITLED: Self = Self(-9);
}

/// Structured connector failure preserving runtime rejection details.
#[derive(Debug)]
pub enum CoAkkaError {
    /// A host value cannot cross the connector's boundary safely.
    InvalidArgument(String),
    /// Nonzero result returned by Core, without interpretation or reclassification.
    Core {
        /// Operation that actually returned this status; contains no user input.
        operation: &'static str,
        /// Exact Core status, including unknown future values.
        status: CoAkkaStatus,
    },
    /// Host loading, lifecycle or output-projection failure, not a Core status.
    Native(String),
    /// Host operating-system I/O failure.
    Io(String),
    /// Invalid or unsupported envelope encoding.
    WireCodec(String),
    /// An application handler unwound; no reply or Core outcome was fabricated.
    HandlerPanic,
    /// A request did not produce a terminal event before its deadline.
    Timeout(String),
    /// The runtime rejected or could not route a request.
    Deadletter(Box<RuntimeDeadletter>),
    /// Startup connection policy was rejected; contains the active state.
    TcpConnectionApply(Box<TcpConnectionApplyResult>),
    /// Startup connection intent failed Core validation before construction.
    TcpConnectionValidation(TcpConnectionValidation),
    /// Startup security policy was rejected; contains the active state.
    TcpSecurityApply(Box<TcpSecurityApplyResult>),
}

impl fmt::Display for CoAkkaError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidArgument(value) => write!(f, "invalid argument: {value}"),
            Self::Core { operation, status } => {
                write!(
                    f,
                    "native runtime error: {operation} returned status {}",
                    status.0
                )
            }
            Self::Native(value) => write!(f, "native runtime error: {value}"),
            Self::Io(value) => write!(f, "I/O error: {value}"),
            Self::WireCodec(value) => write!(f, "wire codec error: {value}"),
            Self::HandlerPanic => write!(f, "application handler panicked; no reply submitted"),
            Self::Timeout(value) => write!(f, "timeout: {value}"),
            Self::Deadletter(deadletter) => write!(
                f,
                "deadletter reason={} target={} detail={}",
                deadletter.reason, deadletter.original.target, deadletter.detail
            ),
            Self::TcpConnectionApply(result) => write!(
                f,
                "TCP connection apply failed status={} reason={} validation={}",
                result.status.0, result.reason_name, result.validation_code.0
            ),
            Self::TcpConnectionValidation(result) => write!(
                f,
                "TCP connection validation failed status={} validation={} field={}",
                result.status.0, result.code.0, result.field
            ),
            Self::TcpSecurityApply(result) => write!(
                f,
                "TCP security apply failed status={} reason={} validation={}",
                result.status.0, result.reason_name, result.validation_code.0
            ),
        }
    }
}
impl std::error::Error for CoAkkaError {}

pub(crate) fn status_to_result(status: i32, operation: &'static str) -> Result<()> {
    if status == 0 {
        Ok(())
    } else {
        Err(CoAkkaError::Core {
            operation,
            status: CoAkkaStatus(status),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn status_preserves_known_and_unknown_values_without_guessing() {
        assert!(status_to_result(0, "probe").is_ok());
        for value in [
            -1,
            -2,
            -3,
            -4,
            -5,
            -6,
            -7,
            -8,
            -9,
            i32::MIN,
            -1000,
            1,
            i32::MAX,
        ] {
            match status_to_result(value, "probe").unwrap_err() {
                CoAkkaError::Core { operation, status } => {
                    assert_eq!(operation, "probe");
                    assert_eq!(status.0, value);
                }
                other => panic!("unexpected reclassification: {other}"),
            }
        }
    }
}
