use crate::{CoAkkaError, Result};
use std::ffi::{c_char, CString};

pub(crate) const LANE_OWNER_GRANTS_FEATURE: u32 = 1 << 25;

/// Stable identity and directly reachable host for one exact lane replica.
#[derive(Clone, Debug)]
pub struct LaneOwnerConfig {
    /// Process or pod incarnation that owns prepared lane state.
    pub owner_instance_id: String,
    /// Host that reaches this exact owner, never a load-balancing service.
    pub advertised_host: String,
}

/// Direct endpoint of the owner retaining one prepared lane record.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct LaneOwnerEndpoint {
    /// Process or pod incarnation identity.
    pub owner_instance_id: String,
    /// Directly reachable owner host.
    pub advertised_host: String,
    /// Actual listener port selected when the lane started.
    pub port: u16,
}

impl LaneOwnerEndpoint {
    /// Copies a control-plane endpoint, checking only C-string representability.
    /// This does not validate Core policy or prove that the endpoint is reachable.
    pub fn from_control_plane(
        owner_instance_id: impl Into<String>,
        advertised_host: impl Into<String>,
        port: u16,
    ) -> Result<Self> {
        let owner_instance_id = owner_instance_id.into();
        let advertised_host = advertised_host.into();
        representable(&owner_instance_id)?;
        representable(&advertised_host)?;
        Ok(Self {
            owner_instance_id,
            advertised_host,
            port,
        })
    }
}

#[repr(C)]
pub(crate) struct NativeOwnerConfig {
    pub(crate) struct_size: usize,
    pub(crate) owner_instance_id: *const c_char,
    pub(crate) advertised_host: *const c_char,
}

#[repr(C)]
pub(crate) struct NativeOwnerEndpoint {
    pub(crate) struct_size: usize,
    pub(crate) port: u16,
    pub(crate) reserved: u16,
    pub(crate) owner_instance_id: [c_char; 128],
    pub(crate) advertised_host: [c_char; 256],
}

impl Default for NativeOwnerEndpoint {
    fn default() -> Self {
        // SAFETY: zero is the documented initialization for every scalar and
        // fixed-size character array in the native endpoint record.
        unsafe { std::mem::zeroed() }
    }
}

pub(crate) fn native_owner(
    owner: &LaneOwnerConfig,
) -> Result<(CString, CString, NativeOwnerConfig)> {
    let id = CString::new(owner.owner_instance_id.as_str())
        .map_err(|_| CoAkkaError::InvalidArgument("owner_instance_id contains NUL".into()))?;
    let host = CString::new(owner.advertised_host.as_str())
        .map_err(|_| CoAkkaError::InvalidArgument("advertised_host contains NUL".into()))?;
    let native = NativeOwnerConfig {
        struct_size: std::mem::size_of::<NativeOwnerConfig>(),
        owner_instance_id: id.as_ptr(),
        advertised_host: host.as_ptr(),
    };
    Ok((id, host, native))
}

pub(crate) fn endpoint(native: &NativeOwnerEndpoint) -> Result<LaneOwnerEndpoint> {
    if native.port == 0 {
        return Err(CoAkkaError::Native("owner grant returned port zero".into()));
    }
    Ok(LaneOwnerEndpoint {
        owner_instance_id: fixed(&native.owner_instance_id)?,
        advertised_host: fixed(&native.advertised_host)?,
        port: native.port,
    })
}

pub(crate) fn fixed(bytes: &[c_char]) -> Result<String> {
    String::from_utf8(fixed_bytes(bytes)?)
        .map_err(|_| CoAkkaError::Native("owner grant returned invalid UTF-8".into()))
}

pub(crate) fn detail(bytes: &[c_char]) -> Result<String> {
    Ok(String::from_utf8_lossy(&fixed_bytes(bytes)?).into_owned())
}

fn fixed_bytes(bytes: &[c_char]) -> Result<Vec<u8>> {
    // Never search beyond the ABI array, even if a loaded image violates its
    // output contract. Diagnostic text stays lossy; bearer values stay strict.
    let end = bytes
        .iter()
        .position(|byte| *byte == 0)
        .ok_or_else(|| CoAkkaError::Native("unterminated Core text output".into()))?;
    Ok(bytes[..end]
        .iter()
        .map(|byte| byte.to_ne_bytes()[0])
        .collect())
}

pub(crate) fn representable(value: &str) -> Result<()> {
    if value.as_bytes().contains(&0) {
        return Err(CoAkkaError::InvalidArgument(
            "lane text contains NUL".into(),
        ));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn fixed_outputs_are_bounded_and_bearers_are_strict_utf8() {
        assert!(fixed(&[]).is_err());
        for size in 1..=256 {
            let mut bytes = vec![c_char::from_ne_bytes([b'q']); size];
            assert!(fixed(&bytes).is_err());
            bytes[size - 1] = 0;
            assert_eq!(fixed(&bytes).unwrap(), "q".repeat(size - 1));
        }
        for byte in 0..=u8::MAX {
            let bytes = [c_char::from_ne_bytes([byte]), 0];
            let expected = if byte == 0 {
                &[][..]
            } else {
                std::slice::from_ref(&byte)
            };
            assert_eq!(
                fixed(&bytes).ok(),
                std::str::from_utf8(expected).ok().map(str::to_owned)
            );
            assert_eq!(detail(&bytes).unwrap(), String::from_utf8_lossy(expected));
        }
    }
}
