//! Rust connector for CoAkka request/reply, transport policy, File Lane, and
//! Stream Lane.
//!
//! Public values own their text and byte storage unless a callback explicitly
//! documents a borrow. Runtime hosts and lanes synchronize close with active
//! calls, but application callbacks remain responsible for their own bounded
//! execution and application-state synchronization.

#![deny(missing_docs)]
#![deny(clippy::undocumented_unsafe_blocks)]
#![deny(unsafe_op_in_unsafe_fn)]

mod error;
mod file_lane;
mod lane_owner;
mod native_library;
mod platform;
mod runtime_client_native;
mod runtime_handlers;
mod runtime_startup;
mod stream_lane;
mod transport;
mod wire;

pub use error::{CoAkkaError, CoAkkaStatus};
pub use file_lane::*;
pub use lane_owner::*;
pub use native_library::RuntimeLibraryResolver;
pub use runtime_startup::*;
pub use stream_lane::*;
pub use transport::*;

use error::status_to_result;
use native_library::NativeLibrary;
use runtime_handlers::HandlerRegistry;
use runtime_startup::apply_network_options;
use std::collections::HashMap;
use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_int, c_void};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::thread::{self, JoinHandle};
use std::time::Duration;
use wire::{decode_deadletter, decode_envelope, encode_envelope, encode_initial_snapshot};

use runtime_client_native::{
    NativeAskClient, NativeAskResultKind, NativeDeliveredRequest, NativeReadResult,
    NativeRequestReader,
};

const ABI_VERSION: u32 = 1;
const MAXIMUM_CLIENT_FRAME_BYTES: usize = 64 * 1024 * 1024;

/// Result returned by connector operations.
pub type Result<T> = std::result::Result<T, CoAkkaError>;

/// Envelope role on the request/reply transport.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(i32)]
pub enum MessageKind {
    /// No role declared; not an inferred request.
    Unspecified = 0,
    /// Request which may expect a terminal response.
    Request = 1,
    /// Response correlated to a request.
    Response = 2,
    /// One-way event.
    Event = 3,
    /// Numeric value unknown to this connector, preserved without guessing.
    Unknown(i32),
}

/// Application-level outcome carried by a response.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(i32)]
pub enum BusinessStatus {
    /// No business outcome declared; not an inferred success.
    Unspecified = 0,
    /// Application operation succeeded.
    Ok = 1,
    /// Application operation failed; inspect error fields.
    Error = 2,
    /// Numeric value unknown to this connector, preserved without guessing.
    Unknown(i32),
}

/// Optional locality constraint supplied to routing.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(i32)]
pub enum DeliveryHint {
    /// No locality preference declared.
    Unspecified = 0,
    /// Lets the route strategy choose.
    RouterDefault = 1,
    /// Prefers a local endpoint but permits remote delivery.
    PreferLocal = 2,
    /// Rejects delivery unless a local endpoint is eligible.
    RequireLocal = 3,
    /// Rejects delivery unless a remote endpoint is eligible.
    RequireRemote = 4,
    /// Numeric value unknown to this connector, preserved without guessing.
    Unknown(i32),
}

/// Application payload encoding identified independently from its schema name.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(i32)]
pub enum PayloadFormat {
    /// No payload format was declared.
    Unspecified = 0,
    /// UTF-8 JSON bytes.
    Json = 1,
    /// Application-defined binary wire format.
    WireBinary = 2,
    /// Apache Thrift payload.
    Thrift = 3,
    /// MessagePack payload.
    MessagePack = 4,
    /// UTF-8 plain text.
    PlainText = 5,
    /// Opaque binary bytes.
    Binary = 6,
    /// Numeric value unknown to this connector, preserved without guessing.
    Unknown(i32),
}

// Wire numbers are values, never Rust discriminant/layout observations. This
// projection deliberately leaves acceptance and default resolution with Core.
macro_rules! wire_values {
    ($name:ident { $($variant:ident = $number:literal),+ $(,)? }) => {
        impl $name {
            /// Preserves a numeric value, including values not yet named here.
            pub const fn from_value(value: i32) -> Self {
                match value { $($number => Self::$variant,)+ other => Self::Unknown(other) }
            }
            /// Returns the exact wire number, including an unknown value.
            pub const fn value(self) -> i32 {
                match self { $(Self::$variant => $number,)+ Self::Unknown(value) => value }
            }
        }
    };
}

wire_values!(MessageKind { Unspecified = 0, Request = 1, Response = 2, Event = 3 });
wire_values!(BusinessStatus { Unspecified = 0, Ok = 1, Error = 2 });
wire_values!(DeliveryHint {
    Unspecified = 0, RouterDefault = 1, PreferLocal = 2, RequireLocal = 3, RequireRemote = 4
});
wire_values!(PayloadFormat {
    Unspecified = 0, Json = 1, WireBinary = 2, Thrift = 3, MessagePack = 4, PlainText = 5, Binary = 6
});

/// Stable application payload type, schema generation, and encoding.
#[derive(Clone, Debug)]
pub struct PayloadIdentity {
    /// Application message type; typed operations require a non-blank value.
    pub message_type: String,
    /// Positive application schema generation.
    pub payload_schema_version: u32,
    /// Encoding of the payload bytes.
    pub payload_format: PayloadFormat,
}

impl PayloadIdentity {
    /// Creates a JSON identity for a named positive schema generation.
    pub fn json(message_type: impl Into<String>, payload_schema_version: u32) -> Self {
        Self {
            message_type: message_type.into(),
            payload_schema_version,
            payload_format: PayloadFormat::Json,
        }
    }

    fn require_typed(&self, what: &str) -> Result<()> {
        if self.message_type.trim().is_empty() {
            return Err(CoAkkaError::InvalidArgument(format!(
                "{what} requires message_type"
            )));
        }
        if self.payload_schema_version == 0 {
            return Err(CoAkkaError::InvalidArgument(format!(
                "{what} requires payload_schema_version >= 1"
            )));
        }
        if self.payload_format == PayloadFormat::Unspecified {
            return Err(CoAkkaError::InvalidArgument(format!(
                "{what} requires payload_format"
            )));
        }
        Ok(())
    }
}

/// Owned request, response, or event crossing the connector boundary.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TransportEnvelope {
    /// Stable unique message identifier.
    pub message_id: String,
    /// Request correlation identifier; blank for uncorrelated one-way work.
    pub correlation_id: String,
    /// Logical source identity.
    pub source: String,
    /// Logical route target.
    pub target: String,
    /// Optional logical reply target.
    pub reply_to: String,
    /// Request, response, or event role.
    pub kind: MessageKind,
    /// True when no response is expected.
    pub one_way: bool,
    /// Request budget in milliseconds as carried on the envelope.
    pub timeout_ms: i32,
    /// Owned application payload bytes.
    pub payload: Vec<u8>,
    /// Owned application metadata.
    pub headers: HashMap<String, String>,
    /// Application response outcome.
    pub status: BusinessStatus,
    /// Stable application error code when status is error.
    pub error_code: String,
    /// Human-readable application error detail.
    pub error_message: String,
    /// Locality constraint for routing.
    pub delivery_hint: DeliveryHint,
    /// Application payload type name.
    pub message_type: String,
    /// Application payload schema generation.
    pub payload_schema_version: u32,
    /// Application payload encoding.
    pub payload_format: PayloadFormat,
}

impl TransportEnvelope {
    /// Decodes payload bytes lossily as UTF-8 for diagnostics.
    pub fn payload_utf8(&self) -> String {
        String::from_utf8_lossy(&self.payload).to_string()
    }

    /// Copies the three payload identity fields.
    pub fn payload_identity(&self) -> PayloadIdentity {
        PayloadIdentity {
            message_type: self.message_type.clone(),
            payload_schema_version: self.payload_schema_version,
            payload_format: self.payload_format,
        }
    }
}

/// Owned deadletter projection returned for a terminal request failure.
#[derive(Clone, Debug)]
pub struct RuntimeDeadletter {
    /// Original envelope rejected by routing or delivery.
    pub original: TransportEnvelope,
    /// Stable reason name, or DEADLETTER_REASON_UNKNOWN for an unnamed number.
    pub reason: String,
    /// Exact Core reason number, including values unknown to this connector.
    pub reason_code: i32,
    /// Human-readable diagnostic detail.
    pub detail: String,
    /// Route generation active when the deadletter was produced.
    pub active_generation: u64,
    /// Resolved host, when endpoint selection completed.
    pub resolved_host: String,
    /// Resolved port, or zero when no endpoint was selected.
    pub resolved_port: u32,
    /// Core-issued delivery attempt count; not an application retry count.
    pub endpoint_attempt_count: u32,
    /// Core-issued transport facts, preserving unknown keys and values.
    pub transport_failure_metadata: HashMap<String, String>,
}

/// Immutable identity of the loaded runtime build.
#[derive(Clone, Debug)]
pub struct RuntimeInfo {
    /// Host ABI generation.
    pub abi_version: u32,
    /// Runtime semantic version.
    pub runtime_version: String,
    /// Source revision embedded in the runtime.
    pub git_commit: String,
    /// Selected delivery backend name.
    pub delivery_backend: String,
}

/// Copied coarse runtime configuration and lifecycle state.
#[derive(Clone, Debug)]
pub struct RuntimeConfigSnapshot {
    /// Configured logical system name.
    pub system_name: String,
    /// Configured node identity.
    pub node_id: String,
    /// Latest atomically applied route generation.
    pub applied_generation: u64,
    /// Routes in the active snapshot.
    pub route_count: usize,
    /// Stable numeric lifecycle state.
    pub runtime_state: i32,
}

/// Core-issued CPU selection facts accepted for one runtime instance.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RuntimeStartupCpuInfo {
    /// Requested Core policy; zero is AUTO.
    pub requested_policy: u32,
    /// Whether the selected policy is supported on this host.
    pub supported: bool,
    /// Logical CPUs available to Core at construction.
    pub available_cpu_count: u32,
    /// Logical CPUs selected by Core.
    pub selected_cpu_count: u32,
    /// Selected logical CPU identifiers, when reported.
    pub selected_cpu_ids: [u32; 2],
    /// Whether Core applied the selection at worker birth.
    pub startup_applied: bool,
}

/// Core-issued optional receiver-readiness facts.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RuntimeStartupIoInfo {
    /// Whether optional readiness was requested.
    pub requested: bool,
    /// Whether the loaded Core contains the optional implementation.
    pub compiled: bool,
    /// Whether Core performed the construction probe.
    pub probed: bool,
    /// Whether the construction probe succeeded.
    pub supported: bool,
    /// Whether the optional path is effective for this running instance.
    pub effective: bool,
    /// Positive Core-issued probe error, or zero.
    pub probe_error: i32,
}

/// Core-issued monitor collection permission.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RuntimeStartupMonitorInfo {
    /// Whether bounded monitor collection was accepted.
    pub enabled: bool,
}

/// Complete accepted startup configuration copied from Core.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RuntimeStartupConfigSnapshot {
    /// Revision governing Core defaults.
    pub defaults_revision: u32,
    /// Groups resolved from Core defaults.
    pub defaulted_groups: u32,
    /// Accepted no-drop policy.
    pub strict_no_drop: bool,
    /// Accepted bounded queue capacity.
    pub queue_capacity: u32,
    /// Accepted request-frame ceiling.
    pub request_max_frame_size: u64,
    /// Runtime lifecycle state in this snapshot.
    pub runtime_state: u32,
    /// Accepted CPU selection facts.
    pub execution: RuntimeStartupCpuInfo,
    /// Accepted TCP connection policy and provenance.
    pub connection: TcpConnectionConfigSnapshot,
    /// Accepted optional readiness facts.
    pub io: RuntimeStartupIoInfo,
    /// Accepted monitor collection permission.
    pub monitor: RuntimeStartupMonitorInfo,
}

/// Core-selected immutable request/response delivery composition.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RuntimeDeliveryConfigSnapshot {
    /// Whether this Core contains the owned-queue composition.
    pub compiled: bool,
    /// Core-selected delivered-request mode.
    pub request_mode: u32,
    /// Core-selected terminal-response mode.
    pub response_mode: u32,
    /// Maximum already-ready remote calls drained in one turn.
    pub remote_batch_max_calls: u32,
    /// Bounded owned-delivery slot capacity.
    pub slot_capacity: u32,
    /// Bounded owned-delivery byte capacity.
    pub byte_capacity: u64,
}

/// Connector-side request correlation and delivery counters.
#[derive(Clone, Debug, Default)]
pub struct RuntimeClientStats {
    /// Requests currently awaiting a terminal event.
    pub pending_requests: usize,
    /// Requests delivered to registered host handlers.
    pub delivered_requests: u64,
    /// Responses matched to pending requests.
    pub matched_responses: u64,
    /// Deadletters matched to pending requests.
    pub matched_deadletters: u64,
    /// Application callback unwinds isolated by the Rust reader, not Core failures.
    pub handler_panics: u64,
}

/// Owner of one started runtime instance and its host-side reader workers.
/// External Drop joins its reader. Drop from that same reader seals admission
/// and native teardown follows when the current callback returns. Callbacks
/// must return promptly and must not form strong Arc cycles with their host.
pub struct RuntimeHost {
    inner: Arc<RuntimeInner>,
    reader: Option<JoinHandle<()>>,
    startup_connection_config: Option<TcpConnectionConfigSnapshot>,
    startup_security_result: Option<TcpSecurityApplyResult>,
}

// One native resource bundle belongs to RuntimeInner. Its worker's Arc keeps
// every native pointer live even if the final public host is dropped there.
struct RuntimeResources {
    request_reader: Option<NativeRequestReader>,
    host_handles: NativeHostHandles,
}

struct RuntimeInner {
    lib: NativeLibrary,
    runtime: RuntimePtr,
    runtime_lib_path: PathBuf,
    closed: AtomicBool,
    transport_mu: Mutex<()>,
    submit_mu: Mutex<()>,
    ask_client: NativeAskClient,
    resources: Mutex<RuntimeResources>,
    handlers: HandlerRegistry,
    pending_requests: AtomicU64,
    delivered_requests: AtomicU64,
    matched_responses: AtomicU64,
    matched_deadletters: AtomicU64,
    handler_panics: AtomicU64,
}

struct RuntimeStartupOwners {
    handles: NativeHostHandles,
    request_reader: NativeRequestReader,
    ask_client: NativeAskClient,
    connection_config: Option<TcpConnectionConfigSnapshot>,
    security_result: Option<TcpSecurityApplyResult>,
}

impl RuntimeHost {
    /// Resolves the packaged runtime and starts one host from a complete spec.
    pub fn start(spec: ConnectorStartSpec) -> Result<Self> {
        Self::start_with_runtime_lib(spec, "")
    }

    /// Starts one host using an explicit runtime path when non-empty.
    ///
    /// Startup is transactional: rejected transport policy, handle export,
    /// snapshot application, or start destroys the partial runtime before
    /// returning. The path must resolve to the same process-wide runtime module
    /// identity as any host or lane opened earlier.
    pub fn start_with_runtime_lib(
        spec: ConnectorStartSpec,
        runtime_lib_path: impl AsRef<str>,
    ) -> Result<Self> {
        let resolved_path = RuntimeLibraryResolver::resolve(runtime_lib_path.as_ref())?;
        let lib = NativeLibrary::open(&resolved_path)?;
        let system_name = CString::new(spec.system_name.clone())
            .map_err(|_| CoAkkaError::InvalidArgument("system_name contains NUL".to_string()))?;
        let node_id = CString::new(spec.node_id.clone())
            .map_err(|_| CoAkkaError::InvalidArgument("node_id contains NUL".to_string()))?;
        let native_config = NativeRuntimeConfig {
            system_name: system_name.as_ptr(),
            node_id: node_id.as_ptr(),
            strict_no_drop: if spec.strict_no_drop { 1 } else { 0 },
            queue_capacity: spec.queue_capacity,
        };
        let runtime = lib.create_native_runtime(&native_config, &spec)?;

        let mut exported_handles = None;
        let mut created_reader = None;
        let mut created_ask_client = None;
        let mut started = false;
        let startup = (|| -> Result<RuntimeStartupOwners> {
            if let Some(network) = &spec.network {
                apply_network_options(&lib, runtime, network)?;
            }
            let startup_facts = lib.startup_config(runtime)?;
            let startup_connection_config = if spec.connection_strategy.is_some() {
                Some(startup_facts.connection)
            } else {
                None
            };
            let startup_security_result = if let Some(security) = &spec.security {
                let result = transport::apply_security_native(&lib, runtime, security)?;
                if !result.applied() {
                    return Err(CoAkkaError::TcpSecurityApply(Box::new(result)));
                }
                Some(result)
            } else {
                None
            };

            let mut handles = NativeHostHandles {
                struct_size: std::mem::size_of::<NativeHostHandles>(),
                flags: host_handle_flags(&spec, startup_facts.monitor.enabled),
                ..NativeHostHandles::default()
            };
            status_to_result(
                // SAFETY: runtime is live and owned by this startup transaction;
                // `handles` is a writable correctly sized output record.
                unsafe {
                    (lib.get_host_handles)(runtime.0, &mut handles as *mut NativeHostHandles)
                },
                "coakka_v2_runtime_get_host_handles",
            )?;
            exported_handles = Some(handles);

            let control = encode_initial_snapshot(&spec)?;
            status_to_result(
                // SAFETY: runtime remains live and `control` is readable for
                // the duration of the synchronous apply call.
                unsafe { (lib.apply_control_envelope)(runtime.0, control.as_ptr(), control.len()) },
                "coakka_v2_runtime_apply_control_envelope",
            )?;
            status_to_result(
                // SAFETY: runtime remains live and this transaction has not
                // exposed it to another owner yet.
                unsafe { (lib.start_runtime)(runtime.0) },
                "coakka_v2_runtime_start",
            )?;
            started = true;
            let request_reader = lib.create_request_reader(runtime, &handles)?;
            created_reader = Some(request_reader);
            let ask_client = lib.create_ask_client(runtime, &handles)?;
            created_ask_client = Some(ask_client);
            Ok(RuntimeStartupOwners {
                handles,
                request_reader,
                ask_client,
                connection_config: startup_connection_config,
                security_result: startup_security_result,
            })
        })();

        let RuntimeStartupOwners {
            handles,
            request_reader,
            ask_client,
            connection_config: startup_connection_config,
            security_result: startup_security_result,
        } = match startup {
            Ok(value) => value,
            Err(error) => {
                if let Some(ask_client) = created_ask_client {
                    lib.destroy_ask_client(ask_client);
                }
                if let Some(request_reader) = created_reader {
                    lib.destroy_request_reader(request_reader);
                }
                if started {
                    // SAFETY: the startup transaction still owns this runtime.
                    let _ = unsafe { (lib.stop_runtime)(runtime.0) };
                }
                if let Some(mut handles) = exported_handles {
                    lib.close_host_handles(&mut handles);
                }
                // SAFETY: startup failed before runtime ownership escaped; this
                // transaction owns and destroys the pointer exactly once.
                unsafe { (lib.destroy_runtime)(runtime.0) };
                return Err(error);
            }
        };

        let inner = Arc::new(RuntimeInner {
            lib,
            runtime,
            runtime_lib_path: resolved_path,
            closed: AtomicBool::new(false),
            transport_mu: Mutex::new(()),
            submit_mu: Mutex::new(()),
            ask_client,
            resources: Mutex::new(RuntimeResources {
                request_reader: Some(request_reader),
                host_handles: handles,
            }),
            handlers: HandlerRegistry::default(),
            pending_requests: AtomicU64::new(0),
            delivered_requests: AtomicU64::new(0),
            matched_responses: AtomicU64::new(0),
            matched_deadletters: AtomicU64::new(0),
            handler_panics: AtomicU64::new(0),
        });
        let reader = spawn_request_reader(inner.clone(), request_reader)?;
        Ok(Self {
            inner,
            reader: Some(reader),
            startup_connection_config,
            startup_security_result,
        })
    }

    /// Returns the resolved runtime library path retained by this host.
    pub fn runtime_lib_path(&self) -> &Path {
        &self.inner.runtime_lib_path
    }

    /// Registers or replaces a synchronous handler for one logical target.
    ///
    /// The handler runs on a connector reader thread. Keep it bounded and
    /// return an owned reply, or `None` for intentionally one-way handling.
    /// Up to 256 exact target keys totaling 64 KiB may be retained. These are
    /// Rust callback-storage limits, not Core route/default values. Replacement
    /// releases the old capture outside locks; an already selected callback
    /// may still finish. Use Weak host references in captures to avoid Arc cycles.
    pub fn register_handler<F>(&self, target: impl Into<String>, handler: F) -> Result<()>
    where
        F: Fn(TransportEnvelope) -> Option<TransportEnvelope> + Send + Sync + 'static,
    {
        self.inner.require_open()?;
        self.inner.handlers.register(target.into(), handler)
    }

    /// Removes an exact handler key and releases its capture outside locks.
    /// Returns false when absent. An already selected invocation may finish;
    /// this does not cancel native work or fabricate its terminal outcome.
    pub fn unregister_handler(&self, target: &str) -> Result<bool> {
        self.inner.require_open()?;
        self.inner.handlers.unregister(target)
    }

    #[allow(clippy::too_many_arguments)]
    /// Builds and sends a typed JSON request, then blocks for its terminal event.
    pub fn ask_json(
        &self,
        source: impl AsRef<str>,
        target: impl AsRef<str>,
        payload_json: impl AsRef<str>,
        payload_identity: PayloadIdentity,
        timeout: Duration,
        operation: impl AsRef<str>,
        delivery_hint: DeliveryHint,
    ) -> Result<TransportEnvelope> {
        let envelope = make_json_request(
            source.as_ref(),
            target.as_ref(),
            payload_json.as_ref().as_bytes().to_vec(),
            payload_identity,
            timeout,
            operation.as_ref(),
            delivery_hint,
            false,
        )?;
        self.ask(envelope, timeout)
    }

    /// Submits an owned request and lets Core match its terminal result under
    /// one monotonic timeout.
    pub fn ask(&self, envelope: TransportEnvelope, timeout: Duration) -> Result<TransportEnvelope> {
        self.inner.require_open()?;
        let timeout_ms = core_timeout_millis(timeout)?;
        let frame = encode_envelope(&envelope)?;
        self.inner.pending_requests.fetch_add(1, Ordering::Relaxed);
        let result = self
            .inner
            .lib
            .ask(self.inner.ask_client, &frame, timeout_ms);
        self.inner.pending_requests.fetch_sub(1, Ordering::Relaxed);
        let result = match result {
            Ok(value) => value,
            Err(CoAkkaError::Timeout(_)) => {
                return Err(CoAkkaError::Timeout(format!(
                    "request timed out target={}",
                    envelope.target
                )))
            }
            Err(error) => return Err(error),
        };
        match result.kind {
            NativeAskResultKind::Response => {
                self.inner.matched_responses.fetch_add(1, Ordering::Relaxed);
                decode_envelope(&result.frame)
            }
            NativeAskResultKind::Deadletter => {
                self.inner
                    .matched_deadletters
                    .fetch_add(1, Ordering::Relaxed);
                Err(CoAkkaError::Deadletter(Box::new(decode_deadletter(
                    &result.frame,
                )?)))
            }
        }
    }

    /// Submits one envelope without registering request correlation.
    pub fn submit_envelope(&self, envelope: &TransportEnvelope) -> Result<()> {
        self.inner.submit_envelope(envelope)
    }

    /// Copies immutable identity from the loaded runtime.
    pub fn runtime_info(&self) -> Result<RuntimeInfo> {
        let mut info = NativeRuntimeInfo {
            struct_size: std::mem::size_of::<NativeRuntimeInfo>(),
            ..NativeRuntimeInfo::default()
        };
        status_to_result(
            // SAFETY: the process-pinned module owns this no-instance getter
            // and `info` is a live correctly sized output record.
            unsafe { (self.inner.lib.get_info)(&mut info as *mut NativeRuntimeInfo) },
            "coakka_v2_runtime_get_info",
        )?;
        Ok(RuntimeInfo {
            abi_version: info.abi_version,
            runtime_version: ptr_to_string(info.runtime_version),
            git_commit: ptr_to_string(info.git_commit),
            delivery_backend: ptr_to_string(info.delivery_backend),
        })
    }

    /// Copies the active coarse configuration and lifecycle state.
    pub fn runtime_config(&self) -> Result<RuntimeConfigSnapshot> {
        let mut config = NativeRuntimeConfigView {
            struct_size: std::mem::size_of::<NativeRuntimeConfigView>(),
            ..NativeRuntimeConfigView::default()
        };
        status_to_result(
            // SAFETY: RuntimeHost owns a live runtime until Drop and `config`
            // is a writable correctly sized output record.
            unsafe {
                (self.inner.lib.get_config)(
                    self.inner.runtime.0,
                    &mut config as *mut NativeRuntimeConfigView,
                )
            },
            "coakka_v2_runtime_get_config",
        )?;
        Ok(RuntimeConfigSnapshot {
            system_name: ptr_to_string(config.system_name),
            node_id: ptr_to_string(config.node_id),
            applied_generation: config.applied_generation,
            route_count: config.route_count,
            runtime_state: config.runtime_state,
        })
    }

    /// Copies Core's accepted immutable startup configuration.
    pub fn runtime_startup_config(&self) -> Result<RuntimeStartupConfigSnapshot> {
        self.inner.require_open()?;
        self.inner.lib.startup_config(self.inner.runtime)
    }

    /// Copies Core's selected native delivery composition.
    pub fn runtime_delivery_config(&self) -> Result<RuntimeDeliveryConfigSnapshot> {
        self.inner.require_open()?;
        self.inner.lib.delivery_config(self.inner.runtime)
    }

    /// Copies connector-side counters without blocking on runtime I/O.
    pub fn client_stats(&self) -> RuntimeClientStats {
        RuntimeClientStats {
            pending_requests: usize::try_from(self.inner.pending_requests.load(Ordering::Relaxed))
                .unwrap_or(usize::MAX),
            delivered_requests: self.inner.delivered_requests.load(Ordering::Relaxed),
            matched_responses: self.inner.matched_responses.load(Ordering::Relaxed),
            matched_deadletters: self.inner.matched_deadletters.load(Ordering::Relaxed),
            handler_panics: self.inner.handler_panics.load(Ordering::Relaxed),
        }
    }

    /// Builds a JSON reply which preserves the request payload identity.
    pub fn make_json_reply_from_request_identity(
        request: &TransportEnvelope,
        source: impl AsRef<str>,
        payload_json: impl AsRef<str>,
    ) -> Result<TransportEnvelope> {
        make_json_reply(
            request,
            source.as_ref(),
            payload_json.as_ref().as_bytes().to_vec(),
            request.payload_identity(),
        )
    }
}

impl Drop for RuntimeHost {
    fn drop(&mut self) {
        self.inner.closed.store(true, Ordering::Release);
        if let Some(reader) = self.reader.take() {
            // A callback may drop the last public owner. Detach only that
            // current thread: its own Arc still owns native resources until
            // dispatch finishes and the reader loop observes closed. External
            // Drop joins normally; no cleanup worker or intentional leak.
            if reader.thread().id() != thread::current().id() {
                let _ = reader.join();
            }
        }
    }
}

impl Drop for RuntimeInner {
    fn drop(&mut self) {
        // The final Arc is the quiescence fence: no host call or reader can
        // still borrow a native owner, including after same-reader host Drop.
        let resources = self
            .resources
            .get_mut()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        if let Some(request_reader) = resources.request_reader.take() {
            self.lib.destroy_request_reader(request_reader);
        }
        // SAFETY: this sole native owner is quiescent and its reader retired.
        let status = unsafe { (self.lib.stop_runtime)(self.runtime.0) };
        if status != 0 {
            eprintln!("[coakka-rust] Core stop returned status {status} during destruction");
        }
        self.lib.destroy_ask_client(self.ask_client);
        self.lib.close_host_handles(&mut resources.host_handles);
        // SAFETY: all host calls are quiescent and attachments retired. Core's
        // destroy contract itself stops if necessary; no status is guessed.
        unsafe { (self.lib.destroy_runtime)(self.runtime.0) };
    }
}

impl RuntimeInner {
    fn require_open(&self) -> Result<()> {
        if self.closed.load(Ordering::Acquire) {
            Err(CoAkkaError::Native("runtime host is closed".to_string()))
        } else {
            Ok(())
        }
    }

    fn submit_envelope(&self, envelope: &TransportEnvelope) -> Result<()> {
        self.require_open()?;
        let _guard = self
            .submit_mu
            .lock()
            .map_err(|_| CoAkkaError::Native("submit mutex poisoned".to_string()))?;
        let bytes = encode_envelope(envelope)?;
        status_to_result(
            // SAFETY: RuntimeInner owns a live runtime, submit is serialized, and
            // encoded bytes remain readable for the synchronous copy.
            unsafe { (self.lib.submit_envelope)(self.runtime.0, bytes.as_ptr(), bytes.len()) },
            "coakka_v2_runtime_submit_envelope",
        )
    }
}

/// Builds an owned successful response correlated to `request`.
pub fn make_json_reply(
    request: &TransportEnvelope,
    source: &str,
    payload: Vec<u8>,
    payload_identity: PayloadIdentity,
) -> Result<TransportEnvelope> {
    payload_identity.require_typed("JSON reply")?;
    let correlation_id = if request.correlation_id.is_empty() {
        request.message_id.clone()
    } else {
        request.correlation_id.clone()
    };
    Ok(TransportEnvelope {
        message_id: format!("{}.reply.{}", request.message_id, source),
        correlation_id,
        source: source.to_string(),
        target: request.source.clone(),
        reply_to: String::new(),
        kind: MessageKind::Response,
        one_way: false,
        timeout_ms: request.timeout_ms,
        payload,
        headers: HashMap::new(),
        status: BusinessStatus::Ok,
        error_code: String::new(),
        error_message: String::new(),
        delivery_hint: DeliveryHint::RouterDefault,
        message_type: payload_identity.message_type,
        payload_schema_version: payload_identity.payload_schema_version,
        payload_format: payload_identity.payload_format,
    })
}

#[allow(clippy::too_many_arguments)]
fn make_json_request(
    source: &str,
    target: &str,
    payload: Vec<u8>,
    payload_identity: PayloadIdentity,
    timeout: Duration,
    operation: &str,
    delivery_hint: DeliveryHint,
    one_way: bool,
) -> Result<TransportEnvelope> {
    payload_identity.require_typed("JSON request")?;
    let timeout_ms = core_timeout_millis(timeout)?;
    let message_id = next_message_id(source);
    let mut headers = HashMap::new();
    headers.insert("method".to_string(), "POST".to_string());
    headers.insert("operation".to_string(), operation.to_string());
    Ok(TransportEnvelope {
        message_id: message_id.clone(),
        correlation_id: if one_way { String::new() } else { message_id },
        source: source.to_string(),
        target: target.to_string(),
        reply_to: if one_way {
            String::new()
        } else {
            format!("{source}/replies")
        },
        kind: MessageKind::Request,
        one_way,
        timeout_ms: timeout_ms as i32,
        payload,
        headers,
        status: BusinessStatus::Ok,
        error_code: String::new(),
        error_message: String::new(),
        delivery_hint,
        message_type: payload_identity.message_type,
        payload_schema_version: payload_identity.payload_schema_version,
        payload_format: payload_identity.payload_format,
    })
}

fn next_message_id(source: &str) -> String {
    static COUNTER: AtomicU64 = AtomicU64::new(1);
    let sequence = COUNTER.fetch_add(1, Ordering::Relaxed);
    format!("{source}.rust.{sequence:x}")
}

fn core_timeout_millis(timeout: Duration) -> Result<u32> {
    let nanos = timeout.as_nanos();
    let millis = nanos.saturating_add(999_999) / 1_000_000;
    if millis > i32::MAX as u128 {
        return Err(CoAkkaError::InvalidArgument(format!(
            "timeout exceeds Core envelope limit of {} ms",
            i32::MAX
        )));
    }
    Ok(millis as u32)
}

fn spawn_request_reader(
    inner: Arc<RuntimeInner>,
    reader: NativeRequestReader,
) -> Result<JoinHandle<()>> {
    thread::Builder::new()
        .name("coakka-reader".into())
        .spawn(move || {
            while !inner.closed.load(Ordering::Acquire) {
                match inner.lib.read_request(reader, 100) {
                    Ok(NativeReadResult::Request(request)) => {
                        if let Err(error) = on_request(&inner, request) {
                            if !inner.closed.load(Ordering::Acquire) {
                                eprintln!("[coakka-rust] request handler failed: {error}");
                            }
                        }
                    }
                    Ok(NativeReadResult::WouldBlock) => {}
                    Ok(NativeReadResult::Closed) => break,
                    Err(error) => {
                        if !inner.closed.load(Ordering::Acquire) {
                            eprintln!("[coakka-rust] request reader failed: {error}");
                        }
                        break;
                    }
                }
            }
        })
        .map_err(|error| CoAkkaError::Io(format!("cannot spawn request reader: {error}")))
}

fn on_request(inner: &Arc<RuntimeInner>, delivered: NativeDeliveredRequest) -> Result<()> {
    let mut request = decode_envelope(&delivered.frame)?;
    request.target = delivered.target;
    request.payload = delivered.payload;
    request.one_way = delivered.one_way;
    let handler = inner.handlers.select(&request.target)?;
    if let Some(handler) = handler {
        inner.delivered_requests.fetch_add(1, Ordering::Relaxed);
        let reply = handler.call(request).map_err(|error| {
            if matches!(error, CoAkkaError::HandlerPanic) {
                inner.handler_panics.fetch_add(1, Ordering::Relaxed);
            }
            error
        })?;
        if let Some(reply) = reply {
            inner.submit_envelope(&reply)?;
        }
    }
    Ok(())
}

fn host_handle_flags(spec: &ConnectorStartSpec, monitor_enabled: bool) -> u32 {
    let mut flags = 0;
    if monitor_enabled {
        flags |= 1 << 0;
    }
    if spec.separate_delivered_request_lane {
        flags |= 1 << 1;
    }
    flags
}

fn ptr_to_string(value: *const c_char) -> String {
    if value.is_null() {
        String::new()
    } else {
        // SAFETY: runtime introspection returns module/runtime-owned
        // NUL-terminated text; callers copy it while the owner is live.
        unsafe { CStr::from_ptr(value) }
            .to_string_lossy()
            .to_string()
    }
}

#[repr(C)]
#[derive(Copy, Clone)]
struct RuntimePtr(*mut c_void);

// SAFETY: the runtime contract supports cross-thread host calls. Mutating
// submit and transport operations are serialized by RuntimeInner. Its final
// Arc retires the pointer only after all host and reader borrows have ended.
unsafe impl Send for RuntimePtr {}
// SAFETY: shared access never transfers pointer ownership; lifecycle and
// mutation rules are enforced by RuntimeInner synchronization.
unsafe impl Sync for RuntimePtr {}

#[repr(C)]
struct NativeRuntimeConfig {
    system_name: *const c_char,
    node_id: *const c_char,
    strict_no_drop: c_int,
    queue_capacity: c_int,
}

#[repr(C)]
struct NativeRuntimeInfo {
    struct_size: usize,
    abi_version: u32,
    feature_flags: u32,
    runtime_version: *const c_char,
    git_commit: *const c_char,
    delivery_backend: *const c_char,
    allocator_backend: *const c_char,
    docs_hint: *const c_char,
    transport_profile: *const c_char,
    transport_profile_version: u32,
}

impl Default for NativeRuntimeInfo {
    fn default() -> Self {
        Self {
            struct_size: 0,
            abi_version: 0,
            feature_flags: 0,
            runtime_version: std::ptr::null(),
            git_commit: std::ptr::null(),
            delivery_backend: std::ptr::null(),
            allocator_backend: std::ptr::null(),
            docs_hint: std::ptr::null(),
            transport_profile: std::ptr::null(),
            transport_profile_version: 0,
        }
    }
}

#[repr(C)]
struct NativeRuntimeConfigView {
    struct_size: usize,
    system_name: *const c_char,
    node_id: *const c_char,
    strict_no_drop: c_int,
    queue_capacity: c_int,
    request_max_frame_size: usize,
    local_dispatch_batch_limit: usize,
    runtime_state: c_int,
    snapshot_present: u32,
    applied_generation: u64,
    route_count: usize,
    transport_bind_host: *const c_char,
    transport_bind_port: u16,
}

impl Default for NativeRuntimeConfigView {
    fn default() -> Self {
        Self {
            struct_size: 0,
            system_name: std::ptr::null(),
            node_id: std::ptr::null(),
            strict_no_drop: 0,
            queue_capacity: 0,
            request_max_frame_size: 0,
            local_dispatch_batch_limit: 0,
            runtime_state: 0,
            snapshot_present: 0,
            applied_generation: 0,
            route_count: 0,
            transport_bind_host: std::ptr::null(),
            transport_bind_port: 0,
        }
    }
}

#[cfg(all(test, target_pointer_width = "64"))]
mod projection_layout_tests {
    use super::{NativeRuntimeConfigView, NativeRuntimeInfo};
    use std::mem::{align_of, offset_of, size_of};

    #[test]
    fn product_field_names_preserve_the_versioned_native_prefix() {
        // Product vocabulary changes Rust names only. The size-checked native
        // prefix still has the exact field positions consumed by Core ABI1.
        assert_eq!(size_of::<NativeRuntimeInfo>(), 72);
        assert_eq!(align_of::<NativeRuntimeInfo>(), 8);
        assert_eq!(offset_of!(NativeRuntimeInfo, delivery_backend), 32);
        assert_eq!(offset_of!(NativeRuntimeInfo, transport_profile), 56);
        assert_eq!(offset_of!(NativeRuntimeInfo, transport_profile_version), 64);
        assert_eq!(size_of::<NativeRuntimeConfigView>(), 88);
        assert_eq!(offset_of!(NativeRuntimeConfigView, transport_bind_host), 72);
        assert_eq!(offset_of!(NativeRuntimeConfigView, transport_bind_port), 80);
    }
}

#[repr(C)]
#[derive(Copy, Clone)]
struct NativeHostHandles {
    struct_size: usize,
    flags: u32,
    request_write_fd: c_int,
    response_read_fd: c_int,
    deadletter_read_fd: c_int,
    control_write_fd: c_int,
    monitor_read_fd: c_int,
    delivered_request_read_fd: c_int,
}

impl Default for NativeHostHandles {
    fn default() -> Self {
        Self {
            struct_size: 0,
            flags: 0,
            request_write_fd: -1,
            response_read_fd: -1,
            deadletter_read_fd: -1,
            control_write_fd: -1,
            monitor_read_fd: -1,
            delivered_request_read_fd: -1,
        }
    }
}
