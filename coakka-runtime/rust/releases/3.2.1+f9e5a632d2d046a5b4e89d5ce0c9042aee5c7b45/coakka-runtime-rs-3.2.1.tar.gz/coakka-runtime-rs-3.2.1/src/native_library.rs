//! Owns native module selection and transactional process-lifetime publication.
//! Filesystem/OS loader calls serve this host-owned resource only; capability
//! and effective runtime facts are always obtained from Core, never inferred.
use crate::runtime_startup::{NativeNetworkOptions, RuntimeGetNetworkConfig};
use crate::{
    file_lane, lane_owner, platform, runtime_client_native, status_to_result, stream_lane,
    transport, CoAkkaError, NativeHostHandles, NativeRuntimeConfigView, NativeRuntimeInfo, Result,
    ABI_VERSION,
};
use std::env;
use std::ffi::{c_int, c_void};
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, OnceLock};

/// Resolves the application's bundled native image or an explicit selection.
pub struct RuntimeLibraryResolver;
impl RuntimeLibraryResolver {
    /// Returns a canonical existing image path; a present invalid override fails.
    ///
    /// Empty input means COAKKA_RUNTIME_LIB if present, otherwise exactly the
    /// canonical executable directory's `native/<target>/<product filename>`.
    /// The application packager owns that resource layout. No source crate,
    /// sibling repo,
    /// old filename, working-directory or system-library fallback is attempted.
    /// Bundle resources elsewhere by supplying their exact path explicitly.
    /// Installation directories must be trusted and stable while loading;
    /// containment/ABI checks are not signatures or protection against a
    /// concurrent hostile replacement of an application file.
    pub fn resolve(explicit_path: &str) -> Result<PathBuf> {
        if !explicit_path.is_empty() {
            return require_existing_library(Path::new(explicit_path));
        }
        if let Some(path) = env::var_os("COAKKA_RUNTIME_LIB") {
            if path.is_empty() {
                return Err(CoAkkaError::InvalidArgument(
                    "COAKKA_RUNTIME_LIB is empty".into(),
                ));
            }
            return require_existing_library(Path::new(&path));
        }
        // Deployment lookup occurs at host/lane construction, never on a request
        // hot path. No build-machine path is retained in the compiled connector.
        let executable = env::current_exe()
            .and_then(fs::canonicalize)
            .map_err(|_| CoAkkaError::Io("application executable is unavailable".into()))?;
        let root = executable
            .parent()
            .ok_or_else(|| CoAkkaError::Io("application directory is unavailable".into()))?;
        let (target, filename) = package_target()?;
        let selected = require_existing_library(&root.join("native").join(target).join(filename))?;
        if !selected.starts_with(root) {
            return Err(CoAkkaError::Native(
                "packaged runtime image escapes its application directory".into(),
            ));
        }
        Ok(selected)
    }
}

fn require_existing_library(path: &Path) -> Result<PathBuf> {
    if !path.is_file() {
        return Err(CoAkkaError::Native(
            "selected runtime image is not an existing file".into(),
        ));
    }
    fs::canonicalize(path)
        .map_err(|error| CoAkkaError::Io(format!("resolve runtime image: {error}")))
}

fn package_target() -> Result<(&'static str, &'static str)> {
    // These are compiler target identifiers, not runtime OS/capability probes.
    match (std::env::consts::OS, std::env::consts::ARCH) {
        ("macos", "aarch64") => Ok(("macos-aarch64", "libcoakka_runtime_v2.dylib")),
        ("linux", "aarch64") => Ok(("linux-aarch64", "libcoakka_runtime_v2.so")),
        ("linux", "x86_64") => Ok(("linux-x86_64", "libcoakka_runtime_v2.so")),
        ("windows", "aarch64") => Ok(("windows-aarch64", "libcoakka_runtime_v2.dll")),
        ("windows", "x86_64") => Ok(("windows-x86_64", "libcoakka_runtime_v2.dll")),
        _ => Err(CoAkkaError::Native(
            "unsupported runtime package target".into(),
        )),
    }
}

#[derive(Clone)]
pub(crate) struct NativeLibrary {
    handle: platform::LibraryHandle,
    pub(crate) get_info: unsafe extern "C" fn(*mut NativeRuntimeInfo) -> c_int,
    pub(crate) get_config: unsafe extern "C" fn(*mut c_void, *mut NativeRuntimeConfigView) -> c_int,
    pub(crate) get_capabilities: transport::RuntimeGetCapabilities,
    pub(crate) validate_tcp_connection_options: transport::RuntimeValidateTcpConnectionOptions,
    pub(crate) create_runtime_native: runtime_client_native::RuntimeCreateNative,
    pub(crate) get_startup_config: runtime_client_native::RuntimeGetStartupConfig,
    pub(crate) get_delivery_config: runtime_client_native::RuntimeGetDeliveryConfig,
    pub(crate) destroy_runtime: unsafe extern "C" fn(*mut c_void),
    pub(crate) apply_network_options:
        unsafe extern "C" fn(*mut c_void, *const NativeNetworkOptions) -> c_int,
    pub(crate) get_network_config: RuntimeGetNetworkConfig,
    pub(crate) get_host_handles: unsafe extern "C" fn(*mut c_void, *mut NativeHostHandles) -> c_int,
    pub(crate) host_handles_close: runtime_client_native::HostHandlesClose,
    pub(crate) request_reader_create: runtime_client_native::RequestReaderCreate,
    pub(crate) request_reader_read: runtime_client_native::RequestReaderRead,
    pub(crate) owned_frame_data: runtime_client_native::OwnedFrameData,
    pub(crate) owned_frame_size: runtime_client_native::OwnedFrameSize,
    pub(crate) owned_frame_release: runtime_client_native::OwnedFrameRelease,
    pub(crate) request_reader_destroy: runtime_client_native::RequestReaderDestroy,
    pub(crate) ask_client_create: runtime_client_native::AskClientCreate,
    pub(crate) ask_client_destroy: runtime_client_native::AskClientDestroy,
    pub(crate) ask_client_begin: runtime_client_native::AskClientBegin,
    pub(crate) ask_ticket_await: runtime_client_native::AskTicketAwait,
    pub(crate) ask_ticket_cancel: runtime_client_native::AskTicketCancel,
    pub(crate) ask_ticket_destroy: runtime_client_native::AskTicketDestroy,
    pub(crate) copy_request_dispatch: runtime_client_native::CopyRequestDispatch,
    pub(crate) client_bytes_release: runtime_client_native::ClientBytesRelease,
    pub(crate) start_runtime: unsafe extern "C" fn(*mut c_void) -> c_int,
    pub(crate) stop_runtime: unsafe extern "C" fn(*mut c_void) -> c_int,
    pub(crate) submit_envelope: unsafe extern "C" fn(*mut c_void, *const u8, usize) -> c_int,
    pub(crate) apply_control_envelope: unsafe extern "C" fn(*mut c_void, *const u8, usize) -> c_int,
    pub(crate) apply_tcp_connection_options: transport::RuntimeApplyTcpConnectionOptions,
    pub(crate) get_tcp_connection_config: transport::RuntimeGetTcpConnectionConfig,
    pub(crate) apply_tcp_security_options: transport::RuntimeApplyTcpSecurityOptions,
    pub(crate) get_tcp_security_info: transport::RuntimeGetTcpSecurityInfo,
    pub(crate) transport_apply_reason_name: transport::RuntimeTransportApplyReasonName,
    pub(crate) file_lane_create: Option<file_lane::FileLaneCreateFn>,
    pub(crate) file_lane_destroy: Option<file_lane::FileLaneDestroyFn>,
    pub(crate) file_lane_start: Option<file_lane::FileLaneStartFn>,
    pub(crate) file_lane_stop: Option<file_lane::FileLaneStopFn>,
    pub(crate) file_lane_get_bound_port: Option<file_lane::FileLaneGetBoundPortFn>,
    pub(crate) file_lane_prepare_receive: Option<file_lane::FileLanePrepareReceiveFn>,
    pub(crate) file_lane_submit_send: Option<file_lane::FileLaneSubmitSendFn>,
    pub(crate) file_lane_get_transfer: Option<file_lane::FileLaneGetTransferFn>,
    pub(crate) file_lane_wait_transfer: Option<file_lane::FileLaneWaitTransferFn>,
    pub(crate) file_lane_cancel_transfer: Option<file_lane::FileLaneTransferControlFn>,
    pub(crate) file_lane_forget_transfer: Option<file_lane::FileLaneTransferControlFn>,
    pub(crate) file_lane_get_stats: Option<file_lane::FileLaneGetStatsFn>,
    pub(crate) file_sha256_path: Option<file_lane::FileSha256PathFn>,
    pub(crate) stream_lane_create: Option<stream_lane::StreamLaneCreateFn>,
    pub(crate) stream_lane_destroy: Option<stream_lane::StreamLaneDestroyFn>,
    pub(crate) stream_lane_start: Option<stream_lane::StreamLaneStartFn>,
    pub(crate) stream_lane_stop: Option<stream_lane::StreamLaneStopFn>,
    pub(crate) stream_lane_get_bound_port: Option<stream_lane::StreamLaneGetBoundPortFn>,
    pub(crate) stream_lane_prepare_publish: Option<stream_lane::StreamLanePreparePublishFn>,
    pub(crate) stream_lane_subscribe: Option<stream_lane::StreamLaneSubscribeFn>,
    pub(crate) stream_lane_get_session: Option<stream_lane::StreamLaneGetSessionFn>,
    pub(crate) stream_lane_wait_session: Option<stream_lane::StreamLaneWaitSessionFn>,
    pub(crate) stream_lane_get_pressure: Option<stream_lane::StreamLaneGetPressureFn>,
    pub(crate) stream_lane_wait_pressure: Option<stream_lane::StreamLaneWaitPressureFn>,
    pub(crate) stream_lane_cancel_session: Option<stream_lane::StreamLaneControlFn>,
    pub(crate) stream_lane_forget_session: Option<stream_lane::StreamLaneControlFn>,
    pub(crate) stream_lane_get_stats: Option<stream_lane::StreamLaneGetStatsFn>,
}

// SAFETY: this value contains immutable function pointers from one module
// pinned for process lifetime; it owns no thread-affine loader state.
unsafe impl Send for NativeLibrary {}
// SAFETY: calling individual functions is governed by their owning runtime or
// lane synchronization, while the symbol table itself is immutable.
unsafe impl Sync for NativeLibrary {}

macro_rules! required_symbol {
    ($handle:expr, $name:literal) => {{
        // SAFETY: every literal invocation below is paired with the matching
        // concrete function-pointer field from the reviewed public contract.
        unsafe { platform::load_symbol($handle, $name) }
    }};
}

macro_rules! optional_symbol {
    ($handle:expr, $name:literal) => {{
        required_symbol!($handle, $name).ok()
    }};
}

impl NativeLibrary {
    // All callers pass a canonical path selected by RuntimeLibraryResolver.
    // Path ownership is prepared before opening; publication after validation
    // only copies the fixed symbol table and moves this already-owned path.
    pub(crate) fn open(path: &Path) -> Result<Self> {
        static PROCESS_LIBRARY: OnceLock<Mutex<Option<ProcessLibraryIdentity>>> = OnceLock::new();

        let mut identity = PROCESS_LIBRARY
            .get_or_init(|| Mutex::new(None))
            .lock()
            .map_err(|_| CoAkkaError::Native("process library mutex poisoned".to_string()))?;
        if let Some(existing) = identity.as_ref() {
            if existing.path != path {
                return Err(CoAkkaError::Native(
                    "a different CoAkka runtime image is already loaded".into(),
                ));
            }
            return Ok(existing.library.clone());
        }
        let selected_path = path.to_path_buf();
        let handle = platform::open_library(path)?;

        let loaded = (|| -> Result<Self> {
            let get_abi: unsafe extern "C" fn() -> u32 =
                required_symbol!(handle, "coakka_v2_runtime_get_abi_version")?;
            // SAFETY: only the version entrypoint is called before ABI admission.
            // No runtime/lane pointer has escaped, and this scope owns the module.
            let abi = unsafe { get_abi() };
            if abi != ABI_VERSION {
                return Err(CoAkkaError::Native(format!("unsupported Core ABI: {abi}")));
            }
            Ok(Self {
                handle,
                get_info: required_symbol!(handle, "coakka_v2_runtime_get_info")?,
                get_config: required_symbol!(handle, "coakka_v2_runtime_get_config")?,
                get_capabilities: required_symbol!(handle, "coakka_v2_runtime_get_capabilities")?,
                validate_tcp_connection_options: required_symbol!(
                    handle,
                    "coakka_v2_runtime_validate_tcp_connection_options"
                )?,
                create_runtime_native: required_symbol!(handle, "coakka_v2_runtime_create_native")?,
                get_startup_config: required_symbol!(
                    handle,
                    "coakka_v2_runtime_get_startup_config"
                )?,
                get_delivery_config: required_symbol!(
                    handle,
                    "coakka_v2_runtime_get_delivery_config"
                )?,
                destroy_runtime: required_symbol!(handle, "coakka_v2_runtime_destroy")?,
                apply_network_options: required_symbol!(
                    handle,
                    "coakka_v2_runtime_apply_network_options"
                )?,
                get_network_config: required_symbol!(
                    handle,
                    "coakka_v2_runtime_get_network_config"
                )?,
                get_host_handles: required_symbol!(handle, "coakka_v2_runtime_get_host_handles")?,
                host_handles_close: required_symbol!(handle, "coakka_v2_host_handles_close")?,
                request_reader_create: required_symbol!(
                    handle,
                    "coakka_v2_runtime_request_reader_create"
                )?,
                request_reader_read: required_symbol!(handle, "coakka_v2_request_reader_read")?,
                owned_frame_data: required_symbol!(handle, "coakka_v2_owned_frame_data")?,
                owned_frame_size: required_symbol!(handle, "coakka_v2_owned_frame_size")?,
                owned_frame_release: required_symbol!(handle, "coakka_v2_owned_frame_release")?,
                request_reader_destroy: required_symbol!(
                    handle,
                    "coakka_v2_request_reader_destroy"
                )?,
                ask_client_create: required_symbol!(handle, "coakka_v2_ask_client_create")?,
                ask_client_destroy: required_symbol!(handle, "coakka_v2_ask_client_destroy")?,
                ask_client_begin: required_symbol!(handle, "coakka_v2_ask_client_begin")?,
                ask_ticket_await: required_symbol!(handle, "coakka_v2_ask_ticket_await")?,
                ask_ticket_cancel: required_symbol!(handle, "coakka_v2_ask_ticket_cancel")?,
                ask_ticket_destroy: required_symbol!(handle, "coakka_v2_ask_ticket_destroy")?,
                copy_request_dispatch: required_symbol!(
                    handle,
                    "coakka_v2_client_copy_request_dispatch"
                )?,
                client_bytes_release: required_symbol!(handle, "coakka_v2_client_bytes_release")?,
                start_runtime: required_symbol!(handle, "coakka_v2_runtime_start")?,
                stop_runtime: required_symbol!(handle, "coakka_v2_runtime_stop")?,
                submit_envelope: required_symbol!(handle, "coakka_v2_runtime_submit_envelope")?,
                apply_control_envelope: required_symbol!(
                    handle,
                    "coakka_v2_runtime_apply_control_envelope"
                )?,
                apply_tcp_connection_options: required_symbol!(
                    handle,
                    "coakka_v2_runtime_apply_tcp_connection_options_ex"
                )?,
                get_tcp_connection_config: required_symbol!(
                    handle,
                    "coakka_v2_runtime_get_tcp_connection_config"
                )?,
                apply_tcp_security_options: required_symbol!(
                    handle,
                    "coakka_v2_runtime_apply_tcp_security_options_ex"
                )?,
                get_tcp_security_info: required_symbol!(
                    handle,
                    "coakka_v2_runtime_get_tcp_security_info"
                )?,
                transport_apply_reason_name: required_symbol!(
                    handle,
                    "coakka_v2_transport_apply_reason_name"
                )?,
                file_lane_create: optional_symbol!(handle, "coakka_v2_file_lane_create_ex"),
                file_lane_destroy: optional_symbol!(handle, "coakka_v2_file_lane_destroy"),
                file_lane_start: optional_symbol!(handle, "coakka_v2_file_lane_start"),
                file_lane_stop: optional_symbol!(handle, "coakka_v2_file_lane_stop"),
                file_lane_get_bound_port: optional_symbol!(
                    handle,
                    "coakka_v2_file_lane_get_bound_port"
                ),
                file_lane_prepare_receive: optional_symbol!(
                    handle,
                    "coakka_v2_file_lane_prepare_receive"
                ),
                file_lane_submit_send: optional_symbol!(handle, "coakka_v2_file_lane_submit_send"),
                file_lane_get_transfer: optional_symbol!(
                    handle,
                    "coakka_v2_file_lane_get_transfer"
                ),
                file_lane_wait_transfer: optional_symbol!(
                    handle,
                    "coakka_v2_file_lane_wait_transfer"
                ),
                file_lane_cancel_transfer: optional_symbol!(
                    handle,
                    "coakka_v2_file_lane_cancel_transfer"
                ),
                file_lane_forget_transfer: optional_symbol!(
                    handle,
                    "coakka_v2_file_lane_forget_transfer"
                ),
                file_lane_get_stats: optional_symbol!(handle, "coakka_v2_file_lane_get_stats"),
                file_sha256_path: optional_symbol!(handle, "coakka_v2_file_sha256_path"),
                stream_lane_create: optional_symbol!(handle, "coakka_v2_stream_lane_create_ex"),
                stream_lane_destroy: optional_symbol!(handle, "coakka_v2_stream_lane_destroy"),
                stream_lane_start: optional_symbol!(handle, "coakka_v2_stream_lane_start"),
                stream_lane_stop: optional_symbol!(handle, "coakka_v2_stream_lane_stop"),
                stream_lane_get_bound_port: optional_symbol!(
                    handle,
                    "coakka_v2_stream_lane_get_bound_port"
                ),
                stream_lane_prepare_publish: optional_symbol!(
                    handle,
                    "coakka_v2_stream_lane_prepare_publish"
                ),
                stream_lane_subscribe: optional_symbol!(handle, "coakka_v2_stream_lane_subscribe"),
                stream_lane_get_session: optional_symbol!(
                    handle,
                    "coakka_v2_stream_lane_get_session"
                ),
                stream_lane_wait_session: optional_symbol!(
                    handle,
                    "coakka_v2_stream_lane_wait_session"
                ),
                stream_lane_get_pressure: optional_symbol!(
                    handle,
                    "coakka_v2_stream_lane_get_pressure"
                ),
                stream_lane_wait_pressure: optional_symbol!(
                    handle,
                    "coakka_v2_stream_lane_wait_pressure"
                ),
                stream_lane_cancel_session: optional_symbol!(
                    handle,
                    "coakka_v2_stream_lane_cancel_session"
                ),
                stream_lane_forget_session: optional_symbol!(
                    handle,
                    "coakka_v2_stream_lane_forget_session"
                ),
                stream_lane_get_stats: optional_symbol!(handle, "coakka_v2_stream_lane_get_stats"),
            })
        })();

        match loaded {
            Ok(library) => {
                // Publish exactly once, only after ABI and the complete required
                // symbol table succeed. The process pin owns the module; host
                // copies contain immutable function pointers, not extra handles.
                *identity = Some(ProcessLibraryIdentity {
                    library: library.clone(),
                    path: selected_path,
                });
                Ok(library)
            }
            Err(error) => {
                // SAFETY: the failed attempt has published nothing. Close only
                // this owned handle; the empty identity permits a later retry.
                unsafe { platform::close_library(handle) };
                Err(error)
            }
        }
    }

    pub(crate) fn has_stream_lane(&self) -> bool {
        self.stream_lane_create.is_some()
            && self.stream_lane_destroy.is_some()
            && self.stream_lane_start.is_some()
            && self.stream_lane_stop.is_some()
            && self.stream_lane_get_bound_port.is_some()
            && self.stream_lane_prepare_publish.is_some()
            && self.stream_lane_subscribe.is_some()
            && self.stream_lane_get_session.is_some()
            && self.stream_lane_wait_session.is_some()
            && self.stream_lane_get_pressure.is_some()
            && self.stream_lane_wait_pressure.is_some()
            && self.stream_lane_cancel_session.is_some()
            && self.stream_lane_forget_session.is_some()
            && self.stream_lane_get_stats.is_some()
    }

    fn require_lane_owner_grants(&self) -> Result<()> {
        let mut info = NativeRuntimeInfo {
            struct_size: std::mem::size_of::<NativeRuntimeInfo>(),
            ..NativeRuntimeInfo::default()
        };
        status_to_result(
            // SAFETY: `info` is a writable ABI record and the function pointer
            // belongs to this process-pinned runtime library.
            unsafe { (self.get_info)(&mut info) },
            "runtime_get_info",
        )?;
        if info.feature_flags & lane_owner::LANE_OWNER_GRANTS_FEATURE == 0 {
            return Err(CoAkkaError::Native(
                "native runtime does not advertise lane-owner grants".into(),
            ));
        }
        Ok(())
    }

    pub(crate) fn load_additive<T: Copy>(&self, symbol: &str) -> Result<T> {
        self.require_lane_owner_grants()?;
        // SAFETY: callers bind `T` to the reviewed additive ABI function named
        // by `symbol`; feature negotiation completed before resolution.
        unsafe { platform::load_symbol(self.handle, symbol) }
    }
}

struct ProcessLibraryIdentity {
    library: NativeLibrary,
    path: PathBuf,
}
