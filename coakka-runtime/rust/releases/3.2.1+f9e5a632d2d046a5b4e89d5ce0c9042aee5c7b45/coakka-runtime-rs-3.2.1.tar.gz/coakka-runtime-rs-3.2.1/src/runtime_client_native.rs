//! Private projection of Core-owned request/reply and startup operations.
//!
//! This module is the only Runtime connector code allowed to hold the opaque
//! ask/request-reader owners. It copies every Core-owned result before release;
//! no descriptor value is inspected, read, or closed by Rust.

use std::ffi::c_void;
use std::mem::size_of;
use std::os::raw::c_int;

use crate::transport::{
    connection_config_from_native, connection_options_native, NativeTcpConnectionConfig,
};
use crate::{
    CoAkkaError, ConnectorStartSpec, NativeHostHandles, NativeLibrary, NativeRuntimeConfig, Result,
    RuntimeDeliveryConfigSnapshot, RuntimePtr, RuntimeStartupConfigSnapshot, RuntimeStartupCpuInfo,
    RuntimeStartupIoInfo, RuntimeStartupMonitorInfo, MAXIMUM_CLIENT_FRAME_BYTES,
};

const STATUS_OK: c_int = 0;
const STATUS_WOULD_BLOCK: c_int = -6;
const STATUS_CLOSED: c_int = -7;

#[derive(Copy, Clone)]
pub(crate) struct NativeRequestReader(*mut c_void);

// SAFETY: Core documents one serialized reader caller. Rust moves this opaque
// owner to exactly one reader thread. The thread's RuntimeInner Arc keeps it
// alive through every read; final owner retirement occurs after reads end.
unsafe impl Send for NativeRequestReader {}

#[derive(Copy, Clone)]
pub(crate) struct NativeAskClient(*mut c_void);

// SAFETY: Core's ask client owns its matching synchronization. Rust never
// dereferences the pointer and destroys it only after host calls have ended.
unsafe impl Send for NativeAskClient {}
// SAFETY: concurrent asks use independent Core-owned tickets.
unsafe impl Sync for NativeAskClient {}

#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub(crate) enum NativeAskResultKind {
    Response,
    Deadletter,
}

pub(crate) struct NativeAskResult {
    pub(crate) kind: NativeAskResultKind,
    pub(crate) frame: Vec<u8>,
}

pub(crate) struct NativeDeliveredRequest {
    pub(crate) frame: Vec<u8>,
    pub(crate) target: String,
    pub(crate) payload: Vec<u8>,
    pub(crate) one_way: bool,
}

pub(crate) enum NativeReadResult {
    Request(NativeDeliveredRequest),
    WouldBlock,
    Closed,
}

#[repr(C)]
pub(crate) struct NativeStartupMonitorOptions {
    struct_size: usize,
    enabled: u32,
    reserved: u32,
}

#[repr(C)]
pub(crate) struct NativeRuntimeStartupOptions {
    struct_size: usize,
    execution: *const c_void,
    connection: *const crate::transport::NativeTcpConnectionOptions,
    io: *const c_void,
    monitor: *const NativeStartupMonitorOptions,
}

#[repr(C)]
#[derive(Default)]
struct NativeStartupCpuInfo {
    requested_policy: u32,
    supported: u32,
    available_cpu_count: u32,
    selected_cpu_count: u32,
    selected_cpu_ids: [u32; 2],
    startup_applied: u32,
    reserved: u32,
}

#[repr(C)]
#[derive(Default)]
struct NativeStartupIoInfo {
    requested: u32,
    compiled: u32,
    probed: u32,
    supported: u32,
    effective: u32,
    probe_error: i32,
}

#[repr(C)]
#[derive(Default)]
struct NativeStartupMonitorInfo {
    enabled: u32,
    reserved: u32,
}

#[repr(C)]
#[derive(Default)]
pub(crate) struct NativeRuntimeStartupConfig {
    struct_size: usize,
    defaults_revision: u32,
    defaulted_groups: u32,
    strict_no_drop: c_int,
    queue_capacity: u32,
    request_max_frame_size: u64,
    runtime_state: u32,
    reserved: u32,
    execution: NativeStartupCpuInfo,
    connection: NativeTcpConnectionConfig,
    io: NativeStartupIoInfo,
    monitor: NativeStartupMonitorInfo,
}

#[repr(C)]
#[derive(Default)]
pub(crate) struct NativeRuntimeDeliveryConfig {
    struct_size: usize,
    compiled: u32,
    request_mode: u32,
    response_mode: u32,
    remote_batch_max_calls: u32,
    slot_capacity: u32,
    reserved: u32,
    byte_capacity: u64,
}

pub(crate) type RuntimeCreateNative = unsafe extern "C" fn(
    *const NativeRuntimeConfig,
    *const NativeRuntimeStartupOptions,
    *mut *mut c_void,
) -> c_int;
pub(crate) type RuntimeGetStartupConfig =
    unsafe extern "C" fn(*mut c_void, *mut NativeRuntimeStartupConfig) -> c_int;
pub(crate) type RuntimeGetDeliveryConfig =
    unsafe extern "C" fn(*mut c_void, *mut NativeRuntimeDeliveryConfig) -> c_int;
pub(crate) type HostHandlesClose = unsafe extern "C" fn(*mut NativeHostHandles);
pub(crate) type RequestReaderCreate =
    unsafe extern "C" fn(*mut c_void, *const NativeHostHandles, *mut *mut c_void) -> c_int;
pub(crate) type RequestReaderRead =
    unsafe extern "C" fn(*mut c_void, u32, *mut *mut c_void) -> c_int;
pub(crate) type OwnedFrameData = unsafe extern "C" fn(*const c_void) -> *const u8;
pub(crate) type OwnedFrameSize = unsafe extern "C" fn(*const c_void) -> usize;
pub(crate) type OwnedFrameRelease = unsafe extern "C" fn(*mut c_void);
pub(crate) type RequestReaderDestroy = unsafe extern "C" fn(*mut c_void);
pub(crate) type AskClientCreate =
    unsafe extern "C" fn(*mut c_void, *const NativeHostHandles) -> *mut c_void;
pub(crate) type AskClientDestroy = unsafe extern "C" fn(*mut c_void);
pub(crate) type AskClientBegin =
    unsafe extern "C" fn(*mut c_void, *const u8, usize, *mut *mut c_void) -> c_int;
pub(crate) type AskTicketAwait =
    unsafe extern "C" fn(*mut c_void, u32, *mut u32, *mut *mut u8, *mut usize) -> c_int;
pub(crate) type AskTicketCancel = unsafe extern "C" fn(*mut c_void);
pub(crate) type AskTicketDestroy = unsafe extern "C" fn(*mut c_void);
pub(crate) type CopyRequestDispatch = unsafe extern "C" fn(
    *const u8,
    usize,
    *mut *mut u8,
    *mut usize,
    *mut *mut u8,
    *mut usize,
    *mut u32,
) -> c_int;
pub(crate) type ClientBytesRelease = unsafe extern "C" fn(*mut u8);

impl NativeLibrary {
    pub(crate) fn create_native_runtime(
        &self,
        config: &NativeRuntimeConfig,
        spec: &ConnectorStartSpec,
    ) -> Result<RuntimePtr> {
        if let Some(connection) = &spec.connection_strategy {
            let validation = crate::transport::validate_connection_native(self, connection);
            if validation.status != crate::CoAkkaStatus::OK
                || validation.code != crate::TcpConnectionValidationCode::VALID
            {
                return Err(CoAkkaError::TcpConnectionValidation(validation));
            }
        }
        let connection = spec
            .connection_strategy
            .as_ref()
            .map(connection_options_native);
        let monitor = spec.monitor.map(|intent| NativeStartupMonitorOptions {
            struct_size: size_of::<NativeStartupMonitorOptions>(),
            enabled: u32::from(intent.enabled),
            reserved: 0,
        });
        let options = NativeRuntimeStartupOptions {
            struct_size: size_of::<NativeRuntimeStartupOptions>(),
            execution: std::ptr::null(),
            connection: connection
                .as_ref()
                .map_or(std::ptr::null(), |value| value as *const _),
            io: std::ptr::null(),
            monitor: monitor
                .as_ref()
                .map_or(std::ptr::null(), |value| value as *const _),
        };
        let options_pointer = if connection.is_some() || monitor.is_some() {
            &options as *const NativeRuntimeStartupOptions
        } else {
            std::ptr::null()
        };
        let mut runtime = std::ptr::null_mut();
        // SAFETY: config and optional pointees are live for the synchronous
        // create call. Core copies them and initializes the null output slot.
        let status = unsafe { (self.create_runtime_native)(config, options_pointer, &mut runtime) };
        require_status(status, "coakka_v2_runtime_create_native")?;
        if runtime.is_null() {
            return Err(CoAkkaError::Native(
                "Core accepted runtime creation without an owner".into(),
            ));
        }
        Ok(RuntimePtr(runtime))
    }

    pub(crate) fn startup_config(
        &self,
        runtime: RuntimePtr,
    ) -> Result<RuntimeStartupConfigSnapshot> {
        let mut native = NativeRuntimeStartupConfig {
            struct_size: size_of::<NativeRuntimeStartupConfig>(),
            ..NativeRuntimeStartupConfig::default()
        };
        // SAFETY: runtime is live and native is one writable complete record.
        let status = unsafe { (self.get_startup_config)(runtime.0, &mut native) };
        require_status(status, "coakka_v2_runtime_get_startup_config")?;
        Ok(RuntimeStartupConfigSnapshot {
            defaults_revision: native.defaults_revision,
            defaulted_groups: native.defaulted_groups,
            strict_no_drop: native.strict_no_drop != 0,
            queue_capacity: native.queue_capacity,
            request_max_frame_size: native.request_max_frame_size,
            runtime_state: native.runtime_state,
            execution: RuntimeStartupCpuInfo {
                requested_policy: native.execution.requested_policy,
                supported: native.execution.supported != 0,
                available_cpu_count: native.execution.available_cpu_count,
                selected_cpu_count: native.execution.selected_cpu_count,
                selected_cpu_ids: native.execution.selected_cpu_ids,
                startup_applied: native.execution.startup_applied != 0,
            },
            connection: connection_config_from_native(native.connection),
            io: RuntimeStartupIoInfo {
                requested: native.io.requested != 0,
                compiled: native.io.compiled != 0,
                probed: native.io.probed != 0,
                supported: native.io.supported != 0,
                effective: native.io.effective != 0,
                probe_error: native.io.probe_error,
            },
            monitor: RuntimeStartupMonitorInfo {
                enabled: native.monitor.enabled != 0,
            },
        })
    }

    pub(crate) fn delivery_config(
        &self,
        runtime: RuntimePtr,
    ) -> Result<RuntimeDeliveryConfigSnapshot> {
        let mut native = NativeRuntimeDeliveryConfig {
            struct_size: size_of::<NativeRuntimeDeliveryConfig>(),
            ..NativeRuntimeDeliveryConfig::default()
        };
        // SAFETY: runtime is live and native is one writable complete record.
        let status = unsafe { (self.get_delivery_config)(runtime.0, &mut native) };
        require_status(status, "coakka_v2_runtime_get_delivery_config")?;
        Ok(RuntimeDeliveryConfigSnapshot {
            compiled: native.compiled != 0,
            request_mode: native.request_mode,
            response_mode: native.response_mode,
            remote_batch_max_calls: native.remote_batch_max_calls,
            slot_capacity: native.slot_capacity,
            byte_capacity: native.byte_capacity,
        })
    }

    pub(crate) fn close_host_handles(&self, handles: &mut NativeHostHandles) {
        // SAFETY: this host owns the complete handle block and calls Core once.
        unsafe { (self.host_handles_close)(handles) };
    }

    pub(crate) fn create_request_reader(
        &self,
        runtime: RuntimePtr,
        handles: &NativeHostHandles,
    ) -> Result<NativeRequestReader> {
        let mut reader = std::ptr::null_mut();
        // SAFETY: runtime and handles remain live; Core initializes the output.
        let status = unsafe { (self.request_reader_create)(runtime.0, handles, &mut reader) };
        require_status(status, "coakka_v2_runtime_request_reader_create")?;
        if reader.is_null() {
            return Err(CoAkkaError::Native(
                "Core accepted request reader creation without an owner".into(),
            ));
        }
        Ok(NativeRequestReader(reader))
    }

    pub(crate) fn destroy_request_reader(&self, reader: NativeRequestReader) {
        // SAFETY: the sole reader thread has joined and this is the final owner.
        unsafe { (self.request_reader_destroy)(reader.0) };
    }

    pub(crate) fn read_request(
        &self,
        reader: NativeRequestReader,
        timeout_ms: u32,
    ) -> Result<NativeReadResult> {
        let mut owned_frame = std::ptr::null_mut();
        // SAFETY: one Rust thread serializes all calls on this reader.
        let status = unsafe { (self.request_reader_read)(reader.0, timeout_ms, &mut owned_frame) };
        if status == STATUS_WOULD_BLOCK {
            return Ok(NativeReadResult::WouldBlock);
        }
        if status == STATUS_CLOSED {
            return Ok(NativeReadResult::Closed);
        }
        require_status(status, "coakka_v2_request_reader_read")?;
        if owned_frame.is_null() {
            return Err(CoAkkaError::Native(
                "Core reported a request without an owned frame".into(),
            ));
        }

        // SAFETY: Core owns the opaque frame until release below.
        let frame_size = unsafe { (self.owned_frame_size)(owned_frame) };
        // SAFETY: same owner and lifetime as frame_size.
        let frame_data = unsafe { (self.owned_frame_data)(owned_frame) };
        let frame =
            if frame_size == 0 || frame_size > MAXIMUM_CLIENT_FRAME_BYTES || frame_data.is_null() {
                Vec::new()
            } else {
                // SAFETY: Core reports a readable span valid through release.
                unsafe { std::slice::from_raw_parts(frame_data, frame_size) }.to_vec()
            };
        // SAFETY: release exactly once after copying the frame.
        unsafe { (self.owned_frame_release)(owned_frame) };
        if frame.is_empty() {
            return Err(CoAkkaError::Native(
                "Core returned an invalid delivered-request frame".to_string(),
            ));
        }

        let mut target = std::ptr::null_mut();
        let mut target_len = 0usize;
        let mut payload = std::ptr::null_mut();
        let mut payload_len = 0usize;
        let mut one_way = 0u32;
        // SAFETY: frame remains readable and all outputs are writable locals.
        let projection_status = unsafe {
            (self.copy_request_dispatch)(
                frame.as_ptr(),
                frame.len(),
                &mut target,
                &mut target_len,
                &mut payload,
                &mut payload_len,
                &mut one_way,
            )
        };
        let target_bytes = copy_owned_bytes(self, target, target_len);
        let payload_bytes = copy_owned_bytes(self, payload, payload_len);
        require_status(projection_status, "coakka_v2_client_copy_request_dispatch")?;
        let target_bytes = target_bytes?;
        let payload_bytes = payload_bytes?;
        if target_bytes.is_empty()
            || target_bytes.len() > MAXIMUM_CLIENT_FRAME_BYTES
            || payload_bytes.len() > MAXIMUM_CLIENT_FRAME_BYTES
            || one_way > 1
        {
            return Err(CoAkkaError::Native(
                "Core returned invalid request dispatch facts".to_string(),
            ));
        }
        let target = String::from_utf8(target_bytes)
            .map_err(|error| CoAkkaError::Native(format!("Core target is not UTF-8: {error}")))?;
        Ok(NativeReadResult::Request(NativeDeliveredRequest {
            frame,
            target,
            payload: payload_bytes,
            one_way: one_way == 1,
        }))
    }

    pub(crate) fn create_ask_client(
        &self,
        runtime: RuntimePtr,
        handles: &NativeHostHandles,
    ) -> Result<NativeAskClient> {
        // SAFETY: runtime and handle block remain live for the client lifetime.
        let client = unsafe { (self.ask_client_create)(runtime.0, handles) };
        if client.is_null() {
            return Err(CoAkkaError::Native(
                "coakka_v2_ask_client_create returned null".to_string(),
            ));
        }
        Ok(NativeAskClient(client))
    }

    pub(crate) fn destroy_ask_client(&self, client: NativeAskClient) {
        // SAFETY: no host ask call remains active when the final owner destroys.
        unsafe { (self.ask_client_destroy)(client.0) };
    }

    pub(crate) fn ask(
        &self,
        client: NativeAskClient,
        frame: &[u8],
        timeout_ms: u32,
    ) -> Result<NativeAskResult> {
        if frame.is_empty() || frame.len() > MAXIMUM_CLIENT_FRAME_BYTES {
            return Err(CoAkkaError::InvalidArgument(
                "request frame is empty or exceeds 64 MiB".to_string(),
            ));
        }
        let mut ticket = std::ptr::null_mut();
        // SAFETY: frame is readable for this synchronous begin call and Core
        // initializes the ticket output before returning.
        let begin_status =
            unsafe { (self.ask_client_begin)(client.0, frame.as_ptr(), frame.len(), &mut ticket) };
        require_status(begin_status, "coakka_v2_ask_client_begin")?;
        if ticket.is_null() {
            return Err(CoAkkaError::Native(
                "Core accepted ask without a ticket owner".into(),
            ));
        }

        let mut kind = 0u32;
        let mut output = std::ptr::null_mut();
        let mut output_len = 0usize;
        // SAFETY: this call is the sole waiter for its Core-owned ticket.
        let await_status = unsafe {
            (self.ask_ticket_await)(ticket, timeout_ms, &mut kind, &mut output, &mut output_len)
        };
        let frame = copy_owned_bytes(self, output, output_len);
        if await_status != STATUS_OK {
            // SAFETY: timeout/close has not transferred a result buffer and
            // cancellation prevents an unconsumed late result from lingering.
            unsafe { (self.ask_ticket_cancel)(ticket) };
        }
        // SAFETY: this function owns the ticket on every path.
        unsafe { (self.ask_ticket_destroy)(ticket) };

        match await_status {
            STATUS_OK => {
                let frame = frame?;
                if frame.is_empty() || frame.len() > MAXIMUM_CLIENT_FRAME_BYTES {
                    return Err(CoAkkaError::Native(
                        "Core returned an invalid terminal frame".to_string(),
                    ));
                }
                let kind = match kind {
                    1 => NativeAskResultKind::Response,
                    2 => NativeAskResultKind::Deadletter,
                    _ => {
                        return Err(CoAkkaError::Native(format!(
                            "Core returned unknown ask result kind {kind}"
                        )))
                    }
                };
                Ok(NativeAskResult { kind, frame })
            }
            STATUS_WOULD_BLOCK => Err(CoAkkaError::Timeout(
                "Core ask deadline elapsed".to_string(),
            )),
            status => Err(CoAkkaError::Core {
                operation: "coakka_v2_ask_ticket_await",
                status: crate::CoAkkaStatus(status),
            }),
        }
    }
}

fn copy_owned_bytes(library: &NativeLibrary, pointer: *mut u8, length: usize) -> Result<Vec<u8>> {
    let invalid = (pointer.is_null() && length != 0)
        || (!pointer.is_null() && length == 0)
        || length > MAXIMUM_CLIENT_FRAME_BYTES;
    let bytes = if pointer.is_null() || invalid {
        Vec::new()
    } else {
        // SAFETY: Core returned a readable owned span which remains live until
        // the release call immediately below.
        unsafe { std::slice::from_raw_parts(pointer, length) }.to_vec()
    };
    if !pointer.is_null() {
        // SAFETY: the pointer was returned by one Core client helper and is
        // released exactly once after copying.
        unsafe { (library.client_bytes_release)(pointer) };
    }
    if invalid {
        Err(CoAkkaError::Native(
            "Core returned an invalid owned byte span".to_string(),
        ))
    } else {
        Ok(bytes)
    }
}

fn require_status(status: c_int, operation: &'static str) -> Result<()> {
    crate::status_to_result(status, operation)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn startup_and_delivery_layouts_match_the_public_64_bit_contract() {
        assert_eq!(size_of::<NativeStartupMonitorOptions>(), 16);
        assert_eq!(size_of::<NativeRuntimeStartupOptions>(), 40);
        assert_eq!(size_of::<NativeStartupCpuInfo>(), 32);
        assert_eq!(size_of::<NativeStartupIoInfo>(), 24);
        assert_eq!(size_of::<NativeRuntimeStartupConfig>(), 176);
        assert_eq!(size_of::<NativeRuntimeDeliveryConfig>(), 40);
    }
}
