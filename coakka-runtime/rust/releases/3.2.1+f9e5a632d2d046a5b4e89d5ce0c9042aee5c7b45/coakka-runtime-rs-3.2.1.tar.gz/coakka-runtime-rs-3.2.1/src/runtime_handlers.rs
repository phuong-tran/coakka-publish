//! Rust-owned callback registrations and unwind isolation, never Core policy.
use crate::{CoAkkaError, Result, TransportEnvelope};
use std::collections::HashMap;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::{Arc, Mutex};

type Handler = dyn Fn(TransportEnvelope) -> Option<TransportEnvelope> + Send + Sync + 'static;
const MAX_HANDLERS: usize = 256;
const MAX_TARGET_BYTES: usize = 64 * 1024;

#[derive(Default)]
struct Entries {
    handlers: HashMap<String, Arc<Handler>>,
    target_bytes: usize,
}

#[derive(Default)]
pub(crate) struct HandlerRegistry {
    entries: Mutex<Entries>,
}

impl HandlerRegistry {
    pub(crate) fn register<F>(&self, target: String, handler: F) -> Result<()>
    where
        F: Fn(TransportEnvelope) -> Option<TransportEnvelope> + Send + Sync + 'static,
    {
        // Stage application ownership before acquiring the registry lock. Even
        // a refused candidate's destructor may reenter registration.
        let candidate: Arc<Handler> = Arc::new(handler);
        let previous = {
            let mut entries = self
                .entries
                .lock()
                .map_err(|_| CoAkkaError::Native("handler registry poisoned".into()))?;
            let replacing = entries.handlers.contains_key(&target);
            if !replacing
                && (entries.handlers.len() == MAX_HANDLERS
                    || target.len() > MAX_TARGET_BYTES - entries.target_bytes)
            {
                return Err(CoAkkaError::InvalidArgument(
                    "Rust handler registration budget exhausted".into(),
                ));
            }
            if !replacing {
                entries.handlers.try_reserve(1).map_err(|_| {
                    CoAkkaError::Native("cannot reserve handler registration".into())
                })?;
                entries.target_bytes += target.len();
            }
            entries.handlers.insert(target, candidate)
        };
        // No mutex is live while arbitrary capture destructors execute.
        drop(previous);
        Ok(())
    }

    pub(crate) fn unregister(&self, target: &str) -> Result<bool> {
        let previous = {
            let mut entries = self
                .entries
                .lock()
                .map_err(|_| CoAkkaError::Native("handler registry poisoned".into()))?;
            let previous = entries.handlers.remove_entry(target);
            if let Some((key, _)) = &previous {
                entries.target_bytes -= key.len();
            }
            previous
        };
        let removed = previous.is_some();
        drop(previous);
        Ok(removed)
    }

    pub(crate) fn select(&self, target: &str) -> Result<Option<SelectedHandler>> {
        let entries = self
            .entries
            .lock()
            .map_err(|_| CoAkkaError::Native("handler registry poisoned".into()))?;
        Ok(entries.handlers.get(target).cloned().map(SelectedHandler))
    }
}

pub(crate) struct SelectedHandler(Arc<Handler>);

impl SelectedHandler {
    pub(crate) fn call(&self, request: TransportEnvelope) -> Result<Option<TransportEnvelope>> {
        // The callback owns its application state. Catch only its unwind; no
        // connector lock or native frame borrow crosses application execution.
        // Core's original request deadline/outcome remains authoritative.
        catch_unwind(AssertUnwindSafe(|| (self.0)(request))).map_err(|_| CoAkkaError::HandlerPanic)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::Weak;

    struct Probe(Arc<AtomicUsize>);
    impl Probe {
        fn touch(&self) {}
    }
    impl Drop for Probe {
        fn drop(&mut self) {
            self.0.fetch_add(1, Ordering::Relaxed);
        }
    }

    #[test]
    fn registration_count_and_target_bytes_are_bounded_and_reusable() {
        let registry = HandlerRegistry::default();
        for index in 0..MAX_HANDLERS {
            registry.register(format!("k{index}"), |_| None).unwrap();
        }
        assert!(registry.register("overflow".into(), |_| None).is_err());
        registry.register("k0".into(), |_| None).unwrap();
        assert!(registry.unregister("k0").unwrap());
        registry
            .register("replacement-slot".into(), |_| None)
            .unwrap();
        assert_eq!(
            registry.entries.lock().unwrap().handlers.len(),
            MAX_HANDLERS
        );
        let registry = HandlerRegistry::default();
        let large = "x".repeat(MAX_TARGET_BYTES);
        registry.register(large.clone(), |_| None).unwrap();
        assert!(registry.register("y".into(), |_| None).is_err());
        registry.register(large.clone(), |_| None).unwrap();
        registry.unregister(&large).unwrap();
        assert_eq!(registry.entries.lock().unwrap().target_bytes, 0);
        assert!(registry
            .register("x".repeat(MAX_TARGET_BYTES + 1), |_| None)
            .is_err());
        registry.register("y".into(), |_| None).unwrap();
    }

    #[test]
    fn selected_capture_lives_until_its_own_borrow_retires() {
        let registry = HandlerRegistry::default();
        let drops = Arc::new(AtomicUsize::new(0));
        let capture = Probe(drops.clone());
        registry
            .register("key".into(), move |_| {
                capture.touch();
                None
            })
            .unwrap();
        let selected = registry.select("key").unwrap().unwrap();
        registry.unregister("key").unwrap();
        assert_eq!(drops.load(Ordering::Relaxed), 0);
        assert!(registry.select("key").unwrap().is_none());
        drop(selected);
        assert_eq!(drops.load(Ordering::Relaxed), 1);
    }

    struct Reenter(Weak<HandlerRegistry>);
    impl Reenter {
        fn touch(&self) {}
    }
    impl Drop for Reenter {
        fn drop(&mut self) {
            self.0.upgrade().unwrap().unregister("k0").unwrap();
        }
    }

    #[test]
    fn refused_candidate_destructor_runs_after_lock_release() {
        let registry = Arc::new(HandlerRegistry::default());
        for index in 0..MAX_HANDLERS {
            registry.register(format!("k{index}"), |_| None).unwrap();
        }
        let capture = Reenter(Arc::downgrade(&registry));
        assert!(registry
            .register("refused".into(), move |_| {
                capture.touch();
                None
            })
            .is_err());
        assert!(registry.select("k0").unwrap().is_none());
        registry.register("available".into(), |_| None).unwrap();
    }

    #[test]
    fn exact_target_keys_do_not_apply_core_admission_policy() {
        let registry = HandlerRegistry::default();
        for target in ["", " ", "x\0y", "có dấu 测试"] {
            registry.register(target.into(), |_| None).unwrap();
            assert!(registry.select(target).unwrap().is_some());
        }
        assert!(registry.select("x").unwrap().is_none());
        assert_eq!(registry.entries.lock().unwrap().handlers.len(), 4);
    }

    #[test]
    fn repeated_replacement_retires_old_roots() {
        let registry = HandlerRegistry::default();
        let drops = Arc::new(AtomicUsize::new(0));
        for index in 0..1024 {
            let capture = Probe(drops.clone());
            registry
                .register("key".into(), move |_| {
                    capture.touch();
                    None
                })
                .unwrap();
            assert_eq!(drops.load(Ordering::Relaxed), index);
        }
        assert_eq!(registry.entries.lock().unwrap().handlers.len(), 1);
        registry.unregister("key").unwrap();
        assert_eq!(drops.load(Ordering::Relaxed), 1024);
    }

    #[test]
    fn concurrent_selection_replacement_and_removal_retire_every_capture() {
        let registry = Arc::new(HandlerRegistry::default());
        let drops = Arc::new(AtomicUsize::new(0));
        let mut workers = Vec::new();
        for worker in 0..4 {
            let registry = registry.clone();
            let drops = drops.clone();
            workers.push(std::thread::spawn(move || {
                for turn in 0..256 {
                    let target = format!("k{}", (worker + turn) % 8);
                    let capture = Probe(drops.clone());
                    registry
                        .register(target.clone(), move |_| {
                            capture.touch();
                            None
                        })
                        .unwrap();
                    let selected = registry.select(&target).unwrap();
                    registry.unregister(&target).unwrap();
                    if let Some(selected) = selected {
                        assert!(selected
                            .call(crate::wire::decode_envelope(&[]).unwrap())
                            .unwrap()
                            .is_none());
                    }
                }
            }));
        }
        for worker in workers {
            worker.join().unwrap();
        }
        assert!(registry.entries.lock().unwrap().handlers.len() <= 8);
        drop(registry);
        assert_eq!(drops.load(Ordering::Relaxed), 1024);
    }
}
