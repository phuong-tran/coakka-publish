//! Startup values preserve intent; Core owns acceptance and effective facts.
//! This cold boundary borrows strings only through synchronous native calls.
use crate::{
    ptr_to_string, status_to_result, CoAkkaError, NativeLibrary, Result, RuntimeHost, RuntimePtr,
    TcpConnectionStrategySpec, TcpSecuritySpec,
};
use std::ffi::{c_char, c_int, c_void, CString};
use std::mem::size_of;

/// Startup intent copied by Core; fields are not accepted configuration facts.
#[derive(Clone, Debug)]
pub struct ConnectorStartSpec {
    /// Logical system name, preserved exactly; embedded NUL cannot cross C.
    pub system_name: String,
    /// App-host node identity, preserved exactly; embedded NUL cannot cross C.
    pub node_id: String,
    /// Required base-config intent; `new` requests no dropping of accepted work.
    pub strict_no_drop: bool,
    /// Requested queue capacity; nonpositive values ask Core to select its default.
    pub queue_capacity: i32,
    /// Initial snapshot generation; Core validates it.
    pub generation: u64,
    /// Complete initial route intent, including an explicitly empty snapshot.
    pub routes: Vec<RouteSpec>,
    /// Optional collection intent; absence and explicit false remain distinct.
    pub monitor: Option<RuntimeMonitorOptions>,
    /// Requests a dedicated delivered-request host lane when supported.
    pub separate_delivered_request_lane: bool,
    /// Optional startup-only TCP connection intent.
    pub connection_strategy: Option<TcpConnectionStrategySpec>,
    /// Optional startup TCP protection intent.
    pub security: Option<TcpSecuritySpec>,
    /// Optional listener participation; absence delegates to Core's default.
    pub network: Option<RuntimeNetworkConfig>,
}

impl ConnectorStartSpec {
    /// Creates request/reply application intent with an initial generation1
    /// snapshot. Queue, execution, connection, monitor and network defaults
    /// remain Core-owned; inspect the resulting host's accepted snapshots.
    pub fn new(system_name: impl Into<String>, node_id: impl Into<String>) -> Self {
        Self {
            system_name: system_name.into(),
            node_id: node_id.into(),
            strict_no_drop: true,
            queue_capacity: 0,
            generation: 1,
            routes: Vec::new(),
            monitor: None,
            separate_delivered_request_lane: true,
            connection_strategy: None,
            security: None,
            network: None,
        }
    }
}

/// Explicit startup monitor-collection intent, distinct from an absent group.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct RuntimeMonitorOptions {
    /// Whether Core may collect monitor information for this instance.
    pub enabled: bool,
}

/// Explicit listener participation submitted to Core.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u32)]
pub enum RuntimeNetworkMode {
    /// Same-process runtime with no listener or remote routes.
    Embedded = 1,
    /// Client-only runtime that may call remote nodes.
    OutboundOnly = 2,
    /// Runtime node with explicit bind and advertised endpoints.
    NetworkNode = 3,
}

/// Listener intent; no endpoint or capability is inferred from routes.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeNetworkConfig {
    /// Requested participation mode.
    pub mode: RuntimeNetworkMode,
    /// Optional bind address; Core validates applicability and address syntax.
    pub bind_host: Option<String>,
    /// Requested bind port, passed unchanged.
    pub bind_port: u16,
    /// Optional advertised identity; Core validates it.
    pub advertise_host: Option<String>,
    /// Requested advertised port; zero is not replaced with the bind port.
    pub advertise_port: u16,
}

impl RuntimeNetworkConfig {
    /// Requests explicit embedded mode, distinct from omitted network intent.
    pub fn embedded() -> Self {
        Self {
            mode: RuntimeNetworkMode::Embedded,
            bind_host: None,
            bind_port: 0,
            advertise_host: None,
            advertise_port: 0,
        }
    }
    /// Requests explicit outbound-only mode with no listener.
    pub fn outbound_only() -> Self {
        Self {
            mode: RuntimeNetworkMode::OutboundOnly,
            ..Self::embedded()
        }
    }
    /// Preserves explicit endpoints; Core decides whether they are valid.
    pub fn network_node(
        bind_host: impl Into<String>,
        bind_port: u16,
        advertise_host: impl Into<String>,
        advertise_port: u16,
    ) -> Self {
        Self {
            mode: RuntimeNetworkMode::NetworkNode,
            bind_host: Some(bind_host.into()),
            bind_port,
            advertise_host: Some(advertise_host.into()),
            advertise_port,
        }
    }
}

/// Accepted listener participation copied from Core, not reconstructed intent.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeNetworkConfigSnapshot {
    /// Core mode value, preserving unknown future values.
    pub mode: u32,
    /// Whether Core accepted explicit network policy.
    pub explicit_policy: bool,
    /// Accepted bind address, empty when no listener exists.
    pub bind_host: String,
    /// Accepted bind port.
    pub bind_port: u16,
    /// Accepted advertised identity.
    pub advertise_host: String,
    /// Accepted advertised port.
    pub advertise_port: u16,
}

/// A logical target and complete endpoint intent for Core's route admission.
#[derive(Clone, Debug)]
pub struct RouteSpec {
    /// Exact target string, without connector whitespace normalization.
    pub target: String,
    /// Complete endpoint set; Core validates count and values.
    pub endpoints: Vec<EndpointSpec>,
    /// Requested route selection strategy.
    pub strategy: RouteStrategy,
    /// Exact key hint supplied to Core.
    pub route_key_hint: String,
    /// Requested flags; Core rejects unsupported bits.
    pub flags: u32,
}
impl RouteSpec {
    /// Creates explicit local single-owner route intent.
    pub fn single_local(target: impl Into<String>, host: impl Into<String>, port: u16) -> Self {
        Self {
            target: target.into(),
            endpoints: vec![EndpointSpec {
                host: host.into(),
                port,
                weight: 1,
                flags: 1,
            }],
            strategy: RouteStrategy::SingleOwner,
            route_key_hint: String::new(),
            flags: 0,
        }
    }
}

/// Endpoint intent, preserved for Core's validation and normalization.
#[derive(Clone, Debug)]
pub struct EndpointSpec {
    /// Exact endpoint identity/address.
    pub host: String,
    /// Requested endpoint port; Core decides whether zero is valid.
    pub port: u16,
    /// Requested relative weight; Core owns the meaning of zero.
    pub weight: u32,
    /// Requested endpoint flags such as local ownership.
    pub flags: u32,
}

/// Endpoint selection intent; omission semantics are owned by Core.
#[derive(Copy, Clone, Debug)]
#[repr(u64)]
pub enum RouteStrategy {
    /// Delegates selection of the strategy to Core.
    Unspecified = 0,
    /// Requests one declared owner.
    SingleOwner = 1,
    /// Requests weighted round-robin selection.
    WeightedRoundRobin = 2,
    /// Requests stable key-based rendezvous selection.
    RendezvousHash = 3,
}

#[repr(C)]
pub(crate) struct NativeNetworkOptions {
    struct_size: usize,
    fields: u64,
    mode: u32,
    reserved: u32,
    bind_host: *const c_char,
    advertise_host: *const c_char,
    bind_port: u16,
    advertise_port: u16,
    reserved2: u32,
}

#[repr(C)]
pub(crate) struct NativeNetworkConfig {
    struct_size: usize,
    mode: u32,
    explicit_policy: u32,
    bind_host: *const c_char,
    advertise_host: *const c_char,
    bind_port: u16,
    advertise_port: u16,
    reserved: u32,
}
pub(crate) type RuntimeGetNetworkConfig =
    unsafe extern "C" fn(*mut c_void, *mut NativeNetworkConfig) -> c_int;

pub(crate) fn apply_network_options(
    lib: &NativeLibrary,
    runtime: RuntimePtr,
    network: &RuntimeNetworkConfig,
) -> Result<()> {
    let bind_host = network
        .bind_host
        .as_deref()
        .map(CString::new)
        .transpose()
        .map_err(|_| CoAkkaError::InvalidArgument("bind_host contains NUL".into()))?;
    let advertise_host = network
        .advertise_host
        .as_deref()
        .map(CString::new)
        .transpose()
        .map_err(|_| CoAkkaError::InvalidArgument("advertise_host contains NUL".into()))?;
    // Presence projects caller intent. Network-node mode requires all fields;
    // fields in other modes still reach Core so it owns their refusal.
    let fields = if network.mode == RuntimeNetworkMode::NetworkNode {
        0x1f
    } else {
        1 | if network.bind_host.is_some() { 2 } else { 0 }
            | if network.bind_port != 0 { 4 } else { 0 }
            | if network.advertise_host.is_some() {
                8
            } else {
                0
            }
            | if network.advertise_port != 0 { 16 } else { 0 }
    };
    let options = NativeNetworkOptions {
        struct_size: size_of::<NativeNetworkOptions>(),
        fields,
        mode: network.mode as u32,
        reserved: 0,
        bind_host: bind_host.as_ref().map_or(std::ptr::null(), |v| v.as_ptr()),
        advertise_host: advertise_host
            .as_ref()
            .map_or(std::ptr::null(), |v| v.as_ptr()),
        bind_port: network.bind_port,
        advertise_port: network.advertise_port,
        reserved2: 0,
    };
    status_to_result(
        // SAFETY: the startup transaction owns runtime; strings are borrowed
        // for this copying call only. Core owns field validation.
        unsafe { (lib.apply_network_options)(runtime.0, &options) },
        "coakka_v2_runtime_apply_network_options",
    )
}

impl RuntimeHost {
    /// Copies accepted network facts while this host borrows the live runtime.
    pub fn runtime_network_config(&self) -> Result<RuntimeNetworkConfigSnapshot> {
        self.inner.require_open()?;
        let mut native = NativeNetworkConfig {
            struct_size: size_of::<NativeNetworkConfig>(),
            mode: 0,
            explicit_policy: 0,
            bind_host: std::ptr::null(),
            advertise_host: std::ptr::null(),
            bind_port: 0,
            advertise_port: 0,
            reserved: 0,
        };
        status_to_result(
            // SAFETY: self borrows the live runtime. Network policy cannot
            // change after startup; string borrows last through copying.
            unsafe { (self.inner.lib.get_network_config)(self.inner.runtime.0, &mut native) },
            "coakka_v2_runtime_get_network_config",
        )?;
        if native.explicit_policy > 1 {
            return Err(CoAkkaError::Native(
                "Core returned invalid network presence".into(),
            ));
        }
        Ok(RuntimeNetworkConfigSnapshot {
            mode: native.mode,
            explicit_policy: native.explicit_policy != 0,
            bind_host: ptr_to_string(native.bind_host),
            bind_port: native.bind_port,
            advertise_host: ptr_to_string(native.advertise_host),
            advertise_port: native.advertise_port,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn network_layouts_match_frozen_public_64_bit_contract() {
        assert_eq!(size_of::<NativeNetworkOptions>(), 48);
        assert_eq!(size_of::<NativeNetworkConfig>(), 40);
    }
}
