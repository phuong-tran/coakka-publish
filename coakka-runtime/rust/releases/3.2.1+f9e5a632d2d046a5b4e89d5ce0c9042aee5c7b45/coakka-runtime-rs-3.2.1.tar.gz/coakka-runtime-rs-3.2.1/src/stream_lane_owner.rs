//! Rust closure storage and native-borrow lifetime, not Core session policy.
use super::{
    ConsumerHolder, NativeLibrary, NativeSessionSnapshot, NativeStreamStats, SourceHolder,
    StreamConsumer, StreamDirection, StreamSource,
};
use crate::{status_to_result, CoAkkaError, Result};
use std::cell::Cell;
use std::ffi::{c_int, c_void, CString};
use std::ptr;
use std::sync::{Condvar, Mutex};

thread_local! { static CALLBACK_LANE: Cell<usize> = const { Cell::new(0) }; }

/// Same-lane close would join the executing native worker. This tracks only
/// Rust callback execution; it never guesses a Core session/lifecycle fact.
pub(super) struct CallbackScope(usize);
impl CallbackScope {
    pub(super) fn enter(key: usize) -> Self {
        Self(CALLBACK_LANE.with(|current| current.replace(key)))
    }
}
impl Drop for CallbackScope {
    fn drop(&mut self) {
        let _ = CALLBACK_LANE.try_with(|current| current.set(self.0));
    }
}

pub(super) enum CallbackRoot {
    Source(Box<SourceHolder>),
    Consumer(Box<ConsumerHolder>),
}
impl CallbackRoot {
    pub(super) fn source(source: StreamSource) -> Self {
        Self::Source(Box::new(SourceHolder {
            callback: Mutex::new(source),
            lane_key: 0,
        }))
    }
    pub(super) fn consumer(consumer: StreamConsumer) -> Self {
        Self::Consumer(Box::new(ConsumerHolder {
            callback: Mutex::new(consumer),
            lane_key: 0,
        }))
    }
    fn context(&mut self, key: usize) -> *mut c_void {
        match self {
            Self::Source(holder) => {
                holder.lane_key = key;
                (&mut **holder as *mut SourceHolder).cast()
            }
            Self::Consumer(holder) => {
                holder.lane_key = key;
                (&mut **holder as *mut ConsumerHolder).cast()
            }
        }
    }
}

struct Entry {
    id: CString,
    direction: StreamDirection,
    _root: CallbackRoot,
}
struct Lifecycle {
    lane: *mut c_void,
    closing: bool,
    active: usize,
}
// SAFETY: pointer use is fenced by active borrows; only the serialized closer
// can destroy it, after native worker join and all host borrows return.
unsafe impl Send for Lifecycle {}

pub(super) struct StreamOwner {
    lib: NativeLibrary,
    key: usize,
    lifecycle: Mutex<Lifecycle>,
    drained: Condvar,
    roots: Mutex<Vec<Entry>>,
    root_limit: usize,
}

struct Borrow<'a> {
    owner: &'a StreamOwner,
    lane: *mut c_void,
}
impl Drop for Borrow<'_> {
    fn drop(&mut self) {
        // No application callout runs under this lock. Recover only to retire a
        // counted borrow during unwinding; poison never licenses new admission.
        let mut state = self
            .owner
            .lifecycle
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        state.active -= 1;
        if state.active == 0 {
            self.owner.drained.notify_all();
        }
    }
}

impl StreamOwner {
    /// Takes an unpublished created lane. Any fallible setup/start failure
    /// destroys it before returning; callback storage precedes native start.
    pub(super) fn start(lib: NativeLibrary, lane: *mut c_void) -> Result<Self> {
        let setup = (|| {
            let mut stats = NativeStreamStats {
                struct_size: std::mem::size_of::<NativeStreamStats>(),
                ..NativeStreamStats::default()
            };
            status_to_result(
                // SAFETY: caller transfers the live unpublished created lane.
                unsafe { lib.stream_lane_get_stats.unwrap()(lane, &mut stats) },
                "stream_lane_get_stats",
            )?;
            let limit = stats
                .capacity
                .checked_add(1)
                .filter(|_| stats.capacity != 0)
                .ok_or_else(|| CoAkkaError::Native("invalid Core callback capacity".into()))?;
            let mut roots = Vec::new();
            roots
                .try_reserve_exact(limit)
                .map_err(|_| CoAkkaError::Native("stream callback storage unavailable".into()))?;
            status_to_result(
                // SAFETY: storage exists and no other host can access this lane yet.
                unsafe { lib.stream_lane_start.unwrap()(lane) },
                "stream_lane_start",
            )?;
            Ok((limit, roots))
        })();
        match setup {
            Ok((root_limit, roots)) => Ok(Self {
                lib,
                key: lane as usize,
                lifecycle: Mutex::new(Lifecycle {
                    lane,
                    closing: false,
                    active: 0,
                }),
                drained: Condvar::new(),
                roots: Mutex::new(roots),
                root_limit,
            }),
            Err(error) => {
                // SAFETY: create/start failure has no published host owner.
                unsafe { lib.stream_lane_destroy.unwrap()(lane) };
                Err(error)
            }
        }
    }

    fn borrow(&self) -> Result<Borrow<'_>> {
        let mut state = self
            .lifecycle
            .lock()
            .map_err(|_| CoAkkaError::Native("stream lane mutex poisoned".into()))?;
        if state.closing || state.lane.is_null() {
            return Err(CoAkkaError::Native("stream lane is closed".into()));
        }
        state.active = state
            .active
            .checked_add(1)
            .ok_or_else(|| CoAkkaError::Native("stream lane borrow limit reached".into()))?;
        Ok(Borrow {
            owner: self,
            lane: state.lane,
        })
    }

    pub(super) fn call<T>(
        &self,
        action: impl FnOnce(&NativeLibrary, *mut c_void) -> Result<T>,
    ) -> Result<T> {
        let borrow = self.borrow()?;
        action(&self.lib, borrow.lane)
    }

    /// Admission holds one native borrow through root publication. The staged
    /// entry exists before FFI and no allocation/projection follows acceptance
    /// under this lock. A panic leaves roots retained and poisons admission;
    /// close can still stop/join and reclaim them. No uncertain root is retried.
    pub(super) fn admit<T>(
        &self,
        id: CString,
        direction: StreamDirection,
        root: CallbackRoot,
        operation: &'static str,
        action: impl FnOnce(&NativeLibrary, *mut c_void, *mut c_void) -> (c_int, T),
    ) -> Result<T> {
        let mut retired = Vec::with_capacity(self.root_limit);
        let mut candidate = Some(root);
        let result = (|| {
            let borrow = self.borrow()?;
            let mut roots = self
                .roots
                .lock()
                .map_err(|_| CoAkkaError::Native("stream callback admission poisoned".into()))?;
            if roots.len() == self.root_limit {
                let mut index = 0;
                while index < roots.len() {
                    let entry = &roots[index];
                    let mut snapshot = NativeSessionSnapshot {
                        struct_size: std::mem::size_of::<NativeSessionSnapshot>(),
                        ..NativeSessionSnapshot::default()
                    };
                    // SAFETY: only accepted, valid keys enter this path; the
                    // owner borrow fences destroy and the root mutex fences
                    // replacement/forget. BAD_STATE here means record absence,
                    // never a wait timeout or guessed terminal state.
                    let status = unsafe {
                        self.lib.stream_lane_get_session.unwrap()(
                            borrow.lane,
                            entry.id.as_ptr(),
                            entry.direction as u32,
                            &mut snapshot,
                        )
                    };
                    if status == -3 {
                        retired.push(roots.swap_remove(index));
                    } else {
                        status_to_result(status, "stream_lane_get_session")?;
                        index += 1;
                    }
                }
            }
            if roots.len() == self.root_limit {
                return Err(CoAkkaError::Native(
                    "stream callback storage exhausted".into(),
                ));
            }
            let previous = roots
                .iter()
                .position(|entry| entry.id == id && entry.direction == direction);
            let mut root = candidate.take().unwrap();
            let context = root.context(self.key);
            roots.push(Entry {
                id,
                direction,
                _root: root,
            });
            let (status, output) = action(&self.lib, borrow.lane, context);
            if status == 0 {
                if let Some(index) = previous {
                    retired.push(roots.swap_remove(index));
                }
                Ok(output)
            } else {
                retired.push(roots.pop().unwrap());
                status_to_result(status, operation)?;
                unreachable!()
            }
        })();
        // Entry/closure Drop may call user code. Both locks and native borrows
        // have ended, including on refusal or unwind of the inner operation.
        drop(retired);
        drop(candidate);
        result
    }

    pub(super) fn control(
        &self,
        id: CString,
        direction: StreamDirection,
        forget: bool,
    ) -> Result<()> {
        let mut retired = None;
        let result = (|| {
            let borrow = self.borrow()?;
            let mut roots = self
                .roots
                .lock()
                .map_err(|_| CoAkkaError::Native("stream callback admission poisoned".into()))?;
            let function = if forget {
                self.lib.stream_lane_forget_session.unwrap()
            } else {
                self.lib.stream_lane_cancel_session.unwrap()
            };
            status_to_result(
                // SAFETY: native borrow and input storage cover this synchronous call.
                unsafe { function(borrow.lane, id.as_ptr(), direction as u32) },
                if forget {
                    "stream_lane_forget_session"
                } else {
                    "stream_lane_cancel_session"
                },
            )?;
            if forget {
                if let Some(index) = roots
                    .iter()
                    .position(|entry| entry.id == id && entry.direction == direction)
                {
                    retired = Some(roots.swap_remove(index));
                }
            }
            Ok(())
        })();
        drop(retired);
        result
    }

    pub(super) fn close(&self) -> Result<()> {
        if CALLBACK_LANE
            .try_with(|current| current.get() == self.key)
            .unwrap_or(false)
        {
            return Err(CoAkkaError::InvalidArgument(
                "cannot close a stream lane from its callback".into(),
            ));
        }
        let lane = {
            let mut state = self.lifecycle.lock().unwrap_or_else(|e| e.into_inner());
            while state.closing {
                state = self.drained.wait(state).unwrap_or_else(|e| e.into_inner());
            }
            if state.lane.is_null() {
                return Ok(());
            }
            state.closing = true;
            state.lane
        };
        // SAFETY: unique closer seals admission. Stop wakes waits and joins
        // native workers without holding Rust locks they may need to return.
        let status = unsafe { self.lib.stream_lane_stop.unwrap()(lane) };
        let mut state = self.lifecycle.lock().unwrap_or_else(|e| e.into_inner());
        if status != 0 {
            state.closing = false;
            self.drained.notify_all();
            return status_to_result(status, "stream_lane_stop");
        }
        while state.active != 0 {
            state = self.drained.wait(state).unwrap_or_else(|e| e.into_inner());
        }
        // SAFETY: native stop joined callbacks and every host borrow has retired.
        unsafe { self.lib.stream_lane_destroy.unwrap()(lane) };
        let retired = std::mem::take(&mut *self.roots.lock().unwrap_or_else(|e| e.into_inner()));
        state.lane = ptr::null_mut();
        state.closing = false;
        self.drained.notify_all();
        drop(state);
        drop(retired);
        Ok(())
    }
}

impl Drop for StreamOwner {
    fn drop(&mut self) {
        if self.close().is_err() {
            // A forbidden last-owner drop on its native callback cannot join
            // itself. Fail closed: never free a live native context. Explicit
            // close on a non-callback thread is required for normal retirement.
            // The native module is already pinned for process lifetime.
            let roots = std::mem::take(self.roots.get_mut().unwrap_or_else(|e| e.into_inner()));
            std::mem::forget(roots);
        }
    }
}

#[cfg(test)]
#[path = "stream_lane_owner_tests.rs"]
mod tests;
