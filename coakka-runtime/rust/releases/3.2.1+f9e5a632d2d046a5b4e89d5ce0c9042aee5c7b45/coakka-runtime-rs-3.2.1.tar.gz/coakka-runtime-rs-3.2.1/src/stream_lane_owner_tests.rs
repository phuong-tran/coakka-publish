//! Actual-Core private publication/unwind seams; no synthetic callback pointer.
use super::*;
use crate::stream_lane::{source_trampoline, NativePublishSpec};
use crate::{StreamLane, StreamLaneConfig, StreamSourceResult, STREAM_LANE_PUBLISHER};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::{mpsc, Arc};
use std::time::{Duration, Instant};

fn lane() -> Arc<StreamLane> {
    Arc::new(
        StreamLane::open(
            StreamLaneConfig {
                flags: STREAM_LANE_PUBLISHER,
                capacity: 1,
                ..Default::default()
            },
            std::env::var("COAKKA_STREAM_LANE_RUNTIME_LIB").expect("exact Core required"),
        )
        .unwrap(),
    )
}

fn root(value: Arc<usize>) -> CallbackRoot {
    CallbackRoot::source(Box::new(move |_| {
        std::hint::black_box(&value);
        StreamSourceResult::End
    }))
}

fn accept(lib: &NativeLibrary, lane: *mut c_void, context: *mut c_void) -> c_int {
    let id = CString::new("owner-private").unwrap();
    let token = CString::new("token").unwrap();
    let spec = NativePublishSpec {
        struct_size: std::mem::size_of::<NativePublishSpec>(),
        id: id.as_ptr(),
        token: token.as_ptr(),
        format_id: 1,
        max_frame_bytes: 16,
        source_next: Some(source_trampoline),
        source_context: context,
    };
    // SAFETY: called only within StreamOwner::admit's native borrow and rooted
    // context. Synchronous input text lives through Core copying/admission.
    unsafe { lib.stream_lane_prepare_publish.unwrap()(lane, &spec) }
}

#[test]
#[ignore = "requires COAKKA_STREAM_LANE_RUNTIME_LIB; release evidence runs ignored tests"]
fn native_borrow_retires_on_unwind() {
    let lane = lane();
    let caught = catch_unwind(AssertUnwindSafe(|| {
        lane.owner
            .call::<()>(|_, _| panic!("intentional borrow unwind"))
            .unwrap();
    }));
    assert!(caught.is_err());
    assert_eq!(lane.owner.lifecycle.lock().unwrap().active, 0);
    lane.stats().unwrap();
    lane.close().unwrap();
}

#[test]
#[ignore = "requires COAKKA_STREAM_LANE_RUNTIME_LIB; release evidence runs ignored tests"]
fn unreceived_admission_retains_context_and_refuses_retry_until_close() {
    let lane = lane();
    let value = Arc::new(1);
    let weak = Arc::downgrade(&value);
    let caught = catch_unwind(AssertUnwindSafe(|| {
        lane.owner
            .admit::<()>(
                CString::new("owner-private").unwrap(),
                StreamDirection::Publish,
                root(value),
                "prepare",
                |lib, native, context| {
                    assert_eq!(accept(lib, native, context), 0);
                    panic!("intentional unwind after native acceptance")
                },
            )
            .unwrap();
    }));
    assert!(caught.is_err());
    assert_eq!(weak.strong_count(), 1);
    assert_eq!(lane.stats().unwrap().retained_records, 1);
    let replacement = Arc::new(2);
    let replacement_weak = Arc::downgrade(&replacement);
    let refused = lane.owner.admit(
        CString::new("owner-private").unwrap(),
        StreamDirection::Publish,
        root(replacement),
        "prepare",
        |_, _, _| -> (c_int, ()) { panic!("retry must not reach FFI") },
    );
    assert!(refused.is_err());
    assert_eq!(replacement_weak.strong_count(), 0);
    assert_eq!(weak.strong_count(), 1);
    lane.close().unwrap();
    assert_eq!(weak.strong_count(), 0);
}

#[test]
#[ignore = "requires COAKKA_STREAM_LANE_RUNTIME_LIB; release evidence runs ignored tests"]
fn close_fences_accepted_but_not_returned_admission() {
    let lane = lane();
    let value = Arc::new(1);
    let weak = Arc::downgrade(&value);
    let (accepted_tx, accepted_rx) = mpsc::sync_channel(1);
    let (release_tx, release_rx) = mpsc::sync_channel(1);
    let admitting = Arc::clone(&lane);
    let admit = std::thread::spawn(move || {
        admitting.owner.admit(
            CString::new("owner-private").unwrap(),
            StreamDirection::Publish,
            root(value),
            "prepare",
            |lib, native, context| {
                let status = accept(lib, native, context);
                accepted_tx.send(status).unwrap();
                release_rx.recv_timeout(Duration::from_secs(5)).unwrap();
                (status, ())
            },
        )
    });
    let accepted = accepted_rx.recv_timeout(Duration::from_secs(5)).unwrap();
    let closing = Arc::clone(&lane);
    let close = std::thread::spawn(move || closing.close());
    let deadline = Instant::now() + Duration::from_secs(2);
    let mut observed = false;
    while Instant::now() < deadline {
        let state = lane.owner.lifecycle.lock().unwrap();
        if state.closing {
            observed = state.active == 1 && !state.lane.is_null() && weak.strong_count() == 1;
            break;
        }
        drop(state);
        std::thread::yield_now();
    }
    // Always release the real admitted call before assertions, including red.
    release_tx.send(()).unwrap();
    admit.join().unwrap().unwrap();
    close.join().unwrap().unwrap();
    assert_eq!(accepted, 0);
    assert!(
        observed,
        "close must retain the lane and context while admission is borrowed"
    );
    assert_eq!(weak.strong_count(), 0);
    lane.close().unwrap();
}
