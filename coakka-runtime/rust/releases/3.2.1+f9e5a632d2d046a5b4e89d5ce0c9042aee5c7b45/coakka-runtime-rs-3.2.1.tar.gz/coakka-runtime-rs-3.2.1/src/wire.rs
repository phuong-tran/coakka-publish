//! Private synchronous projection of the runtime wire contract.
//! Core owns policy. This owner checks byte/span safety and preserves values.

use crate::{
    BusinessStatus, CoAkkaError, ConnectorStartSpec, DeliveryHint, EndpointSpec, MessageKind,
    PayloadFormat, Result, RouteSpec, RuntimeDeadletter, TransportEnvelope,
    MAXIMUM_CLIENT_FRAME_BYTES,
};
use std::collections::HashMap;

#[cfg(test)]
#[path = "wire_tests.rs"]
mod wire_tests;

fn invalid(message: &str) -> CoAkkaError {
    CoAkkaError::WireCodec(message.to_owned())
}

// The existing host frame budget bounds all encoding temporaries, not Core's
// admission policy. Nested route/control buffers have fixed depth (at most
// four live buffers), and no output may grow beyond this bound.
struct Writer {
    bytes: Vec<u8>,
    limit: usize,
}

impl Writer {
    fn new() -> Self {
        Self {
            bytes: Vec::new(),
            limit: MAXIMUM_CLIENT_FRAME_BYTES,
        }
    }

    fn append(&mut self, bytes: &[u8]) -> Result<()> {
        let needed = self
            .bytes
            .len()
            .checked_add(bytes.len())
            .filter(|size| *size <= self.limit)
            .ok_or_else(|| invalid("encoded frame exceeds host byte budget"))?;
        if needed > self.bytes.capacity() {
            // Geometric growth is amortized O(1), capped at the budget. Reserve
            // before mutation: a refusal never publishes a partial frame.
            let capacity = needed
                .max(self.bytes.capacity().saturating_mul(2))
                .min(self.limit);
            self.bytes
                .try_reserve_exact(capacity - self.bytes.len())
                .map_err(|_| invalid("cannot reserve encoded frame storage"))?;
        }
        self.bytes.extend_from_slice(bytes);
        Ok(())
    }

    fn varint(&mut self, mut value: u64) -> Result<()> {
        let mut bytes = [0; 10];
        let mut length = 0;
        while value >= 128 {
            bytes[length] = (value as u8 & 127) | 128;
            length += 1;
            value >>= 7;
        }
        bytes[length] = value as u8;
        self.append(&bytes[..length + 1])
    }

    fn number(&mut self, field: u64, value: u64) -> Result<()> {
        self.varint(field << 3)?;
        self.varint(value)
    }

    fn bytes(&mut self, field: u64, value: &[u8]) -> Result<()> {
        // Empty messages/map entries have presence. Keep the length-zero entry.
        self.varint((field << 3) | 2)?;
        self.varint(value.len() as u64)?;
        self.append(value)
    }

    fn string(&mut self, field: u64, value: &str) -> Result<()> {
        if !value.is_empty() {
            self.bytes(field, value.as_bytes())?;
        }
        Ok(())
    }
}

pub(crate) fn encode_initial_snapshot(spec: &ConnectorStartSpec) -> Result<Vec<u8>> {
    let mut payload = Writer::new();
    payload.number(1, spec.generation)?;
    for route in &spec.routes {
        payload.bytes(2, &encode_route(route)?)?;
    }
    let mut out = Writer::new();
    out.number(1, 1)?;
    out.number(2, spec.generation)?;
    out.number(3, 1)?;
    out.number(4, 2)?;
    out.number(5, 1)?;
    out.number(6, 1)?;
    out.bytes(7, &payload.bytes)?;
    out.bytes(8, &encode_map_entry("source_connector", &spec.system_name)?)?;
    Ok(out.bytes)
}

fn encode_route(route: &RouteSpec) -> Result<Vec<u8>> {
    let mut out = Writer::new();
    out.string(1, &route.target)?;
    out.number(2, route.strategy as u64)?;
    out.string(3, &route.route_key_hint)?;
    if route.flags != 0 {
        out.number(4, route.flags as u64)?;
    }
    for endpoint in &route.endpoints {
        out.bytes(5, &encode_endpoint(endpoint)?)?;
    }
    Ok(out.bytes)
}

fn encode_endpoint(endpoint: &EndpointSpec) -> Result<Vec<u8>> {
    let mut out = Writer::new();
    out.string(1, &endpoint.host)?;
    out.number(2, endpoint.port as u64)?;
    out.number(3, endpoint.weight as u64)?;
    if endpoint.flags != 0 {
        out.number(4, endpoint.flags as u64)?;
    }
    Ok(out.bytes)
}

fn encode_map_entry(key: &str, value: &str) -> Result<Vec<u8>> {
    let mut out = Writer::new();
    out.string(1, key)?;
    out.string(2, value)?;
    Ok(out.bytes)
}

pub(crate) fn encode_envelope(value: &TransportEnvelope) -> Result<Vec<u8>> {
    let mut out = Writer::new();
    out.string(1, &value.message_id)?;
    out.string(2, &value.correlation_id)?;
    out.string(3, &value.source)?;
    out.string(4, &value.target)?;
    out.string(5, &value.reply_to)?;
    out.number(6, value.kind.value() as i64 as u64)?;
    out.number(7, u64::from(value.one_way))?;
    // int32 uses sign-extended two's complement, not connector timeout policy.
    out.number(8, value.timeout_ms as i64 as u64)?;
    out.bytes(9, &value.payload)?;
    for (key, value) in &value.headers {
        out.bytes(10, &encode_map_entry(key, value)?)?;
    }
    out.number(11, value.status.value() as i64 as u64)?;
    out.string(12, &value.error_code)?;
    out.string(13, &value.error_message)?;
    out.number(14, value.delivery_hint.value() as i64 as u64)?;
    out.string(15, &value.message_type)?;
    out.number(16, value.payload_schema_version as u64)?;
    out.number(17, value.payload_format.value() as i64 as u64)?;
    Ok(out.bytes)
}

pub(crate) fn decode_envelope(bytes: &[u8]) -> Result<TransportEnvelope> {
    let mut value = TransportEnvelope {
        message_id: String::new(),
        correlation_id: String::new(),
        source: String::new(),
        target: String::new(),
        reply_to: String::new(),
        kind: MessageKind::Unspecified,
        one_way: false,
        timeout_ms: 0,
        payload: Vec::new(),
        headers: HashMap::new(),
        status: BusinessStatus::Unspecified,
        error_code: String::new(),
        error_message: String::new(),
        delivery_hint: DeliveryHint::Unspecified,
        message_type: String::new(),
        payload_schema_version: 0,
        payload_format: PayloadFormat::Unspecified,
    };
    merge_envelope(bytes, &mut value)?;
    Ok(value)
}

fn merge_envelope(bytes: &[u8], value: &mut TransportEnvelope) -> Result<()> {
    let mut reader = Reader::new(bytes)?;
    while let Some((field, wire)) = reader.tag()? {
        match field {
            1 => value.message_id = reader.string(wire)?,
            2 => value.correlation_id = reader.string(wire)?,
            3 => value.source = reader.string(wire)?,
            4 => value.target = reader.string(wire)?,
            5 => value.reply_to = reader.string(wire)?,
            6 => value.kind = MessageKind::from_value(reader.number(wire)? as i32),
            7 => value.one_way = reader.number(wire)? != 0,
            8 => value.timeout_ms = reader.number(wire)? as i32,
            9 => value.payload = reader.bytes(wire)?.to_vec(),
            10 => insert_entry(&mut value.headers, reader.bytes(wire)?)?,
            11 => value.status = BusinessStatus::from_value(reader.number(wire)? as i32),
            12 => value.error_code = reader.string(wire)?,
            13 => value.error_message = reader.string(wire)?,
            14 => value.delivery_hint = DeliveryHint::from_value(reader.number(wire)? as i32),
            15 => value.message_type = reader.string(wire)?,
            16 => value.payload_schema_version = reader.number(wire)? as u32,
            17 => value.payload_format = PayloadFormat::from_value(reader.number(wire)? as i32),
            _ => reader.skip(wire)?,
        }
    }
    Ok(())
}

pub(crate) fn decode_deadletter(bytes: &[u8]) -> Result<RuntimeDeadletter> {
    let mut reader = Reader::new(bytes)?;
    let mut original_present = false;
    let mut value = RuntimeDeadletter {
        original: decode_envelope(&[])?,
        reason: String::new(),
        reason_code: 0,
        detail: String::new(),
        active_generation: 0,
        resolved_host: String::new(),
        resolved_port: 0,
        endpoint_attempt_count: 0,
        transport_failure_metadata: HashMap::new(),
    };
    while let Some((field, wire)) = reader.tag()? {
        match field {
            1 => {
                // Repeated singular messages merge; their scalars use the last
                // value without discarding prior fields of the original.
                merge_envelope(reader.bytes(wire)?, &mut value.original)?;
                original_present = true;
            }
            2 => value.reason_code = reader.number(wire)? as i32,
            3 => value.detail = reader.string(wire)?,
            4 => value.active_generation = reader.number(wire)?,
            5 => value.resolved_host = reader.string(wire)?,
            6 => value.resolved_port = reader.number(wire)? as u32,
            7 => value.endpoint_attempt_count = reader.number(wire)? as u32,
            8 => insert_entry(&mut value.transport_failure_metadata, reader.bytes(wire)?)?,
            _ => reader.skip(wire)?,
        }
    }
    if !original_present {
        return Err(invalid("deadletter missing original envelope"));
    }
    value.reason = reason_name(value.reason_code).to_owned();
    Ok(value)
}

fn reason_name(reason: i32) -> &'static str {
    match reason {
        0 => "DEADLETTER_REASON_UNSPECIFIED",
        1 => "DEADLETTER_REASON_NO_ACTIVE_SNAPSHOT",
        2 => "DEADLETTER_REASON_ROUTE_MISS",
        3 => "DEADLETTER_REASON_NO_RESPONSIBLE_HOST",
        4 => "DEADLETTER_REASON_QUEUE_REJECTED",
        5 => "DEADLETTER_REASON_LOCAL_HANDOFF_FAILED",
        6 => "DEADLETTER_REASON_DELIVERY_FAILED",
        7 => "DEADLETTER_REASON_REMOTE_TRANSPORT_FAILED",
        8 => "DEADLETTER_REASON_RUNTIME_STOPPED",
        9 => "DEADLETTER_REASON_INVALID_ENVELOPE",
        10 => "DEADLETTER_REASON_ENDPOINT_UNAVAILABLE",
        11 => "DEADLETTER_REASON_REMOTE_REPLY_TIMEOUT",
        12 => "DEADLETTER_REASON_LOCALITY_MISMATCH",
        13 => "DEADLETTER_REASON_EXPIRED_BEFORE_DELIVERY",
        14 => "DEADLETTER_REASON_ONE_WAY_DROPPED_BY_POLICY",
        15 => "DEADLETTER_REASON_REMOTE_TRANSPORT_SECURITY_FAILED",
        _ => "DEADLETTER_REASON_UNKNOWN",
    }
}

fn insert_entry(map: &mut HashMap<String, String>, bytes: &[u8]) -> Result<()> {
    let mut reader = Reader::new(bytes)?;
    let mut key = String::new();
    let mut value = String::new();
    while let Some((field, wire)) = reader.tag()? {
        match field {
            1 => key = reader.string(wire)?,
            2 => value = reader.string(wire)?,
            _ => reader.skip(wire)?,
        }
    }
    // Empty keys are real values; duplicate keys use the last entry.
    map.insert(key, value);
    Ok(())
}

struct Reader<'a> {
    remaining: &'a [u8],
}

impl<'a> Reader<'a> {
    fn new(bytes: &'a [u8]) -> Result<Self> {
        if bytes.len() > MAXIMUM_CLIENT_FRAME_BYTES {
            return Err(invalid("input frame exceeds host byte budget"));
        }
        Ok(Self { remaining: bytes })
    }

    fn tag(&mut self) -> Result<Option<(u64, u8)>> {
        if self.remaining.is_empty() {
            return Ok(None);
        }
        let tag = self.varint()?;
        let field = tag >> 3;
        if field == 0 || field > 0x1fff_ffff {
            return Err(invalid("invalid field number"));
        }
        Ok(Some((field, (tag & 7) as u8)))
    }

    fn number(&mut self, wire: u8) -> Result<u64> {
        require_wire(wire, 0)?;
        self.varint()
    }

    fn string(&mut self, wire: u8) -> Result<String> {
        let value =
            std::str::from_utf8(self.bytes(wire)?).map_err(|_| invalid("invalid UTF-8 text"))?;
        Ok(value.to_owned())
    }

    fn take(&mut self, length: usize) -> Result<&'a [u8]> {
        if length > self.remaining.len() {
            return Err(invalid("truncated field"));
        }
        let (value, rest) = self.remaining.split_at(length);
        self.remaining = rest;
        Ok(value)
    }

    fn bytes(&mut self, wire: u8) -> Result<&'a [u8]> {
        require_wire(wire, 2)?;
        let length = usize::try_from(self.varint()?)
            .map_err(|_| invalid("field length exceeds addressable storage"))?;
        self.take(length)
    }

    fn skip(&mut self, wire: u8) -> Result<()> {
        match wire {
            0 => {
                self.varint()?;
            }
            1 => {
                self.take(8)?;
            }
            2 => {
                self.bytes(wire)?;
            }
            5 => {
                self.take(4)?;
            }
            // This runtime profile has no groups. Do not recursively traverse
            // arbitrary nesting or pretend an end-group marker is a value.
            _ => return Err(invalid("unsupported wire type")),
        }
        Ok(())
    }

    fn varint(&mut self) -> Result<u64> {
        let mut result = 0u64;
        for shift in (0..70).step_by(7) {
            let byte = self.take(1)?[0];
            if shift == 63 && byte > 1 {
                return Err(invalid("varint exceeds 64 bits"));
            }
            result |= u64::from(byte & 127) << shift;
            if byte & 128 == 0 {
                return Ok(result);
            }
        }
        Err(invalid("unterminated varint"))
    }
}

fn require_wire(actual: u8, expected: u8) -> Result<()> {
    if actual == expected {
        Ok(())
    } else {
        Err(invalid("unexpected wire type"))
    }
}
