use super::*;

#[test]
fn absent_enums_are_unspecified_not_business_defaults() {
    let value = decode_envelope(&[]).unwrap();
    assert_eq!(value.kind.value(), 0);
    assert_eq!(value.status.value(), 0);
    assert_eq!(value.delivery_hint.value(), 0);
}

#[test]
fn unknown_enums_keep_their_numeric_value() {
    let value = decode_envelope(&[48, 99, 88, 99, 112, 99, 136, 1, 99]).unwrap();
    assert_eq!(value.kind.value(), 99);
    assert_eq!(value.status.value(), 99);
    assert_eq!(value.delivery_hint.value(), 99);
    assert_eq!(value.payload_format.value(), 99);
}

#[test]
fn negative_timeout_is_not_changed_by_encoding() {
    let mut value = decode_envelope(&[]).unwrap();
    value.timeout_ms = -1;
    let bytes = encode_envelope(&value).unwrap();
    assert_eq!(decode_envelope(&bytes).unwrap().timeout_ms, -1);
}

#[test]
fn empty_map_key_is_a_real_value() {
    let value = decode_envelope(&[82, 3, 18, 1, b'v']).unwrap();
    assert_eq!(value.headers.get("").map(String::as_str), Some("v"));
}

#[test]
fn tenth_varint_byte_cannot_overflow_u64() {
    let mut bytes = vec![64];
    bytes.extend_from_slice(&[128; 9]);
    bytes.push(2);
    assert!(decode_envelope(&bytes).is_err());
}

#[test]
fn field_zero_is_not_a_valid_tag() {
    assert!(decode_envelope(&[0, 0]).is_err());
}

#[test]
fn unknown_fixed_fields_can_be_skipped() {
    let bytes = [
        161, 1, 0, 0, 0, 0, 0, 0, 0, 0, 173, 1, 0, 0, 0, 0, 10, 1, b'x',
    ];
    assert_eq!(decode_envelope(&bytes).unwrap().message_id, "x");
}

#[test]
fn security_deadletter_reason_is_not_unspecified() {
    let value = decode_deadletter(&[10, 0, 16, 15]).unwrap();
    assert_eq!(
        value.reason,
        "DEADLETTER_REASON_REMOTE_TRANSPORT_SECURITY_FAILED"
    );
}

#[test]
fn scalar_golden_vectors_and_unknown_signed_enums_round_trip() {
    for number in [i32::MIN, -1, 0, 1, 2, 3, 4, 6, 99, i32::MAX] {
        let mut value = decode_envelope(&[]).unwrap();
        value.timeout_ms = number;
        value.kind = MessageKind::from_value(number);
        value.status = BusinessStatus::from_value(number);
        value.delivery_hint = DeliveryHint::from_value(number);
        value.payload_format = PayloadFormat::from_value(number);
        value.payload_schema_version = u32::MAX;
        let result = decode_envelope(&encode_envelope(&value).unwrap()).unwrap();
        assert_eq!(result.timeout_ms, number);
        assert_eq!(result.kind.value(), number);
        assert_eq!(result.status.value(), number);
        assert_eq!(result.delivery_hint.value(), number);
        assert_eq!(result.payload_format.value(), number);
        assert_eq!(result.payload_schema_version, u32::MAX);
    }
    let negative_one = [64, 255, 255, 255, 255, 255, 255, 255, 255, 255, 1];
    assert_eq!(decode_envelope(&negative_one).unwrap().timeout_ms, -1);
    let mut writer = Writer::new();
    writer.number(8, -1i64 as u64).unwrap();
    assert_eq!(writer.bytes, negative_one);
    assert!(decode_envelope(&[56, 2]).unwrap().one_way);
}

#[test]
fn deadletter_projects_all_core_facts_and_merges_original_messages() {
    let bytes = [
        10, 3, 10, 1, b'a', 10, 3, 34, 1, b'b', 16, 99, 26, 1, b'd', 32, 17, 42, 1, b'h', 48, 80,
        56, 3, 66, 6, 10, 1, b'k', 18, 1, b'v',
    ];
    let value = decode_deadletter(&bytes).unwrap();
    assert_eq!(value.original.message_id, "a");
    assert_eq!(value.original.target, "b");
    assert_eq!(value.reason_code, 99);
    assert_eq!(value.reason, "DEADLETTER_REASON_UNKNOWN");
    assert_eq!(value.detail, "d");
    assert_eq!(value.active_generation, 17);
    assert_eq!(value.resolved_host, "h");
    assert_eq!(value.resolved_port, 80);
    assert_eq!(value.endpoint_attempt_count, 3);
    assert_eq!(value.transport_failure_metadata.get("k").unwrap(), "v");
    for reason in 0..=15 {
        let value = decode_deadletter(&[10, 0, 16, reason]).unwrap();
        assert_eq!(value.reason_code, i32::from(reason));
        assert_ne!(value.reason, "DEADLETTER_REASON_UNKNOWN");
    }
    assert_eq!(reason_name(7), "DEADLETTER_REASON_REMOTE_TRANSPORT_FAILED");
    assert!(decode_deadletter(&[16, 2]).is_err());
}

#[test]
fn maps_keep_empty_entries_duplicates_unicode_and_embedded_nul() {
    let mut value = decode_envelope(&[]).unwrap();
    value.headers.insert(String::new(), String::new());
    value.headers.insert("có dấu 测试\0".into(), "v\0".into());
    value.message_id = "x\0y".into();
    value.payload = vec![0, 255];
    let result = decode_envelope(&encode_envelope(&value).unwrap()).unwrap();
    assert_eq!(result.headers, value.headers);
    assert_eq!(result.message_id, value.message_id);
    assert_eq!(result.payload, value.payload);
    let duplicate = [82, 3, 18, 1, b'a', 82, 3, 18, 1, b'b'];
    let result = decode_envelope(&duplicate).unwrap();
    assert_eq!(result.headers.len(), 1);
    assert_eq!(result.headers.get("").unwrap(), "b");
}

#[test]
fn invalid_spans_tags_types_and_utf8_fail_closed() {
    let invalid: &[&[u8]] = &[
        &[10],
        &[10, 2, b'a'],
        &[10, 1, 255],
        &[10, 2, 192, 128],
        &[8, 0],
        &[48, 128],
        &[0],
        &[163, 1],
        &[164, 1],
        &[166, 1],
        &[167, 1],
        &[161, 1, 0],
        &[173, 1, 0],
        &[162, 1, 5, 0],
        &[128, 128, 128, 128, 16, 0], // field 2^29, outside the wire range
        &[82, 2, 10, 255],
        &[10, 255, 255, 255, 255, 255, 255, 255, 255, 255, 1],
    ];
    for bytes in invalid {
        assert!(decode_envelope(bytes).is_err(), "{bytes:?}");
    }
    for tenth in 0..=255u8 {
        let mut bytes = vec![128; 9];
        bytes.push(tenth);
        let result = Reader::new(&bytes).unwrap().varint();
        assert_eq!(result.is_ok(), tenth <= 1, "tenth={tenth}");
    }
    let mut writer = Writer::new();
    writer.number(0x1fff_ffff, u64::MAX).unwrap();
    writer.bytes(20, &[255; 40]).unwrap(); // unknown bytes need not be UTF-8
    writer.string(1, "last").unwrap();
    assert_eq!(decode_envelope(&writer.bytes).unwrap().message_id, "last");
}

#[test]
fn encode_and_decode_enforce_the_host_budget_before_copying() {
    let oversized = vec![0; MAXIMUM_CLIENT_FRAME_BYTES + 1];
    assert!(Reader::new(&oversized).is_err());
    assert!(Reader::new(&oversized[..MAXIMUM_CLIENT_FRAME_BYTES]).is_ok());
    assert!(decode_deadletter(&oversized).is_err());
    let mut value = decode_envelope(&[]).unwrap();
    value.payload = oversized;
    assert!(encode_envelope(&value).is_err());
    let mut writer = Writer {
        bytes: Vec::new(),
        limit: 7,
    };
    for _ in 0..7 {
        writer.append(&[1]).unwrap();
    }
    assert_eq!(writer.bytes.capacity(), 7);
    assert!(writer.append(&[2]).is_err());
    assert_eq!(writer.bytes, [1; 7]);
    // Both tag/length overhead and nested message presence count in the budget.
    let mut writer = Writer {
        bytes: Vec::new(),
        limit: 2,
    };
    writer.bytes(1, &[]).unwrap();
    assert_eq!(writer.bytes, [10, 0]);
    assert!(writer.number(1, 0).is_err());
}

#[test]
fn bounded_deterministic_mutation_corpus() {
    // Reproducible mutation, not coverage-guided fuzzing. Fixed seed/count and
    // <=2048-byte inputs bound work and permit exact replay on every host.
    let seeds: &[&[u8]] = &[
        &[],
        &[10, 1, b'x', 48, 1, 64, 127],
        &[82, 0],
        &[10, 0, 16, 15, 56, 3, 66, 3, 18, 1, b'v'],
        &[161, 1, 0, 0, 0, 0, 0, 0, 0, 0, 173, 1, 0, 0, 0, 0],
        &[64, 255, 255, 255, 255, 255, 255, 255, 255, 255, 1],
    ];
    let mut random = 0x0418_2026_1024_u64;
    let mut next = || {
        random ^= random << 13;
        random ^= random >> 7;
        random ^= random << 17;
        random
    };
    let mut accepted = 0;
    let mut rejected = 0;
    for case in 0..100_000 {
        let mut bytes = seeds[case % seeds.len()].to_vec();
        for _ in 0..1 + next() % 16 {
            let offset = next() as usize % (bytes.len() + 1);
            match next() % 4 {
                0 if offset < bytes.len() => {
                    bytes[offset] ^= next() as u8;
                }
                1 => bytes.truncate(offset),
                2 if bytes.len() < 2048 => bytes.insert(offset, next() as u8),
                _ => {
                    if bytes.len() < 2048 {
                        bytes.extend_from_slice(seeds[next() as usize % seeds.len()]);
                    }
                }
            }
        }
        assert!(bytes.len() <= 2048);
        match decode_envelope(&bytes) {
            Ok(value) => {
                accepted += 1;
                let round = decode_envelope(&encode_envelope(&value).unwrap()).unwrap();
                assert_eq!(round, value, "case={case}");
            }
            Err(_) => rejected += 1,
        }
        let _ = decode_deadletter(&bytes);
    }
    assert!(accepted > 1000 && rejected > 1000);
    eprintln!(
        "wire mutation: seed=0x41820261024 inputs=100000 accepted={accepted} rejected={rejected}"
    );
}
