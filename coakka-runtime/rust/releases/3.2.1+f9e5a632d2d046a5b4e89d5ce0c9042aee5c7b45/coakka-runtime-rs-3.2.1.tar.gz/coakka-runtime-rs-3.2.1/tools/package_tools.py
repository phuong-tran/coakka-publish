#!/usr/bin/env python3
"""Bounded source-package integrity and build-time app resource placement.

Checksums establish exact-copy integrity, not publisher authentication. Only
use an archive digest obtained through the trusted candidate/release channel.
The installation owner must keep input/output directories stable during use.
No helper runs at application startup or probes runtime capabilities.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import tarfile
import tempfile

MAX_MEMBERS = 128
MAX_FILE = 8 * 1024 * 1024
MAX_TOTAL = 24 * 1024 * 1024
MAX_ARCHIVE = 16 * 1024 * 1024
MANIFEST = "package-manifest.json"
LEGAL = ("LICENSE", "NOTICE", "PACKAGE-LICENSE.md", "NATIVE-LICENSE.md")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    require(isinstance(name, str) and 0 < len(name) <= 240, "invalid member name")
    path = PurePosixPath(name)
    require(
        path.parts and not path.is_absolute() and str(path) == name,
        "noncanonical member name",
    )
    require(all(part not in (".", "..") for part in path.parts), "unsafe member path")
    require(
        all(ch.isascii() and (ch.isalnum() or ch in "._-/") for ch in name),
        "unsafe member spelling",
    )
    require(
        all(
            not part.endswith((".", " "))
            and part.split(".")[0].upper()
            not in {
                "CON",
                "PRN",
                "AUX",
                "NUL",
                *("COM" + str(i) for i in range(1, 10)),
                *("LPT" + str(i) for i in range(1, 10)),
            }
            for part in path.parts
        ),
        "reserved member name",
    )
    return path


def is_link(path):
    """Reject symlinks and Windows file/directory reparse points on Python3.11.

    is_symlink alone does not recognize a junction. Resource copying must not
    follow one merely because its current target contains valid bytes.
    """
    try:
        metadata = path.lstat()
    except FileNotFoundError:
        return False
    if stat.S_ISLNK(metadata.st_mode):
        return True
    if sys.platform == "win32":
        return bool(metadata.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT)
    return False


def read_file(root, name, maximum=MAX_FILE):
    safe_name(name)
    current = root
    for part in PurePosixPath(name).parts:
        current = current / part
        require(not is_link(current), "linked input refused")
    stat = current.stat()
    require(
        current.is_file() and 0 <= stat.st_size <= maximum, "invalid input type or size"
    )
    with current.open("rb") as source:
        data = source.read(maximum + 1)
    require(
        len(data) == stat.st_size and len(data) <= maximum,
        "input changed or exceeded bound",
    )
    return data


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate metadata key")
        result[key] = value
    return result


def decode_manifest(data):
    require(len(data) <= 256 * 1024, "manifest exceeds bound")
    value = json.loads(data, object_pairs_hook=unique_object)
    require(
        isinstance(value, dict) and value.get("schema") == 1,
        "unsupported package manifest",
    )
    members = value.get("files")
    require(
        isinstance(members, dict) and 0 < len(members) < MAX_MEMBERS,
        "invalid member count",
    )
    folded = set()
    for name, record in members.items():
        safe_name(name)
        require(
            name != MANIFEST and name.casefold() not in folded,
            "duplicate or recursive member",
        )
        folded.add(name.casefold())
        require(
            isinstance(record, dict) and set(record) == {"bytes", "sha256"},
            "invalid member record",
        )
        size, sha = record["bytes"], record["sha256"]
        require(type(size) is int and 0 <= size <= MAX_FILE, "invalid member size")
        require(
            isinstance(sha, str)
            and len(sha) == 64
            and all(c in "0123456789abcdef" for c in sha),
            "invalid member digest",
        )
    require(
        sum(r["bytes"] for r in members.values()) <= MAX_TOTAL, "package exceeds bound"
    )
    require(value.get("host") in ("rust", "tauri"), "invalid package host")
    require(value.get("publication") is False, "candidate promotion is not authorized")
    return value


def validate_members(members):
    require(
        MANIFEST in members and len(members) <= MAX_MEMBERS, "package manifest missing"
    )
    manifest = decode_manifest(members[MANIFEST])
    require(
        set(members) == set(manifest["files"]) | {MANIFEST},
        "package tree differs from manifest",
    )
    for name, record in manifest["files"].items():
        data = members[name]
        require(
            len(data) == record["bytes"] and digest(data) == record["sha256"],
            "package member identity mismatch: " + name,
        )
    return manifest


def tree_members(root):
    require(
        root.is_dir() and not is_link(root), "package root must be a real directory"
    )
    members: dict[str, bytes] = {}
    total = 0
    entries = 0
    # Do not follow directory links or accept unexpected files, even if a caller
    # never intends to use that target's native image.
    for current, directories, files in os.walk(root, followlinks=False):
        entries += 1 + len(files)
        require(entries <= MAX_MEMBERS * 2, "package entry count exceeds bound")
        require(
            not any(is_link(Path(current) / name) for name in directories),
            "linked package directory",
        )
        for name in files:
            relative = (Path(current) / name).relative_to(root).as_posix()
            require(len(members) < MAX_MEMBERS, "too many package members")
            data = read_file(root, relative)
            total += len(data)
            require(total <= MAX_TOTAL, "package exceeds bound")
            members[relative] = data
    return members


def verify_tree(root):
    return validate_members(tree_members(root))


def unpack(archive, expected_digest, destination):
    require(
        archive.is_file() and not is_link(archive), "archive must be a regular file"
    )
    require(archive.stat().st_size <= MAX_ARCHIVE, "archive exceeds bound")
    with archive.open("rb") as source:
        data = source.read(MAX_ARCHIVE + 1)
    require(
        len(data) <= MAX_ARCHIVE and digest(data) == expected_digest,
        "archive identity mismatch",
    )
    # Read the already-admitted immutable byte snapshot, never extract paths
    # supplied directly by a tar header into the filesystem.
    import gzip
    import io

    expanded_limit = MAX_TOTAL + MAX_MEMBERS * 512 + 10240
    with gzip.GzipFile(fileobj=io.BytesIO(data), mode="rb") as compressed:
        expanded = compressed.read(expanded_limit + 1)
    require(len(expanded) <= expanded_limit, "archive expansion exceeds bound")
    members: dict[str, bytes] = {}
    total = 0
    prefix = None
    folded = set()
    with tarfile.open(fileobj=io.BytesIO(expanded), mode="r:") as package:
        for item in package:
            path = safe_name(item.name)
            require(
                item.isfile() and len(path.parts) >= 2 and not item.linkname,
                "non-file archive member",
            )
            require(
                0 <= item.size <= MAX_FILE and len(members) < MAX_MEMBERS,
                "archive member bound exceeded",
            )
            prefix = prefix or path.parts[0]
            require(path.parts[0] == prefix, "multiple archive roots")
            name = PurePosixPath(*path.parts[1:]).as_posix()
            require(name.casefold() not in folded, "duplicate archive member")
            folded.add(name.casefold())
            total += item.size
            require(total <= MAX_TOTAL, "archive exceeds expanded bound")
            stream = package.extractfile(item)
            if stream is None:
                raise ValueError("unreadable member")
            with stream:
                content = stream.read(item.size + 1)
            require(len(content) == item.size, "short archive member")
            members[name] = content
    manifest = validate_members(members)
    require(
        destination.is_absolute() and destination.parent.is_dir(),
        "explicit existing destination parent required",
    )
    require(not is_link(destination.parent), "linked destination parent")
    destination.mkdir()  # Exclusive reservation: never merge/overwrite a tree.
    try:
        for name, content in members.items():
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as output:
                require(output.write(content) == len(content), "short package write")
        verify_tree(destination)
    except BaseException:
        shutil.rmtree(destination)
        raise
    return manifest


def deploy(package_root, executable, target):
    members = tree_members(package_root)
    manifest = validate_members(members)
    require(manifest["host"] == "rust", "select the Rust crate package root")
    native = json.loads(
        members["native-manifest.json"], object_pairs_hook=unique_object
    )
    safe_name(target)
    require("/" not in target, "invalid target name")
    require(target in native["targets"], "target is not bundled")
    entry = native["targets"][target]
    name = entry["file"]
    safe_name(name)
    require("/" not in name, "invalid native filename")
    selected = members["native/" + target + "/" + name]
    require(
        len(selected) == entry["bytes"] and digest(selected) == entry["sha256"],
        "native resource identity mismatch",
    )
    require(
        executable.is_file() and not is_link(executable),
        "executable must be an existing regular file",
    )
    app = executable.resolve(strict=True).parent
    require(
        not app.is_relative_to(package_root.resolve(strict=True)),
        "do not stage into the source package",
    )
    parent = app / "native"
    require(not is_link(parent), "linked resource directory")
    created_parent = not parent.exists()
    parent.mkdir(exist_ok=True)
    destination = parent / target
    # The application must be stopped while its package layout is assembled.
    # Only this newly reserved target directory belongs to the transaction.
    try:
        destination.mkdir()
    except BaseException:
        if created_parent:
            parent.rmdir()
        raise
    try:
        with tempfile.TemporaryDirectory(prefix=".coakka-", dir=parent) as staging:
            stage = Path(staging)
            app_manifest = {**native, "targets": {target: entry}}
            payload = {
                name: selected,
                **{legal: members[legal] for legal in LEGAL},
                "native-manifest.json": (
                    json.dumps(app_manifest, indent=2, sort_keys=True) + "\n"
                ).encode(),
            }
            for filename, content in payload.items():
                with (stage / filename).open("xb") as output:
                    require(
                        output.write(content) == len(content), "short resource write"
                    )
                    output.flush()
                    os.fsync(output.fileno())
                os.rename(stage / filename, destination / filename)
        require(
            digest(read_file(destination, name)) == entry["sha256"],
            "staged resource mismatch",
        )
    except BaseException:
        shutil.rmtree(destination)
        if created_parent:
            parent.rmdir()
        raise
    return destination / name


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    check = commands.add_parser("verify")
    check.add_argument("package", type=Path)
    extract = commands.add_parser("unpack")
    extract.add_argument("archive", type=Path)
    extract.add_argument("sha256")
    extract.add_argument("destination", type=Path)
    install = commands.add_parser("deploy")
    install.add_argument("package", type=Path)
    install.add_argument("executable", type=Path)
    install.add_argument("target")
    args = parser.parse_args()
    try:
        if args.command == "verify":
            verify_tree(args.package)
        elif args.command == "unpack":
            unpack(args.archive, args.sha256, args.destination)
        else:
            print(deploy(args.package, args.executable, args.target))
    except (
        OSError,
        ValueError,
        KeyError,
        TypeError,
        RecursionError,
        tarfile.TarError,
    ) as error:
        parser.exit(1, "package refused: " + str(error) + "\n")


if __name__ == "__main__":
    main()
