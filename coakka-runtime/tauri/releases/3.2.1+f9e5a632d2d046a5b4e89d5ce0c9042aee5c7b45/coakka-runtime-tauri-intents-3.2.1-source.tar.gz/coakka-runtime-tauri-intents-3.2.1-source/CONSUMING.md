# Consuming CoAkka Tauri Intents

The 3.2.1 source archive contains the `rust/` and `tauri-intents/` crates.
Both declare Rust 1.77.2 as their minimum. The command and Tauri 2.11.5
WebView checks ran on macOS ARM64. A full Tauri application selects its own
compiler and platform requirements.

Verify the archive's SHA-256 against the distribution checksum. The root
manifest checks the aggregate and the nested Rust manifest checks its
package. The native manifest records the exact five Core 3.2 ABI 1 images.

Use a path dependency on the adapter:

```toml
[dependencies]
coakka-tauri-intents = { path = "../coakka-runtime-tauri-intents-3.2.1-source/tauri-intents" }
```

Run from the extracted archive root and keep build output outside it.
The command example exercises the intent API from the terminal:

```sh
export CARGO_TARGET_DIR="/absolute/fresh-build-directory"
cargo build --manifest-path tauri-intents/Cargo.toml --example intent_command --release --locked
```

Apply the release profile, path remapping and Windows static-CRT recipe in
the Rust consumer guide (`rust/CONSUMING.md` at the archive root). Before running the built example, use the
nested verified resource helper:

```sh
app="$CARGO_TARGET_DIR/release/examples/intent_command"
python3 rust/tools/package_tools.py deploy rust "$app" macos-aarch64
"$app"
```

Select the actual compiler target (`linux-aarch64` or `windows-x86_64` on those
hosts). No Core dependency installation is required on the consumer's machine.
Move the executable and its installed resources together. Resource copying is
a build/deployment operation; it does not run in the request path.

A real Tauri app owns its bundle resource layout. Resolve the image from that
application resource directory, construct
`RuntimeHost::start_with_runtime_lib(spec, exact_resource_path)`, then pass it
to `RuntimeIntentDispatcher::new(host)`. Do not search development directories,
guess OS support or fall back after an invalid selection. Keep native handles,
file paths and bearer grants out of the WebView.

The command-level call remains small, but must not block a Tauri UI thread:

```rust
fn coakka_ask_intent(
    intent: coakka_tauri_intents::IntentEnvelope,
    state: &coakka_tauri_intents::RuntimeIntentDispatcher,
) -> Result<coakka_tauri_intents::IntentResult, coakka_tauri_intents::IntentError> {
    coakka_tauri_intents::coakka_ask_intent_command(state, intent)
}
```

A GUI host adds explicit command authorization, bounded admission and a
blocking-executor wrapper, then joins accepted work before retiring its final
dispatcher. This archive does not supply or qualify that application policy.
Handle `IntentError.cause`/JSON `cause.kind`, not `message` substrings. Core
status and structured refusal facts remain exact; 64-bit error fields are
decimal strings to preserve JavaScript precision. The owning README defines
the error projection and its typed causes.

The command fixture is not an installer, WebView, Gatekeeper or Authenticode
qualification. App signing, target framework requirements, permission policy
and final GUI E2E remain separate release controls. Never bypass an OS trust
prompt. The adapter projects Core-issued runtime facts; AUTO/multiplex defaults
and the owned response engine are not inferred from the OS.

See [README](README.md) for intent policy and the deliberately reserved
app-host metadata field, and the Rust guide for callback/shutdown limitations.
