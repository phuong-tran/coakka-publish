# CoAkka Tauri Intents

<p align="center">
  <img src="https://raw.githubusercontent.com/phuong-tran/coakka-samples/main/docs/common/assets/brand/coakka-logo.png" alt="CoAkka" width="480">
</p>

The **Tauri Intents 3.2.1 source package** bundles Runtime Core 3.2, ABI 1,
build `f9e5a632d2d046a5b4e89d5ce0c9042aee5c7b45`. It provides a Rust intent
adapter for Tauri 2 applications. The adapter declares Rust 1.77.2 as its crate
minimum. The macOS ARM64 command smoke used Rust 1.95.0. A full app selects
its own Tauri dependencies and compiler.

Tauri is one integration lane in the wider multi-language, multi-platform
[CoAkka ecosystem](https://github.com/phuong-tran/coakka-samples/tree/main/docs).

The boundary is intentionally strict:

- WebView JavaScript sends intent envelopes.
- Rust validates and executes intents.
- Rust converts intents into CoAkka runtime envelopes when runtime delivery is
  the right execution path.
- JavaScript receives a projected result and renders it.

This crate has no Tauri dependency. Its command-level function is synchronous:

```rust
fn coakka_ask_intent(
    intent: coakka_tauri_intents::IntentEnvelope,
    state: &coakka_tauri_intents::RuntimeIntentDispatcher,
) -> Result<coakka_tauri_intents::IntentResult, coakka_tauri_intents::IntentError> {
    coakka_tauri_intents::coakka_ask_intent_command(state, intent)
}
```

This is not a UI-thread command recipe. A real application authorizes the
invoking window/frame, admits a bounded number of operations, and runs blocking
asks on its blocking executor. It seals admission and joins accepted operations
before dropping the final dispatcher. Dropping a window or task handle does not
cancel a running Core request. GUI scheduling, permissions and lifecycle require
their own application-level verification.

Rust app code can register JSON handlers through `RuntimeIntentDispatcher`
without exposing runtime transport envelopes to WebView JavaScript.
The dispatcher is the Rust-side state owner; when the last dispatcher clone is
dropped, the underlying runtime host is dropped and stops the native runtime.
For the callback and shutdown restrictions, follow the Rust connector's owning
README. Core alone reports accepted startup, network and delivery settings.
Omitted execution/connection intent selects Core's AUTO and MULTIPLEXING;
the adapter does not probe the OS or infer native state.

An omitted intent timeout uses two seconds; an explicit positive value is
capped at 30 seconds. These are WebView admission policy, not inferred Core
defaults. Core owns the accepted monotonic deadline and terminal matching.

## Causal errors

`IntentError.cause` retains the original typed Rust error in
`IntentErrorCause::Runtime`; the standard Rust error chain exposes the same
cause. JSON uses a tagged `cause.kind`, never classification by message text.
Core status errors carry exact `operation` and numeric `status`; unknown status
values are preserved. Host, I/O, codec, handler panic and typed timeout outcomes
remain distinct and do not acquire a fabricated Core status. Intent validation,
JSON projection and application failures have their own kinds. Use
`IntentError::application` for an application handler's failure.

Deadletters carry Core's original target, numeric reason, generation, resolved
endpoint, attempt count and transport metadata. Connection/security refusal
includes Core's remaining active configuration, not the rejected input.
All signed/unsigned 64-bit fields in this JSON error projection are decimal
strings, including masks and generations; parse with `BigInt` when arithmetic
is needed. 32-bit codes remain numbers. Error projection does not echo the
original request body. Applications must still authorize access to diagnostic
details and non-secret configuration. `message` is diagnostic text only.

The error projection returns owned diagnostic and causal data to the caller.

`IntentEnvelope.headers` is reserved app-host metadata in this first slice. It
is validated before the runtime boundary, but it is not forwarded into the
runtime request envelope until the Rust connector opens a header-aware ask
surface. JavaScript code should treat headers as intent metadata, not transport
metadata.

## Package and execution scope

The archive carries `rust/` and `tauri-intents/` with their locked
dependencies. Five bundled Core images cover the payload inventory.
The executed command sample and Tauri 2.11.5 WebView checks cover macOS
ARM64. They include trusted and untrusted window IPC and closing the
window with eight accepted requests in flight. Linux and Windows desktop
execution and installer qualification are outside that evidence.
Publisher signing is absent.

See [Consuming](CONSUMING.md) for checksum verification, the command example
and resource placement. Use the distribution archive as a Cargo path dependency.

## File Lane Boundary

The WebView intent API intentionally does not expose file paths, transfer
tokens, or native file-lane methods. Trusted Rust host state may use the Rust
connector directly under the shared [file-lane contract](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/guides/runtime-file-transfer.md).

## Stream Lane Boundary

Do not infer that the Tauri WebView intent package exposes Stream Lane. The
source aggregate gives the trusted Rust host the owner-aware
Rust File and Stream Lane APIs, including `open_owned`, `prepare_*_grant`, and
`from_control_plane`. WebView JavaScript still receives no path, callback, or
bearer grant. Follow the [owner-grant contract](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/reference/runtime-lane-owner-grants.md).

## AI-Assisted Integration

Before generating Tauri integration code, read the public
[AI-assisted integration guide](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/guides/ai-assisted-integration.md)
and the runnable Tauri sample. WebView JavaScript remains intent-only; the Rust
app host owns any runtime, File Lane, or Stream Lane work.

## License

**Free for application use, including commercial and production use.**

The Tauri intent adapter source uses the
[Apache License, Version 2.0](https://github.com/phuong-tran/coakka-samples/blob/main/LICENSE).
The aggregate source archive also contains the Rust runtime connector and
bundled Native Core files. Those native files use the
[CoAkka Native Artifact License 1.2](https://github.com/phuong-tran/coakka-samples/blob/main/NATIVE-LICENSE.md).
Those native terms permit ordinary application and SaaS use but require a
separate agreement to sell or offer CoAkka itself as managed runtime or
infrastructure. See
[CoAkka Package Licensing](https://github.com/phuong-tran/coakka-samples/blob/main/docs/common/package-licensing.md)
for the file-scope map. The aggregate archive carries offline `LICENSE`,
`NATIVE-LICENSE.md`, `PACKAGE-LICENSE.md`, and `NOTICE` copies, and the nested
source adapter carries its Apache-2.0 `LICENSE` copy.
