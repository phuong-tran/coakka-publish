use coakka_runtime::{ConnectorStartSpec, RouteSpec, TcpConnectionMode};
use coakka_tauri_intents::{
    coakka_ask_intent_command, IntentEnvelope, IntentPayloadIdentity, RuntimeIntentDispatcher,
};
use serde_json::json;
use std::collections::HashMap;

fn main() {
    let target = "installed.intent.echo";
    let mut spec = ConnectorStartSpec::new("installed-intent", "installed-intent-node");
    spec.routes = vec![RouteSpec::single_local(target, "127.0.0.1", 19411)];
    let dispatcher = RuntimeIntentDispatcher::start(spec).expect("start installed dispatcher");
    let info = dispatcher.runtime_info().unwrap();
    assert_eq!(info.abi_version, 1);
    assert_eq!(info.git_commit, "f9e5a632d2d046a5b4e89d5ce0c9042aee5c7b45");
    let startup = dispatcher.runtime_startup_config().unwrap();
    assert_eq!(startup.execution.requested_policy, 0);
    assert_eq!(startup.connection.mode, TcpConnectionMode::MULTIPLEXING);
    assert_eq!(startup.connection.explicitly_configured_fields, 0);
    let delivery = dispatcher.runtime_delivery_config().unwrap();
    assert!(delivery.compiled);
    assert_eq!((delivery.request_mode, delivery.response_mode), (2, 2));
    assert_eq!(
        (
            delivery.remote_batch_max_calls,
            delivery.slot_capacity,
            delivery.byte_capacity
        ),
        (8, 16, 4 * 1024 * 1024)
    );
    dispatcher
        .register_json_handler(target, |request| {
            Ok(json!({"operation": request.operation, "echo": request.payload}))
        })
        .unwrap();
    let result = coakka_ask_intent_command(
        &dispatcher,
        IntentEnvelope {
            intent_id: "installed-1".into(),
            source: "installed-ui".into(),
            target: target.into(),
            operation: "echo".into(),
            payload: json!({"message":"installed-Unicode"}),
            payload_identity: IntentPayloadIdentity::json("installed.echo.v1", 1),
            timeout_ms: Some(2_000),
            headers: HashMap::new(),
        },
    )
    .unwrap();
    assert_eq!(result.intent_id, "installed-1");
    assert_eq!(result.payload["operation"], "echo");
    assert_eq!(result.payload["echo"]["message"], "installed-Unicode");
    assert_eq!(result.runtime.message_type, "installed.echo.v1");
    println!(
        "CoAkka installed intent ok Core={} ABI={} AUTO=0 MULTIPLEX=3 owned=2/2",
        info.git_commit, info.abi_version
    );
}
