//! Owned causal errors; only their borrowed JSON view crosses the WebView boundary.
use coakka_runtime::{
    CoAkkaError, RuntimeDeadletter, TcpConnectionApplyResult, TcpConnectionConfigSnapshot,
    TcpConnectionValidation, TcpSecurityApplyResult, TcpSecurityInfoSnapshot,
};
use serde::{ser::SerializeStruct, Serialize, Serializer};
use std::fmt;

#[cfg(test)]
#[path = "error_tests.rs"]
mod tests;

/// A failed intent. `message` is diagnostic text, never a machine-readable cause.
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct IntentError {
    pub code: String,
    pub message: String,
    pub target: Option<String>,
    pub cause: IntentErrorCause,
}

/// The original Rust failure remains available without string parsing or copying
/// its structured state. JSON uses a tagged view, with decimal strings for u64/i64.
#[derive(Debug)]
pub enum IntentErrorCause {
    InvalidIntent,
    Application,
    Json,
    Runtime(Box<CoAkkaError>),
}

impl fmt::Display for IntentError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(&self.message)
    }
}

impl std::error::Error for IntentError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match &self.cause {
            IntentErrorCause::Runtime(error) => Some(error.as_ref()),
            _ => None,
        }
    }
}

impl IntentError {
    pub fn invalid_intent(message: impl Into<String>) -> Self {
        Self {
            code: "INVALID_INTENT".into(),
            message: message.into(),
            target: None,
            cause: IntentErrorCause::InvalidIntent,
        }
    }

    /// An application failure is not a Core rejection or inferred runtime state.
    pub fn application(message: impl Into<String>, target: Option<String>) -> Self {
        Self {
            code: "APPLICATION_ERROR".into(),
            message: message.into(),
            target,
            cause: IntentErrorCause::Application,
        }
    }

    pub(crate) fn json(message: impl Into<String>, target: Option<String>) -> Self {
        Self {
            code: "JSON_ERROR".into(),
            message: message.into(),
            target,
            cause: IntentErrorCause::Json,
        }
    }

    pub(crate) fn from_runtime(error: CoAkkaError, target: Option<String>) -> Self {
        let (code, message, target) = match &error {
            CoAkkaError::Deadletter(value) => (
                value.reason.clone(),
                value.detail.clone(),
                Some(value.original.target.clone()),
            ),
            _ => (
                match &error {
                    CoAkkaError::InvalidArgument(_) => "INVALID_ARGUMENT",
                    CoAkkaError::Core { .. } => "CORE_ERROR",
                    CoAkkaError::Native(_) => "HOST_ERROR",
                    CoAkkaError::Io(_) => "IO_ERROR",
                    CoAkkaError::WireCodec(_) => "CODEC_ERROR",
                    CoAkkaError::HandlerPanic => "HANDLER_PANIC",
                    CoAkkaError::Timeout(_) => "TIMEOUT",
                    CoAkkaError::TcpConnectionApply(_) => "CONNECTION_APPLY_ERROR",
                    CoAkkaError::TcpConnectionValidation(_) => "CONNECTION_VALIDATION_ERROR",
                    CoAkkaError::TcpSecurityApply(_) => "SECURITY_APPLY_ERROR",
                    CoAkkaError::Deadletter(_) => unreachable!("handled above"),
                }
                .into(),
                error.to_string(),
                target,
            ),
        };
        Self {
            code,
            message,
            target,
            cause: IntentErrorCause::Runtime(Box::new(error)),
        }
    }
}

// Serialization is a value projection, not a second error classifier. Matching
// the enum exhaustively forces new Rust outcomes to receive an explicit view.
#[derive(Serialize)]
#[serde(tag = "kind", rename_all = "camelCase")]
enum CauseView<'a> {
    InvalidIntent,
    Application,
    Json,
    InvalidArgument,
    Core {
        operation: &'a str,
        status: i32,
    },
    Host,
    Io,
    Codec,
    HandlerPanic,
    Timeout,
    Deadletter {
        result: View<'a, RuntimeDeadletter>,
    },
    ConnectionApply {
        result: View<'a, TcpConnectionApplyResult>,
    },
    ConnectionValidation {
        result: View<'a, TcpConnectionValidation>,
    },
    SecurityApply {
        result: View<'a, TcpSecurityApplyResult>,
    },
}

impl Serialize for IntentErrorCause {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let view = match self {
            Self::InvalidIntent => CauseView::InvalidIntent,
            Self::Application => CauseView::Application,
            Self::Json => CauseView::Json,
            Self::Runtime(error) => match error.as_ref() {
                CoAkkaError::InvalidArgument(_) => CauseView::InvalidArgument,
                CoAkkaError::Core { operation, status } => CauseView::Core {
                    operation,
                    status: status.0,
                },
                CoAkkaError::Native(_) => CauseView::Host,
                CoAkkaError::Io(_) => CauseView::Io,
                CoAkkaError::WireCodec(_) => CauseView::Codec,
                CoAkkaError::HandlerPanic => CauseView::HandlerPanic,
                CoAkkaError::Timeout(_) => CauseView::Timeout,
                CoAkkaError::Deadletter(value) => CauseView::Deadletter {
                    result: View(value),
                },
                CoAkkaError::TcpConnectionApply(value) => CauseView::ConnectionApply {
                    result: View(value),
                },
                CoAkkaError::TcpConnectionValidation(value) => CauseView::ConnectionValidation {
                    result: View(value),
                },
                CoAkkaError::TcpSecurityApply(value) => CauseView::SecurityApply {
                    result: View(value),
                },
            },
        };
        view.serialize(serializer)
    }
}

struct View<'a, T>(&'a T);
struct Decimal<T>(T);
impl<T: fmt::Display> Serialize for Decimal<T> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        serializer.collect_str(&self.0)
    }
}

impl Serialize for View<'_, RuntimeDeadletter> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let RuntimeDeadletter {
            original: _,
            reason,
            reason_code,
            detail: _,
            active_generation,
            resolved_host,
            resolved_port,
            endpoint_attempt_count,
            transport_failure_metadata,
        } = self.0;
        // The outer error already carries reason/detail/target. Do not echo an
        // entire possibly sensitive request payload into an IPC error response.
        let mut value = serializer.serialize_struct("Deadletter", 7)?;
        value.serialize_field("reason", reason)?;
        value.serialize_field("reasonCode", reason_code)?;
        value.serialize_field("activeGeneration", &Decimal(active_generation))?;
        value.serialize_field("resolvedHost", resolved_host)?;
        value.serialize_field("resolvedPort", resolved_port)?;
        value.serialize_field("endpointAttemptCount", endpoint_attempt_count)?;
        value.serialize_field("transportFailureMetadata", transport_failure_metadata)?;
        value.end()
    }
}

impl Serialize for View<'_, TcpConnectionValidation> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let TcpConnectionValidation {
            status,
            code,
            field,
            minimum_value,
            maximum_value,
        } = self.0;
        let mut value = serializer.serialize_struct("ConnectionValidation", 5)?;
        value.serialize_field("status", &status.0)?;
        value.serialize_field("code", &code.0)?;
        value.serialize_field("field", &Decimal(field))?;
        value.serialize_field("minimumValue", &Decimal(minimum_value))?;
        value.serialize_field("maximumValue", &Decimal(maximum_value))?;
        value.end()
    }
}

impl Serialize for View<'_, TcpConnectionApplyResult> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let TcpConnectionApplyResult {
            status,
            changed,
            reason,
            reason_name,
            runtime_state,
            validation_code,
            validation_field,
            minimum_value,
            maximum_value,
            active_config,
        } = self.0;
        let mut value = serializer.serialize_struct("ConnectionApply", 10)?;
        value.serialize_field("status", &status.0)?;
        value.serialize_field("changed", changed)?;
        value.serialize_field("reason", &reason.0)?;
        value.serialize_field("reasonName", reason_name)?;
        value.serialize_field("runtimeState", runtime_state)?;
        value.serialize_field("validationCode", &validation_code.0)?;
        value.serialize_field("validationField", &Decimal(validation_field))?;
        value.serialize_field("minimumValue", &Decimal(minimum_value))?;
        value.serialize_field("maximumValue", &Decimal(maximum_value))?;
        value.serialize_field("activeConfig", &View(active_config))?;
        value.end()
    }
}

impl Serialize for View<'_, TcpConnectionConfigSnapshot> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let TcpConnectionConfigSnapshot {
            defaults_revision,
            mode,
            applicable_fields,
            explicitly_configured_fields,
            defaulted_fields,
            configurable_fields,
            max_connections,
            max_requests_per_connection,
            idle_timeout_ms,
        } = self.0;
        let mut value = serializer.serialize_struct("ConnectionConfig", 9)?;
        value.serialize_field("defaultsRevision", defaults_revision)?;
        value.serialize_field("mode", &mode.0)?;
        value.serialize_field("applicableFields", &Decimal(applicable_fields))?;
        value.serialize_field(
            "explicitlyConfiguredFields",
            &Decimal(explicitly_configured_fields),
        )?;
        value.serialize_field("defaultedFields", &Decimal(defaulted_fields))?;
        value.serialize_field("configurableFields", &Decimal(configurable_fields))?;
        value.serialize_field("maxConnections", max_connections)?;
        value.serialize_field(
            "maxRequestsPerConnection",
            &Decimal(max_requests_per_connection),
        )?;
        value.serialize_field("idleTimeoutMs", &Decimal(idle_timeout_ms))?;
        value.end()
    }
}

impl Serialize for View<'_, TcpSecurityApplyResult> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let TcpSecurityApplyResult {
            status,
            changed,
            reason,
            reason_name,
            runtime_state,
            validation_code,
            validation_field,
            active_security,
        } = self.0;
        let mut value = serializer.serialize_struct("SecurityApply", 8)?;
        value.serialize_field("status", &status.0)?;
        value.serialize_field("changed", changed)?;
        value.serialize_field("reason", &reason.0)?;
        value.serialize_field("reasonName", reason_name)?;
        value.serialize_field("runtimeState", runtime_state)?;
        value.serialize_field("validationCode", &validation_code.0)?;
        value.serialize_field("validationField", &Decimal(validation_field))?;
        value.serialize_field("activeSecurity", &View(active_security))?;
        value.end()
    }
}

impl Serialize for View<'_, TcpSecurityInfoSnapshot> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let TcpSecurityInfoSnapshot {
            mode,
            credential_source_kind,
            reload_mode,
            reload_status,
            credential_generation,
            credential_id,
            minimum_protocol_version,
            maximum_protocol_version,
            inbound_verification_flags,
            outbound_verification_flags,
            identity_not_before_unix_seconds,
            identity_not_after_unix_seconds,
            identity_fingerprint_sha256,
        } = self.0;
        let mut value = serializer.serialize_struct("SecurityInfo", 13)?;
        value.serialize_field("mode", &mode.0)?;
        value.serialize_field("credentialSourceKind", credential_source_kind)?;
        value.serialize_field("reloadMode", &reload_mode.0)?;
        value.serialize_field("reloadStatus", reload_status)?;
        value.serialize_field("credentialGeneration", &Decimal(credential_generation))?;
        value.serialize_field("credentialId", credential_id)?;
        value.serialize_field("minimumProtocolVersion", minimum_protocol_version)?;
        value.serialize_field("maximumProtocolVersion", maximum_protocol_version)?;
        value.serialize_field(
            "inboundVerificationFlags",
            &Decimal(inbound_verification_flags),
        )?;
        value.serialize_field(
            "outboundVerificationFlags",
            &Decimal(outbound_verification_flags),
        )?;
        value.serialize_field(
            "identityNotBeforeUnixSeconds",
            &Decimal(identity_not_before_unix_seconds),
        )?;
        value.serialize_field(
            "identityNotAfterUnixSeconds",
            &Decimal(identity_not_after_unix_seconds),
        )?;
        value.serialize_field("identityFingerprintSha256", identity_fingerprint_sha256)?;
        value.end()
    }
}
