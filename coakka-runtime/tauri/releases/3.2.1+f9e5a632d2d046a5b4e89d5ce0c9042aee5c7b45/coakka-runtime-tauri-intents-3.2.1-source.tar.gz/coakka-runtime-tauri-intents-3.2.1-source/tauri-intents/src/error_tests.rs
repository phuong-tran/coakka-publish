//! Focused JSON value projection, including fields unavailable in ordinary failures.
use super::*;
use coakka_runtime::{
    CoAkkaStatus, TcpConnectionMode, TcpConnectionValidationCode, TcpSecurityMode,
    TcpSecurityValidationCode, TlsReloadMode, TransportApplyReason,
};
use serde_json::{json, Value};

fn project(error: CoAkkaError) -> Value {
    serde_json::to_value(IntentError::from_runtime(error, None)).unwrap()
}

#[test]
fn causal_host_errors_never_acquire_core_status_from_misleading_text() {
    for (error, kind) in [
        (
            CoAkkaError::InvalidArgument("status -7 closed".into()),
            "invalidArgument",
        ),
        (CoAkkaError::Native("status -7 closed".into()), "host"),
        (CoAkkaError::Io("status -7 closed".into()), "io"),
        (CoAkkaError::WireCodec("status -7 closed".into()), "codec"),
        (CoAkkaError::HandlerPanic, "handlerPanic"),
        (CoAkkaError::Timeout("status -7 closed".into()), "timeout"),
    ] {
        assert_eq!(project(error)["cause"], json!({"kind":kind}));
    }
    for (error, kind) in [
        (IntentError::invalid_intent("timeout"), "invalidIntent"),
        (IntentError::application("timeout", None), "application"),
        (IntentError::json("timeout", None), "json"),
    ] {
        assert_eq!(
            serde_json::to_value(error).unwrap()["cause"],
            json!({"kind":kind})
        );
    }
}

#[test]
fn causal_connection_apply_preserves_all_active_state_and_unknown_numbers() {
    let result = TcpConnectionApplyResult {
        status: CoAkkaStatus(-1234),
        changed: false,
        reason: TransportApplyReason(u32::MAX),
        reason_name: "future-reason".into(),
        runtime_state: 12345,
        validation_code: TcpConnectionValidationCode(u32::MAX),
        validation_field: u64::MAX,
        minimum_value: 9007199254740993,
        maximum_value: u64::MAX,
        active_config: TcpConnectionConfigSnapshot {
            defaults_revision: 123,
            mode: TcpConnectionMode(u32::MAX),
            applicable_fields: u64::MAX,
            explicitly_configured_fields: 9007199254740993,
            defaulted_fields: 1u64 << 63,
            configurable_fields: 0,
            max_connections: u32::MAX,
            max_requests_per_connection: u64::MAX,
            idle_timeout_ms: u64::MAX,
        },
    };
    assert_eq!(
        project(CoAkkaError::TcpConnectionApply(Box::new(result)))["cause"],
        json!({
            "kind":"connectionApply", "result": {
                "status":-1234, "changed":false, "reason":u32::MAX, "reasonName":"future-reason",
                "runtimeState":12345, "validationCode":u32::MAX,
                "validationField":"18446744073709551615", "minimumValue":"9007199254740993",
                "maximumValue":"18446744073709551615", "activeConfig": {
                    "defaultsRevision":123, "mode":u32::MAX, "applicableFields":"18446744073709551615",
                    "explicitlyConfiguredFields":"9007199254740993", "defaultedFields":"9223372036854775808",
                    "configurableFields":"0", "maxConnections":u32::MAX,
                    "maxRequestsPerConnection":"18446744073709551615", "idleTimeoutMs":"18446744073709551615"
                }
            }
        })
    );
}

#[test]
fn causal_security_apply_preserves_nonsecret_state_and_signed_wide_times() {
    let result = TcpSecurityApplyResult {
        status: CoAkkaStatus(-9999),
        changed: false,
        reason: TransportApplyReason(12345),
        reason_name: "future-security".into(),
        runtime_state: 23456,
        validation_code: TcpSecurityValidationCode(34567),
        validation_field: u64::MAX,
        active_security: TcpSecurityInfoSnapshot {
            mode: TcpSecurityMode(u32::MAX),
            credential_source_kind: u32::MAX,
            reload_mode: TlsReloadMode(u32::MAX),
            reload_status: u32::MAX,
            credential_generation: u64::MAX,
            credential_id: "public-identity".into(),
            minimum_protocol_version: 123,
            maximum_protocol_version: 456,
            inbound_verification_flags: u64::MAX,
            outbound_verification_flags: 9007199254740993,
            identity_not_before_unix_seconds: i64::MIN,
            identity_not_after_unix_seconds: i64::MAX,
            identity_fingerprint_sha256: "ab".repeat(32),
        },
    };
    assert_eq!(
        project(CoAkkaError::TcpSecurityApply(Box::new(result)))["cause"],
        json!({
            "kind":"securityApply", "result": {
                "status":-9999, "changed":false, "reason":12345, "reasonName":"future-security",
                "runtimeState":23456, "validationCode":34567, "validationField":"18446744073709551615",
                "activeSecurity": {
                    "mode":u32::MAX, "credentialSourceKind":u32::MAX, "reloadMode":u32::MAX,
                    "reloadStatus":u32::MAX, "credentialGeneration":"18446744073709551615",
                    "credentialId":"public-identity", "minimumProtocolVersion":123, "maximumProtocolVersion":456,
                    "inboundVerificationFlags":"18446744073709551615", "outboundVerificationFlags":"9007199254740993",
                    "identityNotBeforeUnixSeconds":"-9223372036854775808", "identityNotAfterUnixSeconds":"9223372036854775807",
                    "identityFingerprintSha256":"ab".repeat(32)
                }
            }
        })
    );
}

#[test]
fn causal_serialization_failure_is_returned_not_reclassified() {
    struct Refuse;
    impl std::io::Write for Refuse {
        fn write(&mut self, _: &[u8]) -> std::io::Result<usize> {
            Err(std::io::Error::new(
                std::io::ErrorKind::PermissionDenied,
                "refused",
            ))
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }
    let error = IntentError::from_runtime(
        CoAkkaError::Core {
            operation: "original",
            status: CoAkkaStatus(-9876),
        },
        None,
    );
    assert!(serde_json::to_writer(Refuse, &error).unwrap_err().is_io());
    assert_eq!(
        serde_json::to_value(&error).unwrap()["cause"]["status"],
        -9876
    );
}
