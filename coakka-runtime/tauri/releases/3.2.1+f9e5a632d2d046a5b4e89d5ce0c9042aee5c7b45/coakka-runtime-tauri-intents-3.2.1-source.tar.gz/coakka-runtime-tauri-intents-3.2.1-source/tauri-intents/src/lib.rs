use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;

use coakka_runtime::{
    CoAkkaError, ConnectorStartSpec, DeliveryHint, PayloadFormat, PayloadIdentity,
    RuntimeClientStats, RuntimeDeliveryConfigSnapshot, RuntimeHost, RuntimeInfo,
    RuntimeNetworkConfigSnapshot, RuntimeStartupConfigSnapshot, TransportEnvelope,
};
use serde::{Deserialize, Serialize};
use serde_json::Value;

mod error;
pub use error::{IntentError, IntentErrorCause};

pub type Result<T> = std::result::Result<T, IntentError>;

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum IntentPayloadFormat {
    Json,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct IntentPayloadIdentity {
    pub message_type: String,
    pub schema_version: u32,
    pub format: IntentPayloadFormat,
}

impl IntentPayloadIdentity {
    pub fn json(message_type: impl Into<String>, schema_version: u32) -> Self {
        Self {
            message_type: message_type.into(),
            schema_version,
            format: IntentPayloadFormat::Json,
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct IntentEnvelope {
    pub intent_id: String,
    pub source: String,
    pub target: String,
    pub operation: String,
    pub payload: Value,
    pub payload_identity: IntentPayloadIdentity,
    #[serde(default)]
    pub timeout_ms: Option<u64>,
    #[serde(default)]
    pub headers: HashMap<String, String>,
}

impl IntentEnvelope {
    pub fn require_valid(&self) -> Result<()> {
        require_non_blank("intentId", &self.intent_id)?;
        require_non_blank("source", &self.source)?;
        require_non_blank("target", &self.target)?;
        require_non_blank("operation", &self.operation)?;
        require_non_blank(
            "payloadIdentity.messageType",
            &self.payload_identity.message_type,
        )?;
        for (key, value) in &self.headers {
            require_non_blank("headers.key", key)?;
            require_non_blank("headers.value", value)?;
        }
        if self.payload_identity.schema_version == 0 {
            return Err(IntentError::invalid_intent(
                "payloadIdentity.schemaVersion must be >= 1".to_string(),
            ));
        }
        if self.timeout_ms == Some(0) {
            return Err(IntentError::invalid_intent(
                "timeoutMs must be positive when supplied".to_string(),
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct IntentHandlerRequest {
    pub source: String,
    pub target: String,
    pub operation: String,
    pub payload: Value,
    pub payload_identity: IntentPayloadIdentity,
    #[serde(default)]
    pub headers: HashMap<String, String>,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct IntentResult {
    pub intent_id: String,
    pub target: String,
    pub operation: String,
    pub payload: Value,
    pub runtime: IntentRuntimeProjection,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct IntentRuntimeProjection {
    pub message_type: String,
    pub schema_version: u32,
}

pub struct RuntimeIntentDispatcher {
    runtime: Arc<RuntimeHost>,
    default_timeout: Duration,
    max_timeout: Duration,
    delivery_hint: DeliveryHint,
}

impl Clone for RuntimeIntentDispatcher {
    fn clone(&self) -> Self {
        Self {
            runtime: self.runtime.clone(),
            default_timeout: self.default_timeout,
            max_timeout: self.max_timeout,
            delivery_hint: self.delivery_hint,
        }
    }
}

impl RuntimeIntentDispatcher {
    pub fn start(spec: ConnectorStartSpec) -> Result<Self> {
        let runtime =
            RuntimeHost::start(spec).map_err(|error| IntentError::from_runtime(error, None))?;
        Ok(Self::new(runtime))
    }

    pub fn new(runtime: RuntimeHost) -> Self {
        Self {
            runtime: Arc::new(runtime),
            default_timeout: Duration::from_secs(2),
            max_timeout: Duration::from_secs(30),
            delivery_hint: DeliveryHint::RouterDefault,
        }
    }

    pub fn register_json_handler<F>(&self, target: impl Into<String>, handler: F) -> Result<()>
    where
        F: Fn(IntentHandlerRequest) -> Result<Value> + Send + Sync + 'static,
    {
        let target = target.into();
        require_non_blank("target", &target)?;
        let reply_source = target.clone();
        self.runtime
            .register_handler(target, move |request| {
                let intent_request = match IntentHandlerRequest::from_transport_request(&request) {
                    Ok(intent_request) => intent_request,
                    Err(error) => {
                        eprintln!("[coakka-tauri-intents] invalid handler request: {error:?}");
                        return None;
                    }
                };
                let payload = match handler(intent_request).and_then(|payload| {
                    serde_json::to_string(&payload)
                        .map_err(|error| IntentError::json(error.to_string(), None))
                }) {
                    Ok(payload) => payload,
                    Err(error) => {
                        eprintln!("[coakka-tauri-intents] handler failed: {error:?}");
                        return None;
                    }
                };
                RuntimeHost::make_json_reply_from_request_identity(&request, &reply_source, payload)
                    .ok()
            })
            .map_err(|error| IntentError::from_runtime(error, None))
    }

    pub fn runtime_startup_config(&self) -> Result<RuntimeStartupConfigSnapshot> {
        self.runtime
            .runtime_startup_config()
            .map_err(|error| IntentError::from_runtime(error, None))
    }

    pub fn runtime_delivery_config(&self) -> Result<RuntimeDeliveryConfigSnapshot> {
        self.runtime
            .runtime_delivery_config()
            .map_err(|error| IntentError::from_runtime(error, None))
    }

    /// Copies Core's accepted listener participation and explicit-policy fact.
    pub fn runtime_network_config(&self) -> Result<RuntimeNetworkConfigSnapshot> {
        self.runtime
            .runtime_network_config()
            .map_err(|error| IntentError::from_runtime(error, None))
    }

    pub fn runtime_info(&self) -> Result<RuntimeInfo> {
        self.runtime
            .runtime_info()
            .map_err(|error| IntentError::from_runtime(error, None))
    }

    pub fn runtime_client_stats(&self) -> RuntimeClientStats {
        self.runtime.client_stats()
    }

    pub fn ask_intent(&self, intent: IntentEnvelope) -> Result<IntentResult> {
        intent.require_valid()?;
        let timeout = self.timeout_for(&intent);
        let payload_json = serde_json::to_string(&intent.payload)
            .map_err(|error| IntentError::invalid_intent(error.to_string()))?;
        let response = self
            .runtime
            .ask_json(
                &intent.source,
                &intent.target,
                payload_json,
                self.payload_identity_for(&intent)?,
                timeout,
                &intent.operation,
                self.delivery_hint,
            )
            .map_err(|error| map_runtime_error(error, &intent.target))?;
        // The response owns these bytes through synchronous parsing. Borrow
        // valid UTF-8 instead of allocating a diagnostic String; retain the
        // existing lossy conversion for invalid UTF-8 and an owning JSON value.
        let payload = serde_json::from_str::<Value>(&String::from_utf8_lossy(&response.payload))
            .map_err(|error| IntentError::json(error.to_string(), Some(intent.target.clone())))?;
        Ok(IntentResult {
            intent_id: intent.intent_id,
            target: intent.target,
            operation: intent.operation,
            payload,
            runtime: IntentRuntimeProjection {
                message_type: response.message_type,
                schema_version: response.payload_schema_version,
            },
        })
    }

    fn timeout_for(&self, intent: &IntentEnvelope) -> Duration {
        let requested = intent
            .timeout_ms
            .map(Duration::from_millis)
            .unwrap_or(self.default_timeout);
        requested.min(self.max_timeout)
    }

    fn payload_identity_for(&self, intent: &IntentEnvelope) -> Result<PayloadIdentity> {
        match intent.payload_identity.format {
            IntentPayloadFormat::Json => Ok(PayloadIdentity {
                message_type: intent.payload_identity.message_type.clone(),
                payload_schema_version: intent.payload_identity.schema_version,
                payload_format: PayloadFormat::Json,
            }),
        }
    }
}

pub fn coakka_ask_intent_command(
    dispatcher: &RuntimeIntentDispatcher,
    intent: IntentEnvelope,
) -> Result<IntentResult> {
    dispatcher.ask_intent(intent)
}

impl IntentHandlerRequest {
    fn from_transport_request(request: &TransportEnvelope) -> Result<Self> {
        if request.payload_format != PayloadFormat::Json {
            return Err(IntentError::json(
                "intent handler received a non-JSON runtime request",
                Some(request.target.clone()),
            ));
        }
        let payload = serde_json::from_str::<Value>(&String::from_utf8_lossy(&request.payload))
            .map_err(|error| IntentError::json(error.to_string(), Some(request.target.clone())))?;
        Ok(Self {
            source: request.source.clone(),
            target: request.target.clone(),
            operation: request
                .headers
                .get("operation")
                .cloned()
                .unwrap_or_default(),
            payload,
            payload_identity: IntentPayloadIdentity {
                message_type: request.message_type.clone(),
                schema_version: request.payload_schema_version,
                format: IntentPayloadFormat::Json,
            },
            headers: request.headers.clone(),
        })
    }
}

fn require_non_blank(name: &str, value: &str) -> Result<()> {
    if value.trim().is_empty() {
        return Err(IntentError::invalid_intent(format!(
            "{name} must not be blank"
        )));
    }
    Ok(())
}

fn map_runtime_error(error: CoAkkaError, target: &str) -> IntentError {
    IntentError::from_runtime(error, Some(target.to_string()))
}

#[cfg(test)]
mod causal_projection_tests {
    use super::*;
    use coakka_runtime::{CoAkkaStatus, TcpConnectionValidation, TcpConnectionValidationCode};
    use serde_json::json;

    #[test]
    fn causal_public_startup_preserves_core_refusal_and_recovers() {
        let mut spec = ConnectorStartSpec::new("intent-refusal", "intent-refusal");
        spec.generation = 0;
        let error = RuntimeIntentDispatcher::start(spec)
            .err()
            .expect("Core refusal");
        assert!(matches!(error.cause, IntentErrorCause::Runtime(ref cause)
            if matches!(cause.as_ref(), CoAkkaError::Core { status, .. }
                if *status == CoAkkaStatus::INVALID_ARGUMENT)));
        let value = serde_json::to_value(error).unwrap();
        assert_eq!(
            value["cause"],
            json!({"kind":"core", "status":-1,
            "operation":"coakka_v2_runtime_apply_control_envelope"})
        );
        let recovered =
            RuntimeIntentDispatcher::start(ConnectorStartSpec::new("recover", "recover"))
                .expect("normal startup after refusal");
        assert_eq!(
            recovered
                .runtime_startup_config()
                .unwrap()
                .execution
                .requested_policy,
            0
        );
    }

    #[test]
    fn causal_actual_deadletter_projects_exact_core_facts_without_echoing_request() {
        let dispatcher =
            RuntimeIntentDispatcher::start(ConnectorStartSpec::new("missing", "missing"))
                .expect("start dispatcher");
        let error = dispatcher
            .ask_intent(IntentEnvelope {
                intent_id: "missing-1".into(),
                source: "ui".into(),
                target: "absent".into(),
                operation: "echo".into(),
                payload: json!({"private":"do-not-echo-in-error"}),
                payload_identity: IntentPayloadIdentity::json("test.v1", 1),
                timeout_ms: Some(2000),
                headers: HashMap::new(),
            })
            .expect_err("Core deadletter");
        let original = match &error.cause {
            IntentErrorCause::Runtime(cause) => match cause.as_ref() {
                CoAkkaError::Deadletter(value) => value,
                other => panic!("lost deadletter: {other:?}"),
            },
            other => panic!("invented cause: {other:?}"),
        };
        let value = serde_json::to_value(&error).unwrap();
        assert_eq!(value["cause"]["kind"], "deadletter");
        assert_eq!(value["target"], original.original.target);
        assert_eq!(value["cause"]["result"]["reasonCode"], original.reason_code);
        assert_eq!(
            value["cause"]["result"]["activeGeneration"],
            original.active_generation.to_string()
        );
        assert!(!value.to_string().contains("do-not-echo-in-error"));
        assert_eq!(dispatcher.runtime_client_stats().pending_requests, 0);
        // A future Core may issue currently unnamed reasons and metadata. The
        // JSON boundary must preserve them without a local lookup/default table.
        let IntentErrorCause::Runtime(mut source) = error.cause else {
            unreachable!()
        };
        let CoAkkaError::Deadletter(ref mut deadletter) = *source else {
            unreachable!()
        };
        deadletter.reason_code = -9876;
        deadletter.active_generation = u64::MAX;
        deadletter
            .transport_failure_metadata
            .insert("future-key".into(), "future-value".into());
        let projected = IntentError::from_runtime(*source, Some("wrong-local-target".into()));
        assert!(std::error::Error::source(&projected).is_some());
        let value = serde_json::to_value(projected).unwrap();
        assert_eq!(value["target"], "absent");
        assert_eq!(value["cause"]["result"]["reasonCode"], -9876);
        assert_eq!(
            value["cause"]["result"]["activeGeneration"],
            u64::MAX.to_string()
        );
        assert_eq!(
            value["cause"]["result"]["transportFailureMetadata"]["future-key"],
            "future-value"
        );
    }

    #[test]
    fn causal_core_status_is_not_replaced_by_display_text() {
        for status in [-7, -9876, i32::MIN, i32::MAX] {
            let error = map_runtime_error(
                CoAkkaError::Core {
                    operation: "request_await",
                    status: CoAkkaStatus(status),
                },
                "svc.echo",
            );
            let value = serde_json::to_value(error).unwrap();
            assert_eq!(value["cause"]["kind"], "core");
            assert_eq!(value["cause"]["status"], status);
            assert_eq!(value["cause"]["operation"], "request_await");
        }
    }

    #[test]
    fn causal_timeout_and_host_failure_with_identical_text_stay_distinct() {
        for (source, expected) in [
            (CoAkkaError::Timeout("timed out".into()), "timeout"),
            (CoAkkaError::Native("timed out".into()), "host"),
        ] {
            let value = serde_json::to_value(map_runtime_error(source, "svc.echo")).unwrap();
            assert_eq!(value["cause"]["kind"], expected);
            assert!(value["cause"].get("status").is_none());
        }
    }

    #[test]
    fn causal_validation_preserves_unknown_codes_and_wide_bounds() {
        let source = CoAkkaError::TcpConnectionValidation(TcpConnectionValidation {
            status: CoAkkaStatus(-9876),
            code: TcpConnectionValidationCode(u32::MAX),
            field: 1u64 << 63,
            minimum_value: 9007199254740993,
            maximum_value: u64::MAX,
        });
        let value = serde_json::to_value(map_runtime_error(source, "svc.echo")).unwrap();
        assert_eq!(
            value["cause"],
            json!({"kind":"connectionValidation", "result": {
                "status": -9876, "code": u32::MAX, "field": "9223372036854775808",
                "minimumValue": "9007199254740993", "maximumValue": "18446744073709551615"
            }})
        );
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use coakka_runtime::{RouteSpec, TcpConnectionMode};
    use serde_json::json;
    use std::thread;

    #[test]
    fn ask_intent_roundtrips_through_native_runtime() {
        let target = "tauri.intent.echo";
        let mut spec = ConnectorStartSpec::new("tauri-intent-test", "tauri-intent-test-node");
        spec.queue_capacity = 64;
        spec.routes = vec![RouteSpec::single_local(target, "127.0.0.1", 19411)];

        let dispatcher = RuntimeIntentDispatcher::start(spec).expect("start dispatcher");
        let startup = dispatcher
            .runtime_startup_config()
            .expect("read Core startup facts");
        let delivery = dispatcher
            .runtime_delivery_config()
            .expect("read Core delivery facts");
        assert_eq!(startup.execution.requested_policy, 0);
        assert_eq!(startup.connection.mode, TcpConnectionMode::MULTIPLEXING);
        assert_eq!(startup.connection.explicitly_configured_fields, 0);
        let network = dispatcher
            .runtime_network_config()
            .expect("Core network facts");
        assert_eq!(network.mode, 1);
        assert!(!network.explicit_policy);
        assert_eq!(startup.defaulted_groups, 15);
        // The frozen Core candidate uses owned delivery on every target. Do
        // not infer an obsolete pipe mode from the application's OS target.
        assert!(delivery.compiled);
        assert_eq!(delivery.request_mode, 2);
        assert_eq!(delivery.response_mode, 2);
        assert_eq!(delivery.remote_batch_max_calls, 8);
        assert_eq!(delivery.slot_capacity, 16);
        assert_eq!(delivery.byte_capacity, 4 * 1024 * 1024);
        dispatcher
            .register_json_handler(target, |request| {
                Ok(json!({
                    "handledBy": "rust",
                    "operation": request.operation,
                    "echo": request.payload
                }))
            })
            .expect("register handler");

        let result = coakka_ask_intent_command(
            &dispatcher,
            IntentEnvelope {
                intent_id: "intent-1".to_string(),
                source: "tauri-ui".to_string(),
                target: target.to_string(),
                operation: "echo".to_string(),
                payload: json!({"message":"hello-tauri-intent"}),
                payload_identity: IntentPayloadIdentity::json("samples.tauri.echo.request.v1", 1),
                timeout_ms: Some(2_000),
                headers: HashMap::new(),
            },
        )
        .expect("ask intent");

        assert_eq!(result.intent_id, "intent-1");
        assert_eq!(result.payload["handledBy"], "rust");
        assert_eq!(result.payload["operation"], "echo");
        assert_eq!(result.payload["echo"]["message"], "hello-tauri-intent");
        assert_eq!(result.runtime.message_type, "samples.tauri.echo.request.v1");
    }

    #[test]
    fn rejects_blank_intent_before_runtime_boundary() {
        let intent = IntentEnvelope {
            intent_id: String::new(),
            source: "tauri-ui".to_string(),
            target: "svc.echo".to_string(),
            operation: "echo".to_string(),
            payload: json!({}),
            payload_identity: IntentPayloadIdentity::json("samples.tauri.echo.request.v1", 1),
            timeout_ms: None,
            headers: HashMap::new(),
        };

        let error = intent
            .require_valid()
            .expect_err("blank intent id rejected");
        assert_eq!(error.code, "INVALID_INTENT");
    }

    #[test]
    fn rejects_blank_header_before_runtime_boundary() {
        let mut headers = HashMap::new();
        headers.insert("".to_string(), "trace-1".to_string());
        let intent = IntentEnvelope {
            intent_id: "intent-1".to_string(),
            source: "tauri-ui".to_string(),
            target: "svc.echo".to_string(),
            operation: "echo".to_string(),
            payload: json!({}),
            payload_identity: IntentPayloadIdentity::json("samples.tauri.echo.request.v1", 1),
            timeout_ms: None,
            headers,
        };

        let error = intent.require_valid().expect_err("blank header rejected");
        assert_eq!(error.code, "INVALID_INTENT");
    }

    #[test]
    fn rejects_zero_timeout_before_runtime_boundary() {
        let intent = IntentEnvelope {
            intent_id: "intent-1".to_string(),
            source: "tauri-ui".to_string(),
            target: "svc.echo".to_string(),
            operation: "echo".to_string(),
            payload: json!({}),
            payload_identity: IntentPayloadIdentity::json("samples.tauri.echo.request.v1", 1),
            timeout_ms: Some(0),
            headers: HashMap::new(),
        };

        let error = intent.require_valid().expect_err("zero timeout rejected");
        assert_eq!(error.code, "INVALID_INTENT");
    }

    #[test]
    fn core_deadline_owns_a_slow_intent_timeout() {
        let target = "tauri.intent.slow";
        let mut spec = ConnectorStartSpec::new("tauri-timeout-test", "tauri-timeout-node");
        spec.routes = vec![RouteSpec::single_local(target, "127.0.0.1", 19412)];
        let dispatcher = RuntimeIntentDispatcher::start(spec).expect("start dispatcher");
        dispatcher
            .register_json_handler(target, |_request| {
                thread::sleep(Duration::from_millis(60));
                Ok(json!({"late": true}))
            })
            .expect("register slow handler");

        let error = dispatcher
            .ask_intent(IntentEnvelope {
                intent_id: "intent-timeout".to_string(),
                source: "tauri-ui".to_string(),
                target: target.to_string(),
                operation: "slow".to_string(),
                payload: json!({}),
                payload_identity: IntentPayloadIdentity::json("samples.tauri.slow.v1", 1),
                timeout_ms: Some(5),
                headers: HashMap::new(),
            })
            .expect_err("Core deadline should expire");
        assert_eq!(error.code, "TIMEOUT");
        assert!(matches!(error.cause, IntentErrorCause::Runtime(ref cause)
            if matches!(cause.as_ref(), CoAkkaError::Timeout(_))));
        assert_eq!(
            serde_json::to_value(error).unwrap()["cause"]["kind"],
            "timeout"
        );
    }

    #[test]
    fn large_json_intent_roundtrips_without_a_webview_copy_policy() {
        let target = "tauri.intent.large";
        let mut spec = ConnectorStartSpec::new("tauri-large-test", "tauri-large-node");
        spec.routes = vec![RouteSpec::single_local(target, "127.0.0.1", 19413)];
        let dispatcher = RuntimeIntentDispatcher::start(spec).expect("start dispatcher");
        dispatcher
            .register_json_handler(target, |request| Ok(request.payload))
            .expect("register large handler");
        let body = "x".repeat(96 * 1024);
        let result = dispatcher
            .ask_intent(IntentEnvelope {
                intent_id: "intent-large".to_string(),
                source: "tauri-ui".to_string(),
                target: target.to_string(),
                operation: "echo".to_string(),
                payload: json!({"body": body}),
                payload_identity: IntentPayloadIdentity::json("samples.tauri.large.v1", 1),
                timeout_ms: Some(2_000),
                headers: HashMap::new(),
            })
            .expect("large intent roundtrip");
        assert_eq!(
            result.payload["body"].as_str().map(str::len),
            Some(96 * 1024)
        );
    }

    #[test]
    fn repeated_dispatcher_lifecycle_releases_core_owners() {
        for round in 0..16 {
            let spec = ConnectorStartSpec::new(
                "tauri-lifecycle-test",
                format!("tauri-lifecycle-node-{round}"),
            );
            let dispatcher = RuntimeIntentDispatcher::start(spec).expect("start dispatcher");
            let startup = dispatcher
                .runtime_startup_config()
                .expect("read startup config");
            assert_eq!(startup.execution.requested_policy, 0);
            assert_eq!(startup.connection.mode, TcpConnectionMode::MULTIPLEXING);
        }
    }

    #[test]
    fn cloned_dispatchers_share_core_matching_under_concurrency() {
        let target = "tauri.intent.concurrent";
        let mut spec = ConnectorStartSpec::new("tauri-concurrent-test", "tauri-concurrent-node");
        spec.queue_capacity = 256;
        spec.routes = vec![RouteSpec::single_local(target, "127.0.0.1", 19414)];
        let dispatcher = RuntimeIntentDispatcher::start(spec).expect("start dispatcher");
        dispatcher
            .register_json_handler(target, |request| Ok(request.payload))
            .expect("register concurrent handler");

        let workers: Vec<_> = (0..4)
            .map(|worker| {
                let dispatcher = dispatcher.clone();
                thread::spawn(move || {
                    for sequence in 0..32 {
                        let result = dispatcher
                            .ask_intent(IntentEnvelope {
                                intent_id: format!("intent-{worker}-{sequence}"),
                                source: format!("tauri-ui-{worker}"),
                                target: target.to_string(),
                                operation: "echo".to_string(),
                                payload: json!({"worker": worker, "sequence": sequence}),
                                payload_identity: IntentPayloadIdentity::json(
                                    "samples.tauri.concurrent.v1",
                                    1,
                                ),
                                timeout_ms: Some(2_000),
                                headers: HashMap::new(),
                            })
                            .expect("concurrent ask");
                        assert_eq!(result.payload["worker"], worker);
                        assert_eq!(result.payload["sequence"], sequence);
                    }
                })
            })
            .collect();
        for worker in workers {
            worker.join().expect("join concurrent worker");
        }
        let stats = dispatcher.runtime.client_stats();
        assert_eq!(stats.pending_requests, 0);
        assert_eq!(stats.matched_responses, 128);
    }
}

#[cfg(test)]
mod payload_projection_tests {
    use super::*;
    use coakka_runtime::{make_json_reply, RouteSpec};
    use serde_json::json;

    #[test]
    fn response_projection_keeps_values_ownership_errors_and_terminal_accounting() {
        let target = "tauri.projection.echo";
        let bodies = [
            b"null".to_vec(),
            r#"{"echo":"Tiếng Việt 😀"}"#.as_bytes().to_vec(),
            format!(r#"{{"echo":"{}"}}"#, "x".repeat(96 * 1024)).into_bytes(),
            b"{\"echo\":\"\xff\"}".to_vec(),
            Vec::new(),
            b"{broken".to_vec(),
        ];
        for (index, body) in bodies.into_iter().enumerate() {
            // Keep the former owning projection as an independent value oracle.
            let original_text = String::from_utf8_lossy(&body).to_string();
            let expected = serde_json::from_str::<Value>(&original_text);
            let mut spec =
                ConnectorStartSpec::new("tauri-projection-test", format!("node-{index}"));
            spec.routes = vec![RouteSpec::single_local(target, "local", 0)];
            let runtime = RuntimeHost::start(spec).unwrap();
            runtime
                .register_handler(target, move |request| {
                    // Exercise the real handler projection with the same owned
                    // input; no decoded view may borrow this request afterward.
                    let projected = IntentHandlerRequest::from_transport_request(&request).unwrap();
                    assert_eq!(projected.payload, json!({"request": "Tiếng Việt 😀"}));
                    make_json_reply(
                        &request,
                        target,
                        body.clone(),
                        PayloadIdentity::json("test.projection.reply.v1", 1),
                    )
                    .ok()
                })
                .unwrap();
            let dispatcher = RuntimeIntentDispatcher::new(runtime);
            let result = dispatcher.ask_intent(IntentEnvelope {
                intent_id: format!("projection-{index}"),
                source: "projection-client".into(),
                target: target.into(),
                operation: "echo".into(),
                payload: json!({"request": "Tiếng Việt 😀"}),
                payload_identity: IntentPayloadIdentity::json("test.projection.request.v1", 1),
                timeout_ms: Some(2_000),
                headers: HashMap::new(),
            });
            let stats = dispatcher.runtime_client_stats();
            assert_eq!(stats.pending_requests, 0);
            assert_eq!(stats.matched_responses, 1);
            drop(dispatcher);
            match (expected, result) {
                (Ok(expected), Ok(result)) => assert_eq!(result.payload, expected),
                (Err(expected), Err(result)) => {
                    assert_eq!(result.code, "JSON_ERROR");
                    assert_eq!(result.target.as_deref(), Some(target));
                    assert_eq!(result.message, expected.to_string());
                }
                (expected, result) => panic!("projection changed: {expected:?} -> {result:?}"),
            }
        }
    }
}
