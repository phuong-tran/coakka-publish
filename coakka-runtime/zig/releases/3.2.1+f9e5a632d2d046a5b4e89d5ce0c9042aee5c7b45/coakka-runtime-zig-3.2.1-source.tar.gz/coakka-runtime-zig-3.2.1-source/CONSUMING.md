# Consuming The Zig 3.2.1 Source Package

Use Zig 0.16.0 and a matching C compiler.
See the [qualified host scope](README.md#scope-and-evidence).
Compare the archive SHA-256 with the catalog before unpacking. Choose an
existing absolute work directory for generated files.

~~~sh
shasum -a 256 coakka-runtime-zig-3.2.1-source.tar.gz
tar -xzf coakka-runtime-zig-3.2.1-source.tar.gz
cd coakka-runtime-zig-3.2.1-source
export COAKKA_CONNECTOR_WORK_ROOT="/absolute/existing-work"
export COAKKA_ZIG_GLOBAL_CACHE_ROOT="/absolute/existing-zig-cache"
bash scripts/verify-native-payload.sh
bash scripts/smoke.sh
~~~

The payload verifier checks all five Core files. The smoke uses the bundled
Core and exercises startup, request/reply, cancellation and route-miss
deadletter. See [archive verification](RELEASE.md) for additional checks.
