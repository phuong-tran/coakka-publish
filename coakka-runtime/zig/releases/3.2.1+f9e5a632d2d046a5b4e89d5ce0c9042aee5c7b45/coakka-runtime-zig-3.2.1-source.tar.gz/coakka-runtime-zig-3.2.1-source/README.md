# CoAkka Runtime Zig Connector

The **Zig 3.2.1 source package** bundles Runtime Core 3.2 (ABI 1),
commit `f9e5a632d2d046a5b4e89d5ce0c9042aee5c7b45`. In `3.2.1`, `3.2` is the
Core generation and `1` is this connector's revision on that Core.

Normal startup leaves CPU placement, connection strategy and monitoring
unspecified. Core selects AUTO, MULTIPLEXED and monitor OFF and reports what it
accepted. The connector does not infer CPU support or replace a rejected choice.
See [Runtime Monitoring](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/operations/runtime-monitoring.md).

Zig exposes an explicit runtime owner and copied configuration snapshots.
Use `defer host.deinit()` before closing the loaded module. `RuntimeHost` values
must not be copied after startup; serialize work with teardown. `networkConfig()`
returns an owned copy of the network policy accepted by Core at startup. The current
qualified compiler is Zig 0.16.0.


## Run From The Archive

Follow [Consuming](CONSUMING.md) to verify the archive and build the smoke with
Zig 0.16.0. [Archive verification](RELEASE.md) lists the checks
available in the package.

Core owns routing, request matching, timeouts and bounded delivery. The adapter
retains one Core ask owner per runtime and releases request views before their
owner. No new thread, queue or local matching policy is added.

## Scope And Evidence

Zig 0.16.0 application execution was checked on macOS ARM64, Raspberry Pi 5
(Linux ARM64), WSL2 (Linux x86-64), native Windows x86-64, and Windows ARM64
in UTM. The Windows runs used applications cross-built on macOS.

The five bundled Core images are a payload inventory. The 3.2.1 smoke does
not qualify TLS or minimum OS versions.

File and Stream examples use the existing
[file](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/guides/runtime-file-transfer.md),
[stream](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/guides/runtime-streaming.md)
and [owner-grant](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/reference/runtime-lane-owner-grants.md)
contracts. Compare the archive hash with the distribution catalog before use.

## Common Guidance

[Documentation](https://github.com/phuong-tran/coakka-samples/blob/main/docs/README.md),
[AI-assisted integration](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/guides/ai-assisted-integration.md)
and [Troubleshooting](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/operations/troubleshooting.md)
describe package selection, ownership and platform trust.

## License

Connector source uses the included Apache License 2.0. Native binaries use the
included CoAkka Native Artifact License 1.2. The package retains its LICENSE,
NATIVE-LICENSE.md, PACKAGE-LICENSE.md and NOTICE material.

![CoAkka](https://raw.githubusercontent.com/phuong-tran/coakka-samples/main/docs/common/assets/brand/coakka-logo.png)
