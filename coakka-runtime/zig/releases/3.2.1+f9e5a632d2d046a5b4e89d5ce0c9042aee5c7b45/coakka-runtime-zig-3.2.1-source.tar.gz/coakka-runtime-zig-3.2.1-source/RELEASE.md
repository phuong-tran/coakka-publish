# Verify The Zig 3.2.1 Source Package

Confirm the archive SHA-256 against the distribution catalog, then use the
commands in [Consuming](CONSUMING.md) from the extracted archive.
`scripts/verify-native-payload.sh` checks the five bundled Core 3.2 images.
`scripts/smoke.sh` builds and runs a consumer using the matching bundled image.

The optional `scripts/check-platform-source.sh` uses Zig to check the package
sources for Linux ARM64 and Windows x86-64. It does not execute on those
targets. The [README](README.md#scope-and-evidence) records execution scope.
