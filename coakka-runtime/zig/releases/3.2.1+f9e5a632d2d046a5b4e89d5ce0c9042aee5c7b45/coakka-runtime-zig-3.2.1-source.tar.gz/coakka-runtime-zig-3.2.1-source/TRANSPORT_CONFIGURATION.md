# Zig Runtime Configuration And Ownership

This guide covers the 3.2.1 source distribution. Core owns accepted configuration,
capabilities and terminal outcomes.

~~~zig
const spec = runtime.localStartSpec("orders", "orders-1", "svc.orders");
var host = switch (try native.startHost(spec)) {
    .started => |started| started,
    .startup_rejected => return error.StartupRejected,
    .security_rejected => return error.SecurityRejected,
    .network_rejected => return error.NetworkRejected,
};
defer host.deinit();
const accepted = try host.startupConfig();
~~~

Normally leave queue capacity, network, CPU, connection and monitoring absent.
Core accepts its defaults; queue capacity 0 selects the native default. startupConfig()
returns a pointer-free Core-issued snapshot, including supported/applied CPU
facts. Unknown numeric values remain represented. No effective configuration
exists when construction refuses; startup_rejected carries Core's status.

Explicit network choices are forwarded unchanged. Core validates field presence,
addresses and ports; the connector does not fill a missing advertised port or
replace an explicit zero. A refusal returns network_rejected with Core's status.
Omitting network differs from explicitly choosing embedded mode, even when both
have the same effective mode.

networkConfig() returns Core's accepted policy captured at startup, including
its explicit-policy flag, addresses and ports. Host strings are copied into
bounded values, so a returned snapshot remains valid after the runtime closes.
The connector allows up to 255 bytes per copied host and refuses startup if a
native output exceeds that storage; it never truncates or invents a value.
Calling the getter after close fails. These are cold startup copies, with no
per-request configuration work.

Explicit connection intent is submitted during native construction. A later
applyConnectionStrategy() attempt returns Core's immutable-state result.
Security startup/reload preserves the existing structured Core result. Bad,
stale or unsupported choices are never retried through another mode.

RuntimeHost owns one Core ask client and one delivered-request reader. A frame
view is borrowed only through a synchronous reply-builder call and then released.
Finish calls before deinit(); do not copy an active RuntimeHost or race work
with teardown. The module loader retains its single-active-host and
process-resident identity contract. That bookkeeping owns module lifetime and
is not a source of Core configuration facts.

TLS files and business retry policy belong to the application. See
[TLS/mTLS](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/reference/tls-and-mtls.md)
and [Runtime Monitoring](https://github.com/phuong-tran/coakka-samples/blob/main/docs/coakka-runtime/operations/runtime-monitoring.md).
