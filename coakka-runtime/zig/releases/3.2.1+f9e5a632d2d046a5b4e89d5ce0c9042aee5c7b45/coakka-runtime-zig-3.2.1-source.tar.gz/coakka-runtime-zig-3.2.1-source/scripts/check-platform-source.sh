#!/usr/bin/env bash
set -euo pipefail

: "${COAKKA_CONNECTOR_WORK_ROOT:?set an existing absolute connector work directory}"
[[ "${COAKKA_CONNECTOR_WORK_ROOT}" == /* && -d "${COAKKA_CONNECTOR_WORK_ROOT}" && ! -L "${COAKKA_CONNECTOR_WORK_ROOT}" ]] || exit 2

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
zig_root="$(cd "${script_dir}/.." && pwd)"
work_root="$(mktemp -d "${COAKKA_CONNECTOR_WORK_ROOT}/coakka-zig-cross.XXXXXX")"
trap 'rm -rf "${work_root}"' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
export TMPDIR="${work_root}"

zig build --cache-dir "${work_root}/zig-cache" --global-cache-dir "${COAKKA_ZIG_GLOBAL_CACHE_ROOT:?select the reusable Zig cache}" --build-file "${zig_root}/build.zig" -Dtarget=aarch64-linux-gnu \
  -Doptimize=ReleaseSafe --prefix "${work_root}/linux"
zig build --cache-dir "${work_root}/zig-cache" --global-cache-dir "${COAKKA_ZIG_GLOBAL_CACHE_ROOT:?select the reusable Zig cache}" --build-file "${zig_root}/build.zig" -Dtarget=x86_64-windows-gnu \
  -Doptimize=ReleaseSafe --prefix "${work_root}/windows"
file "${work_root}/linux/bin/coakka-runtime-zig-smoke" | grep -q 'ELF 64-bit.*ARM aarch64'
file "${work_root}/windows/bin/coakka-runtime-zig-smoke.exe" | grep -q 'PE32+ executable.*x86-64'
echo "[zig-platform-source] Linux ARM64 and Windows x86-64 compile/link ok"
