#!/usr/bin/env bash
set -euo pipefail
: "${COAKKA_CONNECTOR_WORK_ROOT:?set an existing absolute connector work directory}"
[[ "${COAKKA_CONNECTOR_WORK_ROOT}" == /* && -d "${COAKKA_CONNECTOR_WORK_ROOT}" && ! -L "${COAKKA_CONNECTOR_WORK_ROOT}" ]] || exit 2
work_root="$(mktemp -d "${COAKKA_CONNECTOR_WORK_ROOT}/zig-smoke.XXXXXX")"
trap 'rm -rf "${work_root}"' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
export TMPDIR="${work_root}"

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
zig_root="$(cd "${script_dir}/.." && pwd)"
command -v zig >/dev/null 2>&1 || {
  echo "[zig-runtime-smoke] zig toolchain is required" >&2
  exit 1
}

runtime_lib="${COAKKA_RUNTIME_LIB:-}"
if [[ -z "${runtime_lib}" ]]; then
  case "$(uname -s)" in
    Darwin)
      platform="macos-aarch64"
      filename="libcoakka_runtime_v2.dylib"
      ;;
    Linux)
      case "$(uname -m)" in
        aarch64|arm64) platform="linux-aarch64" ;;
        x86_64|amd64) platform="linux-x86_64" ;;
        *) echo "[zig-runtime-smoke] no bundled Linux native for $(uname -m)" >&2; exit 64 ;;
      esac
      filename="libcoakka_runtime_v2.so"
      ;;
    MINGW*|MSYS*|CYGWIN*)
      case "${PROCESSOR_ARCHITEW6432:-${PROCESSOR_ARCHITECTURE:-$(uname -m)}}" in
        ARM64|arm64|aarch64) platform="windows-aarch64" ;;
        AMD64|amd64|x86_64) platform="windows-x86_64" ;;
        *) echo "[zig-runtime-smoke] no bundled native for this Windows architecture" >&2; exit 64 ;;
      esac
      filename="libcoakka_runtime_v2.dll"
      ;;
    *) echo "[zig-runtime-smoke] unsupported OS: $(uname -s)" >&2; exit 64 ;;
  esac
  packaged="${zig_root}/native/${platform}/${filename}"
  if [[ -f "${packaged}" ]]; then
    runtime_lib="${packaged}"
  else
    echo "[zig-runtime-smoke] bundled runtime not found; set COAKKA_RUNTIME_LIB" >&2
    exit 1
  fi
fi

[[ -f "${runtime_lib}" ]] || {
  echo "[zig-runtime-smoke] runtime library not found: ${runtime_lib}" >&2
  exit 1
}

COAKKA_RUNTIME_LIB="${runtime_lib}" zig build --cache-dir "${work_root}/zig-cache" --prefix "${work_root}/out" --global-cache-dir "${COAKKA_ZIG_GLOBAL_CACHE_ROOT:?select the reusable Zig cache}" --build-file "${zig_root}/build.zig" smoke
