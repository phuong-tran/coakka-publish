const std = @import("std");

/// Core's network participation intent. Unknown values reach Core unchanged.
pub const Mode = enum(u32) { embedded = 1, outbound_only = 2, network_node = 3, _ };

/// Strings are sentinel-terminated borrows for one synchronous Core apply.
/// Presence, address and port policy are validated by Core, including zero.
pub const Config = extern struct {
    struct_size: usize = @sizeOf(Config),
    fields: u64,
    mode: Mode,
    reserved: u32 = 0,
    bind_host: ?[*:0]const u8 = null,
    advertise_host: ?[*:0]const u8 = null,
    bind_port: u16 = 0,
    advertise_port: u16 = 0,
    reserved2: u32 = 0,

    pub fn embedded() Config {
        return .{ .fields = 0x01, .mode = .embedded };
    }
    pub fn outboundOnly() Config {
        return .{ .fields = 0x01, .mode = .outbound_only };
    }
    pub fn networkNode(bind_host: [*:0]const u8, bind_port: u16, advertise_host: [*:0]const u8, advertise_port: u16) Config {
        return .{ .fields = 0x1f, .mode = .network_node, .bind_host = bind_host, .bind_port = bind_port, .advertise_host = advertise_host, .advertise_port = advertise_port };
    }
};

/// The exact public Core snapshot layout. Its strings remain Core-owned.
pub const NativeSnapshot = extern struct {
    struct_size: usize = @sizeOf(NativeSnapshot),
    mode: u32 = 0,
    explicit_policy: u32 = 0,
    bind_host: ?[*:0]const u8 = null,
    advertise_host: ?[*:0]const u8 = null,
    bind_port: u16 = 0,
    advertise_port: u16 = 0,
    reserved: u32 = 0,
};

/// Bounded connector-owned output storage; overflow refuses projection.
/// This output capacity does not validate or rewrite Core input policy.
pub const Host = struct {
    bytes: [256]u8 = [_]u8{0} ** 256,
    len: usize = 0,
    pub fn slice(self: *const Host) []const u8 {
        return self.bytes[0..self.len];
    }
};

/// Accepted immutable policy copied during startup, independent of Core lifetime.
pub const Snapshot = struct {
    mode: u32,
    explicit_policy: bool,
    bind_host: Host,
    advertise_host: Host,
    bind_port: u16,
    advertise_port: u16,
};

fn copyHost(text: ?[*:0]const u8) !Host {
    var out = Host{};
    if (text) |value| {
        while (out.len < out.bytes.len) : (out.len += 1) {
            if (value[out.len] == 0) return out;
            out.bytes[out.len] = value[out.len];
        }
        return error.NetworkHostProjectionOverflow;
    }
    return out;
}

/// Copy while the runtime is alive and before any concurrent apply/destroy.
/// Failure returns no snapshot; the caller retires its partially started owner.
pub fn project(raw: NativeSnapshot) !Snapshot {
    return .{ .mode = raw.mode, .explicit_policy = raw.explicit_policy != 0, .bind_host = try copyHost(raw.bind_host), .advertise_host = try copyHost(raw.advertise_host), .bind_port = raw.bind_port, .advertise_port = raw.advertise_port };
}

test "network ABI matches the installed 64-bit C snapshot" {
    try std.testing.expectEqual(@as(usize, 48), @sizeOf(Config));
    try std.testing.expectEqual(@as(usize, 40), @sizeOf(NativeSnapshot));
    try std.testing.expectEqual(@as(usize, 16), @offsetOf(NativeSnapshot, "bind_host"));
    try std.testing.expectEqual(@as(usize, 32), @offsetOf(NativeSnapshot, "bind_port"));
}

test "network intent preserves explicit zero and omitted fields" {
    const value = Config.networkNode("127.0.0.1", 8123, "host", 0);
    try std.testing.expectEqual(@as(u16, 0), value.advertise_port);
    const omitted = Config{ .fields = 1, .mode = .network_node };
    try std.testing.expectEqual(@as(?[*:0]const u8, null), omitted.bind_host);
    try std.testing.expectEqual(@as(u16, 0), omitted.bind_port);
}

test "network projection owns exact strings and fails closed on overflow" {
    var input: [4:0]u8 = "node".*;
    const snapshot = try project(.{ .mode = 777, .explicit_policy = 1, .bind_host = &input });
    input[0] = 'x';
    try std.testing.expectEqualStrings("node", snapshot.bind_host.slice());
    try std.testing.expectEqual(@as(u32, 777), snapshot.mode);
    try std.testing.expectEqual(@as(usize, 0), snapshot.advertise_host.len);
    var limit: [255:0]u8 = @splat('a');
    try std.testing.expectEqual(@as(usize, 255), (try project(.{ .bind_host = &limit })).bind_host.len);
    var overflow: [256:0]u8 = @splat('a');
    try std.testing.expectError(error.NetworkHostProjectionOverflow, project(.{ .bind_host = &overflow }));
}
