const std = @import("std");
const runtime = @import("runtime.zig");

const CFile = opaque {};
extern "c" fn fopen(path: [*:0]const u8, mode: [*:0]const u8) ?*CFile;
extern "c" fn fwrite(data: *const anyopaque, size: usize, count: usize, file: *CFile) usize;
extern "c" fn fclose(file: *CFile) c_int;
extern "c" fn remove(path: [*:0]const u8) c_int;

fn require(condition: bool, message: []const u8) !void {
    if (!condition) {
        std.debug.print("zig transport smoke failed: {s}\n", .{message});
        return error.TransportSmokeFailed;
    }
}

fn takeStarted(result: runtime.StartHostResult) !runtime.RuntimeHost {
    return switch (result) {
        .started => |host| host,
        .startup_rejected => error.UnexpectedStartupRejection,
        .security_rejected => error.UnexpectedSecurityRejection,
        .network_rejected => error.UnexpectedNetworkRejection,
    };
}

fn verifyEmbeddedNul(native: *runtime.NativeRuntime) !void {
    var spec = runtime.smokeSpec();
    spec.security = .{ .credential_id = "truncated\x00credential" };
    const result = native.startHost(spec) catch |err| {
        if (err == error.EmbeddedNul) return;
        return err;
    };
    var host = try takeStarted(result);
    host.deinit();
    return error.EmbeddedNulWasAccepted;
}

fn pathZ(buffer: []u8, root: []const u8, name: []const u8) ![:0]u8 {
    return try std.fmt.bufPrintZ(buffer, "{s}/{s}", .{ root, name });
}

fn runFileLaneSmoke(native: *runtime.NativeRuntime, root: []const u8) !void {
    var source_buf: [4096]u8 = undefined;
    var destination_buf: [4096]u8 = undefined;
    const source = try pathZ(&source_buf, root, "source.bin");
    const destination = try pathZ(&destination_buf, root, "destination.bin");
    _ = remove(source.ptr);
    _ = remove(destination.ptr);
    defer {
        _ = remove(source.ptr);
        _ = remove(destination.ptr);
    }
    const file = fopen(source.ptr, "wb") orelse return error.PayloadOpenFailed;
    var block: [64 * 1024]u8 = undefined;
    for (&block, 0..) |*value, index| value.* = @truncate(index * 31 + 17);
    var remaining: usize = 9 * 1024 * 1024 + 731;
    while (remaining != 0) {
        const count = @min(remaining, block.len);
        if (fwrite(&block, 1, count, file) != count) return error.PayloadWriteFailed;
        remaining -= count;
    }
    if (fclose(file) != 0) return error.PayloadWriteFailed;
    const digest = try native.fileSha256(source.ptr);
    const receiver_config = runtime.FileLaneConfig{ .flags = 2 };
    const sender_config = runtime.FileLaneConfig{ .flags = 1 };
    var receiver = try native.openOwnedFileLane(receiver_config, .{ .owner_instance_id = "zig-file-replica-2", .advertised_host = "127.0.0.1" });
    defer receiver.close() catch {};
    var sender = try native.openFileLane(sender_config);
    defer sender.close() catch {};
    const id: [:0]const u8 = "zig-file-lane-multi-quantum";
    const token: [:0]const u8 = "zig-file-lane-token";
    const receive = runtime.FileReceiveSpec{ .transfer_id = id.ptr, .authorization_token = token.ptr, .destination_path = destination.ptr, .expected_size = digest.size, .expected_sha256 = digest.sha256 };
    const grant = try receiver.prepareReceiveGrant(&receive);
    if (!std.mem.eql(u8, grant.owner.ownerInstanceId(), "zig-file-replica-2") or grant.owner.port == 0) return error.InvalidOwnerGrant;
    const send = grant.toSendSpec(source.ptr, 0);
    try sender.submitSend(&send);
    var send_sequence: u64 = 0;
    var receive_sequence: u64 = 0;
    var sent: runtime.FileTransferSnapshot = undefined;
    var received: runtime.FileTransferSnapshot = undefined;
    for (0..64) |_| {
        sent = try sender.waitTransfer(id.ptr, 1, send_sequence, 30_000);
        if (sent.terminal()) break;
        send_sequence = sent.update_sequence;
    } else return error.TransferTimeout;
    for (0..64) |_| {
        received = try receiver.waitTransfer(id.ptr, 2, receive_sequence, 30_000);
        if (received.terminal()) break;
        receive_sequence = received.update_sequence;
    } else return error.TransferTimeout;
    if (!sent.succeeded() or !received.succeeded()) return error.TransferFailed;
    const destination_digest = try native.fileSha256(destination.ptr);
    if (!std.mem.eql(u8, &digest.sha256, &destination_digest.sha256) or digest.size != destination_digest.size) return error.PayloadMismatch;
}

const StreamSourceContext = struct {
    lock: std.atomic.Mutex = .unlocked,
    payload: []const u8,
    offset: usize = 0,
};
const StreamSinkContext = struct {
    lock: std.atomic.Mutex = .unlocked,
    storage: []u8,
    offset: usize = 0,
};
fn streamSource(context: ?*anyopaque, destination: [*]u8, capacity: usize, frame: *runtime.stream_lane.Frame) callconv(.c) c_int {
    const source: *StreamSourceContext = @ptrCast(@alignCast(context orelse return -1));
    while (!source.lock.tryLock()) std.atomic.spinLoopHint();
    defer source.lock.unlock();
    if (source.offset == source.payload.len) return -7;
    const count = @min(capacity, source.payload.len - source.offset);
    @memcpy(destination[0..count], source.payload[source.offset..][0..count]);
    source.offset += count;
    frame.size = count;
    return 0;
}
fn streamConsumer(context: ?*anyopaque, data: [*]const u8, frame: *const runtime.stream_lane.Frame) callconv(.c) c_int {
    const sink: *StreamSinkContext = @ptrCast(@alignCast(context orelse return -1));
    while (!sink.lock.tryLock()) std.atomic.spinLoopHint();
    defer sink.lock.unlock();
    if (frame.size == 0 or sink.offset + frame.size > sink.storage.len) return -1;
    @memcpy(sink.storage[sink.offset..][0..frame.size], data[0..frame.size]);
    sink.offset += frame.size;
    return 0;
}

fn runStreamLaneSmoke(native: *runtime.NativeRuntime) !void {
    const allocator = std.heap.page_allocator;
    const payload = try allocator.alloc(u8, 2 * 1024 * 1024 + 731);
    defer allocator.free(payload);
    for (payload, 0..) |*value, index| value.* = @truncate(index * 31 + 17);
    const received = try allocator.alloc(u8, payload.len);
    defer allocator.free(received);
    var source = StreamSourceContext{ .payload = payload };
    var sink = StreamSinkContext{ .storage = received };
    var publisher = try native.openOwnedStreamLane(.{ .flags = runtime.stream_lane.Publisher }, .{ .owner_instance_id = "zig-stream-replica-3", .advertised_host = "127.0.0.1" });
    defer publisher.close() catch {};
    var subscriber = try native.openStreamLane(.{ .flags = runtime.stream_lane.Subscriber });
    defer subscriber.close() catch {};
    const id: [:0]const u8 = "zig-stream-lane";
    const token: [:0]const u8 = "zig-stream-token";
    const publish = runtime.StreamPublishSpec{ .session_id = id.ptr, .authorization_token = token.ptr, .format_id = 0x43414d31, .max_frame_bytes = 64 * 1024, .source_next = streamSource, .source_context = &source };
    const grant = try publisher.preparePublishGrant(&publish);
    if (!std.mem.eql(u8, grant.owner.ownerInstanceId(), "zig-stream-replica-3") or grant.owner.port == 0) return error.InvalidOwnerGrant;
    const subscribe = grant.toSubscribeSpec(256 * 1024, 0, streamConsumer, &sink);
    try subscriber.subscribe(&subscribe);
    var publish_sequence: u64 = 0;
    var subscribe_sequence: u64 = 0;
    var published: runtime.StreamSessionSnapshot = undefined;
    var consumed: runtime.StreamSessionSnapshot = undefined;
    for (0..64) |_| {
        published = try publisher.waitSession(id.ptr, runtime.stream_lane.DirectionPublish, publish_sequence, 30_000);
        if (published.terminal()) break;
        publish_sequence = published.update_sequence;
    } else return error.StreamTimeout;
    for (0..64) |_| {
        consumed = try subscriber.waitSession(id.ptr, runtime.stream_lane.DirectionSubscribe, subscribe_sequence, 30_000);
        if (consumed.terminal()) break;
        subscribe_sequence = consumed.update_sequence;
    } else return error.StreamTimeout;
    if (!published.succeeded() or !consumed.succeeded() or sink.offset != payload.len or
        !std.mem.eql(u8, payload, received)) return error.StreamPayloadMismatch;
    _ = try publisher.getPressure(id.ptr, runtime.stream_lane.DirectionPublish);
    const stats = try subscriber.getStats();
    if (stats.consumed_bytes != payload.len) return error.StreamStatsMismatch;
}

const network_overflow_host: [256:0]u8 = @splat('x');
fn oversizedNetworkOutput(_: ?*runtime.Runtime, out: *@import("network.zig").NativeSnapshot) callconv(.c) c_int {
    out.* = .{ .mode = 777, .bind_host = &network_overflow_host };
    return 0;
}

// Network validation and accepted presence are Core facts, never local inference.
fn verifyNetworkIntent(native: *runtime.NativeRuntime) !void {
    const network = @import("network.zig");
    for ([_]runtime.NetworkConfig{ .embedded(), .outboundOnly() }) |intent| {
        var spec = runtime.smokeSpec();
        spec.network = intent;
        var host = try takeStarted(try native.startHost(spec));
        defer host.deinit();
        const accepted = try host.networkConfig();
        try require(accepted.mode == @intFromEnum(intent.mode) and accepted.explicit_policy, "Core accepted explicit network policy");
        try require(accepted.bind_host.len == 0 and accepted.advertise_host.len == 0 and accepted.bind_port == 0 and accepted.advertise_port == 0, "Core absent network endpoints");
    }
    const invalid = [_]runtime.NetworkConfig{
        .networkNode("127.0.0.1", 39191, "node.example", 0),
        .networkNode("127.0.0.1", 0, "node.example", 39192),
        .networkNode("not-an-address", 39191, "node.example", 39192),
        .networkNode("127.0.0.1", 39191, "0.0.0.0", 39192),
        .{ .fields = 1, .mode = .network_node },
        .{ .fields = 0, .mode = .embedded },
        .{ .fields = 0x100, .mode = .embedded },
        .{ .fields = 1, .mode = @enumFromInt(999) },
        .{ .fields = 1, .mode = .embedded, .bind_host = "127.0.0.1" },
        .{ .fields = 3, .mode = .outbound_only },
    };
    for (invalid) |intent| {
        var spec = runtime.smokeSpec();
        spec.network = intent;
        switch (try native.startHost(spec)) {
            .network_rejected => |status| try require(status.eql(.invalid_argument), "Core typed network refusal"),
            .started => |value| { var host = value; host.deinit(); return error.InvalidNetworkAccepted; },
            else => return error.UnexpectedNetworkRefusalStage,
        }
    }
    // A created Core owner accepts valid node endpoints without starting a
    // listener. This fixture owns no port and adds no platform probing.
    const config = runtime.RuntimeConfig{ .system_name = "zig-network-copy", .node_id = "zig-network-copy", .strict_no_drop = 1, .queue_capacity = 0 };
    var owner: ?*runtime.Runtime = null;
    try require(native.create_native(&config, null, &owner) == 0 and owner != null, "network projection fixture owner");
    defer if (owner != null) native.destroy(owner);
    var advertised: [12:0]u8 = "node.example".*;
    const node = runtime.NetworkConfig.networkNode("127.0.0.1", 39191, &advertised, 39192);
    try require(native.apply_network(owner, &node) == 0, "Core accepted node endpoints");
    advertised[0] = 'x';
    var raw = network.NativeSnapshot{};
    try require(native.get_network_config(owner, &raw) == 0, "Core network getter");
    const accepted = try network.project(raw);
    native.destroy(owner);
    owner = null;
    try require(accepted.mode == 3 and accepted.explicit_policy, "Core explicit node fact");
    try require(std.mem.eql(u8, accepted.bind_host.slice(), "127.0.0.1") and std.mem.eql(u8, accepted.advertise_host.slice(), "node.example"), "network copied input and output lifetimes");
    try require(accepted.bind_port == 39191 and accepted.advertise_port == 39192, "Core accepted node ports");
    // Fault only the FFI output projection, after real Core startup. The existing
    // errdefer must retire the partially started owner and release its host slot.
    const getter = native.get_network_config;
    native.get_network_config = oversizedNetworkOutput;
    const failure = native.startHost(runtime.smokeSpec());
    native.get_network_config = getter;
    if (failure) |value| {
        if (value == .started) { var leaked = value.started; leaked.deinit(); }
        return error.OversizedNetworkOutputAccepted;
    } else |err| try require(err == error.NetworkHostProjectionOverflow, "projection failure is explicit");
    var recovered = try takeStarted(try native.startHost(runtime.smokeSpec()));
    defer recovered.deinit();
    try require((try recovered.networkConfig()).mode == 1, "projection failure retired its owner");
}

pub fn main(init: std.process.Init) !void {
    const lib_path = init.environ_map.get("COAKKA_RUNTIME_LIB") orelse {
        std.debug.print("set COAKKA_RUNTIME_LIB=/path/to/libcoakka_runtime_v2\n", .{});
        return error.MissingRuntimeLibraryPath;
    };

    const sizes = runtime.transport.abiSizes();
    try require(sizes.capabilities == 48, "capabilities ABI size");
    try require(sizes.connection_options == 48, "connection options ABI size");
    try require(sizes.connection_validation == 40, "connection validation ABI size");
    try require(sizes.connection_config == 72, "connection config ABI size");
    try require(sizes.connection_apply_result == 136, "connection result ABI size");
    try require(sizes.security_options == 72, "security options ABI size");
    try require(sizes.security_validation == 24, "security validation ABI size");
    try require(sizes.security_config == 40, "security config ABI size");
    try require(sizes.security_identity == 248, "security identity ABI size");
    try require(sizes.security_info == 296, "security info ABI size");
    try require(sizes.security_apply_result == 344, "security result ABI size");

    var native = try runtime.NativeRuntime.open(lib_path);
    defer native.close();
    if (init.environ_map.get("COAKKA_FILE_LANE_SMOKE") != null) try runFileLaneSmoke(&native, init.environ_map.get("TMPDIR") orelse return error.MissingWorkDirectory);
    if (init.environ_map.get("COAKKA_STREAM_LANE_SMOKE") != null) try runStreamLaneSmoke(&native);
    const info = try native.readInfo();
    const capabilities = try native.readCapabilities();
    try verifyNetworkIntent(&native);
    const mode: runtime.TcpConnectionMode = if (capabilities.effective.supports(.tcp_bounded_pool))
        .bounded_pool
    else
        .per_exchange;

    var default_config: runtime.StartupSnapshot = undefined;
    {
        var host = try takeStarted(try native.startHost(runtime.smokeSpec()));
        defer host.deinit();
        const accepted = try host.startupConfig();
        default_config = accepted;
        const accepted_network = try host.networkConfig();
        try require(accepted_network.mode == 1 and !accepted_network.explicit_policy, "Core omitted embedded policy presence");
        try require(accepted.defaulted_groups == 15 and accepted.execution.requested_policy == 0 and
            accepted.connection.mode == 3 and accepted.monitor.enabled == 0 and accepted.io.requested == 0, "Core-owned defaults");
        try host.smokeRawRoundTrip();
        try host.smokeCancelAndLateReply();
        try host.smokeRawRoundTrip();
        try host.smokeRouteMissDeadletter();
        host.deinit();
        try std.testing.expectError(error.RuntimeClosed, host.startupConfig());
        try std.testing.expectError(error.RuntimeClosed, host.stats());
        try std.testing.expectError(error.RuntimeClosed, host.networkConfig());
        host.deinit();
    }

    var invalid_mode_spec = runtime.smokeSpec();
    invalid_mode_spec.connection_strategy = .{ .mode = .{ .value = 999 } };
    switch (try native.startHost(invalid_mode_spec)) {
        .startup_rejected => |status| {
            try require(status.eql(.invalid_argument), "unknown construction mode status");
        },
        .started => |value| {
            var host = value;
            host.deinit();
            return error.UnknownModeWasAccepted;
        },
        .security_rejected => return error.UnexpectedSecurityRejection,
        .network_rejected => return error.UnexpectedNetworkRejection,
    }

    var plaintext_fields_spec = runtime.smokeSpec();
    plaintext_fields_spec.security = .{
        .credential_generation = 1,
        .credential_id = "must-not-be-ignored",
    };
    switch (try native.startHost(plaintext_fields_spec)) {
        .security_rejected => |result| {
            try require(result.status.eql(.invalid_argument), "plaintext field status");
            try require(result.validation_code.value == 7, "plaintext field validation");
            try require(result.active_security.credential_generation == 0, "plaintext rejection state");
        },
        .started => |value| {
            var host = value;
            host.deinit();
            return error.PlaintextFieldsWereAccepted;
        },
        .startup_rejected => return error.UnexpectedStartupRejection,
        .network_rejected => return error.UnexpectedNetworkRejection,
    }

    try verifyEmbeddedNul(&native);

    {
        var configured_spec = runtime.smokeSpec();
        configured_spec.connection_strategy = .{ .mode = mode };
        configured_spec.security = .{};
        var host = try takeStarted(try native.startHost(configured_spec));
        defer host.deinit();

        const stats = try host.stats();
        try require(runtime.isStarted(stats, 1, 1), "runtime stats");
        try require((try host.capabilities()).effective.value == capabilities.effective.value, "capabilities");
        try require((try host.startupConfig()).connection.mode == mode.value, "accepted construction connection");
        try require(host.startup_security_result != null, "security startup result");
        try require(host.startup_security_result.?.applied(), "security startup apply");
        try require((try host.connectionConfig()).mode.eql(mode), "effective connection mode");

        const rejected = try host.applyConnectionStrategy(.{});
        try require(rejected.status.eql(.bad_state), "post-start connection status");
        try require(!rejected.changed, "post-start connection changed state");
        try require(rejected.active_config.mode.eql(mode), "post-start active mode");
        try host.smokeRawRoundTrip();
        try host.smokeCancelAndLateReply();
        try host.smokeRawRoundTrip();
        try host.smokeRouteMissDeadletter();
    }

    var tls_executed = false;
    if (capabilities.effective.supports(.tcp_tls)) {
        if (init.environ_map.get("COAKKA_TLS_FIXTURE_ROOT")) |fixture_root| {
            var ca_buffer: [4096]u8 = undefined;
            var cert_buffer: [4096]u8 = undefined;
            var server_key_buffer: [4096]u8 = undefined;
            var client_key_buffer: [4096]u8 = undefined;
            const ca_file = try pathZ(&ca_buffer, fixture_root, "ca.pem");
            const cert_file = try pathZ(&cert_buffer, fixture_root, "server.pem");
            const server_key = try pathZ(&server_key_buffer, fixture_root, "server.key");
            const client_key = try pathZ(&client_key_buffer, fixture_root, "client.key");

            var tls_spec = runtime.smokeSpec();
            tls_spec.security = .{
                .mode = .tls,
                .credential_generation = 1,
                .credential_id = "zig-generation-1",
                .ca_certificate_file = ca_file,
                .identity_certificate_file = cert_file,
                .private_key_file = server_key,
            };
            var host = try takeStarted(try native.startHost(tls_spec));
            defer host.deinit();

            const startup = host.startup_security_result orelse return error.MissingTlsStartupResult;
            try require(startup.applied(), "TLS startup status");
            try require(startup.active_security.credential_generation == 1, "TLS startup generation");
            try require(startup.active_security.identity_fingerprint_sha256.slice().len == 64, "TLS fingerprint");

            const bad_reload = try host.applySecurity(.{
                .mode = .tls,
                .credential_generation = 2,
                .credential_id = "zig-generation-2-bad",
                .ca_certificate_file = ca_file,
                .identity_certificate_file = cert_file,
                .private_key_file = client_key,
            });
            try require(bad_reload.status.eql(.invalid_argument), "bad TLS reload status");
            try require(!bad_reload.changed, "bad TLS reload changed state");
            try require(bad_reload.active_security.credential_generation == 1, "bad TLS reload generation");
            try require((try host.securityInfo()).credential_generation == 1, "TLS getter after rejection");

            const applied = try host.applySecurity(.{
                .mode = .tls,
                .credential_generation = 2,
                .credential_id = "zig-generation-2",
                .ca_certificate_file = ca_file,
                .identity_certificate_file = cert_file,
                .private_key_file = server_key,
            });
            try require(applied.applied() and applied.changed, "valid TLS reload status");
            try require(applied.active_security.credential_generation == 2, "valid TLS generation");

            const stale = try host.applySecurity(.{
                .mode = .tls,
                .credential_generation = 1,
                .credential_id = "zig-generation-1-stale",
                .ca_certificate_file = ca_file,
                .identity_certificate_file = cert_file,
                .private_key_file = server_key,
            });
            try require(stale.status.eql(.invalid_argument), "stale TLS status");
            try require(!stale.changed, "stale TLS changed state");
            try require(stale.active_security.credential_generation == 2, "stale TLS generation");
            tls_executed = true;
        }
    }

    std.debug.print(
        "coakka_runtime_zig_smoke abi={d} runtime={s} git={s} capabilities={d} defaultMode={d} cpuPolicy={d} selectedCpuCount={d} cpuApplied={d} monitor={d} explicitMode={d} tls_executed={} rawRoundTrip=ok cancelLateReply=ok routeMissDeadletter=ok networkIntent=ok\n",
        .{
            info.abi_version,
            cstr(info.runtime_version),
            cstr(info.git_commit),
            capabilities.effective.value,
            default_config.connection.mode,
            default_config.execution.requested_policy,
            default_config.execution.selected_cpu_count,
            default_config.execution.startup_applied,
            default_config.monitor.enabled,
            mode.value,
            tls_executed,
        },
    );
}

fn cstr(value: ?[*:0]const u8) []const u8 {
    if (value) |ptr| return std.mem.span(ptr);
    return "";
}
