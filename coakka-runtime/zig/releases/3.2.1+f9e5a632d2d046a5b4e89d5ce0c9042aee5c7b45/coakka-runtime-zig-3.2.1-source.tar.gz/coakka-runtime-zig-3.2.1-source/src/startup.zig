const transport = @import("transport.zig");

/// Only submitted connection intent is populated; omitted groups stay Core-owned.
pub const NativeOptions = extern struct {
    struct_size: usize = @sizeOf(NativeOptions),
    execution: ?*const anyopaque = null,
    connection: ?*const transport.NativeConnectionOptions = null,
    io: ?*const anyopaque = null,
    monitor: ?*const anyopaque = null,
};

/// Core-issued CPU placement facts; unsupported placement is represented as reported.
pub const CpuInfo = extern struct {
    requested_policy: u32,
    supported: u32,
    available_cpu_count: u32,
    selected_cpu_count: u32,
    selected_cpu_ids: [2]u32,
    startup_applied: u32,
    reserved: u32,
};
pub const IoInfo = extern struct {
    requested: u32,
    compiled: u32,
    probed: u32,
    supported: u32,
    effective: u32,
    probe_error: i32,
};
pub const MonitorInfo = extern struct { enabled: u32, reserved: u32 };

/// One pointer-free accepted startup snapshot, copied only when requested.
pub const Snapshot = extern struct {
    struct_size: usize = @sizeOf(Snapshot),
    defaults_revision: u32,
    defaulted_groups: u32,
    strict_no_drop: i32,
    queue_capacity: u32,
    request_max_frame_size: u64,
    runtime_state: u32,
    reserved: u32,
    execution: CpuInfo,
    connection: transport.NativeConnectionConfig,
    io: IoInfo,
    monitor: MonitorInfo,
};

test "startup ABI matches the public 64-bit C contract" {
    const std = @import("std");
    try std.testing.expectEqual(@as(usize, 40), @sizeOf(NativeOptions));
    try std.testing.expectEqual(@as(usize, 176), @sizeOf(Snapshot));
    try std.testing.expectEqual(@as(usize, 40), @offsetOf(Snapshot, "execution"));
    try std.testing.expectEqual(@as(usize, 72), @offsetOf(Snapshot, "connection"));
    try std.testing.expectEqual(@as(usize, 144), @offsetOf(Snapshot, "io"));
    try std.testing.expectEqual(@as(usize, 168), @offsetOf(Snapshot, "monitor"));
}
