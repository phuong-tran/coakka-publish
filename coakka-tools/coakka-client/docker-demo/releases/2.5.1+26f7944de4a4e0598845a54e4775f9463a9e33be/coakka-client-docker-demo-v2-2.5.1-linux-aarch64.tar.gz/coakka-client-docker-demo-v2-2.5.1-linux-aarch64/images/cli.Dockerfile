FROM ubuntu:24.04@sha256:4fbb8e6a8395de5a7550b33509421a2bafbc0aab6c06ba2cef9ebffbc7092d90

LABEL org.opencontainers.image.base.name="docker.io/library/ubuntu:24.04" \
      io.coakka.base.digest="sha256:4fbb8e6a8395de5a7550b33509421a2bafbc0aab6c06ba2cef9ebffbc7092d90"

COPY artifacts/cli/ /opt/coakka/
COPY payloads/ /opt/coakka-demo/payloads/

ENV LD_LIBRARY_PATH=/opt/coakka/lib
WORKDIR /opt/coakka-demo

ENTRYPOINT ["/opt/coakka/bin/coakka-client"]
