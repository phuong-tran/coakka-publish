#ifndef COAKKA_V2_EVENT_SERVICE_H
#define COAKKA_V2_EVENT_SERVICE_H

/*
 * Umbrella include for the future coakka-event-service public C ABI.
 *
 * Include this file when callers want both the noun/value types and the API
 * entrypoints. The current tree still does not ship a runnable implementation
 * behind these declarations yet.
 */
#include "coakka/v2/event_service_types.h"
#include "coakka/v2/event_service_api.h"

#endif
