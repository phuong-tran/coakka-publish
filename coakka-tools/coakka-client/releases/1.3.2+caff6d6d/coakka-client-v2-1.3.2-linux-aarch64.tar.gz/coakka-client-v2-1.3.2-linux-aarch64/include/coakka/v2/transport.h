#ifndef COAKKA_V2_TRANSPORT_H
#define COAKKA_V2_TRANSPORT_H

#include <stddef.h>
#include <stdint.h>

#include "coakka/v2/runtime.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct coakka_v2_frame_reader_t coakka_v2_frame_reader_t;

/*
 * Stable deadletter reason vocabulary shared by framed runtime deadletter
 * payloads and public C clients. Numeric values intentionally match
 * coakka.v2.transport.DeadletterReason in the protobuf wire profile.
 */
typedef enum coakka_v2_deadletter_reason_t {
    COAKKA_V2_DEADLETTER_REASON_UNSPECIFIED = 0u,
    COAKKA_V2_DEADLETTER_REASON_NO_ACTIVE_SNAPSHOT = 1u,
    COAKKA_V2_DEADLETTER_REASON_ROUTE_MISS = 2u,
    COAKKA_V2_DEADLETTER_REASON_NO_RESPONSIBLE_HOST = 3u,
    COAKKA_V2_DEADLETTER_REASON_QUEUE_REJECTED = 4u,
    COAKKA_V2_DEADLETTER_REASON_LOCAL_HANDOFF_FAILED = 5u,
    COAKKA_V2_DEADLETTER_REASON_DELIVERY_FAILED = 6u,
    COAKKA_V2_DEADLETTER_REASON_REMOTE_TRANSPORT_FAILED = 7u,
    COAKKA_V2_DEADLETTER_REASON_RUNTIME_STOPPED = 8u,
    COAKKA_V2_DEADLETTER_REASON_INVALID_ENVELOPE = 9u,
    COAKKA_V2_DEADLETTER_REASON_ENDPOINT_UNAVAILABLE = 10u,
    COAKKA_V2_DEADLETTER_REASON_REMOTE_REPLY_TIMEOUT = 11u,
    COAKKA_V2_DEADLETTER_REASON_LOCALITY_MISMATCH = 12u,
    COAKKA_V2_DEADLETTER_REASON_EXPIRED_BEFORE_DELIVERY = 13u,
    COAKKA_V2_DEADLETTER_REASON_ONE_WAY_DROPPED_BY_POLICY = 14u
} coakka_v2_deadletter_reason_t;

/*
 * Stable transport-envelope vocabulary. Numeric values intentionally match the
 * protobuf wire profile, but hosts should use these C values instead of
 * importing or generating protobuf code for payload-facing connector paths.
 */
typedef enum coakka_v2_message_kind_t {
    COAKKA_V2_MESSAGE_KIND_UNSPECIFIED = 0u,
    COAKKA_V2_MESSAGE_KIND_REQUEST = 1u,
    COAKKA_V2_MESSAGE_KIND_RESPONSE = 2u,
    COAKKA_V2_MESSAGE_KIND_EVENT = 3u
} coakka_v2_message_kind_t;

typedef enum coakka_v2_business_status_t {
    COAKKA_V2_BUSINESS_STATUS_UNSPECIFIED = 0u,
    COAKKA_V2_BUSINESS_STATUS_OK = 1u,
    COAKKA_V2_BUSINESS_STATUS_ERROR = 2u
} coakka_v2_business_status_t;

typedef enum coakka_v2_delivery_hint_t {
    COAKKA_V2_DELIVERY_HINT_UNSPECIFIED = 0u,
    COAKKA_V2_DELIVERY_HINT_ROUTER_DEFAULT = 1u,
    COAKKA_V2_DELIVERY_HINT_PREFER_LOCAL = 2u,
    COAKKA_V2_DELIVERY_HINT_REQUIRE_LOCAL = 3u,
    COAKKA_V2_DELIVERY_HINT_REQUIRE_REMOTE = 4u
} coakka_v2_delivery_hint_t;

typedef enum coakka_v2_payload_format_t {
    COAKKA_V2_PAYLOAD_FORMAT_UNSPECIFIED = 0u,
    COAKKA_V2_PAYLOAD_FORMAT_JSON = 1u,
    COAKKA_V2_PAYLOAD_FORMAT_PROTOBUF = 2u,
    COAKKA_V2_PAYLOAD_FORMAT_THRIFT = 3u,
    COAKKA_V2_PAYLOAD_FORMAT_MSGPACK = 4u,
    COAKKA_V2_PAYLOAD_FORMAT_PLAIN_TEXT = 5u,
    COAKKA_V2_PAYLOAD_FORMAT_BINARY = 6u
} coakka_v2_payload_format_t;

typedef struct coakka_v2_transport_header_t {
    const char *key;
    const char *value;
} coakka_v2_transport_header_t;

typedef struct coakka_v2_transport_header_view_t {
    char *key;
    char *value;
} coakka_v2_transport_header_view_t;

/*
 * Payload-facing envelope input for hosts that should not own protobuf encode
 * logic. The caller owns all pointers for the duration of
 * coakka_v2_transport_build_envelope(). The returned wire buffer is owned by
 * the caller and must be released with coakka_v2_transport_buffer_release().
 */
typedef struct coakka_v2_transport_envelope_t {
    size_t struct_size;
    const char *message_id;
    const char *correlation_id;
    const char *source;
    const char *target;
    const char *reply_to;
    uint32_t kind;
    int one_way;
    int32_t timeout_ms;
    const uint8_t *payload;
    size_t payload_len;
    const coakka_v2_transport_header_t *headers;
    size_t header_count;
    uint32_t status;
    const char *error_code;
    const char *error_message;
    uint32_t delivery_hint;
    const char *message_type;
    uint32_t payload_schema_version;
    uint32_t payload_format;
} coakka_v2_transport_envelope_t;

/*
 * Native-owned decoded transport envelope. Call
 * coakka_v2_transport_envelope_view_init() before first use and
 * coakka_v2_transport_envelope_view_cleanup() after each successful or partial
 * parse. Strings, headers, and payload are released by cleanup.
 */
typedef struct coakka_v2_transport_envelope_view_t {
    size_t struct_size;
    coakka_v2_transport_header_view_t *headers;
    size_t header_count;
    char *message_id;
    char *correlation_id;
    char *source;
    char *target;
    char *reply_to;
    char *message_type;
    char *error_code;
    char *error_message;
    uint8_t *payload;
    size_t payload_len;
    uint32_t kind;
    int one_way;
    int32_t timeout_ms;
    uint32_t payload_schema_version;
    uint32_t payload_format;
    uint32_t delivery_hint;
    uint32_t status;
} coakka_v2_transport_envelope_view_t;

typedef struct coakka_v2_transport_deadletter_view_t {
    size_t struct_size;
    coakka_v2_transport_envelope_view_t original_envelope;
    char *detail;
    char *resolved_host;
    uint32_t reason;
    uint64_t active_generation;
    uint32_t resolved_port;
    uint32_t endpoint_attempt_count;
} coakka_v2_transport_deadletter_view_t;

void coakka_v2_transport_envelope_view_init(
    coakka_v2_transport_envelope_view_t *view);

void coakka_v2_transport_envelope_view_cleanup(
    coakka_v2_transport_envelope_view_t *view);

void coakka_v2_transport_deadletter_view_init(
    coakka_v2_transport_deadletter_view_t *view);

void coakka_v2_transport_deadletter_view_cleanup(
    coakka_v2_transport_deadletter_view_t *view);

coakka_v2_status_t coakka_v2_transport_build_envelope(
    const coakka_v2_transport_envelope_t *envelope,
    uint8_t **out_buf,
    size_t *out_len);

coakka_v2_status_t coakka_v2_transport_parse_envelope(
    const uint8_t *frame_buf,
    size_t frame_len,
    coakka_v2_transport_envelope_view_t *out_view);

coakka_v2_status_t coakka_v2_transport_parse_deadletter(
    const uint8_t *frame_buf,
    size_t frame_len,
    coakka_v2_transport_deadletter_view_t *out_view);

size_t coakka_v2_transport_c_string_length(const char *value);

coakka_v2_status_t coakka_v2_transport_copy_bytes(
    const uint8_t *src,
    size_t src_len,
    uint8_t *out_buf,
    size_t out_buf_len);

void coakka_v2_transport_buffer_release(uint8_t *buf);

/**
 * Creates a bounded framed-pipe reader.
 *
 * The reader does not own fd. The host remains responsible for closing the fd
 * when the lane is no longer needed.
 */
coakka_v2_frame_reader_t *coakka_v2_frame_reader_create(int fd, size_t max_frame_size);

/** Destroys a frame reader without closing the fd passed at creation time. */
void coakka_v2_frame_reader_destroy(coakka_v2_frame_reader_t *reader);

/**
 * Attempts to read one complete frame without blocking the runtime.
 *
 * Returns COAKKA_V2_ERR_WOULD_BLOCK when no full frame is available. On
 * COAKKA_V2_OK, out_buf is caller-owned and must be released with
 * coakka_v2_frame_release(). Frames whose advertised payload length exceeds
 * max_frame_size or cannot be represented safely by the runtime allocator are
 * rejected as COAKKA_V2_ERR_IO.
 */
coakka_v2_status_t coakka_v2_frame_read_try(coakka_v2_frame_reader_t *reader,
                                            uint8_t **out_buf,
                                            size_t *out_len);

/** Writes one length-prefixed frame to fd. The payload span is not retained. */
coakka_v2_status_t coakka_v2_frame_write(int fd,
                                         const uint8_t *payload,
                                         size_t payload_len);

/** Releases a buffer returned by coakka_v2_frame_read_try(). */
void coakka_v2_frame_release(uint8_t *buf);

/**
 * Consumes monitor doorbell bytes and returns the number of signals drained.
 *
 * monitor_read_fd is a wakeup signal. It does not carry serialized monitor
 * event records; refresh stats/health through direct runtime APIs after drain.
 */
coakka_v2_status_t coakka_v2_monitor_consume(int fd, uint64_t *out_signal_count);

#ifdef __cplusplus
}
#endif

#endif
