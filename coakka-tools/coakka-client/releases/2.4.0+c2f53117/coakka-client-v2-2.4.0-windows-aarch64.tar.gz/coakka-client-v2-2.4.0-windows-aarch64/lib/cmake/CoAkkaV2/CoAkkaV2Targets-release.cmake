#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "CoAkkaV2::runtime_v2" for configuration "Release"
set_property(TARGET CoAkkaV2::runtime_v2 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CoAkkaV2::runtime_v2 PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libcoakka_runtime_v2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/libcoakka_runtime_v2.dll"
  )

list(APPEND _cmake_import_check_targets CoAkkaV2::runtime_v2 )
list(APPEND _cmake_import_check_files_for_CoAkkaV2::runtime_v2 "${_IMPORT_PREFIX}/lib/libcoakka_runtime_v2.dll.a" "${_IMPORT_PREFIX}/bin/libcoakka_runtime_v2.dll" )

# Import target "CoAkkaV2::coakka_v2_coakka_client" for configuration "Release"
set_property(TARGET CoAkkaV2::coakka_v2_coakka_client APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CoAkkaV2::coakka_v2_coakka_client PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/coakka-client.exe"
  )

list(APPEND _cmake_import_check_targets CoAkkaV2::coakka_v2_coakka_client )
list(APPEND _cmake_import_check_files_for_CoAkkaV2::coakka_v2_coakka_client "${_IMPORT_PREFIX}/bin/coakka-client.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
