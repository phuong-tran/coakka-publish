# CoAkka Runtime Tools License Map

These tools are free to use in applications, including commercial and
production applications. The licenses apply to their respective materials;
they are not alternative licenses for the package as a whole.

CoAkka-owned compiled native libraries and executables are licensed under the
CoAkka Native Artifact License 1.2 in `NATIVE-LICENSE.md`. Ordinary internal,
production, commercial, application and SaaS use is permitted. A separate
agreement is required to offer CoAkka itself as managed runtime or
substantially equivalent infrastructure, as defined by that license.

CoAkka-owned package documentation and other non-native materials use the
Apache License, Version 2.0 in `LICENSE`.

Incorporated portions owned by other copyright holders retain their applicable
terms. Their copyright, permission, license and disclaimer notices are in
`NOTICE`; the full Apache License, Version 2.0 is in `LICENSE`. Those terms
apply to those portions, not to CoAkka-owned material. CoAkka's native terms
do not replace or narrow the rights granted for those portions.

No separate installation of an incorporated library is required. The package
includes its applicable offline legal material. `NOTICE` is attribution and
license material, not an installation guide.
