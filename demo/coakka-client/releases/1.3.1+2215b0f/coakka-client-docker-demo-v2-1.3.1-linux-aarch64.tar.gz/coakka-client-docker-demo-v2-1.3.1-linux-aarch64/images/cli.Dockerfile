FROM ubuntu:24.04

COPY artifacts/cli/ /opt/coakka/
COPY payloads/ /opt/coakka-demo/payloads/

ENV LD_LIBRARY_PATH=/opt/coakka/lib
WORKDIR /opt/coakka-demo

ENTRYPOINT ["/opt/coakka/bin/coakka-client"]
