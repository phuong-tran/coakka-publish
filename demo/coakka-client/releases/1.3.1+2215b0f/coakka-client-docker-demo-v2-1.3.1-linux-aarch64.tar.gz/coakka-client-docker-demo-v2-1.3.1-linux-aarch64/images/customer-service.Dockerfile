FROM ubuntu:24.04

COPY artifacts/customer-service/ /opt/coakka-demo/

ENV LD_LIBRARY_PATH=/opt/coakka-demo/lib

ENTRYPOINT ["/opt/coakka-demo/bin/coakka-demo-customer-service"]
