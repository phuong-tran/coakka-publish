# `coakka-client` Zero-Install Docker Demo (`linux-x86_64`)

This bundle is the zero-install evaluation path for the public CLI release.

It does not require the sibling source workspace or host-side `cmake`,
`protobuf`, or compiler packages.

The bundle already contains:

- one prebuilt `coakka-client` prefix for `linux-x86_64`
- one prebuilt native demo service for `linux-x86_64`
- one small Docker Compose surface that builds two tiny runtime images from
  those staged artifacts

## Bring Up

```sh
docker compose build
docker compose up -d customer-service
```

## Call The Demo Service

```sh
docker compose run --rm --no-deps -T cli \
  call \
  --host customer-service \
  --port 19091 \
  --route customer.create \
  --payload "customer#42"
```

Expected stdout:

```text
created:customer#42
```

`ask` is the request/reply alias for the same path:

```sh
docker compose run --rm --no-deps -T cli \
  ask \
  --host customer-service \
  --port 19091 \
  --route customer.create \
  --payload "customer#42"
```

Expected stdout is the same request/reply payload shape:

```text
created:customer#42
```

JSON request from a file:

```sh
docker compose run --rm --no-deps -T cli \
  call \
  --host customer-service \
  --port 19091 \
  --route customer.create \
  --payload-file payloads/customer-create.json \
  --content-type application/json \
  --output json
```

Expected stdout contains these stable fields:

```json
{
  "ok": true,
  "content_type": "application/json",
  "request_message_type": "customer.create.request",
  "request_payload_schema_version": 1,
  "payload_format": "JSON",
  "payload_text": "created:{\"customer_id\":\"99\",\"tier\":\"gold\"}"
}
```

JSON request streamed from `stdin`:

```sh
printf '{"customer_id":"stdin","tier":"silver"}' | \
docker compose run --rm --no-deps -T cli \
  call \
  --host customer-service \
  --port 19091 \
  --route customer.create \
  --payload-file - \
  --content-type application/json \
  --header tenant=silver \
  --output json
```

Expected stdout contains:

```json
{
  "ok": true,
  "content_type": "application/json",
  "payload_text": "created:{\"customer_id\":\"stdin\",\"tier\":\"silver\"}"
}
```

Interactive shell against the same service:

```sh
docker compose run --rm --no-deps -it cli \
  shell \
  --host customer-service \
  --port 19091
```

The first shell cut also supports one sourced batch file from inside the same
session:

```text
coakka> source payloads/customer-create-shell.coakka
coakka> payload customer#shell-ask
coakka> ask
coakka> \quit
```

Shell batch files may include full-line comments starting with `#`.

or one shell batch run directly:

```sh
docker compose run --rm --no-deps -T cli \
  shell \
  --host customer-service \
  --port 19091 \
  --script payloads/customer-create-shell.coakka
```

Expected stdout first prints the raw `call` reply, then the raw `ask` reply,
then one JSON envelope:

```text
created:customer#script
created:customer#script-ask
```

```json
{
  "ok": true,
  "content_type": "application/json",
  "payload_text": "created:{\"customer_id\":\"script\",\"tier\":\"violet\"}"
}
```

## Tear Down

```sh
docker compose down -v
```

## Notes

- `compose.yaml` pins the service and CLI images to `linux/amd64`
  so the bundle can run on hosts that need emulation for this Linux target.
- The business story stays intentionally small:
  - one service exposes `customer.create`
  - `coakka-client call` and `ask` drive request/reply directly over CoAkka
    public TCP ingress
  - the reply comes back as `created:<payload>`
