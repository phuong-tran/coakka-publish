package coakka_logger

const (
	LoggerGoVersion            = "0.1.0"
	LoggerNativeCoreVersion    = "0.1.0"
	LoggerNativeGitCommit      = "ba2a66d98eb5"
	LoggerNativePackageVersion = "0.1.0+ba2a66d98eb5"
)
