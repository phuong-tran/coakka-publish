#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mojo_root="$(cd "${script_dir}/.." && pwd)"
native_package_version="0.1.0+ba2a66d98eb5"

if ! command -v mojo >/dev/null 2>&1; then
  echo "[mojo-logger-smoke] skip: mojo toolchain not found"
  exit 0
fi

logger_lib="${COAKKA_LOGGER_LIB:-}"
if [[ -z "${logger_lib}" ]]; then
  case "$(uname -s)" in
    Darwin)
      if [[ -f "${mojo_root}/native/macos-aarch64/libcoakka_logger_core-${native_package_version}.dylib" ]]; then
        logger_lib="${mojo_root}/native/macos-aarch64/libcoakka_logger_core-${native_package_version}.dylib"
      else
        logger_lib="${mojo_root}/../staging/native/${native_package_version}/macos-aarch64/libcoakka_logger_core.dylib"
      fi
      ;;
    Linux)
      case "$(uname -m)" in
        x86_64)
          if [[ -f "${mojo_root}/native/linux-x86_64/libcoakka_logger_core-${native_package_version}.so" ]]; then
            logger_lib="${mojo_root}/native/linux-x86_64/libcoakka_logger_core-${native_package_version}.so"
          else
            logger_lib="${mojo_root}/../staging/native/${native_package_version}/linux-x86_64/libcoakka_logger_core.so"
          fi
          ;;
        aarch64|arm64)
          if [[ -f "${mojo_root}/native/linux-aarch64/libcoakka_logger_core-${native_package_version}.so" ]]; then
            logger_lib="${mojo_root}/native/linux-aarch64/libcoakka_logger_core-${native_package_version}.so"
          else
            logger_lib="${mojo_root}/../staging/native/${native_package_version}/linux-aarch64/libcoakka_logger_core.so"
          fi
          ;;
        *) echo "[mojo-logger-smoke] unsupported arch: $(uname -m)" >&2; exit 64 ;;
      esac
      ;;
    *) echo "[mojo-logger-smoke] unsupported os: $(uname -s)" >&2; exit 64 ;;
  esac
fi

mojo "${mojo_root}/src/logger_abi_smoke.mojo" "${logger_lib}"
