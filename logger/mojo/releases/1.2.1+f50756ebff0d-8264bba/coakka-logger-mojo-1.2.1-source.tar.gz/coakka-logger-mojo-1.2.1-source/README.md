# CoAkka Logger Mojo Connector

Experimental Mojo lane for the standalone CoAkka native logger ABI.

This first slice verifies only the stable ABI entrypoint:

- load `libcoakka_logger_core` through Mojo FFI
- call `coakka_logger_core_get_abi_version`

The full logger lifecycle wrapper should wait until a local Mojo toolchain is
available for compile and runtime smoke coverage.

## Smoke

```sh
COAKKA_LOGGER_LIB=/path/to/libcoakka_logger_core.dylib bash scripts/smoke.sh
```

