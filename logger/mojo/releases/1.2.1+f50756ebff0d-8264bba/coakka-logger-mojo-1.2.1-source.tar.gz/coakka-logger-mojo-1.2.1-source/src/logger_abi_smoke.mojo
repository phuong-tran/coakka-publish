from std.ffi import OwnedDLHandle
from std.memory import forget_deinit
from std.sys import argv


comptime EXPECTED_ABI_VERSION = 10


def read_logger_abi(lib_path: String) raises -> UInt32:
    var lib = OwnedDLHandle(lib_path)
    var get_abi = lib.get_function[def() thin abi("C") -> UInt32](
        "coakka_logger_core_get_abi_version"
    )
    var abi = get_abi()
    # Mojo nightly currently crashes while unloading this logger dylib on macOS.
    # The smoke process exits immediately after the ABI probe, so keeping the
    # handle loaded is the least surprising probe behavior.
    forget_deinit(lib^)
    return abi


def main() raises:
    var args = argv()
    if len(args) <= 1:
        print("usage: mojo logger_abi_smoke.mojo /path/to/libcoakka_logger_core")
        return

    var lib_path = String(args[1])
    var abi = read_logger_abi(lib_path)
    if abi != EXPECTED_ABI_VERSION:
        print("coakka_logger_mojo_smoke unexpected_abi=", abi)
        return

    print("coakka_logger_mojo_smoke abi=", abi)
