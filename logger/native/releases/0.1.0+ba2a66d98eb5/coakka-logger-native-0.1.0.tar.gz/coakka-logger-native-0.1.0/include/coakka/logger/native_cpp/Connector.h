#ifndef COAKKA_LOGGER_NATIVE_CPP_CONNECTOR_H
#define COAKKA_LOGGER_NATIVE_CPP_CONNECTOR_H

#include "coakka/logger/core.h"
#include "coakka/logger/utils.h"

#include <chrono>
#include <cstdint>
#include <optional>
#include <stdexcept>
#include <string>

namespace coakka::logger::native_cpp {

struct StartSpec {
  std::string system_name = "logger-core";
  uint32_t queue_capacity = 256;
  coakka_logger_level_t min_level = COAKKA_LOGGER_LEVEL_TRACE;
  coakka_logger_sink_mode_t sink_mode = COAKKA_LOGGER_SINK_MODE_MANUAL_DRAIN;
  uint32_t sink_targets = COAKKA_LOGGER_SINK_TARGET_NONE;
  std::string output_path;
  std::string file_output_path;
  uint64_t max_file_size_bytes = 0;
  uint64_t file_max_size_bytes = 0;
  uint64_t max_total_size_bytes = 0;
  uint64_t file_total_size_limit_bytes = 0;
  std::string emergency_output_path;
  std::string file_emergency_output_path;
  uint64_t emergency_file_size_bytes = 0;
  uint64_t file_emergency_size_bytes = 0;
  uint32_t max_archived_files = 0;
  uint32_t file_max_archived_files = 0;
  int32_t console_fd = -1;
  int32_t console_stdout_fd = -1;
  int32_t console_stderr_fd = -1;
  uint32_t console_stdout_level_mask = COAKKA_LOGGER_LEVEL_MASK_TRACE |
                                       COAKKA_LOGGER_LEVEL_MASK_DEBUG |
                                       COAKKA_LOGGER_LEVEL_MASK_INFO;
  uint32_t console_stderr_level_mask = COAKKA_LOGGER_LEVEL_MASK_WARN |
                                       COAKKA_LOGGER_LEVEL_MASK_ERROR |
                                       COAKKA_LOGGER_LEVEL_MASK_FATAL;
  uint32_t category_capacity = 64;
  uint32_t message_capacity = 512;
};

struct LoggerInfoView {
  uint32_t abi_version = 0;
  std::string runtime_version;
  std::string git_commit;
  std::string docs_hint;
};

struct LoggerConfigView {
  std::string system_name;
  coakka_logger_core_state_t state = COAKKA_LOGGER_CORE_STATE_CREATED;
  std::string state_name;
  uint32_t queue_capacity = 0;
  coakka_logger_level_t min_level = COAKKA_LOGGER_LEVEL_TRACE;
  std::string min_level_name;
  coakka_logger_sink_mode_t sink_mode = COAKKA_LOGGER_SINK_MODE_MANUAL_DRAIN;
  std::string sink_mode_name;
  uint32_t sink_targets = COAKKA_LOGGER_SINK_TARGET_NONE;
  std::string output_path;
  std::string file_output_path;
  uint64_t max_file_size_bytes = 0;
  uint64_t file_max_size_bytes = 0;
  uint64_t max_total_size_bytes = 0;
  uint64_t file_total_size_limit_bytes = 0;
  std::string emergency_output_path;
  std::string file_emergency_output_path;
  uint64_t emergency_file_size_bytes = 0;
  uint64_t file_emergency_size_bytes = 0;
  coakka_logger_pressure_state_t pressure_state = COAKKA_LOGGER_PRESSURE_STATE_NORMAL;
  std::string pressure_state_name;
  uint32_t max_archived_files = 0;
  uint32_t file_max_archived_files = 0;
  int32_t console_fd = -1;
  int32_t console_stdout_fd = -1;
  int32_t console_stderr_fd = -1;
  uint32_t console_stdout_level_mask = 0;
  uint32_t console_stderr_level_mask = 0;
  uint32_t category_capacity = 0;
  uint32_t message_capacity = 0;
};

struct LoggerStatsView {
  coakka_logger_core_state_t state = COAKKA_LOGGER_CORE_STATE_CREATED;
  std::string state_name;
  uint32_t queue_capacity = 0;
  uint32_t queue_depth = 0;
  uint32_t queue_high_watermark = 0;
  uint64_t next_sequence = 0;
  uint64_t emitted_count = 0;
  uint64_t delivered_count = 0;
  uint64_t dropped_count = 0;
  uint64_t dropped_below_level_count = 0;
  uint64_t dropped_pressure_count = 0;
  // Aggregate compatibility counters across every active concrete sink target.
  uint64_t sink_write_count = 0;
  uint64_t sink_bytes_written = 0;
  uint64_t sink_write_failure_count = 0;
  uint64_t sink_current_file_size_bytes = 0;
  uint64_t sink_total_size_bytes = 0;
  // Preferred concrete file-target counters.
  uint64_t file_write_count = 0;
  uint64_t file_bytes_written = 0;
  uint64_t file_write_failure_count = 0;
  uint64_t file_current_size_bytes = 0;
  uint64_t file_total_size_bytes = 0;
  coakka_logger_pressure_state_t pressure_state = COAKKA_LOGGER_PRESSURE_STATE_NORMAL;
  std::string pressure_state_name;
  uint64_t sink_roll_count = 0;
  uint64_t sink_deleted_archive_count = 0;
  uint64_t file_roll_count = 0;
  uint64_t file_deleted_archive_count = 0;
  bool emergency_active = false;
  coakka_logger_emergency_reason_t emergency_last_reason = COAKKA_LOGGER_EMERGENCY_REASON_NONE;
  std::string emergency_last_reason_name;
  uint64_t emergency_enter_count = 0;
  uint64_t emergency_recovered_count = 0;
  uint64_t emergency_bytes_written = 0;
  uint64_t emergency_write_failure_count = 0;
  uint64_t emergency_overwrite_count = 0;
  coakka_logger_emergency_reason_t emergency_last_recovered_reason = COAKKA_LOGGER_EMERGENCY_REASON_NONE;
  uint64_t emergency_last_recovered_duration_ms = 0;
  uint64_t emergency_last_recovered_dropped_total = 0;
  uint64_t emergency_last_recovered_dropped_pressure = 0;
  uint64_t emergency_last_recovered_deleted_archives = 0;
  uint64_t reload_count = 0;
  uint64_t sink_reopen_failure_count = 0;
  uint64_t sink_roll_failure_count = 0;
  uint64_t sink_append_failure_count = 0;
  uint64_t sink_cleanup_failure_count = 0;
  uint64_t file_reopen_failure_count = 0;
  uint64_t file_roll_failure_count = 0;
  uint64_t file_append_failure_count = 0;
  uint64_t file_cleanup_failure_count = 0;
  // Preferred concrete console-target counters.
  uint64_t console_write_count = 0;
  uint64_t console_bytes_written = 0;
  uint64_t console_write_failure_count = 0;
};

struct LoggerRecord {
  uint64_t sequence = 0;
  uint64_t wall_time_unix_ms = 0;
  uint64_t monotonic_time_ns = 0;
  coakka_logger_level_t level = COAKKA_LOGGER_LEVEL_INFO;
  std::string level_name;
  std::string category;
  std::string message;
};

class StatusError : public std::runtime_error {
public:
  StatusError(const std::string& what, coakka_logger_status_t status);

  [[nodiscard]] coakka_logger_status_t status() const noexcept {
    return status_;
  }

private:
  coakka_logger_status_t status_;
};

class LoggerHandle {
public:
  explicit LoggerHandle(const StartSpec& spec);
  ~LoggerHandle();

  LoggerHandle(const LoggerHandle&) = delete;
  LoggerHandle& operator=(const LoggerHandle&) = delete;
  LoggerHandle(LoggerHandle&& other) noexcept;
  LoggerHandle& operator=(LoggerHandle&& other) noexcept;

  static LoggerInfoView readLoggerInfo();
  [[nodiscard]] LoggerConfigView readConfig() const;
  [[nodiscard]] LoggerStatsView readStats() const;
  [[nodiscard]] bool isEnabled(coakka_logger_level_t level) const;
  [[nodiscard]] bool isEnabledForCategory(const std::string& category,
                                          coakka_logger_level_t level) const;
  void reloadConfig(const StartSpec& spec);
  void stop();

  // Advanced escape hatch for callers that need direct access to the raw C
  // handle. Ordinary app code should stay on LoggerClient/LoggerOrchestrator
  // log(...) entrypoints instead.
  [[nodiscard]] coakka_logger_core_handle_t* raw() const noexcept {
    return handle_;
  }

private:
  coakka_logger_core_handle_t* handle_ = nullptr;
  StartSpec spec_;
  uint32_t category_capacity_ = 0;
  uint32_t message_capacity_ = 0;

  [[nodiscard]] uint32_t categoryCapacity() const noexcept {
    return category_capacity_;
  }

  [[nodiscard]] uint32_t messageCapacity() const noexcept {
    return message_capacity_;
  }

  friend class LoggerClient;
};

class LoggerClient {
public:
  explicit LoggerClient(LoggerHandle& handle);

  [[nodiscard]] bool isEnabled(coakka_logger_level_t level) const;
  [[nodiscard]] bool isEnabledForCategory(const std::string& category,
                                          coakka_logger_level_t level) const;
  void reloadConfig(const StartSpec& spec) {
    handle_->reloadConfig(spec);
  }
  // Normal text-only logging path for app-facing code.
  uint64_t log(coakka_logger_level_t level,
               const std::string& category,
               const std::string& message) const;
  uint64_t logTrace(const std::string& category,
                    const std::string& message) const;
  uint64_t logDebug(const std::string& category,
                    const std::string& message) const;
  uint64_t logInfo(const std::string& category,
                   const std::string& message) const;
  uint64_t logWarn(const std::string& category,
                   const std::string& message) const;
  uint64_t logError(const std::string& category,
                    const std::string& message) const;
  uint64_t logFatal(const std::string& category,
                    const std::string& message) const;
  // Raw escape hatch for callers that intentionally want full record control.
  uint64_t emitRaw(const coakka_logger_core_record_t& record) const;
  [[nodiscard]] std::optional<LoggerRecord> poll() const;
  [[nodiscard]] std::optional<LoggerRecord> await(std::chrono::milliseconds timeout) const;

private:
  LoggerHandle* handle_;
};

class LoggerOrchestrator {
public:
  explicit LoggerOrchestrator(const StartSpec& spec);

  static LoggerInfoView readLoggerInfo() {
    return LoggerHandle::readLoggerInfo();
  }

  [[nodiscard]] LoggerConfigView readConfig() const {
    return handle_.readConfig();
  }

  [[nodiscard]] LoggerStatsView readStats() const {
    return handle_.readStats();
  }

  [[nodiscard]] bool isEnabled(coakka_logger_level_t level) const {
    return handle_.isEnabled(level);
  }

  [[nodiscard]] bool isEnabledForCategory(const std::string& category,
                                          coakka_logger_level_t level) const {
    return handle_.isEnabledForCategory(category, level);
  }

  void reloadConfig(const StartSpec& spec) {
    handle_.reloadConfig(spec);
  }

  // Normal text-only logging path for app-facing code.
  uint64_t log(coakka_logger_level_t level,
               const std::string& category,
               const std::string& message) const {
    return client_.log(level, category, message);
  }

  uint64_t logTrace(const std::string& category,
                    const std::string& message) const {
    return client_.logTrace(category, message);
  }

  uint64_t logDebug(const std::string& category,
                    const std::string& message) const {
    return client_.logDebug(category, message);
  }

  uint64_t logInfo(const std::string& category,
                   const std::string& message) const {
    return client_.logInfo(category, message);
  }

  uint64_t logWarn(const std::string& category,
                   const std::string& message) const {
    return client_.logWarn(category, message);
  }

  uint64_t logError(const std::string& category,
                    const std::string& message) const {
    return client_.logError(category, message);
  }

  uint64_t logFatal(const std::string& category,
                    const std::string& message) const {
    return client_.logFatal(category, message);
  }

  // Raw escape hatch for callers that intentionally want full record control.
  uint64_t emitRaw(const coakka_logger_core_record_t& record) const {
    return client_.emitRaw(record);
  }

  [[nodiscard]] std::optional<LoggerRecord> poll() const {
    return client_.poll();
  }

  [[nodiscard]] std::optional<LoggerRecord> await(std::chrono::milliseconds timeout) const {
    return client_.await(timeout);
  }

  void stop() {
    handle_.stop();
  }

private:
  LoggerHandle handle_;
  LoggerClient client_;
};

}  // namespace coakka::logger::native_cpp

#endif
