#include "coakka/logger/native_cpp/Connector.h"

#include <array>
#include <sstream>
#include <utility>

namespace coakka::logger::native_cpp {

namespace {

void throw_if_not_ok(coakka_logger_status_t status, const std::string& context) {
  if (status == COAKKA_LOGGER_STATUS_OK) {
    return;
  }
  throw StatusError(context + ": " + coakka_logger_status_name(status), status);
}

StartSpec sanitize_spec(StartSpec spec) {
  if (spec.system_name.empty()) {
    spec.system_name = "logger-core";
  }
  if (spec.output_path.empty()) {
    spec.output_path = spec.file_output_path;
  }
  if (spec.file_output_path.empty()) {
    spec.file_output_path = spec.output_path;
  }
  if (spec.max_file_size_bytes == 0u) {
    spec.max_file_size_bytes = spec.file_max_size_bytes;
  }
  if (spec.file_max_size_bytes == 0u) {
    spec.file_max_size_bytes = spec.max_file_size_bytes;
  }
  if (spec.max_total_size_bytes == 0u) {
    spec.max_total_size_bytes = spec.file_total_size_limit_bytes;
  }
  if (spec.file_total_size_limit_bytes == 0u) {
    spec.file_total_size_limit_bytes = spec.max_total_size_bytes;
  }
  if (spec.emergency_output_path.empty()) {
    spec.emergency_output_path = spec.file_emergency_output_path;
  }
  if (spec.file_emergency_output_path.empty()) {
    spec.file_emergency_output_path = spec.emergency_output_path;
  }
  if (spec.emergency_file_size_bytes == 0u) {
    spec.emergency_file_size_bytes = spec.file_emergency_size_bytes;
  }
  if (spec.file_emergency_size_bytes == 0u) {
    spec.file_emergency_size_bytes = spec.emergency_file_size_bytes;
  }
  if (spec.max_archived_files == 0u) {
    spec.max_archived_files = spec.file_max_archived_files;
  }
  if (spec.file_max_archived_files == 0u) {
    spec.file_max_archived_files = spec.max_archived_files;
  }
  return spec;
}

LoggerRecord make_record(const coakka_logger_core_record_buffer_t& raw_record) {
  LoggerRecord record;
  record.sequence = raw_record.sequence;
  record.wall_time_unix_ms = raw_record.wall_time_unix_ms;
  record.monotonic_time_ns = raw_record.monotonic_time_ns;
  record.level = raw_record.level;
  record.level_name = coakka_logger_level_name(raw_record.level);
  record.category.assign(raw_record.category, raw_record.category_length);
  record.message.assign(raw_record.message, raw_record.message_length);
  return record;
}

}  // namespace

StatusError::StatusError(const std::string& what, coakka_logger_status_t status)
    : std::runtime_error(what), status_(status) {}

LoggerHandle::LoggerHandle(const StartSpec& spec) : spec_(sanitize_spec(spec)) {
  coakka_logger_core_config_t config = coakka_logger_core_default_config();
  config.system_name = spec_.system_name.c_str();
  config.queue_capacity = spec_.queue_capacity;
  config.min_level = spec_.min_level;
  config.sink_mode = spec_.sink_mode;
  config.sink_targets = spec_.sink_targets;
  config.output_path = spec_.output_path.empty() ? NULL : spec_.output_path.c_str();
  config.max_file_size_bytes = spec_.max_file_size_bytes;
  config.max_total_size_bytes = spec_.max_total_size_bytes;
  config.emergency_output_path =
      spec_.emergency_output_path.empty() ? NULL : spec_.emergency_output_path.c_str();
  config.emergency_file_size_bytes = spec_.emergency_file_size_bytes;
  config.max_archived_files = spec_.max_archived_files;
  config.file_output_path = spec_.file_output_path.empty() ? NULL : spec_.file_output_path.c_str();
  config.file_max_size_bytes = spec_.file_max_size_bytes;
  config.file_total_size_limit_bytes = spec_.file_total_size_limit_bytes;
  config.file_emergency_output_path =
      spec_.file_emergency_output_path.empty() ? NULL : spec_.file_emergency_output_path.c_str();
  config.file_emergency_size_bytes = spec_.file_emergency_size_bytes;
  config.file_max_archived_files = spec_.file_max_archived_files;
  config.console_fd = spec_.console_fd;
  config.console_stdout_fd = spec_.console_stdout_fd;
  config.console_stderr_fd = spec_.console_stderr_fd;
  config.console_stdout_level_mask = spec_.console_stdout_level_mask;
  config.console_stderr_level_mask = spec_.console_stderr_level_mask;
  config.category_capacity = spec_.category_capacity;
  config.message_capacity = spec_.message_capacity;
  category_capacity_ = spec_.category_capacity;
  message_capacity_ = spec_.message_capacity;

  throw_if_not_ok(coakka_logger_core_create(&config, &handle_), "logger_core_create");
  try {
    throw_if_not_ok(coakka_logger_core_start(handle_), "logger_core_start");
  } catch (...) {
    coakka_logger_core_destroy(handle_);
    handle_ = nullptr;
    throw;
  }
}

LoggerHandle::~LoggerHandle() {
  if (handle_ != nullptr) {
    (void)coakka_logger_core_stop(handle_);
    coakka_logger_core_destroy(handle_);
    handle_ = nullptr;
  }
}

LoggerHandle::LoggerHandle(LoggerHandle&& other) noexcept
    : handle_(other.handle_),
      spec_(std::move(other.spec_)),
      category_capacity_(other.category_capacity_),
      message_capacity_(other.message_capacity_) {
  other.handle_ = nullptr;
  other.category_capacity_ = 0u;
  other.message_capacity_ = 0u;
}

LoggerHandle& LoggerHandle::operator=(LoggerHandle&& other) noexcept {
  if (this == &other) {
    return *this;
  }
  if (handle_ != nullptr) {
    (void)coakka_logger_core_stop(handle_);
    coakka_logger_core_destroy(handle_);
  }
  handle_ = other.handle_;
  spec_ = std::move(other.spec_);
  category_capacity_ = other.category_capacity_;
  message_capacity_ = other.message_capacity_;
  other.handle_ = nullptr;
  other.category_capacity_ = 0u;
  other.message_capacity_ = 0u;
  return *this;
}

LoggerInfoView LoggerHandle::readLoggerInfo() {
  coakka_logger_core_info_t info{};
  info.struct_size = sizeof(info);
  throw_if_not_ok(coakka_logger_core_get_info(&info), "logger_core_get_info");

  LoggerInfoView view;
  view.abi_version = info.abi_version;
  view.runtime_version = info.runtime_version == nullptr ? "" : info.runtime_version;
  view.git_commit = info.git_commit == nullptr ? "" : info.git_commit;
  view.docs_hint = info.docs_hint == nullptr ? "" : info.docs_hint;
  return view;
}

LoggerConfigView LoggerHandle::readConfig() const {
  coakka_logger_core_config_view_t raw{};
  raw.struct_size = sizeof(raw);
  throw_if_not_ok(coakka_logger_core_get_config(handle_, &raw), "logger_core_get_config");

  LoggerConfigView view;
  view.system_name = raw.system_name == nullptr ? "" : raw.system_name;
  view.state = raw.state;
  view.state_name = coakka_logger_state_name(raw.state);
  view.queue_capacity = raw.queue_capacity;
  view.min_level = raw.min_level;
  view.min_level_name = coakka_logger_level_name(raw.min_level);
  view.sink_mode = raw.sink_mode;
  view.sink_mode_name = coakka_logger_sink_mode_name(raw.sink_mode);
  view.sink_targets = raw.sink_targets;
  view.output_path = raw.output_path == nullptr ? "" : raw.output_path;
  view.file_output_path = raw.file_output_path == nullptr ? "" : raw.file_output_path;
  view.max_file_size_bytes = raw.max_file_size_bytes;
  view.file_max_size_bytes = raw.file_max_size_bytes;
  view.max_total_size_bytes = raw.max_total_size_bytes;
  view.file_total_size_limit_bytes = raw.file_total_size_limit_bytes;
  view.emergency_output_path = raw.emergency_output_path == nullptr ? "" : raw.emergency_output_path;
  view.file_emergency_output_path =
      raw.file_emergency_output_path == nullptr ? "" : raw.file_emergency_output_path;
  view.emergency_file_size_bytes = raw.emergency_file_size_bytes;
  view.file_emergency_size_bytes = raw.file_emergency_size_bytes;
  view.pressure_state = raw.pressure_state;
  view.pressure_state_name = coakka_logger_pressure_state_name(raw.pressure_state);
  view.max_archived_files = raw.max_archived_files;
  view.file_max_archived_files = raw.file_max_archived_files;
  view.console_fd = raw.console_fd;
  view.console_stdout_fd = raw.console_stdout_fd;
  view.console_stderr_fd = raw.console_stderr_fd;
  view.console_stdout_level_mask = raw.console_stdout_level_mask;
  view.console_stderr_level_mask = raw.console_stderr_level_mask;
  view.category_capacity = raw.category_capacity;
  view.message_capacity = raw.message_capacity;
  return view;
}

LoggerStatsView LoggerHandle::readStats() const {
  coakka_logger_core_stats_t raw{};
  raw.struct_size = sizeof(raw);
  throw_if_not_ok(coakka_logger_core_get_stats(handle_, &raw), "logger_core_get_stats");

  LoggerStatsView view;
  view.state = raw.state;
  view.state_name = coakka_logger_state_name(raw.state);
  view.queue_capacity = raw.queue_capacity;
  view.queue_depth = raw.queue_depth;
  view.queue_high_watermark = raw.queue_high_watermark;
  view.next_sequence = raw.next_sequence;
  view.emitted_count = raw.emitted_count;
  view.delivered_count = raw.delivered_count;
  view.dropped_count = raw.dropped_count;
  view.dropped_below_level_count = raw.dropped_below_level_count;
  view.dropped_pressure_count = raw.dropped_pressure_count;
  view.sink_write_count = raw.sink_write_count;
  view.sink_bytes_written = raw.sink_bytes_written;
  view.sink_write_failure_count = raw.sink_write_failure_count;
  view.sink_current_file_size_bytes = raw.sink_current_file_size_bytes;
  view.sink_total_size_bytes = raw.sink_total_size_bytes;
  view.file_write_count = raw.file_write_count;
  view.file_bytes_written = raw.file_bytes_written;
  view.file_write_failure_count = raw.file_write_failure_count;
  view.file_current_size_bytes = raw.file_current_size_bytes;
  view.file_total_size_bytes = raw.file_total_size_bytes;
  view.pressure_state = raw.pressure_state;
  view.pressure_state_name = coakka_logger_pressure_state_name(raw.pressure_state);
  view.sink_roll_count = raw.sink_roll_count;
  view.sink_deleted_archive_count = raw.sink_deleted_archive_count;
  view.file_roll_count = raw.file_roll_count;
  view.file_deleted_archive_count = raw.file_deleted_archive_count;
  view.emergency_active = raw.emergency_active != 0;
  view.emergency_last_reason = raw.emergency_last_reason;
  view.emergency_last_reason_name = coakka_logger_emergency_reason_name(raw.emergency_last_reason);
  view.emergency_enter_count = raw.emergency_enter_count;
  view.emergency_recovered_count = raw.emergency_recovered_count;
  view.emergency_bytes_written = raw.emergency_bytes_written;
  view.emergency_write_failure_count = raw.emergency_write_failure_count;
  view.emergency_overwrite_count = raw.emergency_overwrite_count;
  view.emergency_last_recovered_reason = raw.emergency_last_recovered_reason;
  view.emergency_last_recovered_duration_ms = raw.emergency_last_recovered_duration_ms;
  view.emergency_last_recovered_dropped_total = raw.emergency_last_recovered_dropped_total;
  view.emergency_last_recovered_dropped_pressure = raw.emergency_last_recovered_dropped_pressure;
  view.emergency_last_recovered_deleted_archives = raw.emergency_last_recovered_deleted_archives;
  view.reload_count = raw.reload_count;
  view.sink_reopen_failure_count = raw.sink_reopen_failure_count;
  view.sink_roll_failure_count = raw.sink_roll_failure_count;
  view.sink_append_failure_count = raw.sink_append_failure_count;
  view.sink_cleanup_failure_count = raw.sink_cleanup_failure_count;
  view.file_reopen_failure_count = raw.file_reopen_failure_count;
  view.file_roll_failure_count = raw.file_roll_failure_count;
  view.file_append_failure_count = raw.file_append_failure_count;
  view.file_cleanup_failure_count = raw.file_cleanup_failure_count;
  view.console_write_count = raw.console_write_count;
  view.console_bytes_written = raw.console_bytes_written;
  view.console_write_failure_count = raw.console_write_failure_count;
  return view;
}

bool LoggerHandle::isEnabled(coakka_logger_level_t level) const {
  return coakka_logger_core_is_enabled(handle_, level) != 0;
}

bool LoggerHandle::isEnabledForCategory(const std::string& category,
                                        coakka_logger_level_t level) const {
  return coakka_logger_core_is_enabled_for_category(handle_, category.c_str(), level) != 0;
}

void LoggerHandle::reloadConfig(const StartSpec& spec) {
  const StartSpec effective_spec = sanitize_spec(spec);
  coakka_logger_core_config_t config = coakka_logger_core_default_config();
  config.system_name = effective_spec.system_name.c_str();
  config.queue_capacity = effective_spec.queue_capacity;
  config.min_level = effective_spec.min_level;
  config.sink_mode = effective_spec.sink_mode;
  config.sink_targets = effective_spec.sink_targets;
  config.output_path = effective_spec.output_path.empty() ? NULL : effective_spec.output_path.c_str();
  config.max_file_size_bytes = effective_spec.max_file_size_bytes;
  config.max_total_size_bytes = effective_spec.max_total_size_bytes;
  config.max_archived_files = effective_spec.max_archived_files;
  config.file_output_path =
      effective_spec.file_output_path.empty() ? NULL : effective_spec.file_output_path.c_str();
  config.file_max_size_bytes = effective_spec.file_max_size_bytes;
  config.file_total_size_limit_bytes = effective_spec.file_total_size_limit_bytes;
  config.file_max_archived_files = effective_spec.file_max_archived_files;
  config.category_capacity = effective_spec.category_capacity;
  config.message_capacity = effective_spec.message_capacity;
  config.emergency_output_path =
      effective_spec.emergency_output_path.empty() ? NULL : effective_spec.emergency_output_path.c_str();
  config.emergency_file_size_bytes = effective_spec.emergency_file_size_bytes;
  config.file_emergency_output_path = effective_spec.file_emergency_output_path.empty()
                                          ? NULL
                                          : effective_spec.file_emergency_output_path.c_str();
  config.file_emergency_size_bytes = effective_spec.file_emergency_size_bytes;
  config.console_fd = effective_spec.console_fd;
  config.console_stdout_fd = effective_spec.console_stdout_fd;
  config.console_stderr_fd = effective_spec.console_stderr_fd;
  config.console_stdout_level_mask = effective_spec.console_stdout_level_mask;
  config.console_stderr_level_mask = effective_spec.console_stderr_level_mask;
  throw_if_not_ok(coakka_logger_core_reload_config(handle_, &config), "logger_core_reload_config");
  spec_ = effective_spec;
  category_capacity_ = effective_spec.category_capacity;
  message_capacity_ = effective_spec.message_capacity;
}

void LoggerHandle::stop() {
  throw_if_not_ok(coakka_logger_core_stop(handle_), "logger_core_stop");
}

LoggerClient::LoggerClient(LoggerHandle& handle) : handle_(&handle) {}

bool LoggerClient::isEnabled(coakka_logger_level_t level) const {
  return handle_->isEnabled(level);
}

bool LoggerClient::isEnabledForCategory(const std::string& category,
                                        coakka_logger_level_t level) const {
  return handle_->isEnabledForCategory(category, level);
}

uint64_t LoggerClient::log(coakka_logger_level_t level,
                           const std::string& category,
                           const std::string& message) const {
  uint64_t sequence = 0;
  throw_if_not_ok(coakka_logger_core_log(handle_->raw(),
                                         level,
                                         category.c_str(),
                                         message.c_str(),
                                         &sequence),
                  "logger_core_log");
  return sequence;
}

uint64_t LoggerClient::logTrace(const std::string& category,
                                const std::string& message) const {
  return log(COAKKA_LOGGER_LEVEL_TRACE, category, message);
}

uint64_t LoggerClient::logDebug(const std::string& category,
                                const std::string& message) const {
  return log(COAKKA_LOGGER_LEVEL_DEBUG, category, message);
}

uint64_t LoggerClient::logInfo(const std::string& category,
                               const std::string& message) const {
  return log(COAKKA_LOGGER_LEVEL_INFO, category, message);
}

uint64_t LoggerClient::logWarn(const std::string& category,
                               const std::string& message) const {
  return log(COAKKA_LOGGER_LEVEL_WARN, category, message);
}

uint64_t LoggerClient::logError(const std::string& category,
                                const std::string& message) const {
  return log(COAKKA_LOGGER_LEVEL_ERROR, category, message);
}

uint64_t LoggerClient::logFatal(const std::string& category,
                                const std::string& message) const {
  return log(COAKKA_LOGGER_LEVEL_FATAL, category, message);
}

uint64_t LoggerClient::emitRaw(const coakka_logger_core_record_t& record) const {
  uint64_t sequence = 0;
  throw_if_not_ok(coakka_logger_core_emit(handle_->raw(), &record, &sequence), "logger_core_emit");
  return sequence;
}

std::optional<LoggerRecord> LoggerClient::poll() const {
  return await(std::chrono::milliseconds(0));
}

std::optional<LoggerRecord> LoggerClient::await(std::chrono::milliseconds timeout) const {
  std::string category(handle_->categoryCapacity(), '\0');
  std::string message(handle_->messageCapacity(), '\0');
  coakka_logger_core_record_buffer_t raw_record{};
  raw_record.struct_size = sizeof(raw_record);
  raw_record.category = category.data();
  raw_record.category_capacity = category.size();
  raw_record.message = message.data();
  raw_record.message_capacity = message.size();

  const auto status = coakka_logger_core_read_next(handle_->raw(),
                                                   static_cast<uint32_t>(timeout.count()),
                                                   &raw_record);
  if (status == COAKKA_LOGGER_STATUS_TIMED_OUT) {
    return std::nullopt;
  }
  throw_if_not_ok(status, "logger_core_read_next");
  return make_record(raw_record);
}

LoggerOrchestrator::LoggerOrchestrator(const StartSpec& spec)
    : handle_(spec), client_(handle_) {}

}  // namespace coakka::logger::native_cpp
