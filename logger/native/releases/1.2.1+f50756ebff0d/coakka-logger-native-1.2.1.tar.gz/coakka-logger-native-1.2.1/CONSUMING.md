# Consuming CoAkka Logger Native C/C++

Unpack the archive into your dependency directory:

~~~sh
tar -xzf coakka-logger-native-1.2.1.tar.gz
~~~

## C ABI

~~~cmake
set(CMAKE_PREFIX_PATH "/path/to/coakka-logger-native-1.2.1")
find_package(CoAkkaLoggerNative CONFIG REQUIRED)

add_executable(logger_c main.c)
target_link_libraries(logger_c PRIVATE CoAkkaLoggerNative::core)
~~~

The C ABI is declared by include/coakka/logger/core.h and
include/coakka/logger/utils.h.

## C++ Wrapper

~~~cmake
set(CMAKE_PREFIX_PATH "/path/to/coakka-logger-native-1.2.1")
find_package(CoAkkaLoggerNative CONFIG REQUIRED)

add_executable(logger_cpp main.cpp)
target_link_libraries(logger_cpp PRIVATE CoAkkaLoggerNative::native_cpp_connector)
~~~

## Platform Selection

The package includes these platform directories:

- native/linux-aarch64
- native/linux-x86_64
- native/macos-aarch64
- native/windows-aarch64
- native/windows-x86_64

## Runtime Loader

~~~sh
DYLD_LIBRARY_PATH=/path/to/coakka-logger-native-1.2.1/native/macos-aarch64 ./logger_cpp
LD_LIBRARY_PATH=/path/to/coakka-logger-native-1.2.1/native/linux-x86_64 ./logger_cpp
~~~

On Windows, keep libcoakka_logger_core.dll beside the executable or on PATH.
