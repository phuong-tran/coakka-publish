# CoAkka Logger Node

`logger/node/` is the Node.js host connector lane for the standalone CoAkka
native logger core.

It mirrors the Python logger lane:

- load `libcoakka_logger_core` through `koffi`
- keep Node-side formatting above the native core
- let the native logger own queueing, pressure policy, sinks, and lifecycle
- package staged native libraries into the npm tarball for macOS aarch64,
  Linux aarch64, and Linux x86_64

## Build

```sh
npm --prefix logger/node run build
```

The script stages native libraries from:

```text
logger/staging/native/1.2.1+f50756ebff0d/
```

## Smoke

```sh
npm --prefix logger/node test
npm --prefix logger/node run smoke:packaged
```

## Example

```ts
import { Logger } from "coakka-logger-node";

const logger = Logger.start();
try {
  logger.info("app", "started");
  const record = logger.awaitNext(1000);
} finally {
  logger.close();
}
```
