from __future__ import annotations

import ctypes
import threading
from dataclasses import dataclass

from ._native import (
    COAKKA_LOGGER_CORE_ABI_VERSION,
    CoakkaLoggerLevel,
    CoakkaLoggerLevelMask,
    CoakkaLoggerPressureState,
    CoakkaLoggerSinkMode,
    CoakkaLoggerSinkTarget,
    CoakkaLoggerStatus,
    LoggerCoreConfig,
    LoggerCoreConfigView,
    LoggerCoreInfo,
    LoggerCoreRecordBuffer,
    LoggerCoreStats,
    LoggerLibraryResolver,
    decode_native_text,
    load_logger_library,
)


@dataclass(frozen=True)
class LoggerSpec:
    system_name: str = "pythonLogger"
    queue_capacity: int = 256
    category_capacity: int = 64
    message_capacity: int = 512
    min_level: int = CoakkaLoggerLevel.TRACE


@dataclass(frozen=True)
class LoggerInfoSnapshot:
    abi_version: int
    runtime_version: str
    git_commit: str
    docs_hint: str


@dataclass(frozen=True)
class LoggerConfigSnapshot:
    system_name: str
    state: int
    state_name: str
    queue_capacity: int
    category_capacity: int
    message_capacity: int


@dataclass(frozen=True)
class LoggerStatsSnapshot:
    state: int
    state_name: str
    queue_capacity: int
    queue_depth: int
    queue_high_watermark: int
    next_sequence: int
    emitted_count: int
    delivered_count: int
    dropped_count: int


@dataclass(frozen=True)
class LoggerRecordSnapshot:
    sequence: int
    wall_time_unix_ms: int
    monotonic_time_ns: int
    level: int
    level_name: str
    category: str
    message: str


class LoggerStatusError(RuntimeError):
    def __init__(self, operation: str, status: int, status_name: str):
        super().__init__(f"{operation} failed: {status_name} ({status})")
        self.operation = operation
        self.status = status
        self.status_name = status_name


class Logger:
    def __init__(
        self,
        lib: ctypes.CDLL,
        handle: ctypes.c_void_p,
        spec: LoggerSpec,
    ) -> None:
        self._lib = lib
        self._handle = handle
        self._spec = spec
        self._lock = threading.Lock()
        self._stopped = False
        self._closed = False

    @classmethod
    def start(
        cls,
        logger_lib_path: str | None = None,
        spec: LoggerSpec = LoggerSpec(),
    ) -> "Logger":
        lib = load_logger_library(LoggerLibraryResolver.resolve(logger_lib_path))
        abi_version = lib.coakka_logger_core_get_abi_version()
        if abi_version != COAKKA_LOGGER_CORE_ABI_VERSION:
            raise RuntimeError(
                f"unexpected logger ABI version: expected {COAKKA_LOGGER_CORE_ABI_VERSION}, got {abi_version}"
            )

        config = _make_config(spec)
        out_handle = ctypes.c_void_p()
        _require_ok(lib, lib.coakka_logger_core_create(ctypes.byref(config), ctypes.byref(out_handle)), "logger_core_create")
        if not out_handle.value:
            raise RuntimeError("logger_core_create returned null handle")

        try:
            _require_ok(lib, lib.coakka_logger_core_start(out_handle), "logger_core_start")
        except BaseException:
            lib.coakka_logger_core_destroy(out_handle)
            raise
        return cls(lib, out_handle, spec)

    @classmethod
    def read_info(cls, logger_lib_path: str | None = None) -> LoggerInfoSnapshot:
        lib = load_logger_library(LoggerLibraryResolver.resolve(logger_lib_path))
        info = LoggerCoreInfo()
        info.struct_size = ctypes.sizeof(LoggerCoreInfo)
        _require_ok(lib, lib.coakka_logger_core_get_info(ctypes.byref(info)), "logger_core_get_info")
        return LoggerInfoSnapshot(
            abi_version=info.abi_version,
            runtime_version=decode_native_text(info.runtime_version),
            git_commit=decode_native_text(info.git_commit),
            docs_hint=decode_native_text(info.docs_hint),
        )

    def config(self) -> LoggerConfigSnapshot:
        with self._lock:
            self._require_open()
            view = LoggerCoreConfigView()
            view.struct_size = ctypes.sizeof(LoggerCoreConfigView)
            _require_ok(self._lib, self._lib.coakka_logger_core_get_config(self._handle, ctypes.byref(view)), "logger_core_get_config")
            return LoggerConfigSnapshot(
                system_name=decode_native_text(view.system_name),
                state=view.state,
                state_name=decode_native_text(self._lib.coakka_logger_state_name(view.state)),
                queue_capacity=view.queue_capacity,
                category_capacity=view.category_capacity,
                message_capacity=view.message_capacity,
            )

    def stats(self) -> LoggerStatsSnapshot:
        with self._lock:
            self._require_open()
            stats = LoggerCoreStats()
            stats.struct_size = ctypes.sizeof(LoggerCoreStats)
            _require_ok(self._lib, self._lib.coakka_logger_core_get_stats(self._handle, ctypes.byref(stats)), "logger_core_get_stats")
            return LoggerStatsSnapshot(
                state=stats.state,
                state_name=decode_native_text(self._lib.coakka_logger_state_name(stats.state)),
                queue_capacity=stats.queue_capacity,
                queue_depth=stats.queue_depth,
                queue_high_watermark=stats.queue_high_watermark,
                next_sequence=stats.next_sequence,
                emitted_count=stats.emitted_count,
                delivered_count=stats.delivered_count,
                dropped_count=stats.dropped_count,
            )

    def is_enabled(self, level: int) -> bool:
        with self._lock:
            self._require_open()
            return self._lib.coakka_logger_core_is_enabled(self._handle, level) != 0

    def is_enabled_for_category(self, category: str, level: int) -> bool:
        with self._lock:
            self._require_open()
            return self._lib.coakka_logger_core_is_enabled_for_category(
                self._handle,
                _encode_text(category),
                level,
            ) != 0

    def log(self, level: int, category: str, message: str) -> int | None:
        if not self.is_enabled_for_category(category, level):
            return None
        with self._lock:
            self._require_open()
            out_sequence = ctypes.c_uint64()
            status = self._lib.coakka_logger_core_log(
                self._handle,
                level,
                _encode_text(category),
                _encode_text(message),
                ctypes.byref(out_sequence),
            )
            _require_ok(self._lib, status, "logger_core_log")
            return out_sequence.value

    def trace(self, category: str, message: str) -> int | None:
        return self.log(CoakkaLoggerLevel.TRACE, category, message)

    def debug(self, category: str, message: str) -> int | None:
        return self.log(CoakkaLoggerLevel.DEBUG, category, message)

    def info(self, category: str, message: str) -> int | None:
        return self.log(CoakkaLoggerLevel.INFO, category, message)

    def warn(self, category: str, message: str) -> int | None:
        return self.log(CoakkaLoggerLevel.WARN, category, message)

    def error(self, category: str, message: str) -> int | None:
        return self.log(CoakkaLoggerLevel.ERROR, category, message)

    def fatal(self, category: str, message: str) -> int | None:
        return self.log(CoakkaLoggerLevel.FATAL, category, message)

    def poll(self) -> LoggerRecordSnapshot | None:
        return self.await_next(timeout_ms=0)

    def await_next(self, timeout_ms: int = 1000) -> LoggerRecordSnapshot | None:
        category_buffer = ctypes.create_string_buffer(max(1, self._spec.category_capacity))
        message_buffer = ctypes.create_string_buffer(max(1, self._spec.message_capacity))
        record = LoggerCoreRecordBuffer()
        record.struct_size = ctypes.sizeof(LoggerCoreRecordBuffer)
        record.category = ctypes.cast(category_buffer, ctypes.c_void_p)
        record.category_capacity = len(category_buffer)
        record.message = ctypes.cast(message_buffer, ctypes.c_void_p)
        record.message_capacity = len(message_buffer)

        with self._lock:
            self._require_open()
            status = self._lib.coakka_logger_core_read_next(self._handle, timeout_ms, ctypes.byref(record))
            if status == CoakkaLoggerStatus.TIMED_OUT:
                return None
            _require_ok(self._lib, status, "logger_core_read_next")
            return LoggerRecordSnapshot(
                sequence=record.sequence,
                wall_time_unix_ms=record.wall_time_unix_ms,
                monotonic_time_ns=record.monotonic_time_ns,
                level=record.level,
                level_name=decode_native_text(self._lib.coakka_logger_level_name(record.level)),
                category=category_buffer.value.decode("utf-8"),
                message=message_buffer.value.decode("utf-8"),
            )

    def stop(self) -> None:
        with self._lock:
            if self._closed or self._stopped:
                return
            _require_ok(self._lib, self._lib.coakka_logger_core_stop(self._handle), "logger_core_stop")
            self._stopped = True

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            if not self._stopped:
                self._lib.coakka_logger_core_stop(self._handle)
                self._stopped = True
            self._lib.coakka_logger_core_destroy(self._handle)
            self._closed = True

    def __enter__(self) -> "Logger":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()

    def _require_open(self) -> None:
        if self._closed:
            raise RuntimeError("logger is closed")


def _make_config(spec: LoggerSpec) -> LoggerCoreConfig:
    config = LoggerCoreConfig()
    config.struct_size = ctypes.sizeof(LoggerCoreConfig)
    config.system_name = _encode_text(spec.system_name)
    config.queue_capacity = spec.queue_capacity
    config.min_level = spec.min_level
    config.sink_mode = CoakkaLoggerSinkMode.MANUAL_DRAIN
    config.output_path = None
    config.max_file_size_bytes = 0
    config.max_total_size_bytes = 0
    config.pressure_state = CoakkaLoggerPressureState.NORMAL
    config.max_archived_files = 0
    config.category_capacity = spec.category_capacity
    config.message_capacity = spec.message_capacity
    config.emergency_output_path = None
    config.emergency_file_size_bytes = 0
    config.category_override_capacity = 32
    config.sink_targets = CoakkaLoggerSinkTarget.NONE
    config.console_fd = -1
    config.console_stdout_fd = -1
    config.console_stderr_fd = -1
    config.console_stdout_level_mask = (
        CoakkaLoggerLevelMask.TRACE | CoakkaLoggerLevelMask.DEBUG | CoakkaLoggerLevelMask.INFO
    )
    config.console_stderr_level_mask = (
        CoakkaLoggerLevelMask.WARN | CoakkaLoggerLevelMask.ERROR | CoakkaLoggerLevelMask.FATAL
    )
    config.file_output_path = None
    config.file_max_size_bytes = 0
    config.file_total_size_limit_bytes = 0
    config.file_max_archived_files = 0
    config.file_emergency_output_path = None
    config.file_emergency_size_bytes = 0
    return config


def _encode_text(value: str) -> bytes:
    return value.encode("utf-8")


def _require_ok(lib: ctypes.CDLL, status: int, operation: str) -> None:
    if status == CoakkaLoggerStatus.OK:
        return
    raise LoggerStatusError(
        operation=operation,
        status=status,
        status_name=decode_native_text(lib.coakka_logger_status_name(status)),
    )
