from __future__ import annotations

import atexit
import ctypes
import os
import shutil
import tempfile
import threading
from importlib import resources
from pathlib import Path

from ._packaging import LOGGER_NATIVE_PACKAGE_VERSION


COAKKA_LOGGER_CORE_ABI_VERSION = 10


class CoakkaLoggerStatus:
    OK = 0
    INVALID_ARGUMENT = 1
    BAD_STATE = 2
    QUEUE_FULL = 3
    RECORD_TOO_LARGE = 4
    TIMED_OUT = 5
    BUFFER_TOO_SMALL = 6
    INTERNAL_ERROR = 7


class CoakkaLoggerLevel:
    TRACE = 0
    DEBUG = 1
    INFO = 2
    WARN = 3
    ERROR = 4
    FATAL = 5


class CoakkaLoggerSinkMode:
    MANUAL_DRAIN = 0
    FILE = 1
    CONSOLE = 2
    MULTI = 3


class CoakkaLoggerSinkTarget:
    NONE = 0
    FILE = 1 << 0
    CONSOLE = 1 << 1


class CoakkaLoggerPressureState:
    NORMAL = 0
    QUOTA_PRESSURE = 1
    DROP_LOW_PRIORITY = 2
    EMERGENCY_ONLY = 3


class CoakkaLoggerLevelMask:
    TRACE = 1 << CoakkaLoggerLevel.TRACE
    DEBUG = 1 << CoakkaLoggerLevel.DEBUG
    INFO = 1 << CoakkaLoggerLevel.INFO
    WARN = 1 << CoakkaLoggerLevel.WARN
    ERROR = 1 << CoakkaLoggerLevel.ERROR
    FATAL = 1 << CoakkaLoggerLevel.FATAL
    ALL = (1 << 6) - 1


class LoggerCoreInfo(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("abi_version", ctypes.c_uint32),
        ("runtime_version", ctypes.c_char_p),
        ("git_commit", ctypes.c_char_p),
        ("docs_hint", ctypes.c_char_p),
    ]


class LoggerCoreConfig(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("system_name", ctypes.c_char_p),
        ("queue_capacity", ctypes.c_uint32),
        ("min_level", ctypes.c_int),
        ("sink_mode", ctypes.c_int),
        ("output_path", ctypes.c_char_p),
        ("max_file_size_bytes", ctypes.c_uint64),
        ("max_total_size_bytes", ctypes.c_uint64),
        ("pressure_state", ctypes.c_int),
        ("max_archived_files", ctypes.c_uint32),
        ("category_capacity", ctypes.c_uint32),
        ("message_capacity", ctypes.c_uint32),
        ("emergency_output_path", ctypes.c_char_p),
        ("emergency_file_size_bytes", ctypes.c_uint64),
        ("category_override_capacity", ctypes.c_uint32),
        ("sink_targets", ctypes.c_uint32),
        ("console_fd", ctypes.c_int32),
        ("console_stdout_fd", ctypes.c_int32),
        ("console_stderr_fd", ctypes.c_int32),
        ("console_stdout_level_mask", ctypes.c_uint32),
        ("console_stderr_level_mask", ctypes.c_uint32),
        ("file_output_path", ctypes.c_char_p),
        ("file_max_size_bytes", ctypes.c_uint64),
        ("file_total_size_limit_bytes", ctypes.c_uint64),
        ("file_max_archived_files", ctypes.c_uint32),
        ("file_emergency_output_path", ctypes.c_char_p),
        ("file_emergency_size_bytes", ctypes.c_uint64),
    ]


class LoggerCoreConfigView(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("system_name", ctypes.c_char_p),
        ("state", ctypes.c_int),
        ("queue_capacity", ctypes.c_uint32),
        ("min_level", ctypes.c_int),
        ("sink_mode", ctypes.c_int),
        ("output_path", ctypes.c_char_p),
        ("max_file_size_bytes", ctypes.c_uint64),
        ("max_total_size_bytes", ctypes.c_uint64),
        ("pressure_state", ctypes.c_int),
        ("max_archived_files", ctypes.c_uint32),
        ("category_capacity", ctypes.c_uint32),
        ("message_capacity", ctypes.c_uint32),
        ("emergency_output_path", ctypes.c_char_p),
        ("emergency_file_size_bytes", ctypes.c_uint64),
        ("category_override_capacity", ctypes.c_uint32),
        ("sink_targets", ctypes.c_uint32),
        ("console_fd", ctypes.c_int32),
        ("console_stdout_fd", ctypes.c_int32),
        ("console_stderr_fd", ctypes.c_int32),
        ("console_stdout_level_mask", ctypes.c_uint32),
        ("console_stderr_level_mask", ctypes.c_uint32),
        ("file_output_path", ctypes.c_char_p),
        ("file_max_size_bytes", ctypes.c_uint64),
        ("file_total_size_limit_bytes", ctypes.c_uint64),
        ("file_max_archived_files", ctypes.c_uint32),
        ("file_emergency_output_path", ctypes.c_char_p),
        ("file_emergency_size_bytes", ctypes.c_uint64),
    ]


class LoggerCoreStats(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("state", ctypes.c_int),
        ("queue_capacity", ctypes.c_uint32),
        ("queue_depth", ctypes.c_uint32),
        ("queue_high_watermark", ctypes.c_uint32),
        ("next_sequence", ctypes.c_uint64),
        ("emitted_count", ctypes.c_uint64),
        ("delivered_count", ctypes.c_uint64),
        ("dropped_count", ctypes.c_uint64),
        ("dropped_below_level_count", ctypes.c_uint64),
        ("sink_write_count", ctypes.c_uint64),
        ("sink_bytes_written", ctypes.c_uint64),
        ("sink_write_failure_count", ctypes.c_uint64),
        ("sink_current_file_size_bytes", ctypes.c_uint64),
        ("sink_total_size_bytes", ctypes.c_uint64),
        ("pressure_state", ctypes.c_int),
        ("sink_roll_count", ctypes.c_uint64),
        ("sink_deleted_archive_count", ctypes.c_uint64),
        ("dropped_pressure_count", ctypes.c_uint64),
        ("emergency_active", ctypes.c_uint32),
        ("emergency_last_reason", ctypes.c_int),
        ("emergency_enter_count", ctypes.c_uint64),
        ("emergency_recovered_count", ctypes.c_uint64),
        ("emergency_bytes_written", ctypes.c_uint64),
        ("emergency_write_failure_count", ctypes.c_uint64),
        ("emergency_overwrite_count", ctypes.c_uint64),
        ("emergency_last_recovered_reason", ctypes.c_int),
        ("emergency_last_recovered_duration_ms", ctypes.c_uint64),
        ("emergency_last_recovered_dropped_total", ctypes.c_uint64),
        ("emergency_last_recovered_dropped_pressure", ctypes.c_uint64),
        ("emergency_last_recovered_deleted_archives", ctypes.c_uint64),
        ("reload_count", ctypes.c_uint64),
        ("category_override_count", ctypes.c_uint32),
        ("sink_reopen_failure_count", ctypes.c_uint64),
        ("sink_roll_failure_count", ctypes.c_uint64),
        ("sink_append_failure_count", ctypes.c_uint64),
        ("sink_cleanup_failure_count", ctypes.c_uint64),
        ("file_write_count", ctypes.c_uint64),
        ("file_bytes_written", ctypes.c_uint64),
        ("file_write_failure_count", ctypes.c_uint64),
        ("file_current_size_bytes", ctypes.c_uint64),
        ("file_total_size_bytes", ctypes.c_uint64),
        ("file_roll_count", ctypes.c_uint64),
        ("file_deleted_archive_count", ctypes.c_uint64),
        ("file_reopen_failure_count", ctypes.c_uint64),
        ("file_roll_failure_count", ctypes.c_uint64),
        ("file_append_failure_count", ctypes.c_uint64),
        ("file_cleanup_failure_count", ctypes.c_uint64),
        ("console_write_count", ctypes.c_uint64),
        ("console_bytes_written", ctypes.c_uint64),
        ("console_write_failure_count", ctypes.c_uint64),
    ]


class LoggerCoreRecordBuffer(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("sequence", ctypes.c_uint64),
        ("wall_time_unix_ms", ctypes.c_uint64),
        ("monotonic_time_ns", ctypes.c_uint64),
        ("level", ctypes.c_int),
        ("category", ctypes.c_void_p),
        ("category_capacity", ctypes.c_size_t),
        ("category_length", ctypes.c_size_t),
        ("message", ctypes.c_void_p),
        ("message_capacity", ctypes.c_size_t),
        ("message_length", ctypes.c_size_t),
    ]


class LoggerLibraryResolver:
    ENV_VAR = "COAKKA_LOGGER_LIB"
    _embedded_path_cache: dict[str, str] = {}
    _cache_lock = threading.Lock()

    @classmethod
    def resolve(cls, explicit_path: str | os.PathLike[str] | None = None) -> str:
        if explicit_path is not None and str(explicit_path).strip() != "":
            return cls._require_existing(Path(explicit_path), "explicit logger_lib_path")

        configured_path = os.environ.get(cls.ENV_VAR, "").strip()
        if configured_path:
            return cls._require_existing(Path(configured_path), f"${cls.ENV_VAR}")

        embedded = cls._resolve_embedded()
        if embedded is not None:
            return embedded

        for candidate in cls._search_candidates():
            if candidate.exists():
                return str(candidate.resolve())

        platform_id = cls.platform_id()
        raise FileNotFoundError(
            "native logger library was not found. "
            f"Set {cls.ENV_VAR}, pass logger_lib_path explicitly, or package "
            f"one of {', '.join(cls.resource_file_names_for_current_platform())} "
            f"under coakka_logger/native/{platform_id}/."
        )

    @classmethod
    def platform_id(cls, os_name: str | None = None, arch_name: str | None = None) -> str:
        resolved_os = os_name or cls._current_os_name()
        resolved_arch = arch_name or cls._current_arch_name()
        if os_name is None and os.name == "nt":
            resolved_os = "Windows"
        return f"{cls.normalize_os(resolved_os)}-{cls.normalize_arch(resolved_arch)}"

    @staticmethod
    def normalize_os(os_name: str) -> str:
        normalized = os_name.lower()
        if "mac" in normalized or "darwin" in normalized:
            return "macos"
        if "linux" in normalized:
            return "linux"
        if "windows" in normalized or normalized.startswith("win"):
            return "windows"
        raise RuntimeError(f"unsupported os.name={os_name}; supported platforms are macOS, Linux, and Windows")

    @staticmethod
    def normalize_arch(arch_name: str) -> str:
        normalized = arch_name.lower()
        if normalized in ("aarch64", "arm64"):
            return "aarch64"
        if normalized in ("x86_64", "amd64"):
            return "x86_64"
        raise RuntimeError(f"unsupported os.arch={arch_name}; supported architectures are aarch64 and x86_64")

    @classmethod
    def resource_file_names_for_current_platform(cls, os_name: str | None = None) -> list[str]:
        versioned_base = f"libcoakka_logger_core-{LOGGER_NATIVE_PACKAGE_VERSION}"
        match cls.normalize_os(os_name or cls._current_os_name()):
            case "macos":
                return [f"{versioned_base}.dylib", "libcoakka_logger_core.dylib", "libcoakka_logger_core.so"]
            case "linux":
                return [f"{versioned_base}.so", "libcoakka_logger_core.so"]
            case "windows":
                return [f"{versioned_base}.dll", "libcoakka_logger_core.dll"]
        raise RuntimeError("unsupported platform")

    @classmethod
    def _resolve_embedded(cls) -> str | None:
        platform_id = cls.platform_id()
        with cls._cache_lock:
            cached = cls._embedded_path_cache.get(platform_id)
            if cached is not None:
                return cached

            resource = cls._resolve_resource(platform_id, cls.resource_file_names_for_current_platform())
            if resource is None:
                return None

            temp_dir = Path(tempfile.mkdtemp(prefix="coakka-logger-native-"))
            atexit.register(shutil.rmtree, temp_dir, ignore_errors=True)
            logger_path = cls._extract_resource(temp_dir, resource[0], resource[1])
            resolved_path = str(logger_path.resolve())
            cls._embedded_path_cache[platform_id] = resolved_path
            return resolved_path

    @staticmethod
    def _resolve_resource(platform_id: str, candidate_file_names: list[str]) -> tuple[str, bytes] | None:
        package_root = resources.files("coakka_logger")
        for file_name in candidate_file_names:
            candidate = package_root / "native" / platform_id / file_name
            if candidate.is_file():
                return str(candidate), candidate.read_bytes()
        return None

    @staticmethod
    def _extract_resource(temp_dir: Path, resource_path: str, resource_bytes: bytes) -> Path:
        target = temp_dir / Path(resource_path).name
        target.write_bytes(resource_bytes)
        return target

    @staticmethod
    def _search_candidates() -> list[Path]:
        cwd = Path.cwd()
        repo_root = Path(__file__).resolve().parents[3]
        names = LoggerLibraryResolver.resource_file_names_for_current_platform()
        roots = [
            cwd / "lib",
            repo_root / "lib",
            repo_root / "logger" / "python" / "lib",
        ]
        return [root / name for root in roots for name in names]

    @staticmethod
    def _current_os_name() -> str:
        if os.name == "nt":
            return "Windows"
        return os.uname().sysname

    @staticmethod
    def _current_arch_name() -> str:
        if os.name == "nt":
            return os.environ.get("PROCESSOR_ARCHITECTURE", "")
        return os.uname().machine

    @staticmethod
    def _require_existing(path: Path, source: str) -> str:
        if not path.exists():
            raise FileNotFoundError(f"{source} does not exist: {path}")
        return str(path.resolve())


def load_logger_library(path: str) -> ctypes.CDLL:
    lib = ctypes.CDLL(path)
    lib.coakka_logger_core_get_abi_version.argtypes = []
    lib.coakka_logger_core_get_abi_version.restype = ctypes.c_uint32
    lib.coakka_logger_core_get_info.argtypes = [ctypes.POINTER(LoggerCoreInfo)]
    lib.coakka_logger_core_get_info.restype = ctypes.c_int
    lib.coakka_logger_core_create.argtypes = [ctypes.POINTER(LoggerCoreConfig), ctypes.POINTER(ctypes.c_void_p)]
    lib.coakka_logger_core_create.restype = ctypes.c_int
    lib.coakka_logger_core_start.argtypes = [ctypes.c_void_p]
    lib.coakka_logger_core_start.restype = ctypes.c_int
    lib.coakka_logger_core_stop.argtypes = [ctypes.c_void_p]
    lib.coakka_logger_core_stop.restype = ctypes.c_int
    lib.coakka_logger_core_destroy.argtypes = [ctypes.c_void_p]
    lib.coakka_logger_core_destroy.restype = None
    lib.coakka_logger_core_get_config.argtypes = [ctypes.c_void_p, ctypes.POINTER(LoggerCoreConfigView)]
    lib.coakka_logger_core_get_config.restype = ctypes.c_int
    lib.coakka_logger_core_get_stats.argtypes = [ctypes.c_void_p, ctypes.POINTER(LoggerCoreStats)]
    lib.coakka_logger_core_get_stats.restype = ctypes.c_int
    lib.coakka_logger_core_is_enabled.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.coakka_logger_core_is_enabled.restype = ctypes.c_int
    lib.coakka_logger_core_is_enabled_for_category.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
    lib.coakka_logger_core_is_enabled_for_category.restype = ctypes.c_int
    lib.coakka_logger_core_log.argtypes = [
        ctypes.c_void_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.POINTER(ctypes.c_uint64),
    ]
    lib.coakka_logger_core_log.restype = ctypes.c_int
    lib.coakka_logger_core_read_next.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint32,
        ctypes.POINTER(LoggerCoreRecordBuffer),
    ]
    lib.coakka_logger_core_read_next.restype = ctypes.c_int
    lib.coakka_logger_status_name.argtypes = [ctypes.c_int]
    lib.coakka_logger_status_name.restype = ctypes.c_char_p
    lib.coakka_logger_level_name.argtypes = [ctypes.c_int]
    lib.coakka_logger_level_name.restype = ctypes.c_char_p
    lib.coakka_logger_state_name.argtypes = [ctypes.c_int]
    lib.coakka_logger_state_name.restype = ctypes.c_char_p
    return lib


def decode_native_text(value: bytes | None) -> str:
    return value.decode("utf-8") if value else ""
