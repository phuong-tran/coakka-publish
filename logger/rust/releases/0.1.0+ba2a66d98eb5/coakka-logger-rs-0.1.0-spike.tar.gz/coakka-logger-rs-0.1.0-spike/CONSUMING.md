# Consuming CoAkka Rust Logger Spike

Use this package as a path dependency or unpack it into a workspace. The wrapper
loads the bundled native logger library for the current supported platform.
