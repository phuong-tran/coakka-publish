# CoAkka Rust Logger Spike

This package is a small Rust wrapper around the public CoAkka logger C ABI. It
bundles native logger libraries for linux-aarch64, linux-x86_64, and
macos-aarch64.
