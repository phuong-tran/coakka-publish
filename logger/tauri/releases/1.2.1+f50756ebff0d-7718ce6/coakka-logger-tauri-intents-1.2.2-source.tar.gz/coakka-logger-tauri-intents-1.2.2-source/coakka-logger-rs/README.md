# Rust Logger Connector

<p align="center">
  <img src="https://raw.githubusercontent.com/phuong-tran/coakka-samples/main/docs/assets/brand/coakka-logo.png" alt="CoAkka" width="480">
</p>

This lane builds the `coakka-logger-rs` source package for the standalone
CoAkka logger core.

The package wraps the public logger C ABI and bundles supported native logger
libraries staged under:

```text
logger/staging/native/1.2.1+f50756ebff0d/
```

Build and smoke the package:

```sh
bash logger/rust/scripts/smoke-packaged-package.sh
```
