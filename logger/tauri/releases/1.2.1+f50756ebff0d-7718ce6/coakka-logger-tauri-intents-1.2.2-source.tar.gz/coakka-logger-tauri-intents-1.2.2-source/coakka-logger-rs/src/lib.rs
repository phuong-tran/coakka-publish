//! Rust host connector for the bounded CoAkka logger core.
//!
//! [`Logger`] owns one started logger instance. Admission is non-blocking and
//! reports queue pressure as `Ok(None)`; reading a delivered record is a
//! separate bounded wait. Drop stops and destroys the owned instance.

#![deny(missing_docs)]
#![deny(clippy::undocumented_unsafe_blocks)]
#![deny(unsafe_op_in_unsafe_fn)]

use std::error::Error;
use std::ffi::{CStr, CString};
use std::fmt;
use std::mem;
use std::os::raw::{c_char, c_int, c_void};
use std::path::{Path, PathBuf};
use std::ptr;
use std::sync::Arc;

const ABI_VERSION: u32 = 10;
const STATUS_OK: i32 = 0;
const STATUS_QUEUE_FULL: i32 = 3;
const STATUS_TIMED_OUT: i32 = 5;
const RTLD_NOW: c_int = 2;

/// Result type returned by logger connector operations.
pub type Result<T> = std::result::Result<T, LoggerError>;

/// Failure returned before, while loading, or across the logger boundary.
#[derive(Debug)]
pub enum LoggerError {
    /// A host value violates a documented input contract.
    InvalidArgument(String),
    /// The logger core rejected a named operation.
    Native {
        /// Stable connector operation name.
        operation: &'static str,
        /// Logger-core status code returned by the operation.
        status: i32,
    },
    /// The connector could not resolve or validate the logger core.
    Load(String),
}

impl fmt::Display for LoggerError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            LoggerError::InvalidArgument(value) => write!(f, "invalid argument: {value}"),
            LoggerError::Native { operation, status } => {
                write!(f, "{operation} failed with status {status}")
            }
            LoggerError::Load(value) => write!(f, "failed to load native logger: {value}"),
        }
    }
}

impl Error for LoggerError {}

/// Bounded logger configuration copied during [`Logger::start`].
#[derive(Clone, Debug)]
pub struct LoggerSpec {
    /// Non-empty application or service identity.
    pub system_name: String,
    /// Maximum admitted records; zero selects 256.
    pub queue_capacity: u32,
    /// Maximum category bytes copied into a delivered record; zero selects 64.
    pub category_capacity: u32,
    /// Maximum message bytes copied into a delivered record; zero selects 512.
    pub message_capacity: u32,
    /// Minimum admitted severity.
    pub min_level: LoggerLevel,
}

impl LoggerSpec {
    /// Creates a conservative in-memory logger spec for `system_name`.
    pub fn new(system_name: impl Into<String>) -> Self {
        Self {
            system_name: system_name.into(),
            queue_capacity: 256,
            category_capacity: 64,
            message_capacity: 512,
            min_level: LoggerLevel::Trace,
        }
    }
}

/// Ordered logger severity used for admission filtering.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(i32)]
pub enum LoggerLevel {
    /// Finest diagnostic detail.
    Trace = 0,
    /// Debug diagnostic detail.
    Debug = 1,
    /// Normal operational information.
    Info = 2,
    /// Recoverable or noteworthy condition.
    Warn = 3,
    /// Failed operation requiring attention.
    Error = 4,
    /// Process- or service-ending failure.
    Fatal = 5,
}

/// Immutable logger-core build identity.
#[derive(Clone, Debug)]
pub struct LoggerInfo {
    /// Host contract version exported by the core.
    pub abi_version: u32,
    /// Logger-core semantic version.
    pub runtime_version: String,
    /// Source revision embedded in the logger core.
    pub git_commit: String,
}

/// Copied bounded-queue counters observed at one instant.
#[derive(Clone, Debug)]
pub struct LoggerStats {
    /// Configured queue capacity in records.
    pub queue_capacity: u32,
    /// Records currently retained in the queue.
    pub queue_depth: u32,
    /// Highest observed queue depth since start.
    pub queue_high_watermark: u32,
    /// Records accepted since start.
    pub emitted_count: u64,
    /// Records delivered to the host since start.
    pub delivered_count: u64,
    /// Records explicitly dropped by bounded policy since start.
    pub dropped_count: u64,
}

/// One owned record copied out of the logger core.
#[derive(Clone, Debug)]
pub struct LoggerRecord {
    /// Monotonic logger-assigned record sequence.
    pub sequence: u64,
    /// Record severity.
    pub level: LoggerLevel,
    /// Owned category text.
    pub category: String,
    /// Owned message text.
    pub message: String,
}

/// Owner of one started bounded logger instance.
///
/// The owner may move between threads, but callers must serialize simultaneous
/// method calls. Dropping it stops and destroys the logger instance.
pub struct Logger {
    native: Arc<Native>,
    handle: *mut c_void,
    spec: LoggerSpec,
}

// SAFETY: ownership may move between threads. The public contract requires a
// shared Logger to be externally serialized; Drop remains the sole destroyer.
unsafe impl Send for Logger {}

impl Logger {
    /// Loads the logger core, copies `spec`, creates the bounded queue, and starts it.
    pub fn start(spec: LoggerSpec) -> Result<Self> {
        if spec.system_name.trim().is_empty() {
            return Err(LoggerError::InvalidArgument(
                "system_name is required".to_string(),
            ));
        }
        let native = Arc::new(Native::open()?);
        // SAFETY: Native::open validates this function symbol and its signature.
        let abi = unsafe { (native.get_abi_version)() };
        if abi != ABI_VERSION {
            return Err(LoggerError::Load(format!("unexpected ABI version {abi}")));
        }
        let system_name = CString::new(spec.system_name.clone())
            .map_err(|_| LoggerError::InvalidArgument("system_name contains NUL".to_string()))?;
        let config = NativeConfig {
            struct_size: mem::size_of::<NativeConfig>(),
            system_name: system_name.as_ptr(),
            queue_capacity: if spec.queue_capacity == 0 {
                256
            } else {
                spec.queue_capacity
            },
            min_level: spec.min_level as i32,
            sink_mode: 0,
            output_path: ptr::null(),
            max_file_size_bytes: 0,
            max_total_size_bytes: 0,
            pressure_state: 0,
            max_archived_files: 0,
            category_capacity: if spec.category_capacity == 0 {
                64
            } else {
                spec.category_capacity
            },
            message_capacity: if spec.message_capacity == 0 {
                512
            } else {
                spec.message_capacity
            },
            emergency_output_path: ptr::null(),
            emergency_file_size_bytes: 0,
            category_override_capacity: 0,
            sink_targets: 0,
            console_fd: 0,
            console_stdout_fd: 0,
            console_stderr_fd: 0,
            console_stdout_level_mask: 0,
            console_stderr_level_mask: 0,
            file_output_path: ptr::null(),
            file_max_size_bytes: 0,
            file_total_size_limit_bytes: 0,
            file_max_archived_files: 0,
            file_emergency_output_path: ptr::null(),
            file_emergency_size_bytes: 0,
        };
        let mut handle: *mut c_void = ptr::null_mut();
        // SAFETY: config and its borrowed system_name remain valid for this synchronous call.
        require("create", unsafe { (native.create)(&config, &mut handle) })?;
        if handle.is_null() {
            return Err(LoggerError::Load(
                "logger create returned a null handle".to_string(),
            ));
        }
        // SAFETY: create returned the owned handle and native remains loaded.
        if let Err(err) = require("start", unsafe { (native.start)(handle) }) {
            // SAFETY: start failed before ownership was published; destroy consumes the handle.
            unsafe { (native.destroy)(handle) };
            return Err(err);
        }
        Ok(Self {
            native,
            handle,
            spec: LoggerSpec {
                queue_capacity: config.queue_capacity,
                category_capacity: config.category_capacity,
                message_capacity: config.message_capacity,
                ..spec
            },
        })
    }

    /// Reads immutable logger-core build information without starting a logger.
    pub fn read_info() -> Result<LoggerInfo> {
        Native::open()?.read_info()
    }

    /// Attempts non-blocking admission of one record.
    ///
    /// Returns the assigned sequence on admission or `None` when the bounded
    /// queue is full. Category and message are copied during the call.
    pub fn try_log(
        &self,
        level: LoggerLevel,
        category: &str,
        message: &str,
    ) -> Result<Option<u64>> {
        let category = CString::new(category)
            .map_err(|_| LoggerError::InvalidArgument("category contains NUL".to_string()))?;
        let message = CString::new(message)
            .map_err(|_| LoggerError::InvalidArgument("message contains NUL".to_string()))?;
        let mut sequence = 0u64;
        // SAFETY: self owns a live handle; the C strings and sequence output live through the call.
        let status = unsafe {
            (self.native.log)(
                self.handle,
                level as i32,
                category.as_ptr(),
                message.as_ptr(),
                &mut sequence,
            )
        };
        if status == STATUS_OK {
            Ok(Some(sequence))
        } else if status == STATUS_QUEUE_FULL {
            Ok(None)
        } else {
            Err(LoggerError::Native {
                operation: "log",
                status,
            })
        }
    }

    /// Attempts non-blocking admission at [`LoggerLevel::Info`].
    pub fn try_info(&self, category: &str, message: &str) -> Result<Option<u64>> {
        self.try_log(LoggerLevel::Info, category, message)
    }

    /// Waits up to `timeout_ms` for the next delivered record.
    ///
    /// Returns `None` on timeout. Returned text owns its storage.
    pub fn await_next(&self, timeout_ms: u32) -> Result<Option<LoggerRecord>> {
        let mut category = vec![0u8; self.spec.category_capacity.max(1) as usize];
        let mut message = vec![0u8; self.spec.message_capacity.max(1) as usize];
        let mut record = NativeRecord {
            struct_size: mem::size_of::<NativeRecord>(),
            sequence: 0,
            wall_time_unix_ms: 0,
            monotonic_time_ns: 0,
            level: 0,
            category: category.as_mut_ptr() as *mut c_char,
            category_capacity: category.len(),
            category_length: 0,
            message: message.as_mut_ptr() as *mut c_char,
            message_capacity: message.len(),
            message_length: 0,
        };
        // SAFETY: record points at live, writable buffers whose capacities are declared exactly.
        let status = unsafe { (self.native.read_next)(self.handle, timeout_ms, &mut record) };
        if status == STATUS_TIMED_OUT {
            return Ok(None);
        }
        require("read_next", status)?;
        if record.category_length > category.len() || record.message_length > message.len() {
            return Err(LoggerError::Load(
                "logger returned a record length larger than its destination buffer".to_string(),
            ));
        }
        Ok(Some(LoggerRecord {
            sequence: record.sequence,
            level: level_from_i32(record.level),
            category: String::from_utf8_lossy(&category[..record.category_length]).to_string(),
            message: String::from_utf8_lossy(&message[..record.message_length]).to_string(),
        }))
    }

    /// Returns a copied queue and delivery counter snapshot.
    pub fn stats(&self) -> Result<LoggerStats> {
        let mut stats = NativeStats {
            struct_size: mem::size_of::<NativeStats>(),
            ..NativeStats::default()
        };
        // SAFETY: self owns a live handle and stats is a correctly sized writable output.
        require("get_stats", unsafe {
            (self.native.get_stats)(self.handle, &mut stats)
        })?;
        Ok(LoggerStats {
            queue_capacity: stats.queue_capacity,
            queue_depth: stats.queue_depth,
            queue_high_watermark: stats.queue_high_watermark,
            emitted_count: stats.emitted_count,
            delivered_count: stats.delivered_count,
            dropped_count: stats.dropped_count,
        })
    }
}

impl Drop for Logger {
    fn drop(&mut self) {
        // SAFETY: Logger is the sole owner; stop precedes the single destroy.
        unsafe {
            (self.native.stop)(self.handle);
            (self.native.destroy)(self.handle);
        }
    }
}

fn require(operation: &'static str, status: i32) -> Result<()> {
    if status == STATUS_OK {
        Ok(())
    } else {
        Err(LoggerError::Native { operation, status })
    }
}

fn level_from_i32(value: i32) -> LoggerLevel {
    match value {
        0 => LoggerLevel::Trace,
        1 => LoggerLevel::Debug,
        2 => LoggerLevel::Info,
        3 => LoggerLevel::Warn,
        4 => LoggerLevel::Error,
        5 => LoggerLevel::Fatal,
        _ => LoggerLevel::Info,
    }
}

fn c_string(ptr: *const c_char) -> String {
    if ptr.is_null() {
        String::new()
    } else {
        // SAFETY: callers only pass optional NUL-terminated strings borrowed from core snapshots.
        unsafe { CStr::from_ptr(ptr).to_string_lossy().to_string() }
    }
}

struct Native {
    handle: *mut c_void,
    get_abi_version: unsafe extern "C" fn() -> u32,
    get_info: unsafe extern "C" fn(*mut NativeInfo) -> i32,
    create: unsafe extern "C" fn(*const NativeConfig, *mut *mut c_void) -> i32,
    start: unsafe extern "C" fn(*mut c_void) -> i32,
    stop: unsafe extern "C" fn(*mut c_void) -> i32,
    destroy: unsafe extern "C" fn(*mut c_void),
    get_stats: unsafe extern "C" fn(*mut c_void, *mut NativeStats) -> i32,
    log: unsafe extern "C" fn(*mut c_void, i32, *const c_char, *const c_char, *mut u64) -> i32,
    read_next: unsafe extern "C" fn(*mut c_void, u32, *mut NativeRecord) -> i32,
}

// SAFETY: Native is an immutable function table plus a process library handle;
// Logger owns and externally serializes mutable logger instances.
unsafe impl Send for Native {}
// SAFETY: all fields are immutable after construction and library unload waits
// for the final Arc<Native> owner.
unsafe impl Sync for Native {}

impl Native {
    fn open() -> Result<Self> {
        let path = resolve_native_path()?;
        let c_path = CString::new(path.to_string_lossy().as_bytes())
            .map_err(|_| LoggerError::Load("native path contains NUL".to_string()))?;
        // SAFETY: c_path is NUL-terminated and lives through the loader call.
        let handle = unsafe { open_library(c_path.as_ptr()) };
        if handle.is_null() {
            return Err(LoggerError::Load(dlerror_string()));
        }
        // SAFETY: symbol validates non-null addresses and converts each to its
        // reviewed exported function signature while the library is loaded.
        let loaded = unsafe {
            (|| {
                Ok(Self {
                    handle,
                    get_abi_version: symbol(handle, "coakka_logger_core_get_abi_version")?,
                    get_info: symbol(handle, "coakka_logger_core_get_info")?,
                    create: symbol(handle, "coakka_logger_core_create")?,
                    start: symbol(handle, "coakka_logger_core_start")?,
                    stop: symbol(handle, "coakka_logger_core_stop")?,
                    destroy: symbol(handle, "coakka_logger_core_destroy")?,
                    get_stats: symbol(handle, "coakka_logger_core_get_stats")?,
                    log: symbol(handle, "coakka_logger_core_log")?,
                    read_next: symbol(handle, "coakka_logger_core_read_next")?,
                })
            })()
        };
        if loaded.is_err() {
            // SAFETY: no Native owner exists on the error path, so this closes
            // the loader handle exactly once after a partial symbol load.
            unsafe { close_library(handle) };
        }
        loaded
    }

    fn read_info(&self) -> Result<LoggerInfo> {
        let mut info = NativeInfo {
            struct_size: mem::size_of::<NativeInfo>(),
            abi_version: 0,
            runtime_version: ptr::null(),
            git_commit: ptr::null(),
            docs_hint: ptr::null(),
        };
        // SAFETY: the function table is validated and info is a sized writable output.
        require("get_info", unsafe { (self.get_info)(&mut info) })?;
        Ok(LoggerInfo {
            abi_version: info.abi_version,
            runtime_version: c_string(info.runtime_version),
            git_commit: c_string(info.git_commit),
        })
    }
}

impl Drop for Native {
    fn drop(&mut self) {
        // SAFETY: the final Arc owner unloads the library after all Logger owners are gone.
        unsafe {
            close_library(self.handle);
        }
    }
}

fn resolve_native_path() -> Result<PathBuf> {
    let root = Path::new(env!("CARGO_MANIFEST_DIR"));
    let platform = platform_id()?;
    let candidates: &[&str] = if cfg!(target_os = "macos") {
        &[
            "libcoakka_logger_core-1.2.1+f50756ebff0d.dylib",
            "libcoakka_logger_core.dylib",
        ]
    } else if cfg!(target_os = "windows") {
        &[
            "libcoakka_logger_core-1.2.1+f50756ebff0d.dll",
            "libcoakka_logger_core.dll",
        ]
    } else {
        &[
            "libcoakka_logger_core-1.2.1+f50756ebff0d.so",
            "libcoakka_logger_core.so",
        ]
    };
    for candidate in candidates {
        let path = root.join("native").join(&platform).join(candidate);
        if path.is_file() {
            return Ok(path);
        }
    }
    Err(LoggerError::Load(format!(
        "no bundled native logger for {platform}"
    )))
}

fn platform_id() -> Result<String> {
    let os = if cfg!(target_os = "macos") {
        "macos"
    } else if cfg!(target_os = "linux") {
        "linux"
    } else if cfg!(target_os = "windows") {
        "windows"
    } else {
        return Err(LoggerError::Load(
            "unsupported operating system".to_string(),
        ));
    };
    let arch = if cfg!(target_arch = "aarch64") {
        "aarch64"
    } else if cfg!(target_arch = "x86_64") {
        "x86_64"
    } else {
        return Err(LoggerError::Load("unsupported architecture".to_string()));
    };
    Ok(format!("{os}-{arch}"))
}

unsafe fn symbol<T>(handle: *mut c_void, name: &str) -> Result<T> {
    let c_name = CString::new(name).unwrap();
    // SAFETY: handle is a live library and c_name is a live NUL-terminated symbol name.
    let ptr = unsafe { load_symbol_pointer(handle, c_name.as_ptr()) };
    if ptr.is_null() {
        Err(LoggerError::Load(format!(
            "missing symbol {name}: {}",
            dlerror_string()
        )))
    } else {
        // SAFETY: callers select T from a reviewed exported function signature;
        // the non-null address remains valid for Native's lifetime.
        Ok(unsafe { mem::transmute_copy(&ptr) })
    }
}

fn dlerror_string() -> String {
    // SAFETY: platform error APIs return process-owned diagnostic state which
    // is copied before returning from this function.
    unsafe {
        #[cfg(target_os = "windows")]
        {
            format!("GetLastError={}", GetLastError())
        }
        #[cfg(any(target_os = "linux", target_os = "macos"))]
        {
            let ptr = dlerror();
            if ptr.is_null() {
                "unknown dlerror".to_string()
            } else {
                CStr::from_ptr(ptr).to_string_lossy().to_string()
            }
        }
    }
}

#[repr(C)]
struct NativeInfo {
    struct_size: usize,
    abi_version: u32,
    runtime_version: *const c_char,
    git_commit: *const c_char,
    docs_hint: *const c_char,
}

#[repr(C)]
struct NativeConfig {
    struct_size: usize,
    system_name: *const c_char,
    queue_capacity: u32,
    min_level: i32,
    sink_mode: i32,
    output_path: *const c_char,
    max_file_size_bytes: u64,
    max_total_size_bytes: u64,
    pressure_state: i32,
    max_archived_files: u32,
    category_capacity: u32,
    message_capacity: u32,
    emergency_output_path: *const c_char,
    emergency_file_size_bytes: u64,
    category_override_capacity: u32,
    sink_targets: u32,
    console_fd: i32,
    console_stdout_fd: i32,
    console_stderr_fd: i32,
    console_stdout_level_mask: u32,
    console_stderr_level_mask: u32,
    file_output_path: *const c_char,
    file_max_size_bytes: u64,
    file_total_size_limit_bytes: u64,
    file_max_archived_files: u32,
    file_emergency_output_path: *const c_char,
    file_emergency_size_bytes: u64,
}

#[repr(C)]
struct NativeRecord {
    struct_size: usize,
    sequence: u64,
    wall_time_unix_ms: u64,
    monotonic_time_ns: u64,
    level: i32,
    category: *mut c_char,
    category_capacity: usize,
    category_length: usize,
    message: *mut c_char,
    message_capacity: usize,
    message_length: usize,
}

#[repr(C)]
#[derive(Default)]
struct NativeStats {
    struct_size: usize,
    state: i32,
    queue_capacity: u32,
    queue_depth: u32,
    queue_high_watermark: u32,
    next_sequence: u64,
    emitted_count: u64,
    delivered_count: u64,
    dropped_count: u64,
    dropped_below_level_count: u64,
    sink_write_count: u64,
    sink_bytes_written: u64,
    sink_write_failure_count: u64,
    sink_current_file_size_bytes: u64,
    sink_total_size_bytes: u64,
    pressure_state: i32,
    sink_roll_count: u64,
    sink_deleted_archive_count: u64,
    dropped_pressure_count: u64,
    emergency_active: u32,
    emergency_last_reason: i32,
    emergency_enter_count: u64,
    emergency_recovered_count: u64,
    emergency_bytes_written: u64,
    emergency_write_failure_count: u64,
    emergency_overwrite_count: u64,
    emergency_last_recovered_reason: i32,
    emergency_last_recovered_duration_ms: u64,
    emergency_last_recovered_dropped_total: u64,
    emergency_last_recovered_dropped_pressure: u64,
    emergency_last_recovered_deleted_archives: u64,
    reload_count: u64,
    category_override_count: u32,
    sink_reopen_failure_count: u64,
    sink_roll_failure_count: u64,
    sink_append_failure_count: u64,
    sink_cleanup_failure_count: u64,
    file_write_count: u64,
    file_bytes_written: u64,
    file_write_failure_count: u64,
    file_current_size_bytes: u64,
    file_total_size_bytes: u64,
    file_roll_count: u64,
    file_deleted_archive_count: u64,
    file_reopen_failure_count: u64,
    file_roll_failure_count: u64,
    file_append_failure_count: u64,
    file_cleanup_failure_count: u64,
    console_write_count: u64,
    console_bytes_written: u64,
    console_write_failure_count: u64,
}

#[cfg(any(target_os = "linux", target_os = "macos"))]
extern "C" {
    fn dlopen(filename: *const c_char, flags: c_int) -> *mut c_void;
    fn dlsym(handle: *mut c_void, symbol: *const c_char) -> *mut c_void;
    fn dlclose(handle: *mut c_void) -> c_int;
    fn dlerror() -> *const c_char;
}

#[cfg(target_os = "windows")]
type HModule = *mut c_void;

#[cfg(target_os = "windows")]
extern "system" {
    fn LoadLibraryA(lpLibFileName: *const c_char) -> HModule;
    fn GetProcAddress(hModule: HModule, lpProcName: *const c_char) -> *mut c_void;
    fn FreeLibrary(hLibModule: HModule) -> i32;
    fn GetLastError() -> u32;
}

#[cfg(any(target_os = "linux", target_os = "macos"))]
unsafe fn open_library(path: *const c_char) -> *mut c_void {
    // SAFETY: caller supplies a live NUL-terminated path.
    unsafe { dlopen(path, RTLD_NOW) }
}

#[cfg(target_os = "windows")]
unsafe fn open_library(path: *const c_char) -> *mut c_void {
    // SAFETY: caller supplies a live NUL-terminated path.
    unsafe { LoadLibraryA(path) }
}

#[cfg(any(target_os = "linux", target_os = "macos"))]
unsafe fn load_symbol_pointer(handle: *mut c_void, symbol: *const c_char) -> *mut c_void {
    // SAFETY: caller supplies a live library and NUL-terminated symbol.
    unsafe { dlsym(handle, symbol) }
}

#[cfg(target_os = "windows")]
unsafe fn load_symbol_pointer(handle: *mut c_void, symbol: *const c_char) -> *mut c_void {
    // SAFETY: caller supplies a live library and NUL-terminated symbol.
    unsafe { GetProcAddress(handle, symbol) }
}

#[cfg(any(target_os = "linux", target_os = "macos"))]
unsafe fn close_library(handle: *mut c_void) {
    // SAFETY: caller is the final owner of this live library handle.
    unsafe { dlclose(handle) };
}

#[cfg(target_os = "windows")]
unsafe fn close_library(handle: *mut c_void) {
    // SAFETY: caller is the final owner of this live library handle.
    unsafe { FreeLibrary(handle) };
}
