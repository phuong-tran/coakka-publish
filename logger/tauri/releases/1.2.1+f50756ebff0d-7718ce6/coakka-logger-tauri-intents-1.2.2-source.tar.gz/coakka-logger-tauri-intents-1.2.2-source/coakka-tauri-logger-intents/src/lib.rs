use std::sync::{Arc, Mutex};

use coakka_logger::{Logger, LoggerError, LoggerLevel, LoggerRecord, LoggerSpec, LoggerStats};
use serde::{Deserialize, Serialize};

pub type Result<T> = std::result::Result<T, LoggerIntentError>;

#[derive(Copy, Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum LoggerIntentLevel {
    Trace,
    Debug,
    Info,
    Warn,
    Error,
    Fatal,
}

impl LoggerIntentLevel {
    fn to_logger_level(self) -> LoggerLevel {
        match self {
            Self::Trace => LoggerLevel::Trace,
            Self::Debug => LoggerLevel::Debug,
            Self::Info => LoggerLevel::Info,
            Self::Warn => LoggerLevel::Warn,
            Self::Error => LoggerLevel::Error,
            Self::Fatal => LoggerLevel::Fatal,
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct LoggerIntent {
    pub intent_id: String,
    pub source: String,
    pub level: LoggerIntentLevel,
    pub category: String,
    pub message: String,
    #[serde(default)]
    pub await_drain_ms: Option<u32>,
}

impl LoggerIntent {
    pub fn require_valid(&self) -> Result<()> {
        require_non_blank("intentId", &self.intent_id)?;
        require_non_blank("source", &self.source)?;
        require_non_blank("category", &self.category)?;
        if self.message.as_bytes().contains(&0) {
            return Err(LoggerIntentError::invalid_intent(
                "message must not contain NUL bytes",
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct LoggerIntentResult {
    pub intent_id: String,
    pub source: String,
    pub accepted: bool,
    pub sequence: Option<u64>,
    #[serde(default)]
    pub record: Option<LoggerRecordProjection>,
    pub stats: LoggerStatsProjection,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct LoggerRecordProjection {
    pub sequence: u64,
    pub level: LoggerIntentLevel,
    pub category: String,
    pub message: String,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct LoggerStatsProjection {
    pub queue_capacity: u32,
    pub queue_depth: u32,
    pub queue_high_watermark: u32,
    pub emitted_count: u64,
    pub delivered_count: u64,
    pub dropped_count: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct LoggerIntentError {
    pub code: String,
    pub message: String,
}

impl LoggerIntentError {
    pub fn invalid_intent(message: impl Into<String>) -> Self {
        Self {
            code: "INVALID_LOGGER_INTENT".to_string(),
            message: message.into(),
        }
    }

    pub fn logger(message: impl Into<String>) -> Self {
        Self {
            code: "LOGGER_ERROR".to_string(),
            message: message.into(),
        }
    }
}

pub struct TauriLoggerIntentBridge {
    logger: Arc<Mutex<Logger>>,
}

impl Clone for TauriLoggerIntentBridge {
    fn clone(&self) -> Self {
        Self {
            logger: self.logger.clone(),
        }
    }
}

impl TauriLoggerIntentBridge {
    pub fn start(spec: LoggerSpec) -> Result<Self> {
        let logger = Logger::start(spec).map_err(map_logger_error)?;
        Ok(Self::new(logger))
    }

    pub fn new(logger: Logger) -> Self {
        Self {
            logger: Arc::new(Mutex::new(logger)),
        }
    }

    pub fn log_intent(&self, intent: LoggerIntent) -> Result<LoggerIntentResult> {
        intent.require_valid()?;
        let logger = self
            .logger
            .lock()
            .map_err(|_| LoggerIntentError::logger("logger bridge lock poisoned"))?;
        let sequence = logger
            .try_log(intent.level.to_logger_level(), &intent.category, &intent.message)
            .map_err(map_logger_error)?;
        let record = match (sequence, intent.await_drain_ms) {
            (Some(_), Some(timeout_ms)) => logger.await_next(timeout_ms).map_err(map_logger_error)?,
            _ => None,
        };
        let stats = logger.stats().map_err(map_logger_error)?;
        Ok(LoggerIntentResult {
            intent_id: intent.intent_id,
            source: intent.source,
            accepted: sequence.is_some(),
            sequence,
            record: record.map(LoggerRecordProjection::from_record),
            stats: LoggerStatsProjection::from_stats(stats),
        })
    }
}

pub fn coakka_log_intent_command(
    bridge: &TauriLoggerIntentBridge,
    intent: LoggerIntent,
) -> Result<LoggerIntentResult> {
    bridge.log_intent(intent)
}

impl LoggerRecordProjection {
    fn from_record(record: LoggerRecord) -> Self {
        Self {
            sequence: record.sequence,
            level: match record.level {
                LoggerLevel::Trace => LoggerIntentLevel::Trace,
                LoggerLevel::Debug => LoggerIntentLevel::Debug,
                LoggerLevel::Info => LoggerIntentLevel::Info,
                LoggerLevel::Warn => LoggerIntentLevel::Warn,
                LoggerLevel::Error => LoggerIntentLevel::Error,
                LoggerLevel::Fatal => LoggerIntentLevel::Fatal,
            },
            category: record.category,
            message: record.message,
        }
    }
}

impl LoggerStatsProjection {
    fn from_stats(stats: LoggerStats) -> Self {
        Self {
            queue_capacity: stats.queue_capacity,
            queue_depth: stats.queue_depth,
            queue_high_watermark: stats.queue_high_watermark,
            emitted_count: stats.emitted_count,
            delivered_count: stats.delivered_count,
            dropped_count: stats.dropped_count,
        }
    }
}

fn require_non_blank(name: &str, value: &str) -> Result<()> {
    if value.trim().is_empty() {
        return Err(LoggerIntentError::invalid_intent(format!(
            "{name} must not be blank"
        )));
    }
    Ok(())
}

fn map_logger_error(error: LoggerError) -> LoggerIntentError {
    LoggerIntentError::logger(error.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn log_intent_emits_and_drains_one_record() {
        let bridge = TauriLoggerIntentBridge::start(LoggerSpec::new("tauri-logger-intent-test"))
            .expect("start logger bridge");
        let result = coakka_log_intent_command(
            &bridge,
            LoggerIntent {
                intent_id: "log-1".to_string(),
                source: "tauri-webview".to_string(),
                level: LoggerIntentLevel::Info,
                category: "samples.logger.tauri.basic".to_string(),
                message: "{\"event\":\"hello\",\"language\":\"tauri\"}".to_string(),
                await_drain_ms: Some(1_000),
            },
        )
        .expect("log intent");

        assert!(result.accepted);
        assert_eq!(result.sequence, Some(1));
        assert_eq!(
            result.record.as_ref().map(|record| record.message.as_str()),
            Some("{\"event\":\"hello\",\"language\":\"tauri\"}")
        );
        assert_eq!(result.stats.emitted_count, 1);
        assert_eq!(result.stats.delivered_count, 1);
        assert_eq!(result.stats.dropped_count, 0);
    }

    #[test]
    fn log_intent_reports_queue_pressure() {
        let mut spec = LoggerSpec::new("tauri-logger-pressure-test");
        spec.queue_capacity = 2;
        let bridge = TauriLoggerIntentBridge::start(spec).expect("start logger bridge");
        let mut accepted = 0;
        let mut rejected = 0;

        for index in 0..8 {
            let result = coakka_log_intent_command(
                &bridge,
                LoggerIntent {
                    intent_id: format!("log-{index}"),
                    source: "tauri-webview".to_string(),
                    level: LoggerIntentLevel::Info,
                    category: "samples.logger.tauri.pressure".to_string(),
                    message: format!("{{\"event\":\"pressure\",\"index\":{index}}}"),
                    await_drain_ms: None,
                },
            )
            .expect("log intent");
            if result.accepted {
                accepted += 1;
            } else {
                rejected += 1;
            }
        }

        assert_eq!(accepted, 2);
        assert_eq!(rejected, 6);
        let stats = bridge
            .logger
            .lock()
            .expect("lock logger")
            .stats()
            .expect("stats");
        assert_eq!(stats.dropped_count, 6);
        assert_eq!(stats.queue_high_watermark, 2);
    }

    #[test]
    fn rejects_blank_intent_before_logger_boundary() {
        let intent = LoggerIntent {
            intent_id: String::new(),
            source: "tauri-webview".to_string(),
            level: LoggerIntentLevel::Info,
            category: "samples.logger.tauri.basic".to_string(),
            message: "{}".to_string(),
            await_drain_ms: None,
        };

        let error = intent.require_valid().expect_err("blank intent rejected");
        assert_eq!(error.code, "INVALID_LOGGER_INTENT");
    }
}
