use coakka_logger_rs::LoggerSpec;
use coakka_tauri_logger_intents::{
    coakka_log_intent_command, LoggerIntent, LoggerIntentLevel, TauriLoggerIntentBridge,
};

fn main() -> coakka_tauri_logger_intents::Result<()> {
    let bridge = TauriLoggerIntentBridge::start(LoggerSpec::new("tauri-logger-package-smoke"))?;
    let result = coakka_log_intent_command(
        &bridge,
        LoggerIntent {
            intent_id: "package-log-1".to_string(),
            source: "tauri-webview".to_string(),
            level: LoggerIntentLevel::Info,
            category: "samples.logger.tauri.package".to_string(),
            message: "{\"event\":\"hello-tauri-logger-package\"}".to_string(),
            await_drain_ms: Some(1_000),
        },
    )?;

    println!(
        "coakka_tauri_logger_package_smoke ok accepted={} sequence={}",
        result.accepted,
        result.sequence.unwrap_or_default()
    );
    Ok(())
}
