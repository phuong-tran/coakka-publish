# CoAkka Logger Zig Connector

Experimental Zig lane for the standalone CoAkka native logger ABI.

This lane keeps the host boundary small:

- dynamically load `libcoakka_logger_core`
- create/start/stop one logger instance
- emit one `category + message` record
- read one record through the manual-drain path

## Smoke

```sh
COAKKA_LOGGER_LIB=/path/to/libcoakka_logger_core.dylib bash scripts/smoke.sh
```

If `zig` is not installed, the script exits successfully with a skip message.

