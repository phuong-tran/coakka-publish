#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
zig_root="$(cd "${script_dir}/.." && pwd)"
connector_root="$(cd "${zig_root}/../.." && pwd)"

native_core_version="1.2.1"
native_git_commit="f50756ebff0d"
native_package_version="${native_core_version}+${native_git_commit}"
connector_source_git_commit="$(git -C "${connector_root}" rev-parse --short=7 HEAD)"
artifact_version="1.2.1-source"
package_name="coakka-logger-zig"
package_root_name="${package_name}-${artifact_version}"
archive_name="${package_root_name}.tar.gz"
staging_root="${connector_root}/logger/staging/native/${native_package_version}"
tmp_dir="$(mktemp -d)"

trap 'rm -rf "${tmp_dir}"' EXIT

if [[ ! -d "${staging_root}" ]]; then
  echo "[zig-pack-logger] logger native staging directory not found: ${staging_root}" >&2
  exit 1
fi

package_root="${tmp_dir}/${package_root_name}"
mkdir -p "${package_root}"

cp "${zig_root}/README.md" "${package_root}/README.md"
cp "${zig_root}/CONSUMING.md" "${package_root}/CONSUMING.md"
cp "${zig_root}/build.zig" "${package_root}/build.zig"
cp -R "${zig_root}/src" "${package_root}/src"
cp -R "${zig_root}/scripts" "${package_root}/scripts"

cat > "${package_root}/coakka-logger-zig-package.json" <<EOF
{
  "schema_version": 1,
  "product_lane": "logger",
  "language_lane": "zig",
  "package_name": "coakka-logger-zig",
  "artifact_version": "1.2.1-source",
  "bundled_native_core_version": "${native_core_version}",
  "bundled_native_package_version": "${native_package_version}",
  "bundled_native_git_commit": "${native_git_commit}",
  "connector_source_git_commit": "${connector_source_git_commit}",
  "release_directory": "${native_package_version}-${connector_source_git_commit}",
  "source_package": true
}
EOF

for platform in macos-aarch64 linux-aarch64 linux-x86_64 windows-aarch64 windows-x86_64; do
  source_lib="${staging_root}/${platform}/libcoakka_logger_core.so"
  target_suffix="so"
  if [[ "${platform}" == macos-* ]]; then
    source_lib="${staging_root}/${platform}/libcoakka_logger_core.dylib"
    target_suffix="dylib"
  elif [[ "${platform}" == windows-* ]]; then
    source_lib="${staging_root}/${platform}/libcoakka_logger_core.dll"
    target_suffix="dll"
  fi
  if [[ ! -f "${source_lib}" ]]; then
    echo "[zig-pack-logger] staged logger native not found: ${source_lib}" >&2
    exit 1
  fi
  target_dir="${package_root}/native/${platform}"
  mkdir -p "${target_dir}"
  cp "${source_lib}" "${target_dir}/libcoakka_logger_core.${target_suffix}"
  cp "${source_lib}" "${target_dir}/libcoakka_logger_core-${native_package_version}.${target_suffix}"
done

rm -f "${zig_root}/${package_name}-"*.tar.gz
COPYFILE_DISABLE=1 tar -C "${tmp_dir}" -czf "${zig_root}/${archive_name}" "${package_root_name}"

echo "[zig-pack-logger] archive=${zig_root}/${archive_name}"
