const std = @import("std");

pub const AbiVersion: u32 = 10;
const StatusOk: c_int = 0;
const StatusTimedOut: c_int = 5;
pub const LevelInfo: c_int = 2;

pub const LoggerHandle = opaque {};

pub const LoggerInfo = extern struct {
    struct_size: usize,
    abi_version: u32,
    runtime_version: ?[*:0]const u8,
    git_commit: ?[*:0]const u8,
    docs_hint: ?[*:0]const u8,
};

pub const LoggerConfig = extern struct {
    struct_size: usize,
    system_name: [*:0]const u8,
    queue_capacity: u32,
    min_level: c_int,
    sink_mode: c_int,
    output_path: ?[*:0]const u8,
    max_file_size_bytes: u64,
    max_total_size_bytes: u64,
    pressure_state: c_int,
    max_archived_files: u32,
    category_capacity: u32,
    message_capacity: u32,
    emergency_output_path: ?[*:0]const u8,
    emergency_file_size_bytes: u64,
    category_override_capacity: u32,
    sink_targets: u32,
    console_fd: i32,
    console_stdout_fd: i32,
    console_stderr_fd: i32,
    console_stdout_level_mask: u32,
    console_stderr_level_mask: u32,
    file_output_path: ?[*:0]const u8,
    file_max_size_bytes: u64,
    file_total_size_limit_bytes: u64,
    file_max_archived_files: u32,
    file_emergency_output_path: ?[*:0]const u8,
    file_emergency_size_bytes: u64,
};

pub const RecordBuffer = extern struct {
    struct_size: usize,
    sequence: u64,
    wall_time_unix_ms: u64,
    monotonic_time_ns: u64,
    level: c_int,
    category: [*]u8,
    category_capacity: usize,
    category_length: usize,
    message: [*]u8,
    message_capacity: usize,
    message_length: usize,
};

const GetAbiVersionFn = *const fn () callconv(.c) u32;
const GetInfoFn = *const fn (*LoggerInfo) callconv(.c) c_int;
const CreateFn = *const fn (*const LoggerConfig, *?*LoggerHandle) callconv(.c) c_int;
const StartFn = *const fn (?*LoggerHandle) callconv(.c) c_int;
const StopFn = *const fn (?*LoggerHandle) callconv(.c) c_int;
const DestroyFn = *const fn (?*LoggerHandle) callconv(.c) void;
const LogFn = *const fn (?*LoggerHandle, c_int, [*:0]const u8, [*:0]const u8, *u64) callconv(.c) c_int;
const ReadNextFn = *const fn (?*LoggerHandle, u32, *RecordBuffer) callconv(.c) c_int;

pub const NativeLogger = struct {
    lib: std.DynLib,
    get_abi_version: GetAbiVersionFn,
    get_info: GetInfoFn,
    create: CreateFn,
    start: StartFn,
    stop: StopFn,
    destroy: DestroyFn,
    log: LogFn,
    read_next: ReadNextFn,

    pub fn open(path: []const u8) !NativeLogger {
        var lib = try std.DynLib.open(path);
        errdefer lib.close();

        return .{
            .lib = lib,
            .get_abi_version = lib.lookup(GetAbiVersionFn, "coakka_logger_core_get_abi_version") orelse return error.MissingSymbol,
            .get_info = lib.lookup(GetInfoFn, "coakka_logger_core_get_info") orelse return error.MissingSymbol,
            .create = lib.lookup(CreateFn, "coakka_logger_core_create") orelse return error.MissingSymbol,
            .start = lib.lookup(StartFn, "coakka_logger_core_start") orelse return error.MissingSymbol,
            .stop = lib.lookup(StopFn, "coakka_logger_core_stop") orelse return error.MissingSymbol,
            .destroy = lib.lookup(DestroyFn, "coakka_logger_core_destroy") orelse return error.MissingSymbol,
            .log = lib.lookup(LogFn, "coakka_logger_core_log") orelse return error.MissingSymbol,
            .read_next = lib.lookup(ReadNextFn, "coakka_logger_core_read_next") orelse return error.MissingSymbol,
        };
    }

    pub fn close(self: *NativeLogger) void {
        self.lib.close();
    }

    pub fn readInfo(self: *NativeLogger) !LoggerInfo {
        var info = std.mem.zeroes(LoggerInfo);
        info.struct_size = @sizeOf(LoggerInfo);
        if (self.get_info(&info) != StatusOk) {
            return error.NativeCallFailed;
        }
        if (info.abi_version != AbiVersion) {
            return error.UnsupportedAbiVersion;
        }
        return info;
    }

    pub fn smoke(self: *NativeLogger) !u64 {
        _ = try self.readInfo();
        var config = std.mem.zeroes(LoggerConfig);
        config.struct_size = @sizeOf(LoggerConfig);
        config.system_name = "zig-logger-smoke";
        config.queue_capacity = 32;
        config.min_level = LevelInfo;
        config.category_capacity = 64;
        config.message_capacity = 256;

        var handle: ?*LoggerHandle = null;
        if (self.create(&config, &handle) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.destroy(handle);
        if (self.start(handle) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer _ = self.stop(handle);

        var sequence: u64 = 0;
        if (self.log(handle, LevelInfo, "zig", "hello from zig logger", &sequence) != StatusOk) {
            return error.NativeCallFailed;
        }

        var category: [64]u8 = undefined;
        var message: [256]u8 = undefined;
        var record = std.mem.zeroes(RecordBuffer);
        record.struct_size = @sizeOf(RecordBuffer);
        record.category = &category;
        record.category_capacity = category.len;
        record.message = &message;
        record.message_capacity = message.len;
        const status = self.read_next(handle, 1000, &record);
        if (status == StatusTimedOut) {
            return error.RecordTimedOut;
        }
        if (status != StatusOk) {
            return error.NativeCallFailed;
        }
        if (record.sequence != sequence) {
            return error.UnexpectedRecord;
        }
        return sequence;
    }
};

