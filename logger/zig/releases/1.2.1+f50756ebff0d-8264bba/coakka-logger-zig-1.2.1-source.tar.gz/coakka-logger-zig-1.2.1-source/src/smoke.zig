const std = @import("std");
const logger = @import("logger.zig");

pub fn main(init: std.process.Init) !void {
    const lib_path = init.environ_map.get("COAKKA_LOGGER_LIB") orelse {
        std.debug.print("set COAKKA_LOGGER_LIB=/path/to/libcoakka_logger_core\n", .{});
        return error.MissingLoggerLibraryPath;
    };

    var native = try logger.NativeLogger.open(lib_path);
    defer native.close();
    const sequence = try native.smoke();
    std.debug.print("coakka_logger_zig_smoke sequence={d}\n", .{sequence});
}
