package coakka.quarkus;

import coakka.v2.connector.protocol.ConnectorEnvelope;
import coakka.v2.connector.protocol.ConnectorPayloadIdentity;
import com.fasterxml.jackson.databind.ObjectMapper;

public interface CoAkkaJsonHandler<P, R> extends CoAkkaLocalHandler {
    Class<P> requestType();

    ConnectorPayloadIdentity responseIdentity(R response);

    R handlePayload(P request) throws Exception;

    @Override
    default ConnectorEnvelope handle(ConnectorEnvelope request, ObjectMapper objectMapper) throws Exception {
        P payload = objectMapper.readValue(request.payloadUtf8(), requestType());
        R response = handlePayload(payload);
        return CoAkkaReplies.json(request, target(), response, responseIdentity(response), objectMapper);
    }
}
