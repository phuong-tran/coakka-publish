package coakka.quarkus;

import coakka.v2.connector.protocol.ConnectorEnvelope;
import com.fasterxml.jackson.databind.ObjectMapper;

public interface CoAkkaLocalHandler {
    default String target() {
        return CoAkkaTargets.fromAnnotation(getClass());
    }

    ConnectorEnvelope handle(ConnectorEnvelope request, ObjectMapper objectMapper) throws Exception;
}
