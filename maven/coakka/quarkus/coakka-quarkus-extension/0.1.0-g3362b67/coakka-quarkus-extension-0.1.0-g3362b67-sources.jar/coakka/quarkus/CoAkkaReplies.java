package coakka.quarkus;

import coakka.v2.connector.RuntimeClient;
import coakka.v2.connector.protocol.ConnectorEnvelope;
import coakka.v2.connector.protocol.ConnectorPayloadIdentity;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class CoAkkaReplies {
    private CoAkkaReplies() {
    }

    public static ConnectorEnvelope json(
        ConnectorEnvelope request,
        String source,
        Object payload,
        ConnectorPayloadIdentity payloadIdentity,
        ObjectMapper objectMapper
    ) throws Exception {
        return RuntimeClient.Companion.replyTo(
            request,
            source,
            objectMapper.writeValueAsString(payload),
            payloadIdentity
        );
    }
}
