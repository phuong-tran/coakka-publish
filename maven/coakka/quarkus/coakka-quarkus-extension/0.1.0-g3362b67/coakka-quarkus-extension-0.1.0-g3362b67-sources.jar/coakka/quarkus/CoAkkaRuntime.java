package coakka.quarkus;

import coakka.v2.connector.ConnectorOrchestrator;
import coakka.v2.connector.RuntimeClientStats;
import coakka.v2.connector.RuntimeConfigSnapshot;
import coakka.v2.connector.RuntimeEndpointFlags;
import coakka.v2.connector.RuntimeEndpointSpec;
import coakka.v2.connector.RuntimeInfoSnapshot;
import coakka.v2.connector.RuntimeOverloadPolicySpec;
import coakka.v2.connector.RuntimeRouteSpec;
import coakka.v2.connector.RuntimeStartSpec;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Instance;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@ApplicationScoped
public class CoAkkaRuntime {
    @Inject
    ObjectMapper objectMapper;

    @Inject
    Instance<CoAkkaLocalHandler> handlers;

    @ConfigProperty(name = "coakka.runtime.enabled", defaultValue = "true")
    boolean enabled;

    @ConfigProperty(name = "coakka.runtime.mode", defaultValue = "local")
    String mode;

    @ConfigProperty(name = "coakka.runtime.system-name", defaultValue = "coakka-quarkus-app")
    String systemName;

    @ConfigProperty(name = "coakka.runtime.node-id", defaultValue = "coakka-quarkus-node")
    String nodeId;

    @ConfigProperty(name = "coakka.runtime.source-target", defaultValue = "coakka.quarkus.source")
    String sourceTarget;

    @ConfigProperty(name = "coakka.runtime.generation", defaultValue = "1")
    long generation;

    @ConfigProperty(name = "coakka.runtime.queue-capacity", defaultValue = "128")
    int queueCapacity;

    @ConfigProperty(name = "coakka.runtime.strict-no-drop", defaultValue = "true")
    boolean strictNoDrop;

    @ConfigProperty(name = "coakka.runtime.separate-delivered-request-lane", defaultValue = "true")
    boolean separateDeliveredRequestLane;

    @ConfigProperty(name = "coakka.runtime.local-endpoint-host", defaultValue = "127.0.0.1")
    String localEndpointHost;

    @ConfigProperty(name = "coakka.runtime.local-endpoint-port", defaultValue = "19182")
    int localEndpointPort;

    private ConnectorOrchestrator orchestrator;

    @PostConstruct
    void start() {
        if (!enabled) {
            return;
        }
        if (!"local".equals(mode)) {
            throw new IllegalArgumentException("CoAkka Quarkus extension currently supports only coakka.runtime.mode=local");
        }

        List<CoAkkaLocalHandler> orderedHandlers = new ArrayList<>();
        for (CoAkkaLocalHandler handler : handlers) {
            orderedHandlers.add(handler);
        }
        orderedHandlers.sort(Comparator.comparing(CoAkkaLocalHandler::target));

        List<RuntimeRouteSpec> routes = new ArrayList<>();
        for (CoAkkaLocalHandler handler : orderedHandlers) {
            routes.add(new RuntimeRouteSpec(
                handler.target(),
                List.of(new RuntimeEndpointSpec(
                    localEndpointHost,
                    localEndpointPort,
                    1,
                    RuntimeEndpointFlags.LOCAL
                )),
                coakka.v2.control.RouteResolutionStrategy.ROUTE_RESOLUTION_STRATEGY_SINGLE_OWNER,
                null,
                0
            ));
        }

        orchestrator = ConnectorOrchestrator.Companion.start(new RuntimeStartSpec(
            systemName,
            nodeId,
            queueCapacity,
            strictNoDrop,
            separateDeliveredRequestLane,
            generation,
            new RuntimeOverloadPolicySpec(),
            routes
        ));

        for (CoAkkaLocalHandler handler : orderedHandlers) {
            orchestrator.registerHandler(handler.target(), (request, continuation) -> {
                try {
                    return handler.handle(request, objectMapper);
                } catch (Exception error) {
                    throw new IllegalStateException("CoAkka Quarkus handler failed for target " + handler.target(), error);
                }
            });
        }
    }

    @PreDestroy
    void close() throws Exception {
        if (orchestrator != null) {
            orchestrator.getJava().shutdown().get(3, TimeUnit.SECONDS);
        }
    }

    public ConnectorOrchestrator connector() {
        if (orchestrator == null) {
            throw new IllegalStateException("CoAkka runtime is not started");
        }
        return orchestrator;
    }

    public String sourceTarget() {
        return sourceTarget;
    }

    public RuntimeInfoSnapshot runtimeInfo() {
        return connector().runtimeInfo();
    }

    public RuntimeConfigSnapshot runtimeConfig() {
        return connector().runtimeConfig();
    }

    public RuntimeClientStats clientStats() {
        return connector().clientStats();
    }
}
