package coakka.quarkus;

import coakka.v2.connector.RuntimeClientStats;
import coakka.v2.connector.RuntimeConfigSnapshot;
import coakka.v2.connector.RuntimeInfoSnapshot;
import coakka.v2.connector.protocol.ConnectorDeliveryHint;
import coakka.v2.connector.protocol.ConnectorEnvelope;
import coakka.v2.connector.protocol.ConnectorPayloadIdentity;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

@ApplicationScoped
public class CoAkkaRuntimeClient {
    private final CoAkkaRuntime runtime;
    private final ObjectMapper objectMapper;

    public CoAkkaRuntimeClient(CoAkkaRuntime runtime, ObjectMapper objectMapper) {
        this.runtime = runtime;
        this.objectMapper = objectMapper;
    }

    public <T> T askBlocking(
        String target,
        Object payload,
        ConnectorPayloadIdentity payloadIdentity,
        Class<T> responseType,
        String operation,
        long timeoutMs
    ) throws Exception {
        ConnectorEnvelope response;
        try {
            response = runtime.connector().getJava().ask(
                runtime.sourceTarget(),
                target,
                objectMapper.writeValueAsString(payload),
                payloadIdentity,
                timeoutMs,
                operation,
                ConnectorDeliveryHint.ROUTER_DEFAULT
            ).get(timeoutMs + 1_000, TimeUnit.MILLISECONDS);
        } catch (ExecutionException error) {
            Throwable cause = error.getCause();
            if (cause instanceof Exception exception) {
                throw exception;
            }
            if (cause instanceof Error fatal) {
                throw fatal;
            }
            throw error;
        }
        return objectMapper.readValue(response.payloadUtf8(), responseType);
    }

    public RuntimeInfoSnapshot runtimeInfo() {
        return runtime.runtimeInfo();
    }

    public RuntimeConfigSnapshot runtimeConfig() {
        return runtime.runtimeConfig();
    }

    public RuntimeClientStats clientStats() {
        return runtime.clientStats();
    }
}
