package coakka.v2.connector

import coakka.v2.connector.protocol.ControlEnvelopeMapper
import java.util.concurrent.atomic.AtomicLong

/**
 * Builds and submits connector-owned control snapshots to the runtime.
 *
 * The connector stays responsible for generation monotonicity and route compilation.
 */
class RuntimeControlClient internal constructor(
    private val handle: RuntimeHandle,
    initialSeq: Long = 1,
) {
    private val nextSeq = AtomicLong(initialSeq)

    /**
     * Applies a full route snapshot through the protobuf `ControlEnvelope` lane.
     *
     * @param generation Monotonic control generation for this rollout.
     * @param routes Full route snapshot that should become active.
     * @param sourceConnector Diagnostic connector identifier attached to metadata.
     */
    fun applySnapshot(generation: Long, routes: List<RuntimeRouteSpec>, sourceConnector: String = "connector-kotlin") {
        val envelope = ControlEnvelopeMapper.buildSnapshotEnvelope(
            seq = nextSeq.getAndIncrement(),
            generation = generation,
            routes = routes,
            sourceConnector = sourceConnector,
        )
        handle.applyControlEnvelope(envelope.toByteArray())
    }

    internal fun applyStartSpec(startSpec: RuntimeStartSpec) {
        applySnapshot(
            generation = startSpec.generation,
            routes = startSpec.routes,
            sourceConnector = startSpec.systemName,
        )
    }
}
