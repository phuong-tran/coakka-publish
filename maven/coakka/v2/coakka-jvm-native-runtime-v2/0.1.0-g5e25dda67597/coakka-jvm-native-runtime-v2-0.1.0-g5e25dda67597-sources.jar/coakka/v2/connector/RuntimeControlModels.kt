package coakka.v2.connector

import coakka.v2.control.RouteResolutionStrategy

/**
 * Declares one endpoint candidate inside a route snapshot pushed to the runtime.
 *
 * @property host Host or IP address published to the runtime.
 * @property port Service port published to the runtime.
 * @property weight Relative weight for weighted strategies.
 * @property flags Endpoint flags defined by the runtime ABI.
 */
data class RuntimeEndpointSpec(
    val host: String,
    val port: Int,
    val weight: Int = 1,
    val flags: Int = 0,
)

/**
 * Declares routing policy for one logical target.
 *
 * @property target Logical runtime target name.
 * @property endpoints Eligible endpoints for this target.
 * @property strategy Route resolution strategy from the runtime contract.
 * @property routeKeyHint Header key used by rendezvous hashing.
 * @property flags Route-level flags from the runtime contract.
 */
data class RuntimeRouteSpec(
    val target: String,
    val endpoints: List<RuntimeEndpointSpec>,
    val strategy: RouteResolutionStrategy = RouteResolutionStrategy.ROUTE_RESOLUTION_STRATEGY_SINGLE_OWNER,
    val routeKeyHint: String? = null,
    val flags: Int = 0,
)

/**
 * Collects boot-time settings required to create and seed a runtime instance.
 *
 * @property systemName Connector or host system identifier.
 * @property nodeId Logical node identifier inside the system.
 * @property queueCapacity Ingress queue capacity configured at runtime create time.
 * @property strictNoDrop Whether runtime should stay on strict no-drop behavior where supported.
 * @property separateDeliveredRequestLane Whether the connector should opt into the additive
 * runtime host lane that exports locally delivered `REQUEST` traffic on its own fd.
 * @property generation Initial control generation applied before start.
 * @property routes Initial route snapshot to load before start.
 */
data class RuntimeStartSpec(
    val systemName: String,
    val nodeId: String,
    val queueCapacity: Int = 128,
    val strictNoDrop: Boolean = true,
    val separateDeliveredRequestLane: Boolean = false,
    val generation: Long = 1,
    val routes: List<RuntimeRouteSpec>,
)

/**
 * Mirrors the currently used endpoint flags from the native runtime contract.
 *
 * `LOCAL` means the endpoint is served by the current process.
 * `UNAVAILABLE` means the endpoint stays in snapshot state but must not receive new traffic.
 */
object RuntimeEndpointFlags {
    /** Marks an endpoint as served by the current process. */
    const val LOCAL = 1

    /** Keeps an endpoint in snapshot state but excludes it from new traffic. */
    const val UNAVAILABLE = 1 shl 1
}
