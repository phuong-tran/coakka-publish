package coakka.v2.connector

object JvmRuntimeJarSmoke {
    @JvmStatic
    fun main(args: Array<String>) {
        val info = RuntimeHandle.readRuntimeInfo()
        println(
            "runtime_info abi=${info.abiVersion} version=${info.runtimeVersion} " +
                "git=${info.gitCommit} backend=${info.southboundBackend}",
        )

        val client = RuntimeClient.startLocal(
            localTargets = listOf("svc.echo"),
            systemName = args.firstOrNull().takeUnless(String?::isNullOrBlank) ?: "jar-smoke",
            nodeId = "node-jar-smoke",
        )

        kotlinx.coroutines.runBlocking {
            try {
                client.registerHandler("svc.echo") { request ->
                    RuntimeClient.replyTo(
                        request = request,
                        source = "svc.echo",
                        payloadUtf8 = "echo:${request.payloadUtf8()}",
                    )
                }
                val response = client.ask(
                    source = "smoke-client",
                    target = "svc.echo",
                    payloadUtf8 = "embedded-native-ok",
                )

                check(response.payloadUtf8() == "echo:embedded-native-ok") {
                    "unexpected response payload=${response.payloadUtf8()}"
                }

                println(
                    "runtime_smoke ok payload=${response.payloadUtf8()} " +
                        "version=${info.runtimeVersion} backend=${info.southboundBackend}",
                )
            } finally {
                client.shutdown()
            }
        }
    }
}
