package coakka.v2.connector

import com.sun.jna.ptr.LongByReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Latest-state observability wrapper around the runtime monitor doorbell.
 *
 * The monitor fd is not a history stream. A wakeup only means "refresh your view now".
 */
data class RuntimeMonitorSnapshot(
    val signalCount: Long,
    val health: RuntimeHealthSnapshot,
    val stats: RuntimeStatsSnapshot,
)

class RuntimeMonitor internal constructor(
    private val handle: RuntimeHandle,
) {
    private val consumeLock = Any()

    fun isEnabled(): Boolean = handle.hostHandles.monitor_read_fd >= 0

    fun snapshot(signalCount: Long = 0): RuntimeMonitorSnapshot =
        RuntimeMonitorSnapshot(
            signalCount = signalCount,
            health = handle.health(),
            stats = handle.stats(),
        )

    @JvmOverloads
    fun awaitNextBlocking(timeoutMs: Int = 1_000): RuntimeMonitorSnapshot? {
        check(isEnabled()) { "runtime monitor is not enabled" }
        synchronized(consumeLock) {
            val monitorFd = handle.hostHandles.monitor_read_fd
            if (!waitReadable(monitorFd, timeoutMs)) {
                return null
            }
            val signalCount = LongByReference()
            requireStatus(handle.lib.coakka_v2_monitor_consume(monitorFd, signalCount), "monitor_consume")
            return snapshot(signalCount = signalCount.value)
        }
    }

    @JvmOverloads
    suspend fun awaitNext(timeoutMs: Long = 1_000): RuntimeMonitorSnapshot? =
        withContext(Dispatchers.IO) {
            awaitNextBlocking(timeoutMs.toInt())
        }
}
