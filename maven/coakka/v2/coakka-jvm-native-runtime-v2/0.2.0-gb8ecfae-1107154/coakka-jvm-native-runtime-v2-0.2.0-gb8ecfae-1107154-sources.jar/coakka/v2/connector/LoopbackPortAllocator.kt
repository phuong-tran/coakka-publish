package coakka.v2.connector

import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket

/**
 * Reserves a best-effort IPv4 loopback port for same-process local runtime boot paths.
 *
 * The returned port is not a leased resource; callers should use it immediately for one
 * runtime start or one stable local snapshot story instead of caching it globally.
 */
internal object LoopbackPortAllocator {
    private val ipv4Loopback = InetAddress.getByName("127.0.0.1")

    fun reserveIpv4LoopbackPort(): Int =
        ServerSocket().use { socket ->
            socket.reuseAddress = false
            socket.bind(InetSocketAddress(ipv4Loopback, 0))
            val port = socket.localPort
            check(port > 0) { "failed to reserve a loopback port" }
            port
        }
}
