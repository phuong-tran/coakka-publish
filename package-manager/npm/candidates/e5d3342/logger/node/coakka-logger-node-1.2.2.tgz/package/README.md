# CoAkka Logger Node

`logger/node/` is the Node.js host connector lane for the standalone CoAkka
native logger core.

## New To CoAkka

CoAkka is a native-backed runtime and logger toolkit for application-owned
work. The logger package is the bounded native logger surface: app code emits
records, the native logger owns queueing and pressure behavior, and callers can
observe accepted, delivered, and dropped counts.

Use these public repositories to orient first:

| Repository | Use it for | Link |
| --- | --- | --- |
| `coakka-samples` | Runnable examples and code you can inspect first. | https://github.com/phuong-tran/coakka-samples |
| `coakka-publish` | Released packages, native archives, manifests, checksums, compatibility matrix, and release notes. | https://github.com/phuong-tran/coakka-publish |

Run the matching sample:

```sh
git clone https://github.com/phuong-tran/coakka-samples.git
cd coakka-samples
bash run.sh logger node basic
```

It mirrors the Python logger lane:

- load `libcoakka_logger_core` through `koffi`
- keep Node-side formatting above the native core
- let the native logger own queueing, pressure policy, sinks, and lifecycle
- package staged native libraries into the npm tarball for macOS aarch64,
  Linux aarch64, and Linux x86_64

## Build

```sh
npm --prefix logger/node run build
```

The script stages native libraries from:

```text
logger/staging/native/1.2.1+f50756ebff0d/
```

## Smoke

```sh
npm --prefix logger/node test
npm --prefix logger/node run smoke:packaged
```

## Example

```ts
import { Logger } from "coakka-logger-node";

const logger = Logger.start();
try {
  logger.info("app", "started");
  const record = logger.awaitNext(1000);
} finally {
  logger.close();
}
```
