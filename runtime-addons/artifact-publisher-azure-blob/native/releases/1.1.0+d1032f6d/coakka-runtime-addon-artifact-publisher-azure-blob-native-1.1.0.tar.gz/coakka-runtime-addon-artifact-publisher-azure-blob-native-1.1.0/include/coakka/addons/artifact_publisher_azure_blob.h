#ifndef COAKKA_ADDONS_ARTIFACT_PUBLISHER_AZURE_BLOB_H
#define COAKKA_ADDONS_ARTIFACT_PUBLISHER_AZURE_BLOB_H

#include <stddef.h>
#include <stdint.h>

#include "coakka/v2/file_lane.h"

#if defined(_WIN32)
#if defined(COAKKA_AZURE_BLOB_PUBLISHER_BUILD)
#define COAKKA_AZURE_BLOB_PUBLISHER_API __declspec(dllexport)
#else
#define COAKKA_AZURE_BLOB_PUBLISHER_API __declspec(dllimport)
#endif
#elif defined(__GNUC__) || defined(__clang__)
#define COAKKA_AZURE_BLOB_PUBLISHER_API __attribute__((visibility("default")))
#else
#define COAKKA_AZURE_BLOB_PUBLISHER_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct coakka_azure_blob_publisher_t coakka_azure_blob_publisher_t;

enum {
  COAKKA_AZURE_BLOB_SHA256_BYTES = 32u,
  COAKKA_AZURE_BLOB_JOB_ID_MAX_BYTES = 64u,
  COAKKA_AZURE_BLOB_MAX_TARGETS = 8u,
  COAKKA_AZURE_BLOB_LOCAL_PATH_MAX_BYTES = 512u,
  COAKKA_AZURE_BLOB_DETAIL_MAX_BYTES = 192u
};

typedef enum coakka_azure_blob_status_t {
  COAKKA_AZURE_BLOB_OK = 0,
  COAKKA_AZURE_BLOB_ERR_INVALID_ARG = -1,
  COAKKA_AZURE_BLOB_ERR_NOMEM = -2,
  COAKKA_AZURE_BLOB_ERR_BAD_STATE = -3,
  COAKKA_AZURE_BLOB_ERR_WOULD_BLOCK = -4,
  COAKKA_AZURE_BLOB_ERR_NOT_FOUND = -5,
  COAKKA_AZURE_BLOB_ERR_CAPACITY = -6,
  COAKKA_AZURE_BLOB_ERR_IO = -7,
  COAKKA_AZURE_BLOB_ERR_FEATURE_UNAVAILABLE = -8
} coakka_azure_blob_status_t;

typedef enum coakka_azure_blob_publisher_state_t {
  COAKKA_AZURE_BLOB_PUBLISHER_QUEUED = 1u,
  COAKKA_AZURE_BLOB_PUBLISHER_CONNECTING = 2u,
  COAKKA_AZURE_BLOB_PUBLISHER_FETCHING = 3u,
  COAKKA_AZURE_BLOB_PUBLISHER_VERIFYING_ARTIFACT = 4u,
  COAKKA_AZURE_BLOB_PUBLISHER_ACQUIRED = 5u,
  COAKKA_AZURE_BLOB_PUBLISHER_DISTRIBUTING = 6u,
  COAKKA_AZURE_BLOB_PUBLISHER_COMPLETED = 7u,
  COAKKA_AZURE_BLOB_PUBLISHER_PARTIAL = 8u,
  COAKKA_AZURE_BLOB_PUBLISHER_FAILED = 9u,
  COAKKA_AZURE_BLOB_PUBLISHER_CANCELED = 10u
} coakka_azure_blob_publisher_state_t;

typedef enum coakka_azure_blob_publisher_result_t {
  COAKKA_AZURE_BLOB_RESULT_NONE = 0u,
  COAKKA_AZURE_BLOB_RESULT_OK = 1u,
  COAKKA_AZURE_BLOB_RESULT_INVALID_REQUEST = 2u,
  COAKKA_AZURE_BLOB_RESULT_CONNECT_FAILED = 3u,
  COAKKA_AZURE_BLOB_RESULT_TIMEOUT = 4u,
  COAKKA_AZURE_BLOB_RESULT_TLS_VERIFICATION_FAILED = 5u,
  COAKKA_AZURE_BLOB_RESULT_HTTP_STATUS_REJECTED = 6u,
  COAKKA_AZURE_BLOB_RESULT_REDIRECT_REJECTED = 7u,
  COAKKA_AZURE_BLOB_RESULT_REMOTE_IO = 8u,
  COAKKA_AZURE_BLOB_RESULT_CONTENT_ENCODING_UNSUPPORTED = 9u,
  COAKKA_AZURE_BLOB_RESULT_STORAGE_IO = 10u,
  COAKKA_AZURE_BLOB_RESULT_SIZE_MISMATCH = 11u,
  COAKKA_AZURE_BLOB_RESULT_DIGEST_MISMATCH = 12u,
  COAKKA_AZURE_BLOB_RESULT_DESTINATION_EXISTS = 13u,
  COAKKA_AZURE_BLOB_RESULT_DISTRIBUTION_FAILED = 14u,
  COAKKA_AZURE_BLOB_RESULT_CANCELED_BY_HOST = 15u,
  COAKKA_AZURE_BLOB_RESULT_STOPPED = 16u,
  COAKKA_AZURE_BLOB_RESULT_INTERNAL_ERROR = 17u
} coakka_azure_blob_publisher_result_t;

typedef struct coakka_azure_blob_publish_target_t {
  size_t struct_size;
  const char *transfer_id;
  const char *authorization_token;
  const char *remote_host;
  uint16_t remote_port;
  uint16_t reserved;
  uint32_t timeout_ms;
} coakka_azure_blob_publish_target_t;

typedef struct coakka_azure_blob_publisher_config_t {
  size_t struct_size;
  const char *staging_root;
  coakka_v2_file_lane_t *sender_lane;
  size_t queue_capacity;
  size_t retained_capacity;
  uint32_t default_timeout_ms;
  uint32_t reserved;
} coakka_azure_blob_publisher_config_t;

/**
 * One immutable Azure Blob version acquisition plus File Lane distribution.
 * sas_blob_url is a complete, caller-minted HTTPS service SAS URL. The addon
 * does not append, remove, reorder, or re-encode its path or query. It accepts
 * only a blob-version SAS (`sr=bv`) with read permission, HTTPS-only transport,
 * expiry, and exactly one versionid matching expected_version_id. Shared Key,
 * bearer tokens, snapshots, stored access policies, and account/container SAS
 * are outside this first scope.
 *
 * The SAS URL is a credential. It is copied during submit, cleared after the
 * transfer, and never exposed in snapshots. Independent expected size and
 * SHA-256 are mandatory; Azure ETag and Content-MD5 are not integrity inputs.
 */
typedef struct coakka_azure_blob_publish_spec_t {
  size_t struct_size;
  const char *job_id;
  const char *sas_blob_url;
  const char *ca_certificate_file;
  const char *expected_version_id;
  const char *destination_name;
  uint64_t expected_size;
  uint8_t expected_sha256[COAKKA_AZURE_BLOB_SHA256_BYTES];
  uint32_t timeout_ms;
  uint32_t target_count;
  uint32_t reserved;
  const coakka_azure_blob_publish_target_t *targets;
} coakka_azure_blob_publish_spec_t;

typedef struct coakka_azure_blob_publisher_snapshot_t {
  size_t struct_size;
  uint32_t state;
  uint32_t result;
  uint64_t expected_size;
  uint64_t fetched_bytes;
  uint32_t target_count;
  uint32_t completed_targets;
  uint32_t failed_targets;
  uint32_t cancel_requested;
  uint64_t update_sequence;
  uint64_t submitted_mono_ns;
  uint64_t started_mono_ns;
  uint64_t updated_mono_ns;
  uint64_t terminal_mono_ns;
  char local_path[COAKKA_AZURE_BLOB_LOCAL_PATH_MAX_BYTES];
  char detail[COAKKA_AZURE_BLOB_DETAIL_MAX_BYTES];
} coakka_azure_blob_publisher_snapshot_t;

typedef struct coakka_azure_blob_target_snapshot_t {
  size_t struct_size;
  uint32_t admitted;
  int32_t submit_status;
  uint32_t lane_state;
  uint32_t lane_result;
  uint64_t transferred_bytes;
  char transfer_id[COAKKA_V2_FILE_LANE_TRANSFER_ID_MAX_BYTES + 1u];
} coakka_azure_blob_target_snapshot_t;

COAKKA_AZURE_BLOB_PUBLISHER_API coakka_azure_blob_status_t
coakka_azure_blob_publisher_create(
    const coakka_azure_blob_publisher_config_t *config,
    coakka_azure_blob_publisher_t **out_publisher);
COAKKA_AZURE_BLOB_PUBLISHER_API void
coakka_azure_blob_publisher_destroy(coakka_azure_blob_publisher_t *publisher);
COAKKA_AZURE_BLOB_PUBLISHER_API coakka_azure_blob_status_t
coakka_azure_blob_publisher_start(coakka_azure_blob_publisher_t *publisher);
COAKKA_AZURE_BLOB_PUBLISHER_API coakka_azure_blob_status_t
coakka_azure_blob_publisher_stop(coakka_azure_blob_publisher_t *publisher);
COAKKA_AZURE_BLOB_PUBLISHER_API coakka_azure_blob_status_t
coakka_azure_blob_publisher_submit(
    coakka_azure_blob_publisher_t *publisher,
    const coakka_azure_blob_publish_spec_t *spec);
COAKKA_AZURE_BLOB_PUBLISHER_API coakka_azure_blob_status_t
coakka_azure_blob_publisher_get(
    coakka_azure_blob_publisher_t *publisher, const char *job_id,
    coakka_azure_blob_publisher_snapshot_t *out_snapshot);
COAKKA_AZURE_BLOB_PUBLISHER_API coakka_azure_blob_status_t
coakka_azure_blob_publisher_wait(
    coakka_azure_blob_publisher_t *publisher, const char *job_id,
    uint64_t after_update_sequence, uint32_t timeout_ms,
    coakka_azure_blob_publisher_snapshot_t *out_snapshot);
COAKKA_AZURE_BLOB_PUBLISHER_API coakka_azure_blob_status_t
coakka_azure_blob_publisher_get_target(
    coakka_azure_blob_publisher_t *publisher, const char *job_id,
    uint32_t target_index, coakka_azure_blob_target_snapshot_t *out_snapshot);
COAKKA_AZURE_BLOB_PUBLISHER_API coakka_azure_blob_status_t
coakka_azure_blob_publisher_cancel(coakka_azure_blob_publisher_t *publisher,
                                   const char *job_id);
COAKKA_AZURE_BLOB_PUBLISHER_API coakka_azure_blob_status_t
coakka_azure_blob_publisher_forget(coakka_azure_blob_publisher_t *publisher,
                                   const char *job_id);
COAKKA_AZURE_BLOB_PUBLISHER_API const char *
coakka_azure_blob_publisher_dependency_version(void);

#ifdef __cplusplus
}
#endif

#endif
