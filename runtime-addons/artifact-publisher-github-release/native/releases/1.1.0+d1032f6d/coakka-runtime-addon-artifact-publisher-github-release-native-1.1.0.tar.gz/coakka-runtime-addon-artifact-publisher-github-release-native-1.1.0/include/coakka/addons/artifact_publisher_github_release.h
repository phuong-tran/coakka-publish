#ifndef COAKKA_ADDONS_ARTIFACT_PUBLISHER_GITHUB_RELEASE_H
#define COAKKA_ADDONS_ARTIFACT_PUBLISHER_GITHUB_RELEASE_H

#include <stddef.h>
#include <stdint.h>

#include "coakka/v2/file_lane.h"

#if defined(_WIN32)
#if defined(COAKKA_GITHUB_RELEASE_PUBLISHER_BUILD)
#define COAKKA_GITHUB_RELEASE_PUBLISHER_API __declspec(dllexport)
#else
#define COAKKA_GITHUB_RELEASE_PUBLISHER_API __declspec(dllimport)
#endif
#elif defined(__GNUC__) || defined(__clang__)
#define COAKKA_GITHUB_RELEASE_PUBLISHER_API                                    \
  __attribute__((visibility("default")))
#else
#define COAKKA_GITHUB_RELEASE_PUBLISHER_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct coakka_github_release_publisher_t
    coakka_github_release_publisher_t;

enum {
  COAKKA_GITHUB_RELEASE_SHA256_BYTES = 32u,
  COAKKA_GITHUB_RELEASE_JOB_ID_MAX_BYTES = 64u,
  COAKKA_GITHUB_RELEASE_MAX_TARGETS = 8u,
  COAKKA_GITHUB_RELEASE_LOCAL_PATH_MAX_BYTES = 512u,
  COAKKA_GITHUB_RELEASE_DETAIL_MAX_BYTES = 192u
};

typedef enum coakka_github_release_status_t {
  COAKKA_GITHUB_RELEASE_OK = 0,
  COAKKA_GITHUB_RELEASE_ERR_INVALID_ARG = -1,
  COAKKA_GITHUB_RELEASE_ERR_NOMEM = -2,
  COAKKA_GITHUB_RELEASE_ERR_BAD_STATE = -3,
  COAKKA_GITHUB_RELEASE_ERR_WOULD_BLOCK = -4,
  COAKKA_GITHUB_RELEASE_ERR_NOT_FOUND = -5,
  COAKKA_GITHUB_RELEASE_ERR_CAPACITY = -6,
  COAKKA_GITHUB_RELEASE_ERR_IO = -7,
  COAKKA_GITHUB_RELEASE_ERR_FEATURE_UNAVAILABLE = -8
} coakka_github_release_status_t;

typedef enum coakka_github_release_publisher_state_t {
  COAKKA_GITHUB_RELEASE_PUBLISHER_QUEUED = 1u,
  COAKKA_GITHUB_RELEASE_PUBLISHER_CONNECTING = 2u,
  COAKKA_GITHUB_RELEASE_PUBLISHER_FETCHING = 3u,
  COAKKA_GITHUB_RELEASE_PUBLISHER_VERIFYING_ARTIFACT = 4u,
  COAKKA_GITHUB_RELEASE_PUBLISHER_ACQUIRED = 5u,
  COAKKA_GITHUB_RELEASE_PUBLISHER_DISTRIBUTING = 6u,
  COAKKA_GITHUB_RELEASE_PUBLISHER_COMPLETED = 7u,
  COAKKA_GITHUB_RELEASE_PUBLISHER_PARTIAL = 8u,
  COAKKA_GITHUB_RELEASE_PUBLISHER_FAILED = 9u,
  COAKKA_GITHUB_RELEASE_PUBLISHER_CANCELED = 10u
} coakka_github_release_publisher_state_t;

typedef enum coakka_github_release_publisher_result_t {
  COAKKA_GITHUB_RELEASE_RESULT_NONE = 0u,
  COAKKA_GITHUB_RELEASE_RESULT_OK = 1u,
  COAKKA_GITHUB_RELEASE_RESULT_INVALID_REQUEST = 2u,
  COAKKA_GITHUB_RELEASE_RESULT_CONNECT_FAILED = 3u,
  COAKKA_GITHUB_RELEASE_RESULT_TIMEOUT = 4u,
  COAKKA_GITHUB_RELEASE_RESULT_TLS_VERIFICATION_FAILED = 5u,
  COAKKA_GITHUB_RELEASE_RESULT_HTTP_STATUS_REJECTED = 6u,
  COAKKA_GITHUB_RELEASE_RESULT_REDIRECT_REJECTED = 7u,
  COAKKA_GITHUB_RELEASE_RESULT_REMOTE_IO = 8u,
  COAKKA_GITHUB_RELEASE_RESULT_CONTENT_ENCODING_UNSUPPORTED = 9u,
  COAKKA_GITHUB_RELEASE_RESULT_STORAGE_IO = 10u,
  COAKKA_GITHUB_RELEASE_RESULT_SIZE_MISMATCH = 11u,
  COAKKA_GITHUB_RELEASE_RESULT_DIGEST_MISMATCH = 12u,
  COAKKA_GITHUB_RELEASE_RESULT_DESTINATION_EXISTS = 13u,
  COAKKA_GITHUB_RELEASE_RESULT_DISTRIBUTION_FAILED = 14u,
  COAKKA_GITHUB_RELEASE_RESULT_CANCELED_BY_HOST = 15u,
  COAKKA_GITHUB_RELEASE_RESULT_STOPPED = 16u,
  COAKKA_GITHUB_RELEASE_RESULT_INTERNAL_ERROR = 17u
} coakka_github_release_publisher_result_t;

typedef struct coakka_github_release_publish_target_t {
  size_t struct_size;
  const char *transfer_id;
  const char *authorization_token;
  const char *remote_host;
  uint16_t remote_port;
  uint16_t reserved;
  uint32_t timeout_ms;
} coakka_github_release_publish_target_t;

typedef struct coakka_github_release_publisher_config_t {
  size_t struct_size;
  const char *staging_root;
  coakka_v2_file_lane_t *sender_lane;
  size_t queue_capacity;
  size_t retained_capacity;
  uint32_t default_timeout_ms;
  uint32_t reserved;
} coakka_github_release_publisher_config_t;

/**
 * One identity-pinned GitHub release asset acquisition plus File Lane fanout.
 * asset_url must be an HTTPS URL with exactly this path shape:
 *
 *   /repos/<owner>/<repo>/releases/assets/<positive-decimal-asset-id>
 *
 * Query parameters, fragments, userinfo, latest/tag/release-name/asset-name
 * resolution, and token minting or refresh are outside scope. access_token may
 * be empty for public content or contain one caller-supplied fine-grained token
 * with Contents read permission. storage_host_suffix is mandatory and
 * lower-case (normally `githubusercontent.com`); one 302 redirect may target
 * either the original authority or a DNS-boundary match for that suffix. The
 * access token and GitHub API headers are omitted from cross-authority storage
 * requests.
 *
 * All strings, the digest, and targets are copied during submit. The asset
 * URL, access token, signed redirect URL, and File Lane tokens are cleared
 * after use and never exposed in snapshots. expected_size and expected_sha256
 * independently gate no-clobber staging publication.
 */
typedef struct coakka_github_release_publish_spec_t {
  size_t struct_size;
  const char *job_id;
  const char *asset_url;
  const char *ca_certificate_file;
  const char *access_token;
  const char *storage_host_suffix;
  const char *destination_name;
  uint64_t expected_size;
  uint8_t expected_sha256[COAKKA_GITHUB_RELEASE_SHA256_BYTES];
  uint32_t timeout_ms;
  uint32_t target_count;
  uint32_t reserved;
  const coakka_github_release_publish_target_t *targets;
} coakka_github_release_publish_spec_t;

typedef struct coakka_github_release_publisher_snapshot_t {
  size_t struct_size;
  uint32_t state;
  uint32_t result;
  uint64_t expected_size;
  uint64_t fetched_bytes;
  uint32_t target_count;
  uint32_t completed_targets;
  uint32_t failed_targets;
  uint32_t cancel_requested;
  uint64_t update_sequence;
  uint64_t submitted_mono_ns;
  uint64_t started_mono_ns;
  uint64_t updated_mono_ns;
  uint64_t terminal_mono_ns;
  char local_path[COAKKA_GITHUB_RELEASE_LOCAL_PATH_MAX_BYTES];
  char detail[COAKKA_GITHUB_RELEASE_DETAIL_MAX_BYTES];
} coakka_github_release_publisher_snapshot_t;

typedef struct coakka_github_release_target_snapshot_t {
  size_t struct_size;
  uint32_t admitted;
  int32_t submit_status;
  uint32_t lane_state;
  uint32_t lane_result;
  uint64_t transferred_bytes;
  char transfer_id[COAKKA_V2_FILE_LANE_TRANSFER_ID_MAX_BYTES + 1u];
} coakka_github_release_target_snapshot_t;

COAKKA_GITHUB_RELEASE_PUBLISHER_API coakka_github_release_status_t
coakka_github_release_publisher_create(
    const coakka_github_release_publisher_config_t *config,
    coakka_github_release_publisher_t **out_publisher);
COAKKA_GITHUB_RELEASE_PUBLISHER_API void
coakka_github_release_publisher_destroy(
    coakka_github_release_publisher_t *publisher);
COAKKA_GITHUB_RELEASE_PUBLISHER_API coakka_github_release_status_t
coakka_github_release_publisher_start(
    coakka_github_release_publisher_t *publisher);
COAKKA_GITHUB_RELEASE_PUBLISHER_API coakka_github_release_status_t
coakka_github_release_publisher_stop(
    coakka_github_release_publisher_t *publisher);
COAKKA_GITHUB_RELEASE_PUBLISHER_API coakka_github_release_status_t
coakka_github_release_publisher_submit(
    coakka_github_release_publisher_t *publisher,
    const coakka_github_release_publish_spec_t *spec);
COAKKA_GITHUB_RELEASE_PUBLISHER_API coakka_github_release_status_t
coakka_github_release_publisher_get(
    coakka_github_release_publisher_t *publisher, const char *job_id,
    coakka_github_release_publisher_snapshot_t *out_snapshot);
COAKKA_GITHUB_RELEASE_PUBLISHER_API coakka_github_release_status_t
coakka_github_release_publisher_wait(
    coakka_github_release_publisher_t *publisher, const char *job_id,
    uint64_t after_update_sequence, uint32_t timeout_ms,
    coakka_github_release_publisher_snapshot_t *out_snapshot);
COAKKA_GITHUB_RELEASE_PUBLISHER_API coakka_github_release_status_t
coakka_github_release_publisher_get_target(
    coakka_github_release_publisher_t *publisher, const char *job_id,
    uint32_t target_index,
    coakka_github_release_target_snapshot_t *out_snapshot);
COAKKA_GITHUB_RELEASE_PUBLISHER_API coakka_github_release_status_t
coakka_github_release_publisher_cancel(
    coakka_github_release_publisher_t *publisher, const char *job_id);
COAKKA_GITHUB_RELEASE_PUBLISHER_API coakka_github_release_status_t
coakka_github_release_publisher_forget(
    coakka_github_release_publisher_t *publisher, const char *job_id);
COAKKA_GITHUB_RELEASE_PUBLISHER_API const char *
coakka_github_release_publisher_dependency_version(void);

#ifdef __cplusplus
}
#endif

#endif
