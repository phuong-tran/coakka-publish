# CoAkka Google Drive Artifact Publisher Native Addon

Version `1.1.0` provides the reviewed public C header and native modules for
the platforms declared by the release manifest. It requires CoAkka Runtime
native `2.4.0` or newer with File Lane support.

Fetches one retained Drive blob revision through OAuth and distributes the verified bytes through File Lane.

The archive also carries the private HTTPS engine required by this adapter; it is an implementation module, not a second public API. CoAkka Runtime is always supplied separately. The application
owns Runtime, File Lane, credentials, authorization, retry policy, and lifecycle
ordering. The addon owns its bounded acquisition job and verified staging.

There is no high-level language connector in this release. Applications consume
the small C ABI directly or provide their own wrapper. See `CONSUMING.md`.
