# CoAkka HTTPS Artifact Publisher Native Addon

Version `1.1.0` provides the reviewed public C header and native modules for
the platforms declared by the release manifest. It requires CoAkka Runtime
native `2.4.0` or newer with File Lane support.

Fetches one immutable HTTPS object, verifies size and SHA-256, stages without replacement, and distributes it through File Lane.

The archive carries no other addon module. CoAkka Runtime is always supplied separately. The application
owns Runtime, File Lane, credentials, authorization, retry policy, and lifecycle
ordering. The addon owns its bounded acquisition job and verified staging.

There is no high-level language connector in this release. Applications consume
the small C ABI directly or provide their own wrapper. See `CONSUMING.md`.
