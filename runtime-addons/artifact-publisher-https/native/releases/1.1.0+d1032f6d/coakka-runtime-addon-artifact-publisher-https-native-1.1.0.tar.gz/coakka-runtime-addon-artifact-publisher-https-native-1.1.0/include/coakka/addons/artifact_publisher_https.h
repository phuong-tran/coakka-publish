#ifndef COAKKA_ADDONS_ARTIFACT_PUBLISHER_HTTPS_H
#define COAKKA_ADDONS_ARTIFACT_PUBLISHER_HTTPS_H

#include <stddef.h>
#include <stdint.h>

#include "coakka/v2/file_lane.h"

#if defined(_WIN32)
#if defined(COAKKA_HTTPS_PUBLISHER_BUILD)
#define COAKKA_HTTPS_PUBLISHER_API __declspec(dllexport)
#else
#define COAKKA_HTTPS_PUBLISHER_API __declspec(dllimport)
#endif
#elif defined(__GNUC__) || defined(__clang__)
#define COAKKA_HTTPS_PUBLISHER_API __attribute__((visibility("default")))
#else
#define COAKKA_HTTPS_PUBLISHER_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct coakka_https_publisher_t coakka_https_publisher_t;

enum {
  COAKKA_HTTPS_SHA256_BYTES = 32u,
  COAKKA_HTTPS_JOB_ID_MAX_BYTES = 64u,
  COAKKA_HTTPS_MAX_TARGETS = 8u,
  COAKKA_HTTPS_LOCAL_PATH_MAX_BYTES = 512u,
  COAKKA_HTTPS_DETAIL_MAX_BYTES = 192u
};

typedef enum coakka_https_status_t {
  COAKKA_HTTPS_OK = 0,
  COAKKA_HTTPS_ERR_INVALID_ARG = -1,
  COAKKA_HTTPS_ERR_NOMEM = -2,
  COAKKA_HTTPS_ERR_BAD_STATE = -3,
  COAKKA_HTTPS_ERR_WOULD_BLOCK = -4,
  COAKKA_HTTPS_ERR_NOT_FOUND = -5,
  COAKKA_HTTPS_ERR_CAPACITY = -6,
  COAKKA_HTTPS_ERR_IO = -7,
  COAKKA_HTTPS_ERR_FEATURE_UNAVAILABLE = -8
} coakka_https_status_t;

typedef enum coakka_https_publisher_state_t {
  COAKKA_HTTPS_PUBLISHER_QUEUED = 1u,
  COAKKA_HTTPS_PUBLISHER_CONNECTING = 2u,
  COAKKA_HTTPS_PUBLISHER_FETCHING = 3u,
  COAKKA_HTTPS_PUBLISHER_VERIFYING_ARTIFACT = 4u,
  COAKKA_HTTPS_PUBLISHER_ACQUIRED = 5u,
  COAKKA_HTTPS_PUBLISHER_DISTRIBUTING = 6u,
  COAKKA_HTTPS_PUBLISHER_COMPLETED = 7u,
  COAKKA_HTTPS_PUBLISHER_PARTIAL = 8u,
  COAKKA_HTTPS_PUBLISHER_FAILED = 9u,
  COAKKA_HTTPS_PUBLISHER_CANCELED = 10u
} coakka_https_publisher_state_t;

typedef enum coakka_https_publisher_result_t {
  COAKKA_HTTPS_RESULT_NONE = 0u,
  COAKKA_HTTPS_RESULT_OK = 1u,
  COAKKA_HTTPS_RESULT_INVALID_REQUEST = 2u,
  COAKKA_HTTPS_RESULT_CONNECT_FAILED = 3u,
  COAKKA_HTTPS_RESULT_TIMEOUT = 4u,
  COAKKA_HTTPS_RESULT_TLS_VERIFICATION_FAILED = 5u,
  COAKKA_HTTPS_RESULT_HTTP_STATUS_REJECTED = 6u,
  COAKKA_HTTPS_RESULT_REDIRECT_REJECTED = 7u,
  COAKKA_HTTPS_RESULT_REMOTE_IO = 8u,
  COAKKA_HTTPS_RESULT_CONTENT_ENCODING_UNSUPPORTED = 9u,
  COAKKA_HTTPS_RESULT_STORAGE_IO = 10u,
  COAKKA_HTTPS_RESULT_SIZE_MISMATCH = 11u,
  COAKKA_HTTPS_RESULT_DIGEST_MISMATCH = 12u,
  COAKKA_HTTPS_RESULT_DESTINATION_EXISTS = 13u,
  COAKKA_HTTPS_RESULT_DISTRIBUTION_FAILED = 14u,
  COAKKA_HTTPS_RESULT_CANCELED_BY_HOST = 15u,
  COAKKA_HTTPS_RESULT_STOPPED = 16u,
  COAKKA_HTTPS_RESULT_INTERNAL_ERROR = 17u
} coakka_https_publisher_result_t;

/** Private transport authentication modes used by composed source addons. */
typedef enum coakka_https_auth_mode_t {
  COAKKA_HTTPS_AUTH_DEFAULT = 0u,
  COAKKA_HTTPS_AUTH_AWS_SIGV4 = 1u,
  /** Query-signed URL composed by a semantic adapter; preserve path bytes. */
  COAKKA_HTTPS_AUTH_QUERY_SIGNED = 2u,
  /** Explicit HTTP Basic origin authentication over mandatory TLS. */
  COAKKA_HTTPS_AUTH_HTTP_BASIC = 3u,
  /** Explicit HTTP Digest origin authentication over mandatory TLS. */
  COAKKA_HTTPS_AUTH_HTTP_DIGEST = 4u
} coakka_https_auth_mode_t;

/** Private redirect policy used only by semantic source adapters. */
typedef enum coakka_https_redirect_mode_t {
  COAKKA_HTTPS_REDIRECT_REJECT = 0u,
  /** Follow at most one prevalidated HTTPS redirect. */
  COAKKA_HTTPS_REDIRECT_ONE_ALLOWLISTED = 1u,
  /** Follow at most one prevalidated HTTPS 302 redirect. */
  COAKKA_HTTPS_REDIRECT_ONE_ALLOWLISTED_302 = 2u
} coakka_https_redirect_mode_t;

/** Fixed request profiles used by semantic source adapters. */
typedef enum coakka_https_request_profile_t {
  COAKKA_HTTPS_REQUEST_PROFILE_DEFAULT = 0u,
  /** GitHub REST release-asset media request; never caller-controlled text. */
  COAKKA_HTTPS_REQUEST_PROFILE_GITHUB_RELEASE_ASSET = 1u,
  /** Dropbox content download for one exact `rev:` identity. */
  COAKKA_HTTPS_REQUEST_PROFILE_DROPBOX_REVISION = 2u
} coakka_https_request_profile_t;

/**
 * One File Lane destination. All strings are copied during submit. The lane
 * itself is borrowed from the publisher config for the publisher lifetime.
 * timeout_ms is passed to File Lane; zero selects its normal default.
 */
typedef struct coakka_https_publish_target_t {
  size_t struct_size;
  const char *transfer_id;
  const char *authorization_token;
  const char *remote_host;
  uint16_t remote_port;
  uint16_t reserved;
  uint32_t timeout_ms;
} coakka_https_publish_target_t;

/**
 * Bounded publisher configuration. staging_root must be an absolute path; it
 * is copied and opened during create. sender_lane must already be started and
 * outlive the publisher. Zero capacities/timeouts select conservative
 * defaults. default_timeout_ms bounds libcurl connect and response transfer,
 * not local filesystem operations or File Lane sends.
 */
typedef struct coakka_https_publisher_config_t {
  size_t struct_size;
  const char *staging_root;
  coakka_v2_file_lane_t *sender_lane;
  size_t queue_capacity;
  size_t retained_capacity;
  uint32_t default_timeout_ms;
  uint32_t reserved;
} coakka_https_publisher_config_t;

/**
 * Immutable HTTPS acquisition plus distribution request. The addon copies all
 * strings, targets, digest bytes, CA path, and bearer token before returning.
 * url must use https, must not contain userinfo or a fragment, and must come
 * from trusted host configuration rather than an untrusted request payload.
 * Redirects, proxies, automatic content decoding, and plaintext downgrade are
 * disabled. TLS 1.2 is the minimum protocol version. expected size, digest,
 * and at least one target are mandatory. The size must also fit SHA-256's
 * 64-bit bit-length domain. destination_name is one safe filename below
 * staging_root.
 * timeout_ms=0 selects the publisher default and applies only to acquisition;
 * every target carries its independent File Lane timeout.
 *
 * auth_mode=DEFAULT optionally sends bearer_token. AWS_SIGV4 requires region,
 * access key, and secret key; it rejects bearer authentication and optionally
 * signs aws_session_token as x-amz-security-token. An exact '.' or '..' URL
 * path segment is invalid for AWS_SIGV4. QUERY_SIGNED rejects all header
 * credentials and asks libcurl to preserve the already-signed path.
 * HTTP_BASIC and HTTP_DIGEST require username/password and reject every other
 * credential family; they never negotiate or fall back to another scheme.
 * if_match_etag is optional for DEFAULT/HTTP password modes and, when present,
 * must be one strong entity-tag sent as `If-Match`. It is rejected for signed
 * auth modes so the engine cannot silently alter their signed request shape.
 * expected_content_digest is an optional exact response value for one
 * `Docker-Content-Digest` header. When configured, a missing, duplicate, or
 * mismatched header fails before staging publication. It is intended for OCI
 * semantic adapters and does not replace body SHA-256 verification.
 * redirect_mode defaults to REJECT. ONE_ALLOWLISTED modes are restricted to
 * DEFAULT auth. The general mode accepts status 302 or 307; the `_302` mode
 * accepts only 302. The redirect is parsed and checked
 * before a second request: it must remain HTTPS and target either the original
 * authority or a DNS-boundary match for redirect_host_suffix. Bearer auth is
 * retained only for the original authority and is omitted on a changed
 * authority. Both requests share one monotonic timeout budget. The suffix has
 * no leading dot or port (for example `hf.co`).
 * request_profile defaults to DEFAULT. GITHUB_RELEASE_ASSET adds only the
 * fixed `Accept: application/octet-stream`,
 * `X-GitHub-Api-Version: 2026-03-10`, and
 * `User-Agent: coakka-artifact-source-github-release` origin headers. They are
 * retained on a same-authority redirect and omitted with bearer auth after an
 * authority change. Arbitrary caller-supplied headers remain unsupported.
 * DROPBOX_REVISION requires DEFAULT auth, a mandatory bearer, rejected
 * redirects, and one lowercase hexadecimal dropbox_revision. The engine sends
 * one empty POST and constructs `Dropbox-API-Arg: {"path":"rev:<revision>"}`;
 * callers cannot provide raw JSON, headers, or methods. dropbox_revision must
 * be empty for every other profile.
 * SigV4 uses wall clock as required by the protocol even though lifecycle
 * timeouts remain monotonic.
 */
typedef struct coakka_https_publish_spec_t {
  size_t struct_size;
  const char *job_id;
  const char *url;
  const char *ca_certificate_file;
  const char *bearer_token;
  const char *destination_name;
  uint64_t expected_size;
  uint8_t expected_sha256[COAKKA_HTTPS_SHA256_BYTES];
  uint32_t timeout_ms;
  uint32_t reserved;
  uint32_t target_count;
  const coakka_https_publish_target_t *targets;
  uint32_t auth_mode;
  uint32_t auth_reserved;
  const char *aws_region;
  const char *aws_access_key;
  const char *aws_secret_key;
  const char *aws_session_token;
  const char *http_username;
  const char *http_password;
  const char *if_match_etag;
  const char *expected_content_digest;
  uint32_t redirect_mode;
  uint32_t redirect_reserved;
  const char *redirect_host_suffix;
  uint32_t request_profile;
  uint32_t request_profile_reserved;
  const char *dropbox_revision;
} coakka_https_publish_spec_t;

typedef struct coakka_https_publisher_snapshot_t {
  size_t struct_size;
  uint32_t state;
  uint32_t result;
  uint64_t expected_size;
  uint64_t fetched_bytes;
  uint32_t target_count;
  uint32_t completed_targets;
  uint32_t failed_targets;
  uint32_t cancel_requested;
  uint64_t update_sequence;
  uint64_t submitted_mono_ns;
  uint64_t started_mono_ns;
  uint64_t updated_mono_ns;
  uint64_t terminal_mono_ns;
  char local_path[COAKKA_HTTPS_LOCAL_PATH_MAX_BYTES];
  char detail[COAKKA_HTTPS_DETAIL_MAX_BYTES];
} coakka_https_publisher_snapshot_t;

typedef struct coakka_https_target_snapshot_t {
  size_t struct_size;
  uint32_t admitted;
  int32_t submit_status;
  uint32_t lane_state;
  uint32_t lane_result;
  uint64_t transferred_bytes;
  char transfer_id[COAKKA_V2_FILE_LANE_TRANSFER_ID_MAX_BYTES + 1u];
} coakka_https_target_snapshot_t;

/**
 * Creates one stopped publisher and copies the configuration. Staging is
 * anchored to an opened directory on POSIX and to a directory handle on
 * Windows; symlink/reparse-point traversal is rejected. Caller owns
 * *out_publisher on success.
 */
COAKKA_HTTPS_PUBLISHER_API coakka_https_status_t
coakka_https_publisher_create(const coakka_https_publisher_config_t *config,
                              coakka_https_publisher_t **out_publisher);
/**
 * Stops and releases a publisher. NULL is allowed. The caller must prevent
 * concurrent calls and keep the borrowed sender lane alive through return.
 */
COAKKA_HTTPS_PUBLISHER_API void
coakka_https_publisher_destroy(coakka_https_publisher_t *publisher);
/** Starts the single workflow worker. A stopped instance cannot be restarted.
 */
COAKKA_HTTPS_PUBLISHER_API coakka_https_status_t
coakka_https_publisher_start(coakka_https_publisher_t *publisher);
/**
 * Rejects new work, cooperatively cancels retained work, and joins the worker.
 * Concurrent start/stop calls are serialized internally.
 */
COAKKA_HTTPS_PUBLISHER_API coakka_https_status_t
coakka_https_publisher_stop(coakka_https_publisher_t *publisher);
/** Copies and admits one job, or returns CAPACITY without partial admission. */
COAKKA_HTTPS_PUBLISHER_API coakka_https_status_t
coakka_https_publisher_submit(coakka_https_publisher_t *publisher,
                              const coakka_https_publish_spec_t *spec);
/** Copies the latest retained aggregate snapshot into caller-owned storage. */
COAKKA_HTTPS_PUBLISHER_API coakka_https_status_t coakka_https_publisher_get(
    coakka_https_publisher_t *publisher, const char *job_id,
    coakka_https_publisher_snapshot_t *out_snapshot);
/**
 * Waits on monotonic time for update_sequence to advance. timeout_ms=0 is a
 * nonblocking query and returns WOULD_BLOCK when no newer update exists.
 */
COAKKA_HTTPS_PUBLISHER_API coakka_https_status_t coakka_https_publisher_wait(
    coakka_https_publisher_t *publisher, const char *job_id,
    uint64_t after_update_sequence, uint32_t timeout_ms,
    coakka_https_publisher_snapshot_t *out_snapshot);
/** Copies one retained File Lane target projection. */
COAKKA_HTTPS_PUBLISHER_API coakka_https_status_t
coakka_https_publisher_get_target(coakka_https_publisher_t *publisher,
                                  const char *job_id, uint32_t target_index,
                                  coakka_https_target_snapshot_t *out_snapshot);
/**
 * Requests cooperative cancellation. libcurl observes it through the progress
 * callback; DNS, regular-file write, fsync, certificate-store, or other
 * platform/library calls already executing may finish before cancellation.
 */
COAKKA_HTTPS_PUBLISHER_API coakka_https_status_t coakka_https_publisher_cancel(
    coakka_https_publisher_t *publisher, const char *job_id);
/**
 * Releases one terminal publisher record and its admitted sender records.
 * Callers must not independently forget publisher-owned sender records.
 */
COAKKA_HTTPS_PUBLISHER_API coakka_https_status_t coakka_https_publisher_forget(
    coakka_https_publisher_t *publisher, const char *job_id);
/** Returns libcurl's non-secret runtime version and TLS-backend string. */
COAKKA_HTTPS_PUBLISHER_API const char *
coakka_https_publisher_dependency_version(void);

#ifdef __cplusplus
}
#endif

#endif
