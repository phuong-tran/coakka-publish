# Consuming Hugging Face Hub Artifact Publisher

Unpack Runtime native `2.4.0` or newer and addon `1.1.0`, then expose both
CMake package directories:

```sh
cmake -S app -B build \
  -DCoAkkaRuntimeNativeV2_DIR=/path/to/runtime/cmake \
  -DCoAkkaRuntimeAddonArtifactPublisherHuggingfaceHub_DIR=/path/to/addon/cmake
```

```cmake
find_package(CoAkkaRuntimeAddonArtifactPublisherHuggingfaceHub CONFIG REQUIRED)
target_link_libraries(app PRIVATE
  CoAkkaRuntimeAddonArtifactPublisherHuggingfaceHub::artifact_publisher_huggingface_hub)
```

Keep the Runtime and addon native directories on the process loader path. The
semantic adapters already carry their required private HTTPS module. Platform
requirements are explicit in `manifest.json`. macOS and Linux load the platform libcurl/TLS stack declared by the release manifest. Windows absorbs the reviewed curl/OpenSSL closure and uses operating-system trust/security APIs; the compatible MSVC runtime required by CoAkka Runtime must be present.

The host must keep the borrowed sender lane alive until every publisher instance
has stopped and been destroyed. Cancellation, timeout, integrity validation,
no-clobber staging, and terminal job state are exposed by the C header contract.
