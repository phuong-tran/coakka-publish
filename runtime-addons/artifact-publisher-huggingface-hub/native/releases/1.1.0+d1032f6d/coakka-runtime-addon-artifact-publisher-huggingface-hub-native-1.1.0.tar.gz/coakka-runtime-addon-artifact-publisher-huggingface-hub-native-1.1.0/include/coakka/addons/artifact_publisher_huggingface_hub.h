#ifndef COAKKA_ADDONS_ARTIFACT_PUBLISHER_HUGGINGFACE_HUB_H
#define COAKKA_ADDONS_ARTIFACT_PUBLISHER_HUGGINGFACE_HUB_H

#include <stddef.h>
#include <stdint.h>

#include "coakka/v2/file_lane.h"

#if defined(_WIN32)
#if defined(COAKKA_HUGGINGFACE_HUB_PUBLISHER_BUILD)
#define COAKKA_HUGGINGFACE_HUB_PUBLISHER_API __declspec(dllexport)
#else
#define COAKKA_HUGGINGFACE_HUB_PUBLISHER_API __declspec(dllimport)
#endif
#elif defined(__GNUC__) || defined(__clang__)
#define COAKKA_HUGGINGFACE_HUB_PUBLISHER_API                                   \
  __attribute__((visibility("default")))
#else
#define COAKKA_HUGGINGFACE_HUB_PUBLISHER_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct coakka_huggingface_hub_publisher_t
    coakka_huggingface_hub_publisher_t;

enum {
  COAKKA_HUGGINGFACE_HUB_SHA256_BYTES = 32u,
  COAKKA_HUGGINGFACE_HUB_JOB_ID_MAX_BYTES = 64u,
  COAKKA_HUGGINGFACE_HUB_MAX_TARGETS = 8u,
  COAKKA_HUGGINGFACE_HUB_LOCAL_PATH_MAX_BYTES = 512u,
  COAKKA_HUGGINGFACE_HUB_DETAIL_MAX_BYTES = 192u
};

typedef enum coakka_huggingface_hub_status_t {
  COAKKA_HUGGINGFACE_HUB_OK = 0,
  COAKKA_HUGGINGFACE_HUB_ERR_INVALID_ARG = -1,
  COAKKA_HUGGINGFACE_HUB_ERR_NOMEM = -2,
  COAKKA_HUGGINGFACE_HUB_ERR_BAD_STATE = -3,
  COAKKA_HUGGINGFACE_HUB_ERR_WOULD_BLOCK = -4,
  COAKKA_HUGGINGFACE_HUB_ERR_NOT_FOUND = -5,
  COAKKA_HUGGINGFACE_HUB_ERR_CAPACITY = -6,
  COAKKA_HUGGINGFACE_HUB_ERR_IO = -7,
  COAKKA_HUGGINGFACE_HUB_ERR_FEATURE_UNAVAILABLE = -8
} coakka_huggingface_hub_status_t;

typedef enum coakka_huggingface_hub_publisher_state_t {
  COAKKA_HUGGINGFACE_HUB_PUBLISHER_QUEUED = 1u,
  COAKKA_HUGGINGFACE_HUB_PUBLISHER_CONNECTING = 2u,
  COAKKA_HUGGINGFACE_HUB_PUBLISHER_FETCHING = 3u,
  COAKKA_HUGGINGFACE_HUB_PUBLISHER_VERIFYING_ARTIFACT = 4u,
  COAKKA_HUGGINGFACE_HUB_PUBLISHER_ACQUIRED = 5u,
  COAKKA_HUGGINGFACE_HUB_PUBLISHER_DISTRIBUTING = 6u,
  COAKKA_HUGGINGFACE_HUB_PUBLISHER_COMPLETED = 7u,
  COAKKA_HUGGINGFACE_HUB_PUBLISHER_PARTIAL = 8u,
  COAKKA_HUGGINGFACE_HUB_PUBLISHER_FAILED = 9u,
  COAKKA_HUGGINGFACE_HUB_PUBLISHER_CANCELED = 10u
} coakka_huggingface_hub_publisher_state_t;

typedef enum coakka_huggingface_hub_publisher_result_t {
  COAKKA_HUGGINGFACE_HUB_RESULT_NONE = 0u,
  COAKKA_HUGGINGFACE_HUB_RESULT_OK = 1u,
  COAKKA_HUGGINGFACE_HUB_RESULT_INVALID_REQUEST = 2u,
  COAKKA_HUGGINGFACE_HUB_RESULT_CONNECT_FAILED = 3u,
  COAKKA_HUGGINGFACE_HUB_RESULT_TIMEOUT = 4u,
  COAKKA_HUGGINGFACE_HUB_RESULT_TLS_VERIFICATION_FAILED = 5u,
  COAKKA_HUGGINGFACE_HUB_RESULT_HTTP_STATUS_REJECTED = 6u,
  COAKKA_HUGGINGFACE_HUB_RESULT_REDIRECT_REJECTED = 7u,
  COAKKA_HUGGINGFACE_HUB_RESULT_REMOTE_IO = 8u,
  COAKKA_HUGGINGFACE_HUB_RESULT_CONTENT_ENCODING_UNSUPPORTED = 9u,
  COAKKA_HUGGINGFACE_HUB_RESULT_STORAGE_IO = 10u,
  COAKKA_HUGGINGFACE_HUB_RESULT_SIZE_MISMATCH = 11u,
  COAKKA_HUGGINGFACE_HUB_RESULT_DIGEST_MISMATCH = 12u,
  COAKKA_HUGGINGFACE_HUB_RESULT_DESTINATION_EXISTS = 13u,
  COAKKA_HUGGINGFACE_HUB_RESULT_DISTRIBUTION_FAILED = 14u,
  COAKKA_HUGGINGFACE_HUB_RESULT_CANCELED_BY_HOST = 15u,
  COAKKA_HUGGINGFACE_HUB_RESULT_STOPPED = 16u,
  COAKKA_HUGGINGFACE_HUB_RESULT_INTERNAL_ERROR = 17u
} coakka_huggingface_hub_publisher_result_t;

typedef struct coakka_huggingface_hub_publish_target_t {
  size_t struct_size;
  const char *transfer_id;
  const char *authorization_token;
  const char *remote_host;
  uint16_t remote_port;
  uint16_t reserved;
  uint32_t timeout_ms;
} coakka_huggingface_hub_publish_target_t;

typedef struct coakka_huggingface_hub_publisher_config_t {
  size_t struct_size;
  const char *staging_root;
  coakka_v2_file_lane_t *sender_lane;
  size_t queue_capacity;
  size_t retained_capacity;
  uint32_t default_timeout_ms;
  uint32_t reserved;
} coakka_huggingface_hub_publisher_config_t;

/**
 * One immutable Hugging Face Hub file acquisition plus File Lane fanout.
 * resolve_url must be an HTTPS URL with exactly one of these path shapes:
 *
 *   /<repo-id>/resolve/<40-lowercase-hex-commit>/<file-path>
 *   /datasets/<repo-id>/resolve/<40-lowercase-hex-commit>/<file-path>
 *   /spaces/<repo-id>/resolve/<40-lowercase-hex-commit>/<file-path>
 *
 * repo-id is `name` or `namespace/name`. Query parameters, fragments, userinfo,
 * branch/tag/PR resolution, and token minting or refresh are outside scope.
 * access_token may be empty for public content or contain one caller-supplied
 * fine-grained/read token. storage_host_suffix is mandatory and lower-case
 * (normally `hf.co`); one redirect may target either the original authority or
 * a DNS-boundary match for that suffix. The access token is retained only for
 * the original authority and is omitted from cross-authority storage requests.
 *
 * All strings, the digest, and targets are copied during submit. The resolve
 * URL, access token, signed redirect URL, and File Lane tokens are cleared
 * after use and never exposed in snapshots. expected_size and expected_sha256
 * independently gate no-clobber staging publication.
 */
typedef struct coakka_huggingface_hub_publish_spec_t {
  size_t struct_size;
  const char *job_id;
  const char *resolve_url;
  const char *ca_certificate_file;
  const char *access_token;
  const char *storage_host_suffix;
  const char *destination_name;
  uint64_t expected_size;
  uint8_t expected_sha256[COAKKA_HUGGINGFACE_HUB_SHA256_BYTES];
  uint32_t timeout_ms;
  uint32_t target_count;
  uint32_t reserved;
  const coakka_huggingface_hub_publish_target_t *targets;
} coakka_huggingface_hub_publish_spec_t;

typedef struct coakka_huggingface_hub_publisher_snapshot_t {
  size_t struct_size;
  uint32_t state;
  uint32_t result;
  uint64_t expected_size;
  uint64_t fetched_bytes;
  uint32_t target_count;
  uint32_t completed_targets;
  uint32_t failed_targets;
  uint32_t cancel_requested;
  uint64_t update_sequence;
  uint64_t submitted_mono_ns;
  uint64_t started_mono_ns;
  uint64_t updated_mono_ns;
  uint64_t terminal_mono_ns;
  char local_path[COAKKA_HUGGINGFACE_HUB_LOCAL_PATH_MAX_BYTES];
  char detail[COAKKA_HUGGINGFACE_HUB_DETAIL_MAX_BYTES];
} coakka_huggingface_hub_publisher_snapshot_t;

typedef struct coakka_huggingface_hub_target_snapshot_t {
  size_t struct_size;
  uint32_t admitted;
  int32_t submit_status;
  uint32_t lane_state;
  uint32_t lane_result;
  uint64_t transferred_bytes;
  char transfer_id[COAKKA_V2_FILE_LANE_TRANSFER_ID_MAX_BYTES + 1u];
} coakka_huggingface_hub_target_snapshot_t;

COAKKA_HUGGINGFACE_HUB_PUBLISHER_API coakka_huggingface_hub_status_t
coakka_huggingface_hub_publisher_create(
    const coakka_huggingface_hub_publisher_config_t *config,
    coakka_huggingface_hub_publisher_t **out_publisher);
COAKKA_HUGGINGFACE_HUB_PUBLISHER_API void
coakka_huggingface_hub_publisher_destroy(
    coakka_huggingface_hub_publisher_t *publisher);
COAKKA_HUGGINGFACE_HUB_PUBLISHER_API coakka_huggingface_hub_status_t
coakka_huggingface_hub_publisher_start(
    coakka_huggingface_hub_publisher_t *publisher);
COAKKA_HUGGINGFACE_HUB_PUBLISHER_API coakka_huggingface_hub_status_t
coakka_huggingface_hub_publisher_stop(
    coakka_huggingface_hub_publisher_t *publisher);
COAKKA_HUGGINGFACE_HUB_PUBLISHER_API coakka_huggingface_hub_status_t
coakka_huggingface_hub_publisher_submit(
    coakka_huggingface_hub_publisher_t *publisher,
    const coakka_huggingface_hub_publish_spec_t *spec);
COAKKA_HUGGINGFACE_HUB_PUBLISHER_API coakka_huggingface_hub_status_t
coakka_huggingface_hub_publisher_get(
    coakka_huggingface_hub_publisher_t *publisher, const char *job_id,
    coakka_huggingface_hub_publisher_snapshot_t *out_snapshot);
COAKKA_HUGGINGFACE_HUB_PUBLISHER_API coakka_huggingface_hub_status_t
coakka_huggingface_hub_publisher_wait(
    coakka_huggingface_hub_publisher_t *publisher, const char *job_id,
    uint64_t after_update_sequence, uint32_t timeout_ms,
    coakka_huggingface_hub_publisher_snapshot_t *out_snapshot);
COAKKA_HUGGINGFACE_HUB_PUBLISHER_API coakka_huggingface_hub_status_t
coakka_huggingface_hub_publisher_get_target(
    coakka_huggingface_hub_publisher_t *publisher, const char *job_id,
    uint32_t target_index,
    coakka_huggingface_hub_target_snapshot_t *out_snapshot);
COAKKA_HUGGINGFACE_HUB_PUBLISHER_API coakka_huggingface_hub_status_t
coakka_huggingface_hub_publisher_cancel(
    coakka_huggingface_hub_publisher_t *publisher, const char *job_id);
COAKKA_HUGGINGFACE_HUB_PUBLISHER_API coakka_huggingface_hub_status_t
coakka_huggingface_hub_publisher_forget(
    coakka_huggingface_hub_publisher_t *publisher, const char *job_id);
COAKKA_HUGGINGFACE_HUB_PUBLISHER_API const char *
coakka_huggingface_hub_publisher_dependency_version(void);

#ifdef __cplusplus
}
#endif

#endif
