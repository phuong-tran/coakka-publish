# Third-Party Notices

This Local Drop addon contains no third-party implementation library.
