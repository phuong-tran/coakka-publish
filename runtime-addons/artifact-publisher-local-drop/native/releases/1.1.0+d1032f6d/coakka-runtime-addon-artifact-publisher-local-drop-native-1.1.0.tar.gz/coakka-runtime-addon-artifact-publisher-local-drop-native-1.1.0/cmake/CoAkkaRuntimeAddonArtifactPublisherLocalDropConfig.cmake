include_guard(GLOBAL)

include(CMakeFindDependencyMacro)
find_dependency(CoAkkaRuntimeNativeV2 CONFIG)

get_filename_component(_coakka_addon_root "${CMAKE_CURRENT_LIST_DIR}/.." ABSOLUTE)
if(CMAKE_SYSTEM_NAME STREQUAL "Darwin" AND CMAKE_SYSTEM_PROCESSOR MATCHES "^(arm64|aarch64)$")
  set(_coakka_addon_platform "macos-aarch64")
  set(_coakka_addon_library_name "libcoakka_addon_artifact_publisher_local_drop.dylib")
elseif(CMAKE_SYSTEM_NAME STREQUAL "Linux")
  if(CMAKE_SYSTEM_PROCESSOR MATCHES "^(aarch64|arm64)$")
    set(_coakka_addon_platform "linux-aarch64")
  elseif(CMAKE_SYSTEM_PROCESSOR MATCHES "^(x86_64|amd64|AMD64)$")
    set(_coakka_addon_platform "linux-x86_64")
  else()
    message(FATAL_ERROR "CoAkka Local Drop Artifact Publisher package has no Linux binary for ${CMAKE_SYSTEM_PROCESSOR}")
  endif()
  set(_coakka_addon_library_name "libcoakka_addon_artifact_publisher_local_drop.so")
elseif(CMAKE_SYSTEM_NAME STREQUAL "Windows")
  message(FATAL_ERROR "CoAkka Local Drop addon does not support Windows")
else()
  message(FATAL_ERROR "CoAkka Local Drop Artifact Publisher package does not support ${CMAKE_SYSTEM_NAME}/${CMAKE_SYSTEM_PROCESSOR}")
endif()

set(_coakka_addon_library "${_coakka_addon_root}/native/${_coakka_addon_platform}/${_coakka_addon_library_name}")
if(NOT EXISTS "${_coakka_addon_library}")
  message(FATAL_ERROR "CoAkka addon native library is missing: ${_coakka_addon_library}")
endif()

if(NOT TARGET CoAkkaRuntimeAddonArtifactPublisherLocalDrop::artifact_publisher_local_drop)
  add_library(CoAkkaRuntimeAddonArtifactPublisherLocalDrop::artifact_publisher_local_drop SHARED IMPORTED)
  set_target_properties(CoAkkaRuntimeAddonArtifactPublisherLocalDrop::artifact_publisher_local_drop PROPERTIES
    IMPORTED_LOCATION "${_coakka_addon_library}"
    INTERFACE_INCLUDE_DIRECTORIES "${_coakka_addon_root}/include"
    INTERFACE_LINK_LIBRARIES "CoAkkaRuntimeNativeV2::runtime_v2")
  if(CMAKE_SYSTEM_NAME STREQUAL "Windows")
    set(_coakka_addon_implib "${_coakka_addon_root}/native/${_coakka_addon_platform}/${_coakka_addon_implib_name}")
    if(NOT EXISTS "${_coakka_addon_implib}")
      message(FATAL_ERROR "CoAkka addon import library is missing: ${_coakka_addon_implib}")
    endif()
    set_property(TARGET CoAkkaRuntimeAddonArtifactPublisherLocalDrop::artifact_publisher_local_drop
      PROPERTY IMPORTED_IMPLIB "${_coakka_addon_implib}")
  endif()
endif()

set(CoAkkaRuntimeAddonArtifactPublisherLocalDrop_FOUND TRUE)
set(CoAkkaRuntimeAddonArtifactPublisherLocalDrop_PLATFORM "${_coakka_addon_platform}")
set(CoAkkaRuntimeAddonArtifactPublisherLocalDrop_NATIVE_LIBRARY "${_coakka_addon_library}")
