#ifndef COAKKA_ADDONS_ARTIFACT_PUBLISHER_LOCAL_DROP_H
#define COAKKA_ADDONS_ARTIFACT_PUBLISHER_LOCAL_DROP_H

#include <stddef.h>
#include <stdint.h>

#include "coakka/v2/file_lane.h"

#if defined(_WIN32)
#if defined(COAKKA_LOCAL_DROP_PUBLISHER_BUILD)
#define COAKKA_LOCAL_DROP_API __declspec(dllexport)
#else
#define COAKKA_LOCAL_DROP_API __declspec(dllimport)
#endif
#elif defined(__GNUC__) || defined(__clang__)
#define COAKKA_LOCAL_DROP_API __attribute__((visibility("default")))
#else
#define COAKKA_LOCAL_DROP_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct coakka_local_drop_publisher_t coakka_local_drop_publisher_t;

enum {
  COAKKA_LOCAL_DROP_SHA256_BYTES = 32u,
  COAKKA_LOCAL_DROP_JOB_ID_MAX_BYTES = 64u,
  COAKKA_LOCAL_DROP_MAX_TARGETS = 8u,
  COAKKA_LOCAL_DROP_LOCAL_PATH_MAX_BYTES = 512u,
  COAKKA_LOCAL_DROP_DETAIL_MAX_BYTES = 192u
};

typedef enum coakka_local_drop_status_t {
  COAKKA_LOCAL_DROP_OK = 0,
  COAKKA_LOCAL_DROP_ERR_INVALID_ARG = -1,
  COAKKA_LOCAL_DROP_ERR_NOMEM = -2,
  COAKKA_LOCAL_DROP_ERR_BAD_STATE = -3,
  COAKKA_LOCAL_DROP_ERR_WOULD_BLOCK = -4,
  COAKKA_LOCAL_DROP_ERR_NOT_FOUND = -5,
  COAKKA_LOCAL_DROP_ERR_CAPACITY = -6,
  COAKKA_LOCAL_DROP_ERR_IO = -7,
  COAKKA_LOCAL_DROP_ERR_FEATURE_UNAVAILABLE = -8
} coakka_local_drop_status_t;

typedef enum coakka_local_drop_state_t {
  COAKKA_LOCAL_DROP_QUEUED = 1u,
  COAKKA_LOCAL_DROP_WAITING_FOR_SOURCE = 2u,
  COAKKA_LOCAL_DROP_VERIFYING_SOURCE = 3u,
  COAKKA_LOCAL_DROP_ACQUIRED = 4u,
  COAKKA_LOCAL_DROP_DISTRIBUTING = 5u,
  COAKKA_LOCAL_DROP_COMPLETED = 6u,
  COAKKA_LOCAL_DROP_PARTIAL = 7u,
  COAKKA_LOCAL_DROP_FAILED = 8u,
  COAKKA_LOCAL_DROP_CANCELED = 9u
} coakka_local_drop_state_t;

typedef enum coakka_local_drop_result_t {
  COAKKA_LOCAL_DROP_RESULT_NONE = 0u,
  COAKKA_LOCAL_DROP_RESULT_OK = 1u,
  COAKKA_LOCAL_DROP_RESULT_INVALID_REQUEST = 2u,
  COAKKA_LOCAL_DROP_RESULT_SOURCE_TIMEOUT = 3u,
  COAKKA_LOCAL_DROP_RESULT_SOURCE_REJECTED = 4u,
  COAKKA_LOCAL_DROP_RESULT_SOURCE_IO = 5u,
  COAKKA_LOCAL_DROP_RESULT_SIZE_MISMATCH = 6u,
  COAKKA_LOCAL_DROP_RESULT_DIGEST_MISMATCH = 7u,
  COAKKA_LOCAL_DROP_RESULT_STORAGE_IO = 8u,
  COAKKA_LOCAL_DROP_RESULT_DESTINATION_EXISTS = 9u,
  COAKKA_LOCAL_DROP_RESULT_DISTRIBUTION_FAILED = 10u,
  COAKKA_LOCAL_DROP_RESULT_CANCELED_BY_HOST = 11u,
  COAKKA_LOCAL_DROP_RESULT_STOPPED = 12u,
  COAKKA_LOCAL_DROP_RESULT_INTERNAL_ERROR = 13u
} coakka_local_drop_result_t;

typedef struct coakka_local_drop_target_t {
  size_t struct_size;
  const char *transfer_id;
  const char *authorization_token;
  const char *remote_host;
  uint16_t remote_port;
  uint16_t reserved;
  uint32_t timeout_ms;
} coakka_local_drop_target_t;

/**
 * drop_root must be an existing absolute directory controlled by the host.
 * The addon opens and retains a non-following directory handle; it never scans
 * the directory and never deletes source files. staging_root is a separate
 * absolute directory used for verified no-clobber publication.
 */
typedef struct coakka_local_drop_publisher_config_t {
  size_t struct_size;
  const char *drop_root;
  const char *staging_root;
  coakka_v2_file_lane_t *sender_lane;
  size_t queue_capacity;
  size_t retained_capacity;
  uint32_t default_source_timeout_ms;
  uint32_t poll_interval_ms;
  uint32_t quiet_period_ms;
  uint32_t reserved;
} coakka_local_drop_publisher_config_t;

/**
 * One expected local artifact. source_name and destination_name are safe leaf
 * names, not paths. The source must retain one identity, size, modification
 * time, and change time throughout the quiet window and verified read.
 * Independent expected size/SHA-256 are mandatory. timeout_ms=0 selects the
 * publisher default and covers source waiting/verification, not queue time or
 * subsequent File Lane delivery.
 */
typedef struct coakka_local_drop_publish_spec_t {
  size_t struct_size;
  const char *job_id;
  const char *source_name;
  const char *destination_name;
  uint64_t expected_size;
  uint8_t expected_sha256[COAKKA_LOCAL_DROP_SHA256_BYTES];
  uint32_t timeout_ms;
  uint32_t target_count;
  uint32_t reserved;
  const coakka_local_drop_target_t *targets;
} coakka_local_drop_publish_spec_t;

typedef struct coakka_local_drop_snapshot_t {
  size_t struct_size;
  uint32_t state;
  uint32_t result;
  uint64_t expected_size;
  uint64_t acquired_bytes;
  uint32_t target_count;
  uint32_t completed_targets;
  uint32_t failed_targets;
  uint32_t cancel_requested;
  uint64_t update_sequence;
  uint64_t submitted_mono_ns;
  uint64_t started_mono_ns;
  uint64_t updated_mono_ns;
  uint64_t terminal_mono_ns;
  char local_path[COAKKA_LOCAL_DROP_LOCAL_PATH_MAX_BYTES];
  char detail[COAKKA_LOCAL_DROP_DETAIL_MAX_BYTES];
} coakka_local_drop_snapshot_t;

typedef struct coakka_local_drop_target_snapshot_t {
  size_t struct_size;
  uint32_t admitted;
  int32_t submit_status;
  uint32_t lane_state;
  uint32_t lane_result;
  uint64_t transferred_bytes;
  char transfer_id[COAKKA_V2_FILE_LANE_TRANSFER_ID_MAX_BYTES + 1u];
} coakka_local_drop_target_snapshot_t;

COAKKA_LOCAL_DROP_API coakka_local_drop_status_t
coakka_local_drop_publisher_create(
    const coakka_local_drop_publisher_config_t *config,
    coakka_local_drop_publisher_t **out_publisher);
/** Stops and destroys one publisher. NULL is allowed. */
COAKKA_LOCAL_DROP_API void
coakka_local_drop_publisher_destroy(coakka_local_drop_publisher_t *publisher);
/** Starts the single worker. A stopped instance cannot restart. */
COAKKA_LOCAL_DROP_API coakka_local_drop_status_t
coakka_local_drop_publisher_start(coakka_local_drop_publisher_t *publisher);
/** Rejects admission, wakes source waits, cancels work, and joins the worker.
 */
COAKKA_LOCAL_DROP_API coakka_local_drop_status_t
coakka_local_drop_publisher_stop(coakka_local_drop_publisher_t *publisher);
/** Deep-copies and atomically admits one bounded request. */
COAKKA_LOCAL_DROP_API coakka_local_drop_status_t
coakka_local_drop_publisher_submit(
    coakka_local_drop_publisher_t *publisher,
    const coakka_local_drop_publish_spec_t *spec);
/** Copies the latest retained aggregate snapshot. */
COAKKA_LOCAL_DROP_API coakka_local_drop_status_t
coakka_local_drop_publisher_get(coakka_local_drop_publisher_t *publisher,
                                const char *job_id,
                                coakka_local_drop_snapshot_t *out_snapshot);
/** Waits for an update newer than after_update_sequence using monotonic time.
 */
COAKKA_LOCAL_DROP_API coakka_local_drop_status_t
coakka_local_drop_publisher_wait(coakka_local_drop_publisher_t *publisher,
                                 const char *job_id,
                                 uint64_t after_update_sequence,
                                 uint32_t timeout_ms,
                                 coakka_local_drop_snapshot_t *out_snapshot);
/** Copies one retained File Lane target projection. */
COAKKA_LOCAL_DROP_API coakka_local_drop_status_t
coakka_local_drop_publisher_get_target(
    coakka_local_drop_publisher_t *publisher, const char *job_id,
    uint32_t target_index, coakka_local_drop_target_snapshot_t *out_snapshot);
/** Cooperatively cancels source acquisition and admitted File Lane transfers.
 */
COAKKA_LOCAL_DROP_API coakka_local_drop_status_t
coakka_local_drop_publisher_cancel(coakka_local_drop_publisher_t *publisher,
                                   const char *job_id);
/** Releases one terminal record and its publisher-owned sender records. */
COAKKA_LOCAL_DROP_API coakka_local_drop_status_t
coakka_local_drop_publisher_forget(coakka_local_drop_publisher_t *publisher,
                                   const char *job_id);
/** Returns the loaded Runtime's immutable version string. */
COAKKA_LOCAL_DROP_API const char *
coakka_local_drop_publisher_dependency_version(void);

#ifdef __cplusplus
}
#endif

#endif
