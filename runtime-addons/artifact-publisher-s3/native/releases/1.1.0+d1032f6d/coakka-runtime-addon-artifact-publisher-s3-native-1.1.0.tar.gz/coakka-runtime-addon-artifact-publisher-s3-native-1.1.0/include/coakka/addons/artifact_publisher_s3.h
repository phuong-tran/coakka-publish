#ifndef COAKKA_ADDONS_ARTIFACT_PUBLISHER_S3_H
#define COAKKA_ADDONS_ARTIFACT_PUBLISHER_S3_H

#include <stddef.h>
#include <stdint.h>

#include "coakka/v2/file_lane.h"

#if defined(_WIN32)
#if defined(COAKKA_S3_PUBLISHER_BUILD)
#define COAKKA_S3_PUBLISHER_API __declspec(dllexport)
#else
#define COAKKA_S3_PUBLISHER_API __declspec(dllimport)
#endif
#elif defined(__GNUC__) || defined(__clang__)
#define COAKKA_S3_PUBLISHER_API __attribute__((visibility("default")))
#else
#define COAKKA_S3_PUBLISHER_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct coakka_s3_publisher_t coakka_s3_publisher_t;

enum {
  COAKKA_S3_SHA256_BYTES = 32u,
  COAKKA_S3_JOB_ID_MAX_BYTES = 64u,
  COAKKA_S3_MAX_TARGETS = 8u,
  COAKKA_S3_LOCAL_PATH_MAX_BYTES = 512u,
  COAKKA_S3_DETAIL_MAX_BYTES = 192u
};

typedef enum coakka_s3_status_t {
  COAKKA_S3_OK = 0,
  COAKKA_S3_ERR_INVALID_ARG = -1,
  COAKKA_S3_ERR_NOMEM = -2,
  COAKKA_S3_ERR_BAD_STATE = -3,
  COAKKA_S3_ERR_WOULD_BLOCK = -4,
  COAKKA_S3_ERR_NOT_FOUND = -5,
  COAKKA_S3_ERR_CAPACITY = -6,
  COAKKA_S3_ERR_IO = -7,
  COAKKA_S3_ERR_FEATURE_UNAVAILABLE = -8
} coakka_s3_status_t;

typedef enum coakka_s3_publisher_state_t {
  COAKKA_S3_PUBLISHER_QUEUED = 1u,
  COAKKA_S3_PUBLISHER_CONNECTING = 2u,
  COAKKA_S3_PUBLISHER_FETCHING = 3u,
  COAKKA_S3_PUBLISHER_VERIFYING_ARTIFACT = 4u,
  COAKKA_S3_PUBLISHER_ACQUIRED = 5u,
  COAKKA_S3_PUBLISHER_DISTRIBUTING = 6u,
  COAKKA_S3_PUBLISHER_COMPLETED = 7u,
  COAKKA_S3_PUBLISHER_PARTIAL = 8u,
  COAKKA_S3_PUBLISHER_FAILED = 9u,
  COAKKA_S3_PUBLISHER_CANCELED = 10u
} coakka_s3_publisher_state_t;

typedef enum coakka_s3_publisher_result_t {
  COAKKA_S3_RESULT_NONE = 0u,
  COAKKA_S3_RESULT_OK = 1u,
  COAKKA_S3_RESULT_INVALID_REQUEST = 2u,
  COAKKA_S3_RESULT_CONNECT_FAILED = 3u,
  COAKKA_S3_RESULT_TIMEOUT = 4u,
  COAKKA_S3_RESULT_TLS_VERIFICATION_FAILED = 5u,
  COAKKA_S3_RESULT_HTTP_STATUS_REJECTED = 6u,
  COAKKA_S3_RESULT_REDIRECT_REJECTED = 7u,
  COAKKA_S3_RESULT_REMOTE_IO = 8u,
  COAKKA_S3_RESULT_CONTENT_ENCODING_UNSUPPORTED = 9u,
  COAKKA_S3_RESULT_STORAGE_IO = 10u,
  COAKKA_S3_RESULT_SIZE_MISMATCH = 11u,
  COAKKA_S3_RESULT_DIGEST_MISMATCH = 12u,
  COAKKA_S3_RESULT_DESTINATION_EXISTS = 13u,
  COAKKA_S3_RESULT_DISTRIBUTION_FAILED = 14u,
  COAKKA_S3_RESULT_CANCELED_BY_HOST = 15u,
  COAKKA_S3_RESULT_STOPPED = 16u,
  COAKKA_S3_RESULT_INTERNAL_ERROR = 17u
} coakka_s3_publisher_result_t;

typedef enum coakka_s3_addressing_style_t {
  COAKKA_S3_ADDRESSING_PATH = 1u,
  COAKKA_S3_ADDRESSING_VIRTUAL_HOSTED = 2u
} coakka_s3_addressing_style_t;

typedef struct coakka_s3_publish_target_t {
  size_t struct_size;
  const char *transfer_id;
  const char *authorization_token;
  const char *remote_host;
  uint16_t remote_port;
  uint16_t reserved;
  uint32_t timeout_ms;
} coakka_s3_publish_target_t;

typedef struct coakka_s3_publisher_config_t {
  size_t struct_size;
  const char *staging_root;
  coakka_v2_file_lane_t *sender_lane;
  size_t queue_capacity;
  size_t retained_capacity;
  uint32_t default_timeout_ms;
  uint32_t reserved;
} coakka_s3_publisher_config_t;

/**
 * One immutable S3 GetObject plus File Lane distribution request.
 * endpoint_url is an HTTPS origin without userinfo, query, fragment, or a path
 * other than '/'. bucket and object_key are unescaped UTF-8 input; the addon
 * builds and encodes the final URL. An exact '.' or '..' object-key path
 * segment is invalid. PATH addressing supports MinIO and other S3-compatible
 * origins. VIRTUAL_HOSTED prepends bucket to the endpoint host.
 *
 * AWS access/secret/session credentials are copied during submit, handed to
 * libcurl's SigV4 implementation, then cleared before the network wait. Region
 * is mandatory. version_id is optional; when present it pins GetObject to one
 * immutable version. Independent expected size and SHA-256 remain mandatory;
 * ETag is never treated as an integrity digest.
 */
typedef struct coakka_s3_publish_spec_t {
  size_t struct_size;
  const char *job_id;
  const char *endpoint_url;
  const char *ca_certificate_file;
  const char *region;
  const char *bucket;
  const char *object_key;
  const char *version_id;
  const char *access_key;
  const char *secret_key;
  const char *session_token;
  const char *destination_name;
  uint64_t expected_size;
  uint8_t expected_sha256[COAKKA_S3_SHA256_BYTES];
  uint32_t timeout_ms;
  uint32_t addressing_style;
  uint32_t target_count;
  uint32_t reserved;
  const coakka_s3_publish_target_t *targets;
} coakka_s3_publish_spec_t;

typedef struct coakka_s3_publisher_snapshot_t {
  size_t struct_size;
  uint32_t state;
  uint32_t result;
  uint64_t expected_size;
  uint64_t fetched_bytes;
  uint32_t target_count;
  uint32_t completed_targets;
  uint32_t failed_targets;
  uint32_t cancel_requested;
  uint64_t update_sequence;
  uint64_t submitted_mono_ns;
  uint64_t started_mono_ns;
  uint64_t updated_mono_ns;
  uint64_t terminal_mono_ns;
  char local_path[COAKKA_S3_LOCAL_PATH_MAX_BYTES];
  char detail[COAKKA_S3_DETAIL_MAX_BYTES];
} coakka_s3_publisher_snapshot_t;

typedef struct coakka_s3_target_snapshot_t {
  size_t struct_size;
  uint32_t admitted;
  int32_t submit_status;
  uint32_t lane_state;
  uint32_t lane_result;
  uint64_t transferred_bytes;
  char transfer_id[COAKKA_V2_FILE_LANE_TRANSFER_ID_MAX_BYTES + 1u];
} coakka_s3_target_snapshot_t;

COAKKA_S3_PUBLISHER_API coakka_s3_status_t
coakka_s3_publisher_create(const coakka_s3_publisher_config_t *config,
                           coakka_s3_publisher_t **out_publisher);
/** Stops and destroys one publisher. NULL is allowed. */
COAKKA_S3_PUBLISHER_API void
coakka_s3_publisher_destroy(coakka_s3_publisher_t *publisher);
/** Starts the composed single worker. A stopped instance cannot restart. */
COAKKA_S3_PUBLISHER_API coakka_s3_status_t
coakka_s3_publisher_start(coakka_s3_publisher_t *publisher);
/** Rejects admission, cooperatively cancels work, and joins the worker. */
COAKKA_S3_PUBLISHER_API coakka_s3_status_t
coakka_s3_publisher_stop(coakka_s3_publisher_t *publisher);
/** Deep-copies and admits one request, or fails without partial admission. */
COAKKA_S3_PUBLISHER_API coakka_s3_status_t coakka_s3_publisher_submit(
    coakka_s3_publisher_t *publisher, const coakka_s3_publish_spec_t *spec);
/** Copies the latest retained aggregate snapshot. */
COAKKA_S3_PUBLISHER_API coakka_s3_status_t
coakka_s3_publisher_get(coakka_s3_publisher_t *publisher, const char *job_id,
                        coakka_s3_publisher_snapshot_t *out_snapshot);
COAKKA_S3_PUBLISHER_API coakka_s3_status_t
coakka_s3_publisher_wait(coakka_s3_publisher_t *publisher, const char *job_id,
                         uint64_t after_update_sequence, uint32_t timeout_ms,
                         coakka_s3_publisher_snapshot_t *out_snapshot);
/** Copies one retained File Lane target projection. */
COAKKA_S3_PUBLISHER_API coakka_s3_status_t coakka_s3_publisher_get_target(
    coakka_s3_publisher_t *publisher, const char *job_id, uint32_t target_index,
    coakka_s3_target_snapshot_t *out_snapshot);
/** Requests cooperative cancellation of acquisition and File Lane fanout. */
COAKKA_S3_PUBLISHER_API coakka_s3_status_t coakka_s3_publisher_cancel(
    coakka_s3_publisher_t *publisher, const char *job_id);
/** Releases one terminal record and its publisher-owned sender records. */
COAKKA_S3_PUBLISHER_API coakka_s3_status_t coakka_s3_publisher_forget(
    coakka_s3_publisher_t *publisher, const char *job_id);
COAKKA_S3_PUBLISHER_API const char *
coakka_s3_publisher_dependency_version(void);

#ifdef __cplusplus
}
#endif

#endif
