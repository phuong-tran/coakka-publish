# Consuming The SFTP Artifact Publisher Addon

Unpack CoAkka Runtime native `2.3.0` or newer and this independently versioned
addon archive. Expose both CMake package directories:

```sh
cmake -S app -B build \
  -DCoAkkaRuntimeNativeV2_DIR=/path/to/runtime/cmake \
  -DCoAkkaRuntimeAddonArtifactPublisherSftp_DIR=/path/to/addon/cmake
```

```cmake
find_package(CoAkkaRuntimeNativeV2 CONFIG REQUIRED)
find_package(CoAkkaRuntimeAddonArtifactPublisherSftp CONFIG REQUIRED)

add_executable(service_a main.c)
target_link_libraries(service_a PRIVATE
  CoAkkaRuntimeAddonArtifactPublisherSftp::artifact_publisher_sftp)
```

Keep both matching platform native directories on the process loader path. The
imported addon target brings the Runtime target as an interface dependency.

The app host owns Runtime and File Lane lifecycle. A sender lane passed to the
publisher must remain alive until the publisher has stopped and been destroyed.
The publisher borrows request values only for synchronous admission and copies
accepted jobs into bounded internal state.

Do not install libssh2, OpenSSL, or another addon implementation package on the
target host. Those implementation dependencies are absorbed into the addon
module; macOS zlib is supplied by the operating system.
