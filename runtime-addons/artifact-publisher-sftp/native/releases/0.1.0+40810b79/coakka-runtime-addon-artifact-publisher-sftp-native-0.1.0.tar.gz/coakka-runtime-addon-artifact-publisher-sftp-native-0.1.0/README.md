# CoAkka SFTP Artifact Publisher Native Addon 0.1.0

Release generation: `0.1.0+40810b79`

This optional addon lets a Service A app host acquire a pinned SFTP artifact,
verify its declared size and SHA-256 digest, publish it into no-clobber local
staging, and distribute it through a CoAkka Runtime sender File Lane.

## Compatibility

- addon version: `0.1.0`
- Runtime ABI major: `2`
- minimum CoAkka Runtime native version: `2.3.0`
- required Runtime feature: `file_lane`
- packaged platform: `macos-aarch64`
- minimum packaged macOS deployment target: `26.0`

The Runtime native package is a separate dependency and is not duplicated in
this archive. This module statically absorbs libssh2 `1.11.1` and the OpenSSL
crypto provider `3.6.2`. It uses the macOS system zlib `1.2.12`. Target users do
not install libssh2, OpenSSL, or zlib separately.

## Contents

```text
include/coakka/addons/artifact_publisher_sftp.h
native/macos-aarch64/libcoakka_addon_artifact_publisher_sftp.dylib
native/macos-aarch64/libcoakka_addon_artifact_publisher_sftp.0.dylib
cmake/CoAkkaRuntimeAddonArtifactPublisherSftpConfig.cmake
share/coakka/runtime-addons/artifact-publisher-sftp/addon.manifest.json
LICENSE.md
THIRD_PARTY_NOTICES.md
CONSUMING.md
```

The app host owns credentials, host-key pins, expected metadata, target grants,
business retry and rollout policy, and lifecycle. Start the sender File Lane
before the publisher. Stop and destroy the publisher before stopping the lane.

See `CONSUMING.md` for the native CMake integration contract.
