# Consuming SFTP Artifact Publisher

Unpack Runtime native `2.3.0` or newer and addon `1.2.0`, then expose both
CMake package directories:

```sh
cmake -S app -B build \
  -DCoAkkaRuntimeNativeV2_DIR=/path/to/runtime/cmake \
  -DCoAkkaRuntimeAddonArtifactPublisherSftp_DIR=/path/to/addon/cmake
```

```cmake
find_package(CoAkkaRuntimeAddonArtifactPublisherSftp CONFIG REQUIRED)
target_link_libraries(app PRIVATE
  CoAkkaRuntimeAddonArtifactPublisherSftp::artifact_publisher_sftp)
```

Keep the Runtime and addon native directories on the process loader path. The
semantic adapters already carry their required private HTTPS module. Platform
requirements are explicit in `manifest.json`. The package absorbs libssh2 and its target crypto/compression closure; no SFTP implementation library is installed separately.

The host must keep the borrowed sender lane alive until every publisher instance
has stopped and been destroyed. Cancellation, timeout, integrity validation,
no-clobber staging, and terminal job state are exposed by the C header contract.
