#ifndef COAKKA_ADDONS_ARTIFACT_PUBLISHER_SFTP_H
#define COAKKA_ADDONS_ARTIFACT_PUBLISHER_SFTP_H

#include <stddef.h>
#include <stdint.h>

#include "coakka/v2/file_lane.h"

#if defined(_WIN32)
#if defined(COAKKA_SFTP_PUBLISHER_BUILD)
#define COAKKA_SFTP_PUBLISHER_API __declspec(dllexport)
#else
#define COAKKA_SFTP_PUBLISHER_API __declspec(dllimport)
#endif
#elif defined(__GNUC__) || defined(__clang__)
#define COAKKA_SFTP_PUBLISHER_API __attribute__((visibility("default")))
#else
#define COAKKA_SFTP_PUBLISHER_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct coakka_sftp_publisher_t coakka_sftp_publisher_t;

enum {
  COAKKA_SFTP_SHA256_BYTES = 32u,
  COAKKA_SFTP_JOB_ID_MAX_BYTES = 64u,
  COAKKA_SFTP_MAX_TARGETS = 8u,
  COAKKA_SFTP_LOCAL_PATH_MAX_BYTES = 512u,
  COAKKA_SFTP_DETAIL_MAX_BYTES = 192u
};

typedef enum coakka_sftp_status_t {
  COAKKA_SFTP_OK = 0,
  COAKKA_SFTP_ERR_INVALID_ARG = -1,
  COAKKA_SFTP_ERR_NOMEM = -2,
  COAKKA_SFTP_ERR_BAD_STATE = -3,
  COAKKA_SFTP_ERR_WOULD_BLOCK = -4,
  COAKKA_SFTP_ERR_NOT_FOUND = -5,
  COAKKA_SFTP_ERR_CAPACITY = -6,
  COAKKA_SFTP_ERR_IO = -7,
  COAKKA_SFTP_ERR_FEATURE_UNAVAILABLE = -8
} coakka_sftp_status_t;

typedef enum coakka_sftp_publisher_state_t {
  COAKKA_SFTP_PUBLISHER_QUEUED = 1u,
  COAKKA_SFTP_PUBLISHER_CONNECTING = 2u,
  COAKKA_SFTP_PUBLISHER_VERIFYING_HOST = 3u,
  COAKKA_SFTP_PUBLISHER_AUTHENTICATING = 4u,
  COAKKA_SFTP_PUBLISHER_FETCHING = 5u,
  COAKKA_SFTP_PUBLISHER_VERIFYING_ARTIFACT = 6u,
  COAKKA_SFTP_PUBLISHER_ACQUIRED = 7u,
  COAKKA_SFTP_PUBLISHER_DISTRIBUTING = 8u,
  COAKKA_SFTP_PUBLISHER_COMPLETED = 9u,
  COAKKA_SFTP_PUBLISHER_PARTIAL = 10u,
  COAKKA_SFTP_PUBLISHER_FAILED = 11u,
  COAKKA_SFTP_PUBLISHER_CANCELED = 12u
} coakka_sftp_publisher_state_t;

typedef enum coakka_sftp_publisher_result_t {
  COAKKA_SFTP_RESULT_NONE = 0u,
  COAKKA_SFTP_RESULT_OK = 1u,
  COAKKA_SFTP_RESULT_INVALID_REQUEST = 2u,
  COAKKA_SFTP_RESULT_CONNECT_FAILED = 3u,
  COAKKA_SFTP_RESULT_TIMEOUT = 4u,
  COAKKA_SFTP_RESULT_HOST_KEY_MISMATCH = 5u,
  COAKKA_SFTP_RESULT_AUTH_REJECTED = 6u,
  COAKKA_SFTP_RESULT_REMOTE_NOT_FOUND = 7u,
  COAKKA_SFTP_RESULT_REMOTE_IO = 8u,
  COAKKA_SFTP_RESULT_SOURCE_CHANGED = 9u,
  COAKKA_SFTP_RESULT_STORAGE_IO = 10u,
  COAKKA_SFTP_RESULT_SIZE_MISMATCH = 11u,
  COAKKA_SFTP_RESULT_DIGEST_MISMATCH = 12u,
  COAKKA_SFTP_RESULT_DESTINATION_EXISTS = 13u,
  COAKKA_SFTP_RESULT_DISTRIBUTION_FAILED = 14u,
  COAKKA_SFTP_RESULT_CANCELED_BY_HOST = 15u,
  COAKKA_SFTP_RESULT_STOPPED = 16u,
  COAKKA_SFTP_RESULT_INTERNAL_ERROR = 17u
} coakka_sftp_publisher_result_t;

/**
 * One File Lane destination. All strings are copied during submit. The lane
 * itself is borrowed from the publisher config for the publisher lifetime.
 * timeout_ms is passed to File Lane; zero selects its normal default.
 */
typedef struct coakka_sftp_publish_target_t {
  size_t struct_size;
  const char *transfer_id;
  const char *authorization_token;
  const char *remote_host;
  uint16_t remote_port;
  uint16_t reserved;
  uint32_t timeout_ms;
} coakka_sftp_publish_target_t;

/**
 * Bounded publisher configuration. staging_root is copied and opened during
 * create. sender_lane must already be started and outlive the publisher.
 * Zero capacities/timeouts select conservative defaults. default_timeout_ms
 * bounds SFTP connect through verified local publication, not File Lane sends.
 */
typedef struct coakka_sftp_publisher_config_t {
  size_t struct_size;
  const char *staging_root;
  coakka_v2_file_lane_t *sender_lane;
  size_t queue_capacity;
  size_t retained_capacity;
  uint32_t default_timeout_ms;
  uint32_t reserved;
} coakka_sftp_publisher_config_t;

/**
 * Immutable SFTP acquisition plus distribution request. The addon copies all
 * strings, targets, digest bytes, and the passphrase before returning. The
 * connect address must be numeric; logical_host is copied as endpoint identity
 * and is never resolved by the workflow worker.
 * The host-key SHA-256 pin, expected size, digest, and at least one target are
 * mandatory. destination_name is one safe filename below staging_root.
 * timeout_ms=0 selects the publisher default and applies only to acquisition;
 * every target carries its independent File Lane timeout.
 */
typedef struct coakka_sftp_publish_spec_t {
  size_t struct_size;
  const char *job_id;
  const char *logical_host;
  const char *connect_address;
  uint16_t port;
  uint16_t reserved;
  const char *username;
  const char *private_key_file;
  const char *private_key_passphrase;
  uint8_t host_key_sha256[COAKKA_SFTP_SHA256_BYTES];
  const char *remote_path;
  const char *destination_name;
  uint64_t expected_size;
  uint8_t expected_sha256[COAKKA_SFTP_SHA256_BYTES];
  uint32_t timeout_ms;
  uint32_t target_count;
  const coakka_sftp_publish_target_t *targets;
} coakka_sftp_publish_spec_t;

typedef struct coakka_sftp_publisher_snapshot_t {
  size_t struct_size;
  uint32_t state;
  uint32_t result;
  uint64_t expected_size;
  uint64_t fetched_bytes;
  uint32_t target_count;
  uint32_t completed_targets;
  uint32_t failed_targets;
  uint32_t cancel_requested;
  uint64_t update_sequence;
  uint64_t submitted_mono_ns;
  uint64_t started_mono_ns;
  uint64_t updated_mono_ns;
  uint64_t terminal_mono_ns;
  char local_path[COAKKA_SFTP_LOCAL_PATH_MAX_BYTES];
  char detail[COAKKA_SFTP_DETAIL_MAX_BYTES];
} coakka_sftp_publisher_snapshot_t;

typedef struct coakka_sftp_target_snapshot_t {
  size_t struct_size;
  uint32_t admitted;
  int32_t submit_status;
  uint32_t lane_state;
  uint32_t lane_result;
  uint64_t transferred_bytes;
  char transfer_id[COAKKA_V2_FILE_LANE_TRANSFER_ID_MAX_BYTES + 1u];
} coakka_sftp_target_snapshot_t;

/**
 * Creates one stopped publisher and copies the configuration. Staging is
 * anchored to an opened directory on POSIX and to a directory handle on
 * Windows; symlink/reparse-point traversal is rejected. Caller owns
 * *out_publisher on success.
 */
COAKKA_SFTP_PUBLISHER_API coakka_sftp_status_t
coakka_sftp_publisher_create(const coakka_sftp_publisher_config_t *config,
                             coakka_sftp_publisher_t **out_publisher);
/**
 * Stops and releases a publisher. NULL is allowed. The caller must prevent
 * concurrent calls and keep the borrowed sender lane alive through return.
 */
COAKKA_SFTP_PUBLISHER_API void
coakka_sftp_publisher_destroy(coakka_sftp_publisher_t *publisher);
/** Starts the single workflow worker. A stopped instance cannot be restarted. */
COAKKA_SFTP_PUBLISHER_API coakka_sftp_status_t
coakka_sftp_publisher_start(coakka_sftp_publisher_t *publisher);
/**
 * Rejects new work, cooperatively cancels retained work, wakes network waits,
 * and joins the worker. Concurrent start/stop calls are serialized internally.
 */
COAKKA_SFTP_PUBLISHER_API coakka_sftp_status_t
coakka_sftp_publisher_stop(coakka_sftp_publisher_t *publisher);
/** Copies and admits one job, or returns CAPACITY without partial admission. */
COAKKA_SFTP_PUBLISHER_API coakka_sftp_status_t
coakka_sftp_publisher_submit(coakka_sftp_publisher_t *publisher,
                             const coakka_sftp_publish_spec_t *spec);
/** Copies the latest retained aggregate snapshot into caller-owned storage. */
COAKKA_SFTP_PUBLISHER_API coakka_sftp_status_t
coakka_sftp_publisher_get(coakka_sftp_publisher_t *publisher,
                          const char *job_id,
                          coakka_sftp_publisher_snapshot_t *out_snapshot);
/**
 * Waits on monotonic time for update_sequence to advance. timeout_ms=0 is a
 * nonblocking query and returns WOULD_BLOCK when no newer update exists.
 */
COAKKA_SFTP_PUBLISHER_API coakka_sftp_status_t
coakka_sftp_publisher_wait(coakka_sftp_publisher_t *publisher,
                           const char *job_id, uint64_t after_update_sequence,
                           uint32_t timeout_ms,
                           coakka_sftp_publisher_snapshot_t *out_snapshot);
/** Copies one retained File Lane target projection. */
COAKKA_SFTP_PUBLISHER_API coakka_sftp_status_t
coakka_sftp_publisher_get_target(coakka_sftp_publisher_t *publisher,
                                 const char *job_id, uint32_t target_index,
                                 coakka_sftp_target_snapshot_t *out_snapshot);
/**
 * Requests cooperative cancellation and wakes a blocked network poll. Regular
 * file writes, fsync, and private-key file reads are kernel/library calls and
 * may finish before cancellation is observed.
 */
COAKKA_SFTP_PUBLISHER_API coakka_sftp_status_t
coakka_sftp_publisher_cancel(coakka_sftp_publisher_t *publisher,
                             const char *job_id);
/**
 * Releases one terminal publisher record and its admitted sender records.
 * Callers must not independently forget publisher-owned sender records.
 */
COAKKA_SFTP_PUBLISHER_API coakka_sftp_status_t
coakka_sftp_publisher_forget(coakka_sftp_publisher_t *publisher,
                             const char *job_id);
/** Returns the statically linked libssh2 compile-time version string. */
COAKKA_SFTP_PUBLISHER_API const char *
coakka_sftp_publisher_dependency_version(void);

#ifdef __cplusplus
}
#endif

#endif
