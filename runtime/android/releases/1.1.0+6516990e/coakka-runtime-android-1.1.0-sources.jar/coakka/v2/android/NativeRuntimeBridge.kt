package coakka.v2.android

internal object NativeRuntimeBridge {
    init {
        System.loadLibrary("coakka_runtime_v2")
        System.loadLibrary("coakka_android_jni")
    }

    external fun nativeAbiVersion(): Int

    external fun nativeCreate(
        systemName: String,
        nodeId: String,
        queueCapacity: Int,
        strictNoDrop: Boolean,
    ): Long

    external fun nativeApplyNetwork(
        handle: Long,
        mode: Int,
        bindHost: String?,
        bindPort: Int,
        advertiseHost: String?,
        advertisePort: Int,
    ): Int

    external fun nativeApplyInitialControl(handle: Long, envelope: ByteArray): Int

    external fun nativeOpenHostHandles(handle: Long, flags: Int): IntArray?

    external fun nativeStart(handle: Long): Int

    external fun nativeStop(handle: Long): Int

    external fun nativeConsumeMonitor(fd: Int): Long

    external fun nativeReadHealth(handle: Long): LongArray?

    external fun nativeDestroy(handle: Long)
}

internal object NativeStatus {
    const val OK = 0
}

class CoAkkaNativeException(operation: String, val status: Int) :
    IllegalStateException("$operation failed with native status=$status")

internal fun requireNativeOk(status: Int, operation: String) {
    if (status != NativeStatus.OK) {
        throw CoAkkaNativeException(operation, status)
    }
}
