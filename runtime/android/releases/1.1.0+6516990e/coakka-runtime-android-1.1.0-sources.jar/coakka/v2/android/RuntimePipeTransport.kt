package coakka.v2.android

import android.os.ParcelFileDescriptor
import java.io.Closeable
import java.io.EOFException
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.util.concurrent.atomic.AtomicBoolean

internal class WriteFrameLane(pfd: ParcelFileDescriptor) : Closeable {
    private val stream = ParcelFileDescriptor.AutoCloseOutputStream(pfd)
    private val channel: FileChannel = stream.channel
    private val header = ByteBuffer.allocateDirect(HEADER_BYTES).order(ByteOrder.LITTLE_ENDIAN)
    private val closed = AtomicBoolean(false)

    fun write(payload: ByteArray): Boolean {
        if (closed.get() || payload.size > MAX_FRAME_BYTES) {
            return false
        }
        return runCatching {
            synchronized(channel) {
                header.clear()
                header.putLong(payload.size.toLong())
                header.flip()
                writeFully(channel, header)
                writeFully(channel, ByteBuffer.wrap(payload))
            }
        }.isSuccess
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) {
            runCatching(stream::close)
        }
    }
}

internal class ReadFrameLane(pfd: ParcelFileDescriptor) : Closeable {
    private val stream = ParcelFileDescriptor.AutoCloseInputStream(pfd)
    private val channel: FileChannel = stream.channel
    private val header = ByteBuffer.allocateDirect(HEADER_BYTES).order(ByteOrder.LITTLE_ENDIAN)
    private val closed = AtomicBoolean(false)

    fun read(): ByteArray? {
        if (closed.get()) {
            return null
        }
        return synchronized(channel) {
            header.clear()
            if (!readFully(channel, header, allowCleanEof = true)) {
                return@synchronized null
            }
            header.flip()
            val length = header.long
            require(length in 0..MAX_FRAME_BYTES.toLong()) {
                "invalid runtime frame length=$length"
            }
            val payload = ByteArray(length.toInt())
            if (payload.isNotEmpty()) {
                readFully(channel, ByteBuffer.wrap(payload), allowCleanEof = false)
            }
            payload
        }
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) {
            runCatching(stream::close)
        }
    }
}

internal class MonitorLane(private val pfd: ParcelFileDescriptor) : Closeable {
    private val closed = AtomicBoolean(false)

    fun consume(): Long {
        if (closed.get()) {
            return 0L
        }
        val result = NativeRuntimeBridge.nativeConsumeMonitor(pfd.fd)
        if (result < 0L) {
            throw CoAkkaNativeException("monitor_consume", result.toInt())
        }
        return result
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) {
            runCatching(pfd::close)
        }
    }
}

private fun writeFully(channel: FileChannel, buffer: ByteBuffer) {
    while (buffer.hasRemaining()) {
        val count = channel.write(buffer)
        if (count < 0) {
            throw EOFException("runtime pipe closed while writing frame")
        }
        if (count == 0) {
            throw EOFException("runtime pipe write made no progress")
        }
    }
}

private fun readFully(
    channel: FileChannel,
    buffer: ByteBuffer,
    allowCleanEof: Boolean,
): Boolean {
    var readAny = false
    while (buffer.hasRemaining()) {
        val count = channel.read(buffer)
        if (count < 0) {
            if (allowCleanEof && !readAny) {
                return false
            }
            throw EOFException("runtime pipe closed inside frame")
        }
        if (count == 0) {
            throw EOFException("runtime pipe read made no progress")
        }
        readAny = readAny || count > 0
    }
    return true
}

private const val HEADER_BYTES = 8
private const val MAX_FRAME_BYTES = 16 * 1024 * 1024
