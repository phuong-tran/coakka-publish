package coakka_v2_connector

const (
	CoakkaV2GoVersion            = "0.1.0"
	CoakkaV2NativeCoreVersion    = "0.1.0"
	CoakkaV2NativeGitCommit      = "94a5729"
	CoakkaV2NativePackageVersion = "0.2.0+94a5729"
)
