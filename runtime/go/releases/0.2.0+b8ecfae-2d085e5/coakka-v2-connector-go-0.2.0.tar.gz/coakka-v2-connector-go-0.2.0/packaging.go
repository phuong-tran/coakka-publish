package coakka_v2_connector

const (
	CoakkaV2GoVersion            = "0.2.0"
	CoakkaV2NativeCoreVersion    = "0.2.0"
	CoakkaV2NativeGitCommit      = "b8ecfae"
	CoakkaV2NativePackageVersion = "0.2.0+b8ecfae"
)
