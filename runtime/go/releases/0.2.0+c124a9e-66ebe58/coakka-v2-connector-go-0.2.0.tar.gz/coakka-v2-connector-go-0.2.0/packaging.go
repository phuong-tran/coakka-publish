package coakka_v2_connector

const (
	CoakkaV2GoVersion            = "0.2.0"
	CoakkaV2NativeCoreVersion    = "0.2.0"
	CoakkaV2NativeGitCommit      = "c124a9e"
	CoakkaV2NativePackageVersion = "0.2.0+c124a9e"
)
