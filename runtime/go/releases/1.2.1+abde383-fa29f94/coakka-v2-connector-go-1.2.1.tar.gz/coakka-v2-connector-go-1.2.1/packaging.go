package coakka_v2_connector

const (
	CoakkaV2GoVersion            = "1.2.1"
	CoakkaV2NativeCoreVersion    = "1.2.1"
	CoakkaV2NativeGitCommit      = "abde383"
	CoakkaV2NativePackageVersion = "1.2.1+abde383"
)
