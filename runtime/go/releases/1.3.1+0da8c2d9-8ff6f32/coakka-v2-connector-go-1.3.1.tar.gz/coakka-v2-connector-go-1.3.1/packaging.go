package coakka_v2_connector

const (
	CoakkaV2GoVersion            = "1.3.1"
	CoakkaV2NativeCoreVersion    = "1.3.1"
	CoakkaV2NativeGitCommit      = "0da8c2d9"
	CoakkaV2NativePackageVersion = "1.3.1+0da8c2d9"
)
