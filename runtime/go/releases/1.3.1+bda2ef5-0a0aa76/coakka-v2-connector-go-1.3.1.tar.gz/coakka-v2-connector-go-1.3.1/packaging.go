package coakka_v2_connector

const (
	CoakkaV2GoVersion            = "1.3.1"
	CoakkaV2NativeCoreVersion    = "1.3.1"
	CoakkaV2NativeGitCommit      = "bda2ef5"
	CoakkaV2NativePackageVersion = "1.3.1+bda2ef5"
)
