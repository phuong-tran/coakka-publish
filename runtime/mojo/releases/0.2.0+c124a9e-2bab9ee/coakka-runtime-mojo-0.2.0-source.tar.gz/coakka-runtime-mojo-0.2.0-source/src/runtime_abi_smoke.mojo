from std.ffi import OwnedDLHandle
from std.sys import argv


comptime EXPECTED_ABI_VERSION = 1


def read_runtime_abi(lib_path: String) raises -> UInt32:
    var lib = OwnedDLHandle(lib_path)
    var get_abi = lib.get_function[def() thin abi("C") -> UInt32](
        "coakka_v2_runtime_get_abi_version"
    )
    return get_abi()


def main() raises:
    # Keep the first Mojo lane intentionally tiny until the local toolchain is
    # present in CI. Runtime routing and protobuf policy stay in the native core
    # and existing connector lanes.
    var args = argv()
    if len(args) <= 1:
        print("usage: mojo runtime_abi_smoke.mojo /path/to/libcoakka_runtime_v2")
        return

    var lib_path = String(args[1])
    var abi = read_runtime_abi(lib_path)
    if abi != EXPECTED_ABI_VERSION:
        print("coakka_runtime_mojo_smoke unexpected_abi=", abi)
        return

    print("coakka_runtime_mojo_smoke abi=", abi)
