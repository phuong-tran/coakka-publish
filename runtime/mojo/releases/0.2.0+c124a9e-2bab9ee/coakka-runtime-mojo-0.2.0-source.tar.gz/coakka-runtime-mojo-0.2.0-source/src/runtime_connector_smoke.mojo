from std.ffi import OwnedDLHandle, c_int
from std.sys import argv


# Mojo's direct native-call surface is still evolving, so this file is a thin
# executable smoke over a C shim. The shim owns the runtime lifecycle and proves
# request/reply plus deadletter behavior without presenting a stable Mojo API.
def main() raises:
    var args = argv()
    if len(args) != 2:
        print("usage: mojo runtime_connector_smoke.mojo <connector-shim-library>")
        raise Error("missing connector shim library path")

    var lib = OwnedDLHandle(String(args[1]))
    var status = lib.call["coakka_mojo_runtime_connector_smoke", c_int](0)
    if status != 0:
        raise Error("coakka_mojo_runtime_connector_smoke failed")
