#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mojo_root="$(cd "${script_dir}/.." && pwd)"
connector_root="$(cd "${mojo_root}/.." && pwd)"

native_core_version="1.2.1"
native_git_commit="abde383"
native_package_version="${native_core_version}+${native_git_commit}"
connector_source_git_commit="$(git -C "${connector_root}" rev-parse --short=7 HEAD)"
artifact_version="1.2.1-source"
package_name="coakka-runtime-mojo"
package_root_name="${package_name}-${artifact_version}"
archive_name="${package_root_name}.tar.gz"
staging_root="${connector_root}/v2/staging/native/${native_package_version}"
tmp_dir="$(mktemp -d)"

trap 'rm -rf "${tmp_dir}"' EXIT

if [[ ! -d "${staging_root}" ]]; then
  echo "[mojo-pack-runtime] runtime native staging directory not found: ${staging_root}" >&2
  exit 1
fi

package_root="${tmp_dir}/${package_root_name}"
mkdir -p "${package_root}"

cp "${mojo_root}/README.md" "${package_root}/README.md"
cp "${mojo_root}/CONSUMING.md" "${package_root}/CONSUMING.md"
cp -R "${mojo_root}/src" "${package_root}/src"
cp -R "${mojo_root}/scripts" "${package_root}/scripts"

cat > "${package_root}/coakka-runtime-mojo-package.json" <<EOF
{
  "schema_version": 1,
  "product_lane": "runtime",
  "language_lane": "mojo",
  "package_name": "coakka-runtime-mojo",
  "artifact_version": "1.2.1-source",
  "bundled_native_core_version": "${native_core_version}",
  "bundled_native_package_version": "${native_package_version}",
  "bundled_native_git_commit": "${native_git_commit}",
  "connector_source_git_commit": "${connector_source_git_commit}",
  "release_directory": "${native_package_version}-${connector_source_git_commit}",
  "source_package": true
}
EOF

for platform in macos-aarch64 linux-aarch64 linux-x86_64 windows-aarch64 windows-x86_64; do
  source_lib="${staging_root}/${platform}/libcoakka_runtime_v2.so"
  target_suffix="so"
  if [[ "${platform}" == macos-* ]]; then
    source_lib="${staging_root}/${platform}/libcoakka_runtime_v2.dylib"
    target_suffix="dylib"
  elif [[ "${platform}" == windows-* ]]; then
    source_lib="${staging_root}/${platform}/libcoakka_runtime_v2.dll"
    target_suffix="dll"
  fi
  if [[ ! -f "${source_lib}" ]]; then
    echo "[mojo-pack-runtime] staged runtime native not found: ${source_lib}" >&2
    exit 1
  fi
  target_dir="${package_root}/native/${platform}"
  mkdir -p "${target_dir}"
  cp "${source_lib}" "${target_dir}/libcoakka_runtime_v2.${target_suffix}"
  cp "${source_lib}" "${target_dir}/libcoakka_runtime_v2-${native_package_version}.${target_suffix}"
done

rm -f "${mojo_root}/${package_name}-"*.tar.gz
COPYFILE_DISABLE=1 tar -C "${tmp_dir}" -czf "${mojo_root}/${archive_name}" "${package_root_name}"

echo "[mojo-pack-runtime] archive=${mojo_root}/${archive_name}"
