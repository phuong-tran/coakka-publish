#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mojo_root="$(cd "${script_dir}/.." && pwd)"
native_package_version="1.3.1+0da8c2d9"

if ! command -v mojo >/dev/null 2>&1; then
  echo "[mojo-runtime-smoke] skip: mojo toolchain not found"
  exit 0
fi
if ! command -v cc >/dev/null 2>&1; then
  echo "[mojo-runtime-smoke] skip: C compiler not found"
  exit 0
fi

runtime_lib="${COAKKA_RUNTIME_LIB:-}"
if [[ -z "${runtime_lib}" ]]; then
  case "$(uname -s)" in
    Darwin)
      if [[ -f "${mojo_root}/native/macos-aarch64/libcoakka_runtime_v2-${native_package_version}.dylib" ]]; then
        runtime_lib="${mojo_root}/native/macos-aarch64/libcoakka_runtime_v2-${native_package_version}.dylib"
      else
        runtime_lib="${mojo_root}/../v2/staging/native/${native_package_version}/macos-aarch64/libcoakka_runtime_v2.dylib"
      fi
      ;;
    Linux)
      case "$(uname -m)" in
        x86_64)
          if [[ -f "${mojo_root}/native/linux-x86_64/libcoakka_runtime_v2-${native_package_version}.so" ]]; then
            runtime_lib="${mojo_root}/native/linux-x86_64/libcoakka_runtime_v2-${native_package_version}.so"
          else
            runtime_lib="${mojo_root}/../v2/staging/native/${native_package_version}/linux-x86_64/libcoakka_runtime_v2.so"
          fi
          ;;
        aarch64|arm64)
          if [[ -f "${mojo_root}/native/linux-aarch64/libcoakka_runtime_v2-${native_package_version}.so" ]]; then
            runtime_lib="${mojo_root}/native/linux-aarch64/libcoakka_runtime_v2-${native_package_version}.so"
          else
            runtime_lib="${mojo_root}/../v2/staging/native/${native_package_version}/linux-aarch64/libcoakka_runtime_v2.so"
          fi
          ;;
        *) echo "[mojo-runtime-smoke] unsupported arch: $(uname -m)" >&2; exit 64 ;;
      esac
      ;;
    *) echo "[mojo-runtime-smoke] unsupported os: $(uname -s)" >&2; exit 64 ;;
  esac
fi

tmp_dir="$(mktemp -d)"
trap 'rm -rf "${tmp_dir}"' EXIT

case "$(uname -s)" in
  Darwin)
    shim="${tmp_dir}/libcoakka_mojo_runtime_connector.dylib"
    cc -dynamiclib \
      "${mojo_root}/src/runtime_connector_shim.c" \
      "${runtime_lib}" \
      -o "${shim}"
    DYLD_LIBRARY_PATH="$(dirname "${runtime_lib}"):${tmp_dir}" \
      mojo "${mojo_root}/src/runtime_connector_smoke.mojo" "${shim}"
    ;;
  Linux)
    shim="${tmp_dir}/libcoakka_mojo_runtime_connector.so"
    cc -shared -fPIC \
      "${mojo_root}/src/runtime_connector_shim.c" \
      "${runtime_lib}" \
      -o "${shim}"
    LD_LIBRARY_PATH="$(dirname "${runtime_lib}"):${tmp_dir}" \
      mojo "${mojo_root}/src/runtime_connector_smoke.mojo" "${shim}"
    ;;
  *)
    echo "[mojo-runtime-smoke] unsupported os: $(uname -s)" >&2
    exit 64
    ;;
esac
