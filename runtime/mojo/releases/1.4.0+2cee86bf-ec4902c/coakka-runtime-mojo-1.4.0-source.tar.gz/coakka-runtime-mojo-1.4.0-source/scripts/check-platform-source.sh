#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mojo_root="$(cd "${script_dir}/.." && pwd)"
work_root="$(mktemp -d "${TMPDIR:-/tmp}/coakka-mojo-cross.XXXXXX")"
trap 'rm -rf "${work_root}"' EXIT

command -v cc >/dev/null 2>&1 || { echo "[mojo-platform-source] C compiler required" >&2; exit 1; }
command -v zig >/dev/null 2>&1 || { echo "[mojo-platform-source] zig required for cross checks" >&2; exit 1; }

cc -std=c11 -Wall -Wextra -Werror -fsyntax-only "${mojo_root}/src/runtime_connector_shim.c"
zig cc -target aarch64-linux-gnu -std=c11 -Wall -Wextra -Werror \
  -c "${mojo_root}/src/runtime_connector_shim.c" -o "${work_root}/linux.o"
zig cc -target x86_64-windows-gnu -std=c11 -Wall -Wextra -Werror \
  -c "${mojo_root}/src/runtime_connector_shim.c" -o "${work_root}/windows.o"
file "${work_root}/linux.o" | grep -q 'ELF 64-bit.*ARM aarch64'
file "${work_root}/windows.o" | grep -q 'Intel amd64 COFF object file'
echo "[mojo-platform-source] macOS strict syntax and Linux ARM64/Windows x86-64 objects ok"
