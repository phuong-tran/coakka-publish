#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mojo_root="$(cd "${script_dir}/.." && pwd)"
work_root="$(mktemp -d "${TMPDIR:-/tmp}/coakka-mojo-cross.XXXXXX")"
trap 'rm -rf "${work_root}"' EXIT

command -v cc >/dev/null 2>&1 || { echo "[mojo-platform-source] C compiler required" >&2; exit 1; }
command -v zig >/dev/null 2>&1 || { echo "[mojo-platform-source] zig required for cross checks" >&2; exit 1; }

for source in runtime_connector_shim.c file_lane_shim.c; do
  stem="${source%.c}"
  cc -std=c11 -Wall -Wextra -Werror -fsyntax-only "${mojo_root}/src/${source}"
  zig cc -target aarch64-linux-gnu -std=c11 -Wall -Wextra -Werror \
    -c "${mojo_root}/src/${source}" -o "${work_root}/${stem}-linux.o"
  zig cc -target x86_64-windows-gnu -std=c11 -Wall -Wextra -Werror \
    -c "${mojo_root}/src/${source}" -o "${work_root}/${stem}-windows.o"
  file "${work_root}/${stem}-linux.o" | grep -q 'ELF 64-bit.*ARM aarch64'
  file "${work_root}/${stem}-windows.o" | grep -q 'Intel amd64 COFF object file'
done
echo "[mojo-platform-source] macOS strict syntax and Linux ARM64/Windows x86-64 objects ok"
