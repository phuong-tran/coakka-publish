#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
root="$(cd "${script_dir}/.." && pwd)"
runtime="${COAKKA_FILE_LANE_RUNTIME_LIB:?COAKKA_FILE_LANE_RUNTIME_LIB is required}"
tmp="$(mktemp -d "${TMPDIR:-/tmp}/coakka-mojo-file-lane.XXXXXX")"
trap 'rm -rf "${tmp}"' EXIT
case "$(uname -s)" in
  Darwin) shim="${tmp}/libcoakka_mojo_file_lane.dylib"; cc -std=c11 -Wall -Wextra -Werror -dynamiclib "${root}/src/file_lane_shim.c" "${runtime}" -o "${shim}"; DYLD_LIBRARY_PATH="$(dirname "${runtime}"):${tmp}" mojo "${root}/src/file_lane_smoke.mojo" "${shim}" ;;
  Linux) shim="${tmp}/libcoakka_mojo_file_lane.so"; cc -std=c11 -Wall -Wextra -Werror -shared -fPIC "${root}/src/file_lane_shim.c" "${runtime}" -o "${shim}"; LD_LIBRARY_PATH="$(dirname "${runtime}"):${tmp}" mojo "${root}/src/file_lane_smoke.mojo" "${shim}" ;;
  *) exit 64 ;;
esac
