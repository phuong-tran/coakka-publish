#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mojo_root="$(cd "${script_dir}/.." && pwd)"
command -v mojo >/dev/null 2>&1 || {
  echo "[mojo-runtime-smoke] mojo toolchain is required" >&2
  exit 1
}
command -v cc >/dev/null 2>&1 || {
  echo "[mojo-runtime-smoke] C compiler is required" >&2
  exit 1
}

runtime_lib="${COAKKA_RUNTIME_LIB:-}"
if [[ -z "${runtime_lib}" ]]; then
  case "$(uname -s)" in
    Darwin)
      platform="macos-aarch64"
      filename="libcoakka_runtime_v2.dylib"
      ;;
    Linux)
      case "$(uname -m)" in
        aarch64|arm64) platform="linux-aarch64" ;;
        *) echo "[mojo-runtime-smoke] no bundled Linux native for $(uname -m)" >&2; exit 64 ;;
      esac
      filename="libcoakka_runtime_v2.so"
      ;;
    *) echo "[mojo-runtime-smoke] Mojo execution is not verified on $(uname -s)" >&2; exit 64 ;;
  esac

  packaged="${mojo_root}/native/${platform}/${filename}"
  if [[ -f "${packaged}" ]]; then
    runtime_lib="${packaged}"
  else
    echo "[mojo-runtime-smoke] bundled runtime not found; set COAKKA_RUNTIME_LIB" >&2
    exit 1
  fi
fi

[[ -f "${runtime_lib}" ]] || {
  echo "[mojo-runtime-smoke] runtime library not found: ${runtime_lib}" >&2
  exit 1
}

tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/coakka-mojo-smoke.XXXXXX")"
trap 'rm -rf "${tmp_dir}"' EXIT

case "$(uname -s)" in
  Darwin)
    shim="${tmp_dir}/libcoakka_mojo_runtime_connector.dylib"
    cc -std=c11 -Wall -Wextra -Werror -dynamiclib \
      "${mojo_root}/src/runtime_connector_shim.c" "${runtime_lib}" -o "${shim}"
    DYLD_LIBRARY_PATH="$(dirname "${runtime_lib}"):${tmp_dir}" \
      mojo "${mojo_root}/src/runtime_connector_smoke.mojo" "${shim}"
    ;;
  Linux)
    shim="${tmp_dir}/libcoakka_mojo_runtime_connector.so"
    cc -std=c11 -Wall -Wextra -Werror -shared -fPIC \
      "${mojo_root}/src/runtime_connector_shim.c" "${runtime_lib}" -o "${shim}"
    LD_LIBRARY_PATH="$(dirname "${runtime_lib}"):${tmp_dir}" \
      mojo "${mojo_root}/src/runtime_connector_smoke.mojo" "${shim}"
    ;;
  *)
    echo "[mojo-runtime-smoke] Mojo execution is not verified on $(uname -s)" >&2
    exit 64
    ;;
esac
