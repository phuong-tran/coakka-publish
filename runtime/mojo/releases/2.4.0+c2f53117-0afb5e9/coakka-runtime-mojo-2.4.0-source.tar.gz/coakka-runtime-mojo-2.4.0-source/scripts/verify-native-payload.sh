#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mojo_root="$(cd "${script_dir}/.." && pwd)"
native_root="${mojo_root}/native"

sha256_file() {
  if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print $1}';
  else sha256sum "$1" | awk '{print $1}'; fi
}

verify() {
  local relative="$1" expected="$2" format="$3"
  local path="${native_root}/${relative}"
  [[ -f "${path}" ]] || { echo "[mojo-verify-native] missing ${relative}" >&2; exit 1; }
  [[ "$(sha256_file "${path}")" == "${expected}" ]] || {
    echo "[mojo-verify-native] digest mismatch ${relative}" >&2; exit 1;
  }
  file "${path}" | grep -Eq "${format}" || {
    echo "[mojo-verify-native] format mismatch ${relative}" >&2; exit 1;
  }
}

verify "macos-aarch64/libcoakka_runtime_v2.dylib" \
  "5ca37b5f6d5182d4bd25284785c6b386114857074c91ab9dbefecf0dedda637c" \
  "Mach-O 64-bit dynamically linked shared library arm64"
verify "linux-aarch64/libcoakka_runtime_v2.so" \
  "9ccd618dbb18fb32a0d7201f13a3163de175c7037c3e5325e84824bb32e1843c" \
  "ELF 64-bit LSB shared object, ARM aarch64"
verify "linux-x86_64/libcoakka_runtime_v2.so" \
  "465e831fa564cde87fe3af29390071e4241390e1edcd0153c55ce00017f2c248" \
  "ELF 64-bit LSB shared object, x86-64"
verify "windows-aarch64/libcoakka_runtime_v2.dll" \
  "ae26021aac51ae19d06e317b9ce5a43befa9ef1bc8997e6bbd238e09036df3f9" \
  "PE32\\+ executable \\(DLL\\).*Aarch64"
verify "windows-x86_64/libcoakka_runtime_v2.dll" \
  "795615adb861b74d9c017d480a377a08cd355e1fb83648f06b43ee85c5f049d6" \
  "PE32\\+ executable \\(DLL\\).*x86-64"

count="$(find "${native_root}" -type f \( -name '*.dylib' -o -name '*.so' -o -name '*.dll' \) | wc -l | tr -d ' ')"
[[ "${count}" == "5" ]] || { echo "[mojo-verify-native] expected 5 natives, got ${count}" >&2; exit 1; }
echo "[mojo-verify-native] exact payload ok (macOS/Linux/Windows); publisher signing absent"
