#if !defined(_WIN32) && !defined(_POSIX_C_SOURCE)
#define _POSIX_C_SOURCE 200809L
#endif

#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX 1
#endif
#include <io.h>
#include <windows.h>
#else
#include <time.h>
#include <unistd.h>
#endif

#if defined(_WIN32)
#define COAKKA_MOJO_EXPORT __declspec(dllexport)
#else
#define COAKKA_MOJO_EXPORT __attribute__((visibility("default")))
#endif

typedef enum coakka_v2_status_t {
  COAKKA_V2_OK = 0,
  COAKKA_V2_ERR_INVALID_ARG = -1,
  COAKKA_V2_ERR_BAD_STATE = -3,
  COAKKA_V2_ERR_WOULD_BLOCK = -6
} coakka_v2_status_t;

enum {
  COAKKA_V2_CAPABILITY_TCP_BOUNDED_POOL = UINT64_C(1) << 0,
  COAKKA_V2_CAPABILITY_TCP_TLS = UINT64_C(1) << 2,
  COAKKA_V2_TCP_CONNECTION_PER_EXCHANGE = 0,
  COAKKA_V2_TCP_CONNECTION_BOUNDED_POOL = 1,
  COAKKA_V2_TCP_CONNECTION_FIELD_MODE = UINT64_C(1) << 0,
  COAKKA_V2_TCP_SECURITY_PLAINTEXT = 0,
  COAKKA_V2_TCP_SECURITY_TLS = 1,
  COAKKA_V2_TLS_CREDENTIAL_SOURCE_FILE = 1,
  COAKKA_V2_TLS_RELOAD_GRACEFUL = 0,
  COAKKA_V2_TCP_SECURITY_FIELD_MODE = UINT64_C(1) << 0,
  COAKKA_V2_TCP_SECURITY_FIELD_CREDENTIAL_SOURCE = UINT64_C(1) << 1,
  COAKKA_V2_TCP_SECURITY_FIELD_RELOAD_MODE = UINT64_C(1) << 2,
  COAKKA_V2_TCP_SECURITY_FIELD_CREDENTIAL_GENERATION = UINT64_C(1) << 3,
  COAKKA_V2_TCP_SECURITY_FIELD_CREDENTIAL_ID = UINT64_C(1) << 4,
  COAKKA_V2_TCP_SECURITY_FIELD_CA_CERTIFICATE_FILE = UINT64_C(1) << 5,
  COAKKA_V2_TCP_SECURITY_FIELD_IDENTITY_CERTIFICATE_FILE = UINT64_C(1) << 6,
  COAKKA_V2_TCP_SECURITY_FIELD_PRIVATE_KEY_FILE = UINT64_C(1) << 7,
  COAKKA_V2_TCP_SECURITY_ALL_FIELDS = (UINT64_C(1) << 8) - 1,
  COAKKA_V2_TCP_CONNECTION_UNKNOWN_MODE = 4,
  COAKKA_V2_TCP_SECURITY_FIELD_NOT_APPLICABLE = 7,
};

typedef struct coakka_v2_runtime_t coakka_v2_runtime_t;
typedef struct coakka_v2_ask_client_t coakka_v2_ask_client_t;
typedef struct coakka_v2_ask_ticket_t coakka_v2_ask_ticket_t;
typedef struct coakka_v2_frame_reader_t coakka_v2_frame_reader_t;

typedef struct coakka_v2_runtime_config_t {
  const char* system_name;
  const char* node_id;
  int strict_no_drop;
  int queue_capacity;
} coakka_v2_runtime_config_t;

typedef struct coakka_v2_endpoint_t {
  const char* host;
  uint16_t port;
  uint32_t weight;
  uint32_t flags;
} coakka_v2_endpoint_t;

typedef struct coakka_v2_route_t {
  const char* target;
  int strategy;
  const char* route_key_hint;
  uint32_t flags;
  const coakka_v2_endpoint_t* endpoints;
  size_t endpoint_count;
} coakka_v2_route_t;

typedef struct coakka_v2_control_snapshot_t {
  uint64_t generation;
  const coakka_v2_route_t* routes;
  size_t route_count;
} coakka_v2_control_snapshot_t;

typedef struct coakka_v2_runtime_info_t {
  size_t struct_size;
  uint32_t abi_version;
  uint32_t feature_flags;
  const char* runtime_version;
  const char* git_commit;
} coakka_v2_runtime_info_t;

typedef struct coakka_v2_host_handles_t {
  size_t struct_size;
  uint32_t flags;
  int request_write_fd;
  int response_read_fd;
  int deadletter_read_fd;
  int control_write_fd;
  int monitor_read_fd;
  int delivered_request_read_fd;
} coakka_v2_host_handles_t;

typedef struct coakka_v2_runtime_stats_t {
  size_t struct_size;
  uint64_t applied_generation;
  size_t route_count;
  int runtime_state;
} coakka_v2_runtime_stats_t;

typedef struct coakka_v2_runtime_capabilities_t {
  size_t struct_size;
  uint32_t edition;
  uint32_t license_status;
  uint64_t compiled_capabilities;
  uint64_t entitled_capabilities;
  uint64_t effective_capabilities;
  uint32_t tcp_connection_defaults_revision;
  uint32_t reserved;
} coakka_v2_runtime_capabilities_t;

typedef struct coakka_v2_tcp_connection_options_t {
  size_t struct_size;
  uint64_t fields;
  uint32_t mode;
  uint32_t reserved;
  uint32_t max_connections;
  uint32_t reserved2;
  uint64_t max_requests_per_connection;
  uint64_t idle_timeout_ms;
} coakka_v2_tcp_connection_options_t;

typedef struct coakka_v2_tcp_connection_validation_t {
  size_t struct_size;
  uint32_t code;
  uint32_t reserved;
  uint64_t field;
  uint64_t minimum_value;
  uint64_t maximum_value;
} coakka_v2_tcp_connection_validation_t;

typedef struct coakka_v2_tcp_connection_config_t {
  size_t struct_size;
  uint32_t defaults_revision;
  uint32_t mode;
  uint64_t applicable_fields;
  uint64_t explicitly_configured_fields;
  uint64_t defaulted_fields;
  uint64_t configurable_fields;
  uint32_t max_connections;
  uint32_t reserved;
  uint64_t max_requests_per_connection;
  uint64_t idle_timeout_ms;
} coakka_v2_tcp_connection_config_t;

typedef struct coakka_v2_tcp_connection_apply_result_t {
  size_t struct_size;
  int32_t apply_status;
  uint32_t changed;
  uint32_t reason;
  uint32_t runtime_state;
  coakka_v2_tcp_connection_validation_t validation;
  coakka_v2_tcp_connection_config_t effective_config;
} coakka_v2_tcp_connection_apply_result_t;

typedef struct coakka_v2_tcp_security_options_t {
  size_t struct_size;
  uint64_t fields;
  uint32_t mode;
  uint32_t credential_source_kind;
  uint32_t reload_mode;
  uint32_t reserved;
  uint64_t credential_generation;
  const char* credential_id;
  const char* ca_certificate_file;
  const char* identity_certificate_file;
  const char* private_key_file;
} coakka_v2_tcp_security_options_t;

typedef struct coakka_v2_tcp_security_validation_t {
  size_t struct_size;
  uint32_t code;
  uint32_t reserved;
  uint64_t field;
} coakka_v2_tcp_security_validation_t;

typedef struct coakka_v2_tcp_security_config_t {
  size_t struct_size;
  uint32_t mode;
  uint32_t credential_source_kind;
  uint32_t reload_mode;
  uint32_t reload_status;
  uint64_t credential_generation;
  const char* credential_id;
} coakka_v2_tcp_security_config_t;

typedef struct coakka_v2_tcp_security_identity_t {
  size_t struct_size;
  uint32_t minimum_protocol_version;
  uint32_t maximum_protocol_version;
  uint64_t inbound_verification_flags;
  uint64_t outbound_verification_flags;
  int64_t identity_not_before_unix_seconds;
  int64_t identity_not_after_unix_seconds;
  char credential_id_value[128];
  char identity_fingerprint_sha256[65];
} coakka_v2_tcp_security_identity_t;

typedef struct coakka_v2_tcp_security_info_t {
  size_t struct_size;
  coakka_v2_tcp_security_config_t config;
  coakka_v2_tcp_security_identity_t identity;
} coakka_v2_tcp_security_info_t;

typedef struct coakka_v2_tcp_security_apply_result_t {
  size_t struct_size;
  int32_t apply_status;
  uint32_t changed;
  uint32_t reason;
  uint32_t runtime_state;
  coakka_v2_tcp_security_validation_t validation;
  coakka_v2_tcp_security_info_t active_security;
} coakka_v2_tcp_security_apply_result_t;

_Static_assert(sizeof(coakka_v2_runtime_capabilities_t) == 48, "capabilities ABI drift");
_Static_assert(sizeof(coakka_v2_tcp_connection_options_t) == 48, "connection options ABI drift");
_Static_assert(sizeof(coakka_v2_tcp_connection_validation_t) == 40, "connection validation ABI drift");
_Static_assert(sizeof(coakka_v2_tcp_connection_config_t) == 72, "connection config ABI drift");
_Static_assert(sizeof(coakka_v2_tcp_connection_apply_result_t) == 136, "connection result ABI drift");
_Static_assert(sizeof(coakka_v2_tcp_security_options_t) == 72, "security options ABI drift");
_Static_assert(sizeof(coakka_v2_tcp_security_validation_t) == 24, "security validation ABI drift");
_Static_assert(sizeof(coakka_v2_tcp_security_config_t) == 40, "security config ABI drift");
_Static_assert(sizeof(coakka_v2_tcp_security_identity_t) == 248, "security identity ABI drift");
_Static_assert(sizeof(coakka_v2_tcp_security_info_t) == 296, "security info ABI drift");
_Static_assert(sizeof(coakka_v2_tcp_security_apply_result_t) == 344, "security result ABI drift");

typedef struct coakka_v2_client_raw_request_spec_t {
  size_t struct_size;
  const char* message_id;
  const char* source;
  const char* target;
  const char* reply_to;
  const uint8_t* payload;
  size_t payload_len;
  uint32_t timeout_ms;
  uint32_t delivery_hint;
  uint32_t one_way;
} coakka_v2_client_raw_request_spec_t;

typedef struct coakka_v2_client_raw_reply_spec_t {
  size_t struct_size;
  const uint8_t* request_buf;
  size_t request_len;
  const char* source;
  const uint8_t* payload;
  size_t payload_len;
} coakka_v2_client_raw_reply_spec_t;

typedef struct coakka_v2_network_options_t {
  size_t struct_size;
  uint64_t fields;
  uint32_t mode;
  uint32_t reserved;
  const char* bind_host;
  const char* advertise_host;
  uint16_t bind_port;
  uint16_t advertise_port;
  uint32_t reserved2;
} coakka_v2_network_options_t;

_Static_assert(sizeof(coakka_v2_network_options_t) == 48, "network options ABI drift");

extern coakka_v2_status_t coakka_v2_runtime_get_info(coakka_v2_runtime_info_t* out_info);
extern coakka_v2_runtime_t* coakka_v2_runtime_create(const coakka_v2_runtime_config_t* cfg);
extern void coakka_v2_runtime_destroy(coakka_v2_runtime_t* rt);
extern coakka_v2_status_t coakka_v2_runtime_apply_network_options(
    coakka_v2_runtime_t* rt,
    const coakka_v2_network_options_t* options);
extern coakka_v2_status_t coakka_v2_runtime_get_host_handles(coakka_v2_runtime_t* rt,
                                                             coakka_v2_host_handles_t* out_handles);
extern coakka_v2_status_t coakka_v2_runtime_apply_control_snapshot(
    coakka_v2_runtime_t* rt,
    const coakka_v2_control_snapshot_t* snapshot);
extern coakka_v2_status_t coakka_v2_runtime_start(coakka_v2_runtime_t* rt);
extern coakka_v2_status_t coakka_v2_runtime_stop(coakka_v2_runtime_t* rt);
extern coakka_v2_status_t coakka_v2_runtime_get_stats(coakka_v2_runtime_t* rt,
                                                      coakka_v2_runtime_stats_t* out_stats);
extern coakka_v2_status_t coakka_v2_runtime_get_capabilities(
    coakka_v2_runtime_capabilities_t* out_capabilities);
extern coakka_v2_status_t coakka_v2_runtime_apply_tcp_connection_options_ex(
    coakka_v2_runtime_t* rt,
    const coakka_v2_tcp_connection_options_t* options,
    coakka_v2_tcp_connection_apply_result_t* out_result);
extern coakka_v2_status_t coakka_v2_runtime_get_tcp_connection_config(
    coakka_v2_runtime_t* rt,
    coakka_v2_tcp_connection_config_t* out_config);
extern coakka_v2_status_t coakka_v2_runtime_apply_tcp_security_options_ex(
    coakka_v2_runtime_t* rt,
    const coakka_v2_tcp_security_options_t* options,
    coakka_v2_tcp_security_apply_result_t* out_result);
extern coakka_v2_status_t coakka_v2_runtime_get_tcp_security_info(
    coakka_v2_runtime_t* rt,
    coakka_v2_tcp_security_info_t* out_info);
extern coakka_v2_status_t coakka_v2_runtime_submit_envelope(coakka_v2_runtime_t* rt,
                                                            const uint8_t* buf,
                                                            size_t len);
extern coakka_v2_ask_client_t* coakka_v2_ask_client_create(
    coakka_v2_runtime_t* rt,
    const coakka_v2_host_handles_t* handles);
extern void coakka_v2_ask_client_destroy(coakka_v2_ask_client_t* client);
extern coakka_v2_status_t coakka_v2_ask_client_begin(coakka_v2_ask_client_t* client,
                                                     const uint8_t* request_buf,
                                                     size_t request_len,
                                                     coakka_v2_ask_ticket_t** out_ticket);
extern coakka_v2_status_t coakka_v2_ask_ticket_await(coakka_v2_ask_ticket_t* ticket,
                                                     uint32_t timeout_ms,
                                                     uint32_t* out_result_kind,
                                                     uint8_t** out_buf,
                                                     size_t* out_len);
extern void coakka_v2_ask_ticket_destroy(coakka_v2_ask_ticket_t* ticket);
extern coakka_v2_status_t coakka_v2_client_build_raw_request(
    const coakka_v2_client_raw_request_spec_t* spec,
    uint8_t** out_buf,
    size_t* out_len);
extern coakka_v2_status_t coakka_v2_client_build_raw_reply(
    const coakka_v2_client_raw_reply_spec_t* spec,
    uint8_t** out_buf,
    size_t* out_len);
extern void coakka_v2_client_bytes_release(uint8_t* buf);
extern coakka_v2_frame_reader_t* coakka_v2_frame_reader_create(int fd, size_t max_frame_size);
extern void coakka_v2_frame_reader_destroy(coakka_v2_frame_reader_t* reader);
extern coakka_v2_status_t coakka_v2_frame_read_try(coakka_v2_frame_reader_t* reader,
                                                   uint8_t** out_buf,
                                                   size_t* out_len);
extern void coakka_v2_frame_release(uint8_t* buf);

static int require_ok(coakka_v2_status_t status, const char* step) {
  if (status == COAKKA_V2_OK) {
    return 0;
  }
  fprintf(stderr, "%s failed: %d\n", step, (int)status);
  return 1;
}

static void close_if_open(int* fd) {
  if (fd != NULL && *fd >= 0) {
#if defined(_WIN32)
    (void)_close(*fd);
#else
    close(*fd);
#endif
    *fd = -1;
  }
}

static void close_host_handles(coakka_v2_host_handles_t* handles) {
  if (handles == NULL) {
    return;
  }
  int values[] = {
      handles->request_write_fd,
      handles->response_read_fd,
      handles->deadletter_read_fd,
      handles->control_write_fd,
      handles->monitor_read_fd,
      handles->delivered_request_read_fd,
  };
  for (size_t i = 0; i < sizeof(values) / sizeof(values[0]); ++i) {
    if (values[i] < 0) {
      continue;
    }
    int duplicate = 0;
    for (size_t j = 0; j < i; ++j) {
      if (values[j] == values[i]) {
        duplicate = 1;
        break;
      }
    }
    if (!duplicate) {
      int fd = values[i];
      close_if_open(&fd);
    }
  }
  handles->request_write_fd = -1;
  handles->response_read_fd = -1;
  handles->deadletter_read_fd = -1;
  handles->control_write_fd = -1;
  handles->monitor_read_fd = -1;
  handles->delivered_request_read_fd = -1;
}

static void sleep_one_millisecond(void) {
#if defined(_WIN32)
  Sleep(1u);
#else
  struct timespec duration = {.tv_sec = 0, .tv_nsec = 1000000L};
  while (nanosleep(&duration, &duration) != 0 && errno == EINTR) {
  }
#endif
}

static int read_delivered_frame(coakka_v2_frame_reader_t* reader,
                                uint8_t** out_buf,
                                size_t* out_len) {
  for (int i = 0; i < 1000; ++i) {
    coakka_v2_status_t rc = coakka_v2_frame_read_try(reader, out_buf, out_len);
    if (rc == COAKKA_V2_OK) {
      return (*out_buf != NULL && *out_len > 0) ? 0 : 1;
    }
    if ((int)rc != -6) {
      fprintf(stderr, "frame_read_try failed: %d\n", (int)rc);
      return 1;
    }
    sleep_one_millisecond();
  }
  fprintf(stderr, "timed out waiting for delivered request\n");
  return 1;
}

static int run_raw_roundtrip(coakka_v2_runtime_t* runtime,
                             const coakka_v2_host_handles_t* handles) {
  static const uint8_t request_payload[] = {'h', 'e', 'l', 'l', 'o'};
  static const uint8_t reply_payload[] = {'r', 'e', 'p', 'l', 'y'};

  coakka_v2_ask_client_t* client = coakka_v2_ask_client_create(runtime, handles);
  if (client == NULL) {
    fprintf(stderr, "ask_client_create failed\n");
    return 1;
  }

  coakka_v2_client_raw_request_spec_t request_spec = {0};
  request_spec.struct_size = sizeof(request_spec);
  request_spec.message_id = "req-mojo-raw-1";
  request_spec.source = "mojo-client";
  request_spec.target = "svc.echo";
  request_spec.reply_to = "mojo-client/replies";
  request_spec.payload = request_payload;
  request_spec.payload_len = sizeof(request_payload);
  request_spec.timeout_ms = 1000u;
  request_spec.delivery_hint = 1u;
  request_spec.one_way = 0u;

  uint8_t* request_buf = NULL;
  size_t request_len = 0;
  coakka_v2_ask_ticket_t* ticket = NULL;
  coakka_v2_frame_reader_t* reader = NULL;
  uint8_t* delivered_buf = NULL;
  size_t delivered_len = 0;
  uint8_t* reply_buf = NULL;
  size_t reply_len = 0;
  uint8_t* result_buf = NULL;
  size_t result_len = 0;
  uint32_t result_kind = 0;
  int failed = 0;

  if (require_ok(coakka_v2_client_build_raw_request(&request_spec, &request_buf, &request_len),
                 "build_raw_request") ||
      request_buf == NULL || request_len == 0) {
    failed = 1;
    goto done;
  }
  if (require_ok(coakka_v2_ask_client_begin(client, request_buf, request_len, &ticket),
                 "ask_client_begin") ||
      ticket == NULL) {
    failed = 1;
    goto done;
  }

  reader = coakka_v2_frame_reader_create(handles->delivered_request_read_fd, 64u * 1024u);
  if (reader == NULL || read_delivered_frame(reader, &delivered_buf, &delivered_len)) {
    failed = 1;
    goto done;
  }

  coakka_v2_client_raw_reply_spec_t reply_spec = {0};
  reply_spec.struct_size = sizeof(reply_spec);
  reply_spec.request_buf = delivered_buf;
  reply_spec.request_len = delivered_len;
  reply_spec.source = "svc.echo";
  reply_spec.payload = reply_payload;
  reply_spec.payload_len = sizeof(reply_payload);
  if (require_ok(coakka_v2_client_build_raw_reply(&reply_spec, &reply_buf, &reply_len),
                 "build_raw_reply") ||
      reply_buf == NULL || reply_len == 0) {
    failed = 1;
    goto done;
  }
  if (require_ok(coakka_v2_runtime_submit_envelope(runtime, reply_buf, reply_len),
                 "submit_reply")) {
    failed = 1;
    goto done;
  }
  if (require_ok(coakka_v2_ask_ticket_await(ticket, 1000u, &result_kind, &result_buf, &result_len),
                 "ask_ticket_await") ||
      result_kind != 1u || result_buf == NULL || result_len == 0) {
    failed = 1;
    goto done;
  }

done:
  if (result_buf != NULL) coakka_v2_client_bytes_release(result_buf);
  if (reply_buf != NULL) coakka_v2_client_bytes_release(reply_buf);
  if (delivered_buf != NULL) coakka_v2_frame_release(delivered_buf);
  if (reader != NULL) coakka_v2_frame_reader_destroy(reader);
  if (ticket != NULL) coakka_v2_ask_ticket_destroy(ticket);
  if (request_buf != NULL) coakka_v2_client_bytes_release(request_buf);
  coakka_v2_ask_client_destroy(client);
  return failed;
}

static int run_route_miss_deadletter(coakka_v2_runtime_t* runtime,
                                     const coakka_v2_host_handles_t* handles) {
  static const uint8_t request_payload[] = {'m', 'i', 's', 's', 'i', 'n', 'g'};

  coakka_v2_ask_client_t* client = coakka_v2_ask_client_create(runtime, handles);
  if (client == NULL) {
    fprintf(stderr, "ask_client_create failed\n");
    return 1;
  }

  coakka_v2_client_raw_request_spec_t request_spec = {0};
  request_spec.struct_size = sizeof(request_spec);
  request_spec.message_id = "req-mojo-missing-1";
  request_spec.source = "mojo-client";
  request_spec.target = "svc.missing";
  request_spec.reply_to = "mojo-client/replies";
  request_spec.payload = request_payload;
  request_spec.payload_len = sizeof(request_payload);
  request_spec.timeout_ms = 1000u;
  request_spec.delivery_hint = 1u;
  request_spec.one_way = 0u;

  uint8_t* request_buf = NULL;
  size_t request_len = 0;
  coakka_v2_ask_ticket_t* ticket = NULL;
  uint8_t* result_buf = NULL;
  size_t result_len = 0;
  uint32_t result_kind = 0;
  int failed = 0;

  if (require_ok(coakka_v2_client_build_raw_request(&request_spec, &request_buf, &request_len),
                 "build_missing_raw_request") ||
      request_buf == NULL || request_len == 0) {
    failed = 1;
    goto done;
  }
  if (require_ok(coakka_v2_ask_client_begin(client, request_buf, request_len, &ticket),
                 "ask_missing_client_begin") ||
      ticket == NULL) {
    failed = 1;
    goto done;
  }
  if (require_ok(coakka_v2_ask_ticket_await(ticket, 1000u, &result_kind, &result_buf, &result_len),
                 "ask_missing_ticket_await") ||
      result_kind != 2u || result_buf == NULL || result_len == 0) {
    failed = 1;
    goto done;
  }

done:
  if (result_buf != NULL) coakka_v2_client_bytes_release(result_buf);
  if (ticket != NULL) coakka_v2_ask_ticket_destroy(ticket);
  if (request_buf != NULL) coakka_v2_client_bytes_release(request_buf);
  coakka_v2_ask_client_destroy(client);
  return failed;
}

static coakka_v2_runtime_t* create_runtime(const char* node_id) {
  const coakka_v2_runtime_config_t config = {
      .system_name = "mojo-runtime-smoke",
      .node_id = node_id,
      .strict_no_drop = 1,
      .queue_capacity = 32,
  };
  return coakka_v2_runtime_create(&config);
}

static coakka_v2_host_handles_t init_host_handles(void) {
  coakka_v2_host_handles_t handles = {0};
  handles.struct_size = sizeof(handles);
  handles.flags = 1u | 2u;
  handles.request_write_fd = -1;
  handles.response_read_fd = -1;
  handles.deadletter_read_fd = -1;
  handles.control_write_fd = -1;
  handles.monitor_read_fd = -1;
  handles.delivered_request_read_fd = -1;
  return handles;
}

static int apply_default_route(coakka_v2_runtime_t* runtime) {
  const coakka_v2_endpoint_t endpoint = {
      .host = "127.0.0.1",
      .port = 0,
      .weight = 1,
      .flags = 1u,
  };
  const coakka_v2_route_t route = {
      .target = "svc.echo",
      .strategy = 1,
      .route_key_hint = NULL,
      .flags = 0,
      .endpoints = &endpoint,
      .endpoint_count = 1,
  };
  const coakka_v2_control_snapshot_t snapshot = {
      .generation = 1,
      .routes = &route,
      .route_count = 1,
  };
  return require_ok(coakka_v2_runtime_apply_control_snapshot(runtime, &snapshot),
                    "apply_control_snapshot");
}

static int apply_embedded_network(coakka_v2_runtime_t* runtime) {
  const coakka_v2_network_options_t options = {
      .struct_size = sizeof(options),
      .fields = UINT64_C(1),
      .mode = 1u,
  };
  return require_ok(coakka_v2_runtime_apply_network_options(runtime, &options),
                    "apply_network_options");
}

static int apply_connection(coakka_v2_runtime_t* runtime,
                            uint32_t mode,
                            coakka_v2_tcp_connection_apply_result_t* out) {
  coakka_v2_tcp_connection_options_t options = {0};
  options.struct_size = sizeof(options);
  options.fields = COAKKA_V2_TCP_CONNECTION_FIELD_MODE;
  options.mode = mode;
  memset(out, 0, sizeof(*out));
  out->struct_size = sizeof(*out);
  coakka_v2_status_t status =
      coakka_v2_runtime_apply_tcp_connection_options_ex(runtime, &options, out);
  return (int)status == out->apply_status ? 0 : 1;
}

static int apply_security(coakka_v2_runtime_t* runtime,
                          const coakka_v2_tcp_security_options_t* options,
                          coakka_v2_tcp_security_apply_result_t* out) {
  memset(out, 0, sizeof(*out));
  out->struct_size = sizeof(*out);
  coakka_v2_status_t status =
      coakka_v2_runtime_apply_tcp_security_options_ex(runtime, options, out);
  return (int)status == out->apply_status ? 0 : 1;
}

static int verify_structured_rejections(void) {
  coakka_v2_runtime_t* runtime = create_runtime("mojo-invalid-connection");
  if (runtime == NULL) return 1;
  coakka_v2_tcp_connection_apply_result_t connection = {0};
  int failed = apply_connection(runtime, 999u, &connection) ||
               connection.apply_status != COAKKA_V2_ERR_INVALID_ARG ||
               connection.changed != 0u ||
               connection.validation.code != COAKKA_V2_TCP_CONNECTION_UNKNOWN_MODE ||
               connection.effective_config.mode != COAKKA_V2_TCP_CONNECTION_PER_EXCHANGE;
  coakka_v2_runtime_destroy(runtime);
  if (failed) return 1;

  runtime = create_runtime("mojo-invalid-plaintext");
  if (runtime == NULL) return 1;
  coakka_v2_tcp_security_options_t security = {0};
  security.struct_size = sizeof(security);
  security.fields = COAKKA_V2_TCP_SECURITY_FIELD_MODE |
                    COAKKA_V2_TCP_SECURITY_FIELD_CREDENTIAL_GENERATION |
                    COAKKA_V2_TCP_SECURITY_FIELD_CREDENTIAL_ID;
  security.mode = COAKKA_V2_TCP_SECURITY_PLAINTEXT;
  security.credential_generation = 1u;
  security.credential_id = "must-not-be-ignored";
  coakka_v2_tcp_security_apply_result_t security_result = {0};
  failed = apply_security(runtime, &security, &security_result) ||
           security_result.apply_status != COAKKA_V2_ERR_INVALID_ARG ||
           security_result.changed != 0u ||
           security_result.validation.code != COAKKA_V2_TCP_SECURITY_FIELD_NOT_APPLICABLE ||
           security_result.active_security.config.credential_generation != 0u;
  coakka_v2_runtime_destroy(runtime);
  return failed;
}

static coakka_v2_tcp_security_options_t tls_options(
    uint64_t generation,
    const char* credential_id,
    const char* ca_file,
    const char* identity_file,
    const char* key_file) {
  coakka_v2_tcp_security_options_t options = {0};
  options.struct_size = sizeof(options);
  options.fields = COAKKA_V2_TCP_SECURITY_ALL_FIELDS;
  options.mode = COAKKA_V2_TCP_SECURITY_TLS;
  options.credential_source_kind = COAKKA_V2_TLS_CREDENTIAL_SOURCE_FILE;
  options.reload_mode = COAKKA_V2_TLS_RELOAD_GRACEFUL;
  options.credential_generation = generation;
  options.credential_id = credential_id;
  options.ca_certificate_file = ca_file;
  options.identity_certificate_file = identity_file;
  options.private_key_file = key_file;
  return options;
}

static int fixture_path(char* out,
                        size_t out_size,
                        const char* root,
                        const char* name) {
  int written = snprintf(out, out_size, "%s/%s", root, name);
  return written < 0 || (size_t)written >= out_size;
}

static int run_tls_reload(const char* fixture_root) {
  char ca_file[4096];
  char identity_file[4096];
  char server_key[4096];
  char client_key[4096];
  if (fixture_path(ca_file, sizeof(ca_file), fixture_root, "ca.pem") ||
      fixture_path(identity_file, sizeof(identity_file), fixture_root, "server.pem") ||
      fixture_path(server_key, sizeof(server_key), fixture_root, "server.key") ||
      fixture_path(client_key, sizeof(client_key), fixture_root, "client.key")) {
    return 1;
  }

  coakka_v2_runtime_t* runtime = create_runtime("mojo-tls");
  if (runtime == NULL) return 1;
  coakka_v2_host_handles_t handles = init_host_handles();
  int handles_owned = 0;
  int start_attempted = 0;
  int failed = 0;

  coakka_v2_tcp_security_options_t startup =
      tls_options(1u, "mojo-generation-1", ca_file, identity_file, server_key);
  coakka_v2_tcp_security_apply_result_t startup_result = {0};
  if (apply_security(runtime, &startup, &startup_result) ||
      startup_result.apply_status != COAKKA_V2_OK ||
      startup_result.active_security.config.credential_generation != 1u ||
      strlen(startup_result.active_security.identity.identity_fingerprint_sha256) != 64u ||
      apply_embedded_network(runtime) ||
      apply_default_route(runtime) ||
      require_ok(coakka_v2_runtime_get_host_handles(runtime, &handles), "tls_get_host_handles")) {
    failed = 1;
    goto done;
  }
  char generation_one_fingerprint[65];
  memcpy(generation_one_fingerprint,
         startup_result.active_security.identity.identity_fingerprint_sha256,
         sizeof(generation_one_fingerprint));
  handles_owned = 1;
  start_attempted = 1;
  if (require_ok(coakka_v2_runtime_start(runtime), "tls_runtime_start")) {
    failed = 1;
    goto done;
  }

  coakka_v2_tcp_security_options_t bad =
      tls_options(2u, "mojo-generation-2-bad", ca_file, identity_file, client_key);
  coakka_v2_tcp_security_apply_result_t bad_result = {0};
  coakka_v2_tcp_security_info_t active = {0};
  active.struct_size = sizeof(active);
  if (apply_security(runtime, &bad, &bad_result) ||
      bad_result.apply_status != COAKKA_V2_ERR_INVALID_ARG ||
      bad_result.changed != 0u ||
      bad_result.active_security.config.credential_generation != 1u ||
      strcmp(bad_result.active_security.identity.identity_fingerprint_sha256,
             generation_one_fingerprint) != 0 ||
      require_ok(coakka_v2_runtime_get_tcp_security_info(runtime, &active),
                 "get_security_after_rejection") ||
      active.config.credential_generation != 1u ||
      strcmp(active.identity.identity_fingerprint_sha256,
             generation_one_fingerprint) != 0) {
    failed = 1;
    goto done;
  }

  coakka_v2_tcp_security_options_t replacement =
      tls_options(2u, "mojo-generation-2", ca_file, identity_file, server_key);
  coakka_v2_tcp_security_apply_result_t replacement_result = {0};
  if (apply_security(runtime, &replacement, &replacement_result) ||
      replacement_result.apply_status != COAKKA_V2_OK ||
      replacement_result.changed == 0u ||
      replacement_result.active_security.config.credential_generation != 2u) {
    failed = 1;
    goto done;
  }

  coakka_v2_tcp_security_options_t stale =
      tls_options(1u, "mojo-generation-1-stale", ca_file, identity_file, server_key);
  coakka_v2_tcp_security_apply_result_t stale_result = {0};
  coakka_v2_tcp_security_info_t after_stale = {0};
  after_stale.struct_size = sizeof(after_stale);
  if (apply_security(runtime, &stale, &stale_result) ||
      stale_result.apply_status != COAKKA_V2_ERR_INVALID_ARG ||
      stale_result.changed != 0u ||
      stale_result.active_security.config.credential_generation != 2u ||
      require_ok(coakka_v2_runtime_get_tcp_security_info(runtime, &after_stale),
                 "get_security_after_stale") ||
      after_stale.config.credential_generation != 2u) {
    failed = 1;
  }

done:
  if (start_attempted) (void)coakka_v2_runtime_stop(runtime);
  if (handles_owned) close_host_handles(&handles);
  coakka_v2_runtime_destroy(runtime);
  return failed;
}

/*
 * Mojo FFI smoke entrypoint.
 *
 * This is an evidence-only entrypoint, not an application connector API. The
 * reserved argument is ignored. The call synchronously owns one complete
 * same-process runtime lifecycle and returns 0 only after capability-aware
 * connection setup, atomic rejection checks, request/reply, route-miss
 * deadletter, post-start immutability, and cleanup pass. A nonzero result means
 * the diagnostic written to stderr identifies a failed stage. No runtime,
 * descriptor, or buffer escapes the call. Serialize invocations because the
 * loaded native runtime may own process-wide registration state. TLS reload is
 * exercised only when the runtime exposes the capability and
 * COAKKA_TLS_FIXTURE_ROOT supplies the explicit test credentials.
 */
COAKKA_MOJO_EXPORT int coakka_mojo_runtime_connector_smoke(int ignored) {
  (void)ignored;

  coakka_v2_runtime_info_t info = {0};
  info.struct_size = sizeof(info);
  if (require_ok(coakka_v2_runtime_get_info(&info), "runtime_get_info")) {
    return 1;
  }

  coakka_v2_runtime_capabilities_t capabilities = {0};
  capabilities.struct_size = sizeof(capabilities);
  if (require_ok(coakka_v2_runtime_get_capabilities(&capabilities),
                 "runtime_get_capabilities") ||
      verify_structured_rejections()) {
    return 1;
  }

  uint32_t connection_mode = COAKKA_V2_TCP_CONNECTION_PER_EXCHANGE;
  if ((capabilities.effective_capabilities & COAKKA_V2_CAPABILITY_TCP_BOUNDED_POOL) != 0u) {
    connection_mode = COAKKA_V2_TCP_CONNECTION_BOUNDED_POOL;
  }

  coakka_v2_runtime_t* runtime = create_runtime("mojo-runtime-smoke-node");
  if (runtime == NULL) {
    fprintf(stderr, "runtime_create failed\n");
    return 1;
  }

  coakka_v2_host_handles_t handles = init_host_handles();
  int handles_owned = 0;
  int start_attempted = 0;
  int failed = 0;

  coakka_v2_tcp_connection_apply_result_t connection = {0};
  coakka_v2_tcp_connection_config_t effective_connection = {0};
  effective_connection.struct_size = sizeof(effective_connection);
  coakka_v2_tcp_security_options_t plaintext = {0};
  plaintext.struct_size = sizeof(plaintext);
  plaintext.fields = COAKKA_V2_TCP_SECURITY_FIELD_MODE;
  plaintext.mode = COAKKA_V2_TCP_SECURITY_PLAINTEXT;
  coakka_v2_tcp_security_apply_result_t security = {0};
  if (apply_connection(runtime, connection_mode, &connection) ||
      connection.apply_status != COAKKA_V2_OK ||
      connection.effective_config.mode != connection_mode ||
      require_ok(coakka_v2_runtime_get_tcp_connection_config(runtime, &effective_connection),
                 "get_tcp_connection_config") ||
      effective_connection.mode != connection_mode ||
      apply_security(runtime, &plaintext, &security) ||
      security.apply_status != COAKKA_V2_OK ||
      security.active_security.config.mode != COAKKA_V2_TCP_SECURITY_PLAINTEXT ||
      apply_embedded_network(runtime) ||
      apply_default_route(runtime) ||
      require_ok(coakka_v2_runtime_get_host_handles(runtime, &handles), "get_host_handles")) {
    failed = 1;
    goto done;
  }
  handles_owned = 1;
  start_attempted = 1;
  if (require_ok(coakka_v2_runtime_start(runtime), "runtime_start")) {
    failed = 1;
    goto done;
  }

  coakka_v2_runtime_stats_t stats = {0};
  stats.struct_size = sizeof(stats);
  if (require_ok(coakka_v2_runtime_get_stats(runtime, &stats), "runtime_get_stats")) {
    failed = 1;
    goto done;
  }

  if (stats.applied_generation != 1 || stats.route_count != 1 || stats.runtime_state != 1) {
    fprintf(stderr,
            "unexpected runtime stats generation=%llu routes=%zu state=%d\n",
            (unsigned long long)stats.applied_generation,
            stats.route_count,
            stats.runtime_state);
    failed = 1;
    goto done;
  }

  if (run_raw_roundtrip(runtime, &handles) ||
      run_route_miss_deadletter(runtime, &handles)) {
    failed = 1;
    goto done;
  }

  coakka_v2_tcp_connection_apply_result_t post_start = {0};
  if (apply_connection(runtime, COAKKA_V2_TCP_CONNECTION_PER_EXCHANGE, &post_start) ||
      post_start.apply_status != COAKKA_V2_ERR_BAD_STATE ||
      post_start.changed != 0u ||
      post_start.effective_config.mode != connection_mode) {
    failed = 1;
    goto done;
  }

  if (require_ok(coakka_v2_runtime_stop(runtime), "runtime_stop")) {
    failed = 1;
    goto done;
  }
  start_attempted = 0;
  close_host_handles(&handles);
  handles_owned = 0;
  coakka_v2_runtime_destroy(runtime);
  runtime = NULL;

  int tls_executed = 0;
  const char* tls_fixture_root = getenv("COAKKA_TLS_FIXTURE_ROOT");
  if ((capabilities.effective_capabilities & COAKKA_V2_CAPABILITY_TCP_TLS) != 0u &&
      tls_fixture_root != NULL && tls_fixture_root[0] != '\0') {
    if (run_tls_reload(tls_fixture_root)) {
      failed = 1;
      goto done;
    }
    tls_executed = 1;
  }

  printf("coakka_runtime_mojo_smoke abi=%u runtime=%s git=%s capabilities=%llu connectionMode=%u generation=%llu routes=%zu state=%d rawRoundTrip=ok routeMissDeadletter=ok structuredReject=ok postStartReject=ok tlsReload=%s\n",
         info.abi_version,
         info.runtime_version,
         info.git_commit,
         (unsigned long long)capabilities.effective_capabilities,
         connection_mode,
         (unsigned long long)stats.applied_generation,
         stats.route_count,
         stats.runtime_state,
         tls_executed ? "ok" : "not-run");

done:
  if (runtime != NULL && start_attempted &&
      require_ok(coakka_v2_runtime_stop(runtime), "runtime_stop")) {
    failed = 1;
  }
  if (handles_owned) close_host_handles(&handles);
  if (runtime != NULL) coakka_v2_runtime_destroy(runtime);
  return failed;
}
