#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Exploratory Mojo conformance shim. Callbacks stay in C because Mojo callback
 * ownership across arbitrary native worker threads is not yet a stable API. */

#if defined(_WIN32)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT __attribute__((visibility("default")))
#endif

typedef struct coakka_v2_stream_lane_t coakka_v2_stream_lane_t;
typedef struct {
  size_t struct_size;
  uint64_t sequence, captured, dropped;
  uint32_t flags;
  size_t size;
} frame_t;
typedef int (*source_fn)(void *, uint8_t *, size_t, frame_t *);
typedef int (*consumer_fn)(void *, const uint8_t *, const frame_t *);
typedef struct {
  size_t struct_size;
  uint32_t flags;
  const char *host;
  uint16_t port;
  size_t capacity;
  uint32_t max_frame, max_window, io_timeout, retry, progress_frames,
      progress_ms, publisher_workers, subscriber_workers;
  const void *security;
  uint32_t pressure_ms, stalled_ms, recovery_ms, observation_ms;
} config_t;
typedef struct {
  size_t struct_size;
  const char *id, *token;
  uint64_t format;
  uint32_t max_frame;
  source_fn source;
  void *context;
} publish_t;
typedef struct {
  size_t struct_size;
  const char *id, *token, *host;
  uint16_t port;
  uint64_t format;
  uint32_t max_frame, window, timeout;
  consumer_fn consumer;
  void *context;
} subscribe_t;
typedef struct {
  size_t struct_size;
  uint32_t direction, state, result;
  uint64_t format, frames, bytes, drops, last_sequence;
  uint32_t max_frame, window, cancel;
  uint64_t sequence, submitted, started, updated, terminal;
  char detail[160];
} session_t;
typedef struct {
  const uint8_t *data;
  size_t size, offset;
} source_context_t;
typedef struct {
  uint8_t *data;
  size_t capacity, size;
} sink_context_t;

extern int coakka_v2_stream_lane_create_ex(const config_t *,
                                           coakka_v2_stream_lane_t **);
extern void coakka_v2_stream_lane_destroy(coakka_v2_stream_lane_t *);
extern int coakka_v2_stream_lane_start(coakka_v2_stream_lane_t *);
extern int coakka_v2_stream_lane_stop(coakka_v2_stream_lane_t *);
extern int coakka_v2_stream_lane_get_bound_port(coakka_v2_stream_lane_t *,
                                                uint16_t *);
extern int coakka_v2_stream_lane_prepare_publish(coakka_v2_stream_lane_t *,
                                                 const publish_t *);
extern int coakka_v2_stream_lane_subscribe(coakka_v2_stream_lane_t *,
                                           const subscribe_t *);
extern int coakka_v2_stream_lane_wait_session(coakka_v2_stream_lane_t *,
                                              const char *, uint32_t, uint64_t,
                                              uint32_t, session_t *);

_Static_assert(sizeof(frame_t) == 48, "stream frame ABI drift");
_Static_assert(sizeof(config_t) == 96, "stream config ABI drift");
_Static_assert(sizeof(publish_t) == 56, "stream publish ABI drift");
_Static_assert(sizeof(subscribe_t) == 80, "stream subscribe ABI drift");
_Static_assert(sizeof(session_t) == 280, "stream session ABI drift");

static int source_next(void *opaque, uint8_t *destination, size_t capacity,
                       frame_t *frame) {
  source_context_t *source = (source_context_t *)opaque;
  if (!source || !destination || !frame)
    return -1;
  if (source->offset == source->size)
    return -7;
  size_t count = source->size - source->offset;
  if (count > capacity)
    count = capacity;
  memcpy(destination, source->data + source->offset, count);
  source->offset += count;
  frame->size = count;
  return 0;
}
static int consume(void *opaque, const uint8_t *data, const frame_t *frame) {
  sink_context_t *sink = (sink_context_t *)opaque;
  if (!sink || !data || !frame || frame->size == 0 ||
      sink->size + frame->size > sink->capacity)
    return -1;
  memcpy(sink->data + sink->size, data, frame->size);
  sink->size += frame->size;
  return 0;
}
static int wait_terminal(coakka_v2_stream_lane_t *lane, const char *id,
                         uint32_t direction, session_t *out) {
  uint64_t sequence = 0;
  for (int i = 0; i < 64; ++i) {
    memset(out, 0, sizeof(*out));
    out->struct_size = sizeof(*out);
    if (coakka_v2_stream_lane_wait_session(lane, id, direction, sequence, 30000,
                                           out) != 0)
      return 1;
    if (out->state >= 6)
      return 0;
    sequence = out->sequence;
  }
  return 1;
}

EXPORT int coakka_mojo_stream_lane_smoke(int ignored) {
  (void)ignored;
  const size_t size = 2u * 1024u * 1024u + 731u;
  int failed = 0;
  uint8_t *payload = (uint8_t *)malloc(size),
          *received = (uint8_t *)malloc(size);
  if (!payload || !received) {
    free(payload);
    free(received);
    return 1;
  }
  for (size_t i = 0; i < size; ++i)
    payload[i] = (uint8_t)(i * 31u + 17u);
  config_t pub_config = {0}, sub_config = {0};
  pub_config.struct_size = sizeof(pub_config);
  pub_config.flags = 1;
  pub_config.host = "127.0.0.1";
  sub_config.struct_size = sizeof(sub_config);
  sub_config.flags = 2;
  sub_config.host = "127.0.0.1";
  coakka_v2_stream_lane_t *publisher = NULL, *subscriber = NULL;
  uint16_t port = 0;
  if (coakka_v2_stream_lane_create_ex(&pub_config, &publisher) != 0 ||
      coakka_v2_stream_lane_start(publisher) != 0 ||
      coakka_v2_stream_lane_create_ex(&sub_config, &subscriber) != 0 ||
      coakka_v2_stream_lane_start(subscriber) != 0 ||
      coakka_v2_stream_lane_get_bound_port(publisher, &port) != 0) {
    failed = 1;
    goto done;
  }
  const char *id = "mojo-stream-lane", *token = "mojo-stream-token";
  source_context_t source = {payload, size, 0};
  sink_context_t sink = {received, size, 0};
  publish_t publish = {sizeof(publish), id,          token,  0x43414d31u,
                       64u * 1024u,     source_next, &source};
  subscribe_t subscribe = {
      sizeof(subscribe), id,           token, "127.0.0.1", port, 0x43414d31u,
      64u * 1024u,       256u * 1024u, 0,     consume,     &sink};
  session_t published, consumed;
  if (coakka_v2_stream_lane_prepare_publish(publisher, &publish) != 0 ||
      coakka_v2_stream_lane_subscribe(subscriber, &subscribe) != 0 ||
      wait_terminal(publisher, id, 1, &published) ||
      wait_terminal(subscriber, id, 2, &consumed) || published.state != 6 ||
      published.result != 1 || consumed.state != 6 || consumed.result != 1 ||
      sink.size != size || memcmp(payload, received, size) != 0)
    failed = 1;
done:
  if (subscriber) {
    coakka_v2_stream_lane_stop(subscriber);
    coakka_v2_stream_lane_destroy(subscriber);
  }
  if (publisher) {
    coakka_v2_stream_lane_stop(publisher);
    coakka_v2_stream_lane_destroy(publisher);
  }
  free(payload);
  free(received);
  if (!failed)
    printf("coakka_runtime_mojo_stream_lane_smoke bytes=%llu ok\n",
           (unsigned long long)size);
  return failed;
}
