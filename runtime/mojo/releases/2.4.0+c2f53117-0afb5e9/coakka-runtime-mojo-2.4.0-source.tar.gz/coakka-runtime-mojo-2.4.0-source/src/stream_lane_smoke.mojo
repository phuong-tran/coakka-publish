from std.ffi import OwnedDLHandle, c_int
from std.sys import argv

def main() raises:
    var args = argv()
    if len(args) != 2:
        raise Error("usage: mojo stream_lane_smoke.mojo <stream-lane-shim-library>")
    var lib = OwnedDLHandle(String(args[1]))
    if lib.call["coakka_mojo_stream_lane_smoke", c_int](0) != 0:
        raise Error("coakka_mojo_stream_lane_smoke failed")
