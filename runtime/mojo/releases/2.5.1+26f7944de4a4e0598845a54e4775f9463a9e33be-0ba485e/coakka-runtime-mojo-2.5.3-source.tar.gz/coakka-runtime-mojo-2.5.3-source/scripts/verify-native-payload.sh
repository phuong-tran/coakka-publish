#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mojo_root="$(cd "${script_dir}/.." && pwd)"
native_root="${mojo_root}/native"

sha256_file() {
  if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print $1}';
  else sha256sum "$1" | awk '{print $1}'; fi
}

verify() {
  local relative="$1" expected="$2" format="$3"
  local path="${native_root}/${relative}"
  [[ -f "${path}" ]] || { echo "[mojo-verify-native] missing ${relative}" >&2; exit 1; }
  [[ "$(sha256_file "${path}")" == "${expected}" ]] || {
    echo "[mojo-verify-native] digest mismatch ${relative}" >&2; exit 1;
  }
  file "${path}" | grep -Eq "${format}" || {
    echo "[mojo-verify-native] format mismatch ${relative}" >&2; exit 1;
  }
}

verify "macos-aarch64/libcoakka_runtime_v2.dylib" \
  "277d9ff36b017f2eef2e630ac82bb9ba68f112879297e8067521fe665f82368a" \
  "Mach-O 64-bit dynamically linked shared library arm64"
verify "linux-aarch64/libcoakka_runtime_v2.so" \
  "dedacfa666c398b01e0aefa0bd9f649a6a63722645e5b822252d3e505e7fda43" \
  "ELF 64-bit LSB shared object, ARM aarch64"
verify "linux-x86_64/libcoakka_runtime_v2.so" \
  "0ce69740cff0a5f7d5b2f002340ecff645c3c82f4f50d6dfdb9fb8a19e90a38b" \
  "ELF 64-bit LSB shared object, x86-64"
verify "windows-aarch64/libcoakka_runtime_v2.dll" \
  "0ee49c59de50dad40fa403ce2f32b59e0da05ab7677bf3d1ca8a9ccfe2f9b545" \
  "PE32\\+ executable \\(DLL\\).*Aarch64"
verify "windows-x86_64/libcoakka_runtime_v2.dll" \
  "a54e8a43089adf68f9275c83d0a4495bf8deb384c25f993cd13ef42233da573b" \
  "PE32\\+ executable \\(DLL\\).*x86-64"

count="$(find "${native_root}" -type f \( -name '*.dylib' -o -name '*.so' -o -name '*.dll' \) | wc -l | tr -d ' ')"
[[ "${count}" == "5" ]] || { echo "[mojo-verify-native] expected 5 natives, got ${count}" >&2; exit 1; }
echo "[mojo-verify-native] exact payload ok (macOS/Linux/Windows); publisher signing absent"
