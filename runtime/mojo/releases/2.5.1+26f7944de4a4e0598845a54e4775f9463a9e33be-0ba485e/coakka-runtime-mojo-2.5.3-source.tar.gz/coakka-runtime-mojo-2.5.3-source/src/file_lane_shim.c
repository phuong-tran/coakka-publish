#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * Exploratory Mojo conformance shim, not a stable application API. It keeps
 * the ABI layout and receiver-first lifecycle visible to the source-package
 * smoke while production Mojo ownership is still undefined. The fixed token
 * below is test data for loopback only and must never be copied into a real
 * control plane.
 */

#if defined(_WIN32)
#include <windows.h>
#define EXPORT __declspec(dllexport)
#define PROCESS_ID ((unsigned long)GetCurrentProcessId())
#else
#include <unistd.h>
#define EXPORT __attribute__((visibility("default")))
#define PROCESS_ID ((unsigned long)getpid())
#endif

typedef struct coakka_v2_file_lane_t coakka_v2_file_lane_t;
typedef struct { size_t struct_size; uint32_t mode,reserved; uint64_t generation; const char *id,*ca,*cert,*key; } file_security_t;
typedef struct { size_t struct_size; uint32_t flags; const char *bind_host; uint16_t bind_port; size_t queue_capacity; uint64_t max_file_size; uint32_t io_timeout_ms; uint64_t checkpoint_bytes,progress_bytes; uint32_t progress_interval_ms,sender_workers,receiver_workers; const file_security_t *security; } file_config_t;
typedef struct { size_t struct_size; const char *owner_instance_id,*advertised_host; } owner_config_t;
typedef struct { size_t struct_size; uint16_t port,reserved; char owner_instance_id[128],advertised_host[256]; } owner_endpoint_t;
typedef struct { size_t struct_size; file_config_t lane; owner_config_t owner; } owned_config_t;
typedef struct { size_t struct_size; const char *id,*token,*path; uint64_t size; uint8_t sha[32]; } receive_spec_t;
typedef struct { size_t struct_size; owner_endpoint_t owner; char id[65],token[129]; uint64_t size; uint8_t sha[32]; } receive_grant_t;
typedef struct { size_t struct_size; const char *id,*token,*host; uint16_t port; const char *path; uint64_t size; uint8_t sha[32]; uint32_t timeout_ms; } send_spec_t;
typedef struct { size_t struct_size; uint32_t direction,state,result; uint64_t expected,transferred,committed; uint32_t progress,cancel; uint64_t sequence,submitted,started,updated,terminal; char detail[160]; } transfer_t;
typedef struct { size_t struct_size; uint32_t abi_version,feature_flags; } runtime_info_t;

extern int coakka_v2_file_lane_create_ex(const file_config_t *, coakka_v2_file_lane_t **);
extern int coakka_v2_file_lane_create_owned_ex(const owned_config_t *, coakka_v2_file_lane_t **);
extern int coakka_v2_runtime_get_info(runtime_info_t *);
extern void coakka_v2_file_lane_destroy(coakka_v2_file_lane_t *);
extern int coakka_v2_file_lane_start(coakka_v2_file_lane_t *);
extern int coakka_v2_file_lane_stop(coakka_v2_file_lane_t *);
extern int coakka_v2_file_lane_get_bound_port(coakka_v2_file_lane_t *, uint16_t *);
extern int coakka_v2_file_lane_prepare_receive(coakka_v2_file_lane_t *, const receive_spec_t *);
extern int coakka_v2_file_lane_prepare_receive_grant(coakka_v2_file_lane_t *, const receive_spec_t *, receive_grant_t *);
extern int coakka_v2_file_lane_submit_send(coakka_v2_file_lane_t *, const send_spec_t *);
extern int coakka_v2_file_lane_wait_transfer(coakka_v2_file_lane_t *, const char *, uint32_t, uint64_t, uint32_t, transfer_t *);
extern int coakka_v2_file_sha256_path(const char *, uint8_t[32], uint64_t *);

_Static_assert(sizeof(file_security_t) == 56, "file security ABI drift");
_Static_assert(sizeof(file_config_t) == 96, "file config ABI drift");
_Static_assert(sizeof(receive_spec_t) == 72, "receive spec ABI drift");
_Static_assert(sizeof(send_spec_t) == 96, "send spec ABI drift");
_Static_assert(sizeof(transfer_t) == 256, "transfer ABI drift");
_Static_assert(sizeof(owner_config_t) == 24, "owner config ABI drift");
_Static_assert(sizeof(owner_endpoint_t) == 400, "owner endpoint ABI drift");
_Static_assert(sizeof(owned_config_t) == 128, "owned file config ABI drift");
_Static_assert(sizeof(receive_grant_t) == 648, "file grant ABI drift");

static int wait_terminal(coakka_v2_file_lane_t *lane, const char *id, uint32_t direction, transfer_t *out) {
    uint64_t sequence = 0;
    for (int attempt = 0; attempt < 64; ++attempt) {
        memset(out, 0, sizeof(*out)); out->struct_size = sizeof(*out);
        if (coakka_v2_file_lane_wait_transfer(lane, id, direction, sequence, 30000, out) != 0) return 1;
        if (out->state >= 6) return 0;
        sequence = out->sequence;
    }
    return 1;
}

EXPORT int coakka_mojo_file_lane_smoke(int ignored) {
    (void)ignored;
    char source[256], destination[256];
    const char *tmp = getenv("TMPDIR"); if (tmp == NULL || tmp[0] == '\0') tmp = "/tmp";
    snprintf(source, sizeof(source), "%s/coakka-mojo-file-%lu-source.bin", tmp, PROCESS_ID);
    snprintf(destination, sizeof(destination), "%s/coakka-mojo-file-%lu-destination.bin", tmp, PROCESS_ID);
    remove(source); remove(destination);
    FILE *output = fopen(source, "wb"); if (output == NULL) return 1;
    uint8_t block[64 * 1024]; for (size_t i = 0; i < sizeof(block); ++i) block[i] = (uint8_t)(i * 31u + 17u);
    size_t remaining = 9u * 1024u * 1024u + 731u;
    while (remaining != 0) { size_t count = remaining < sizeof(block) ? remaining : sizeof(block); if (fwrite(block, 1, count, output) != count) { fclose(output); return 1; } remaining -= count; }
    if (fclose(output) != 0) return 1;
    uint8_t sha[32], destination_sha[32]; uint64_t size = 0, destination_size = 0;
    if (coakka_v2_file_sha256_path(source, sha, &size) != 0) return 1;
    file_config_t receiver_config = {0}, sender_config = {0}; receiver_config.struct_size=sizeof(receiver_config);receiver_config.flags=2;receiver_config.bind_host="127.0.0.1";sender_config.struct_size=sizeof(sender_config);sender_config.flags=1;sender_config.bind_host="127.0.0.1";
    runtime_info_t info={sizeof(info),0,0};
    if(coakka_v2_runtime_get_info(&info)!=0||(info.feature_flags&(1u<<25))==0)return 1;
    owner_config_t owner={sizeof(owner),"mojo-file-replica-2","127.0.0.1"};
    owned_config_t owned={sizeof(owned),receiver_config,owner};
    coakka_v2_file_lane_t *receiver=NULL,*sender=NULL; int failed=0;
    if(coakka_v2_file_lane_create_owned_ex(&owned,&receiver)!=0||coakka_v2_file_lane_start(receiver)!=0||coakka_v2_file_lane_create_ex(&sender_config,&sender)!=0||coakka_v2_file_lane_start(sender)!=0){failed=1;goto done;}
    const char *id="mojo-file-lane-multi-quantum",*token="mojo-file-lane-token";
    receive_spec_t receive={sizeof(receive),id,token,destination,size,{0}};memcpy(receive.sha,sha,32);
    receive_grant_t grant={0};grant.struct_size=sizeof(grant);
    transfer_t sent,received;
    if(coakka_v2_file_lane_prepare_receive_grant(receiver,&receive,&grant)!=0||strcmp(grant.owner.owner_instance_id,"mojo-file-replica-2")!=0||grant.owner.port==0){failed=1;goto done;}
    send_spec_t send={sizeof(send),grant.id,grant.token,grant.owner.advertised_host,grant.owner.port,source,grant.size,{0},0};memcpy(send.sha,grant.sha,32);
    if(coakka_v2_file_lane_submit_send(sender,&send)!=0||wait_terminal(sender,id,1,&sent)||wait_terminal(receiver,id,2,&received)||sent.state!=6||sent.result!=1||received.state!=6||received.result!=1||coakka_v2_file_sha256_path(destination,destination_sha,&destination_size)!=0||size!=destination_size||memcmp(sha,destination_sha,32)!=0)failed=1;
done:
    if(sender){coakka_v2_file_lane_stop(sender);coakka_v2_file_lane_destroy(sender);}if(receiver){coakka_v2_file_lane_stop(receiver);coakka_v2_file_lane_destroy(receiver);}remove(source);remove(destination);
    if(!failed)printf("coakka_runtime_mojo_file_lane_smoke bytes=%llu ok\n",(unsigned long long)size);
    return failed;
}
