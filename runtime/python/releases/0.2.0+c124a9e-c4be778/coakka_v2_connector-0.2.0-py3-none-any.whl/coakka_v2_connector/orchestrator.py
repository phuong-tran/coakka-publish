from __future__ import annotations

import atexit
import os
import shutil
import threading
import tempfile
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any, Mapping

from .generated.coakka.v2 import transport_pb2
from ._packaging import COAKKA_V2_NATIVE_PACKAGE_VERSION
from .models import ConnectorStartSpec, DeliveryHint, PayloadIdentity, SubmittedRequest
from .runtime_client import (
    DeadletterSubscription,
    HandlerFn,
    MonitorSnapshot,
    PythonRuntimeClient,
    RuntimeClientStats,
    TerminalEventSubscription,
)

DEFAULT_LIBRARY_CANDIDATES = (
    "libcoakka_runtime_v2.dylib",
    "libcoakka_runtime_v2.so",
)


class RuntimeLibraryResolver:
    ENV_VAR = "COAKKA_RUNTIME_LIB"
    _embedded_path_cache: dict[str, str] = {}
    _cache_lock = threading.Lock()

    @classmethod
    def resolve(
        cls,
        explicit_path: str | os.PathLike[str] | None = None,
        candidate_names: tuple[str, ...] = DEFAULT_LIBRARY_CANDIDATES,
    ) -> str:
        if explicit_path is not None and str(explicit_path).strip() != "":
            return cls._require_existing(Path(explicit_path), "explicit runtime_lib_path")

        configured_path = os.environ.get(cls.ENV_VAR, "").strip()
        if configured_path != "":
            return cls._require_existing(Path(configured_path), f"${cls.ENV_VAR}")

        embedded = cls._resolve_embedded()
        if embedded is not None:
            return embedded

        for candidate in cls._search_candidates(candidate_names):
            if candidate.exists():
                return str(candidate.resolve())

        raise FileNotFoundError(
            "native runtime library was not found. "
            f"Set {cls.ENV_VAR}, pass runtime_lib_path explicitly, or place one of "
            f"{', '.join(candidate_names)} under a repo-local lib/ directory."
        )

    @classmethod
    def platform_id(cls, os_name: str | None = None, arch_name: str | None = None) -> str:
        return f"{cls.normalize_os(os_name or os.uname().sysname)}-{cls.normalize_arch(arch_name or os.uname().machine)}"

    @staticmethod
    def normalize_os(os_name: str) -> str:
        normalized = os_name.lower()
        if "mac" in normalized or "darwin" in normalized:
            return "macos"
        if "linux" in normalized:
            return "linux"
        raise RuntimeError(f"unsupported os.name={os_name}; supported platforms are macOS and Linux")

    @staticmethod
    def normalize_arch(arch_name: str) -> str:
        normalized = arch_name.lower()
        if normalized in ("aarch64", "arm64"):
            return "aarch64"
        if normalized in ("x86_64", "amd64"):
            return "x86_64"
        raise RuntimeError(f"unsupported os.arch={arch_name}; supported architectures are aarch64 and x86_64")

    @classmethod
    def runtime_resource_file_names_for_current_platform(cls, os_name: str | None = None) -> list[str]:
        versioned_base = f"libcoakka_runtime_v2-{COAKKA_V2_NATIVE_PACKAGE_VERSION}"
        match cls.normalize_os(os_name or os.uname().sysname):
            case "macos":
                return [f"{versioned_base}.dylib", "libcoakka_runtime_v2.dylib", "libcoakka_runtime_v2.so"]
            case "linux":
                return [f"{versioned_base}.so", "libcoakka_runtime_v2.so"]
        raise RuntimeError("unsupported platform")

    @classmethod
    def _resolve_embedded(cls) -> str | None:
        platform_id = cls.platform_id()
        with cls._cache_lock:
            cached = cls._embedded_path_cache.get(platform_id)
            if cached is not None:
                return cached

            runtime_resource = cls._resolve_resource(platform_id, cls.runtime_resource_file_names_for_current_platform())
            if runtime_resource is None:
                return None

            temp_dir = Path(tempfile.mkdtemp(prefix="coakka-v2-native-"))
            atexit.register(shutil.rmtree, temp_dir, ignore_errors=True)

            runtime_path = cls._extract_resource(temp_dir, runtime_resource[0], runtime_resource[1])

            resolved_path = str(runtime_path.resolve())
            cls._embedded_path_cache[platform_id] = resolved_path
            return resolved_path

    @staticmethod
    def _search_candidates(candidate_names: tuple[str, ...]) -> list[Path]:
        cwd = Path.cwd()
        repo_root = Path(__file__).resolve().parents[2]
        search_roots = [
            cwd,
            cwd / "lib",
            repo_root,
            repo_root / "lib",
        ]
        candidates: list[Path] = []
        seen: set[Path] = set()
        for root in search_roots:
            for name in candidate_names:
                candidate = root / name if root.name == "lib" else root / "lib" / name
                if candidate not in seen:
                    candidates.append(candidate)
                    seen.add(candidate)
        return candidates

    @staticmethod
    def _require_existing(path: Path, source: str) -> str:
        if not path.exists():
            raise FileNotFoundError(f"{source} does not exist: {path}")
        return str(path.resolve())

    @staticmethod
    def _resolve_resource(platform_id: str, candidate_file_names: list[str]) -> tuple[str, bytes] | None:
        package_root = resources.files("coakka_v2_connector")
        for file_name in candidate_file_names:
            candidate = package_root / "native" / platform_id / file_name
            if candidate.is_file():
                return str(candidate), candidate.read_bytes()
        return None

    @staticmethod
    def _extract_resource(temp_dir: Path, resource_path: str, resource_bytes: bytes) -> Path:
        target = temp_dir / Path(resource_path).name
        target.write_bytes(resource_bytes)
        return target

@dataclass(frozen=True)
class _ControlApi:
    _orchestrator: "ConnectorOrchestrator"

    def apply_snapshot(
        self,
        generation: int,
        routes: list | tuple,
        source_connector: str | None = None,
        seq: int = 1,
        overload_policy=None,
    ) -> None:
        self._orchestrator.apply_snapshot(
            generation=generation,
            routes=routes,
            source_connector=source_connector,
            seq=seq,
            overload_policy=overload_policy,
        )


@dataclass(frozen=True)
class _MonitorApi:
    _orchestrator: "ConnectorOrchestrator"

    def is_enabled(self) -> bool:
        return self._orchestrator.monitor_is_enabled()

    def snapshot(self, signal_count: int = 0) -> MonitorSnapshot:
        return self._orchestrator.monitor_snapshot(signal_count=signal_count)

    def await_next(self, timeout_ms: int = 1000) -> MonitorSnapshot | None:
        return self._orchestrator.await_next_monitor(timeout_ms=timeout_ms)

    def await_applied_generation_at_least(
        self,
        generation: int,
        timeout_ms: int = 1000,
    ) -> MonitorSnapshot | None:
        return self._orchestrator.await_applied_generation_at_least(
            generation=generation,
            timeout_ms=timeout_ms,
        )


class ConnectorOrchestrator:
    _factory_lock = threading.Lock()
    _active: "ConnectorOrchestrator | None" = None

    def __init__(
        self,
        runtime_lib_path: str,
        start_spec: ConnectorStartSpec,
        client: PythonRuntimeClient,
    ):
        self.runtime_lib_path = runtime_lib_path
        self.start_spec = start_spec
        self._client = client
        self.control = _ControlApi(self)
        self.monitor = _MonitorApi(self)
        self._closed = False

    @classmethod
    def start(
        cls,
        start_spec: ConnectorStartSpec,
        runtime_lib_path: str | os.PathLike[str] | None = None,
    ) -> "ConnectorOrchestrator":
        resolved_runtime_lib = RuntimeLibraryResolver.resolve(runtime_lib_path)
        config = start_spec.to_connector_config().require_valid()
        with cls._factory_lock:
            if cls._active is not None:
                raise RuntimeError("ConnectorOrchestrator already started for this Python process")
            orchestrator = cls(
                runtime_lib_path=resolved_runtime_lib,
                start_spec=start_spec,
                client=PythonRuntimeClient(resolved_runtime_lib, config),
            )
            cls._active = orchestrator
            return orchestrator

    @property
    def client(self) -> PythonRuntimeClient:
        return self._client

    def ask_typed(
        self,
        source: str,
        target: str,
        payload: bytes,
        payload_identity: PayloadIdentity,
        timeout_ms: int = 5000,
        operation: str = "ask",
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> transport_pb2.Envelope:
        return self._client.ask_typed(
            source=source,
            target=target,
            payload=payload,
            payload_identity=payload_identity,
            timeout_ms=timeout_ms,
            operation=operation,
            delivery_hint=delivery_hint,
            headers=headers,
        )

    def ask_json(
        self,
        source: str,
        target: str,
        payload: Mapping[str, Any],
        payload_identity: PayloadIdentity,
        timeout_ms: int = 5000,
        operation: str = "ask",
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._client.ask_json(
            source=source,
            target=target,
            payload=payload,
            payload_identity=payload_identity,
            timeout_ms=timeout_ms,
            operation=operation,
            delivery_hint=delivery_hint,
            headers=headers,
        )

    def ask_raw(
        self,
        request: transport_pb2.Envelope,
        timeout_ms: int | None = None,
    ) -> transport_pb2.Envelope:
        return self._client.ask_raw(request=request, timeout_ms=timeout_ms)

    def submit_request_typed(
        self,
        source: str,
        target: str,
        payload: bytes,
        payload_identity: PayloadIdentity,
        timeout_ms: int = 5000,
        operation: str = "ask",
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> SubmittedRequest:
        return self._client.submit_request_typed(
            source=source,
            target=target,
            payload=payload,
            payload_identity=payload_identity,
            timeout_ms=timeout_ms,
            operation=operation,
            delivery_hint=delivery_hint,
            headers=headers,
        )

    def submit_request_json(
        self,
        source: str,
        target: str,
        payload: Mapping[str, Any],
        payload_identity: PayloadIdentity,
        timeout_ms: int = 5000,
        operation: str = "ask",
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> SubmittedRequest:
        return self._client.submit_request_json(
            source=source,
            target=target,
            payload=payload,
            payload_identity=payload_identity,
            timeout_ms=timeout_ms,
            operation=operation,
            delivery_hint=delivery_hint,
            headers=headers,
        )

    def submit_request_raw(self, request: transport_pb2.Envelope) -> SubmittedRequest:
        return self._client.submit_request_raw(request=request)

    def terminal_events(self, buffer_capacity: int = 16) -> TerminalEventSubscription:
        return self._client.terminal_events(buffer_capacity=buffer_capacity)

    def deadletters(self, buffer_capacity: int = 128) -> DeadletterSubscription:
        return self._client.deadletters(buffer_capacity=buffer_capacity)

    def send_one_way_typed(
        self,
        source: str,
        target: str,
        payload: bytes,
        payload_identity: PayloadIdentity,
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        self._client.send_one_way_typed(
            source=source,
            target=target,
            payload=payload,
            payload_identity=payload_identity,
            delivery_hint=delivery_hint,
            headers=headers,
        )

    def send_one_way_json(
        self,
        source: str,
        target: str,
        payload: Mapping[str, Any],
        payload_identity: PayloadIdentity,
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        self._client.send_one_way_json(
            source=source,
            target=target,
            payload=payload,
            payload_identity=payload_identity,
            delivery_hint=delivery_hint,
            headers=headers,
        )

    def submit_envelope(self, envelope: transport_pb2.Envelope) -> None:
        self._client.submit_envelope(envelope)

    def submit_typed_envelope(self, envelope: transport_pb2.Envelope) -> None:
        self._client.submit_typed_envelope(envelope)

    def submit_raw_envelope(self, envelope: transport_pb2.Envelope) -> None:
        self._client.submit_raw_envelope(envelope)

    def register_handler(
        self,
        target: str,
        handler: HandlerFn,
        typed_replies: bool = True,
    ) -> None:
        self._client.register_handler(target=target, handler=handler, typed_replies=typed_replies)

    def register_raw_handler(
        self,
        target: str,
        handler: HandlerFn,
    ) -> None:
        self._client.register_raw_handler(target=target, handler=handler)

    def client_stats(self) -> RuntimeClientStats:
        return self._client.snapshot_stats()

    def runtime_info(self) -> dict[str, Any]:
        return self._client.runtime_info_snapshot()

    def runtime_config(self) -> dict[str, Any]:
        return self._client.runtime_config_snapshot()

    def health(self) -> dict[str, Any]:
        return self._client.health_snapshot()

    def stats(self) -> dict[str, Any]:
        return self._client.stats_snapshot()

    def runtime_snapshot(self) -> dict[str, Any]:
        return self._client.runtime_snapshot()

    def apply_snapshot(
        self,
        generation: int,
        routes: list | tuple,
        source_connector: str | None = None,
        seq: int = 1,
        overload_policy=None,
    ) -> None:
        self._client.apply_snapshot(
            generation=generation,
            routes=routes,
            source_connector=source_connector or self.start_spec.system_name,
            seq=seq,
            overload_policy=overload_policy,
        )

    def monitor_is_enabled(self) -> bool:
        return self._client.monitor_is_enabled()

    def monitor_snapshot(self, signal_count: int = 0) -> MonitorSnapshot:
        return self._client.monitor_snapshot(signal_count=signal_count)

    def await_next_monitor(self, timeout_ms: int = 1000) -> MonitorSnapshot | None:
        return self._client.await_next_monitor(timeout_ms=timeout_ms)

    def await_applied_generation_at_least(
        self,
        generation: int,
        timeout_ms: int = 1000,
    ) -> MonitorSnapshot | None:
        return self._client.await_applied_generation_at_least(
            generation=generation,
            timeout_ms=timeout_ms,
        )

    def close(self) -> None:
        with self._factory_lock:
            if self._closed:
                return
            try:
                self._client.close()
            finally:
                self._closed = True
                if ConnectorOrchestrator._active is self:
                    ConnectorOrchestrator._active = None

    def __enter__(self) -> "ConnectorOrchestrator":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()


RuntimeHost = ConnectorOrchestrator
