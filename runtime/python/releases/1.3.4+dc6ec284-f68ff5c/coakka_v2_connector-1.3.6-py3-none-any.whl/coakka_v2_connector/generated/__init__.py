# Generated protobuf package container for the internal Python connector.
