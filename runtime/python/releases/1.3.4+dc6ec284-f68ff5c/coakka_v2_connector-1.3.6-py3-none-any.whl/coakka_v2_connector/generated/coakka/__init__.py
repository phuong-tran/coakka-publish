"""Generated coakka protobuf package for the Python/JVM demo."""
