"""Generated coakka.v2 protobuf modules for the Python/JVM demo."""
