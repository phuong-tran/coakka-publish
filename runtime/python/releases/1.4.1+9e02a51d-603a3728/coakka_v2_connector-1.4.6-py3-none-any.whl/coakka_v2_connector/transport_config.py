from __future__ import annotations

import ctypes
from dataclasses import dataclass
from enum import IntEnum, IntFlag


class CoakkaStatus(IntEnum):
    OK = 0
    ERR_INVALID_ARG = -1
    ERR_NOMEM = -2
    ERR_BAD_STATE = -3
    ERR_STALE_GENERATION = -4
    ERR_IO = -5
    ERR_WOULD_BLOCK = -6
    ERR_CLOSED = -7
    ERR_FEATURE_UNAVAILABLE = -8
    ERR_FEATURE_NOT_ENTITLED = -9


class RuntimeCapability(IntFlag):
    TCP_BOUNDED_POOL = 1 << 0
    TCP_POOL_TUNING = 1 << 1
    TCP_TLS = 1 << 2
    TCP_MUTUAL_TLS = 1 << 3
    TLS_CREDENTIAL_RELOAD = 1 << 4
    TLS_EXTERNAL_PROVIDER = 1 << 5
    TCP_PERSISTENT_SINGLE_FLIGHT = 1 << 6
    TCP_MULTIPLEXING = 1 << 7


class RuntimeTcpConnectionMode(IntEnum):
    PER_EXCHANGE = 0
    BOUNDED_POOL = 1
    PERSISTENT_SINGLE_FLIGHT = 2
    MULTIPLEXING = 3


class RuntimeTcpSecurityMode(IntEnum):
    PLAINTEXT = 0
    TLS = 1
    MUTUAL_TLS = 2


class RuntimeTlsReloadMode(IntEnum):
    GRACEFUL = 0
    DRAIN_EXISTING_CONNECTIONS = 1


class RuntimeTransportApplyReason(IntEnum):
    NONE = 0
    INVALID_ARGUMENT = 1
    FEATURE_UNAVAILABLE = 2
    FEATURE_NOT_ENTITLED = 3
    RUNTIME_NOT_CONFIGURABLE = 4
    SECURITY_MODE_CHANGE_REQUIRES_RECREATE = 5
    STALE_CREDENTIAL_GENERATION = 6
    CREDENTIAL_REJECTED = 7
    RESOURCE_FAILURE = 8
    ADAPTER_REJECTED = 9


class RuntimeTcpConnectionValidationCode(IntEnum):
    VALID = 0
    INVALID_STRUCT_SIZE = 1
    UNKNOWN_FIELD = 2
    MODE_REQUIRED = 3
    UNKNOWN_MODE = 4
    FIELD_NOT_APPLICABLE = 5
    VALUE_OUT_OF_RANGE = 6
    FEATURE_UNAVAILABLE = 7
    FEATURE_NOT_ENTITLED = 8
    RESERVED_NONZERO = 9
    FIELD_OUTSIDE_STRUCT = 10
    VALUE_WITHOUT_FIELD = 11


class RuntimeTcpSecurityValidationCode(IntEnum):
    VALID = 0
    INVALID_STRUCT_SIZE = 1
    UNKNOWN_FIELD = 2
    MODE_REQUIRED = 3
    UNKNOWN_MODE = 4
    RESERVED_NONZERO = 5
    FIELD_OUTSIDE_STRUCT = 6
    FIELD_NOT_APPLICABLE = 7
    REQUIRED_FIELD_MISSING = 8
    SOURCE_UNAVAILABLE = 9
    FEATURE_UNAVAILABLE = 10
    INVALID_GENERATION = 11
    CREDENTIAL_ID_TOO_LONG = 12
    VALUE_WITHOUT_FIELD = 13


@dataclass(frozen=True)
class RuntimeTcpConnectionStrategySpec:
    mode: RuntimeTcpConnectionMode | int = RuntimeTcpConnectionMode.PER_EXCHANGE
    max_connections: int | None = None
    max_requests_per_connection: int | None = None
    idle_timeout_ms: int | None = None


@dataclass(frozen=True)
class RuntimeTcpSecuritySpec:
    mode: RuntimeTcpSecurityMode | int = RuntimeTcpSecurityMode.PLAINTEXT
    reload_mode: RuntimeTlsReloadMode | int = RuntimeTlsReloadMode.GRACEFUL
    credential_generation: int = 0
    credential_id: str = ""
    ca_certificate_file: str = ""
    identity_certificate_file: str = ""
    private_key_file: str = ""


@dataclass(frozen=True)
class RuntimeTcpConnectionConfigSnapshot:
    defaults_revision: int
    mode: RuntimeTcpConnectionMode | int
    applicable_fields: int
    explicitly_configured_fields: int
    defaulted_fields: int
    configurable_fields: int
    max_connections: int
    max_requests_per_connection: int
    idle_timeout_ms: int


@dataclass(frozen=True)
class RuntimeTcpConnectionApplyResult:
    status: int
    changed: bool
    reason: int
    reason_name: str
    runtime_state: int
    validation_code: int
    validation_field: int
    minimum_value: int
    maximum_value: int
    active_config: RuntimeTcpConnectionConfigSnapshot

    def applied(self) -> bool:
        return self.status == CoakkaStatus.OK


@dataclass(frozen=True)
class RuntimeTcpSecurityInfoSnapshot:
    mode: RuntimeTcpSecurityMode | int
    credential_source_kind: int
    reload_mode: RuntimeTlsReloadMode | int
    reload_status: int
    credential_generation: int
    credential_id: str
    minimum_protocol_version: int
    maximum_protocol_version: int
    inbound_verification_flags: int
    outbound_verification_flags: int
    identity_not_before_unix_seconds: int
    identity_not_after_unix_seconds: int
    identity_fingerprint_sha256: str


@dataclass(frozen=True)
class RuntimeTcpSecurityApplyResult:
    status: int
    changed: bool
    reason: int
    reason_name: str
    runtime_state: int
    validation_code: int
    validation_field: int
    active_security: RuntimeTcpSecurityInfoSnapshot

    def applied(self) -> bool:
        return self.status == CoakkaStatus.OK


@dataclass(frozen=True)
class RuntimeCapabilitiesSnapshot:
    edition: int
    license_status: int
    compiled_capabilities: int
    entitled_capabilities: int
    effective_capabilities: int
    tcp_connection_defaults_revision: int

    def supports(self, capabilities: RuntimeCapability | int) -> bool:
        requested = int(capabilities)
        return self.effective_capabilities & requested == requested


def _status_name(status: int) -> str:
    try:
        return CoakkaStatus(status).name.lower()
    except ValueError:
        return "unknown_status"


class RuntimeTcpConnectionApplyError(RuntimeError):
    def __init__(self, result: RuntimeTcpConnectionApplyResult):
        self.result = result
        super().__init__(
            f"tcp connection strategy apply failed rc={result.status} "
            f"({_status_name(result.status)}) reason={result.reason_name} "
            f"validation={result.validation_code} category=CONFIGURATION"
        )


class RuntimeTcpSecurityApplyError(RuntimeError):
    def __init__(self, result: RuntimeTcpSecurityApplyResult):
        self.result = result
        super().__init__(
            f"tcp security apply failed rc={result.status} "
            f"({_status_name(result.status)}) reason={result.reason_name} "
            f"validation={result.validation_code} category=CONFIGURATION"
        )


class _RuntimeCapabilities(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("edition", ctypes.c_uint32),
        ("license_status", ctypes.c_uint32),
        ("compiled_capabilities", ctypes.c_uint64),
        ("entitled_capabilities", ctypes.c_uint64),
        ("effective_capabilities", ctypes.c_uint64),
        ("tcp_connection_defaults_revision", ctypes.c_uint32),
        ("reserved", ctypes.c_uint32),
    ]


class _TcpConnectionOptions(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("fields", ctypes.c_uint64),
        ("mode", ctypes.c_uint32),
        ("reserved", ctypes.c_uint32),
        ("max_connections", ctypes.c_uint32),
        ("reserved2", ctypes.c_uint32),
        ("max_requests_per_connection", ctypes.c_uint64),
        ("idle_timeout_ms", ctypes.c_uint64),
    ]


class _TcpConnectionValidation(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("code", ctypes.c_uint32),
        ("reserved", ctypes.c_uint32),
        ("field", ctypes.c_uint64),
        ("minimum_value", ctypes.c_uint64),
        ("maximum_value", ctypes.c_uint64),
    ]


class _TcpConnectionConfig(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("defaults_revision", ctypes.c_uint32),
        ("mode", ctypes.c_uint32),
        ("applicable_fields", ctypes.c_uint64),
        ("explicitly_configured_fields", ctypes.c_uint64),
        ("defaulted_fields", ctypes.c_uint64),
        ("configurable_fields", ctypes.c_uint64),
        ("max_connections", ctypes.c_uint32),
        ("reserved", ctypes.c_uint32),
        ("max_requests_per_connection", ctypes.c_uint64),
        ("idle_timeout_ms", ctypes.c_uint64),
    ]


class _TcpConnectionApplyResult(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("apply_status", ctypes.c_int32),
        ("changed", ctypes.c_uint32),
        ("reason", ctypes.c_uint32),
        ("runtime_state", ctypes.c_uint32),
        ("validation", _TcpConnectionValidation),
        ("effective_config", _TcpConnectionConfig),
    ]


class _TcpSecurityOptions(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("fields", ctypes.c_uint64),
        ("mode", ctypes.c_uint32),
        ("credential_source_kind", ctypes.c_uint32),
        ("reload_mode", ctypes.c_uint32),
        ("reserved", ctypes.c_uint32),
        ("credential_generation", ctypes.c_uint64),
        ("credential_id", ctypes.c_char_p),
        ("ca_certificate_file", ctypes.c_char_p),
        ("identity_certificate_file", ctypes.c_char_p),
        ("private_key_file", ctypes.c_char_p),
    ]


class _TcpSecurityValidation(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("code", ctypes.c_uint32),
        ("reserved", ctypes.c_uint32),
        ("field", ctypes.c_uint64),
    ]


class _TcpSecurityConfig(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("mode", ctypes.c_uint32),
        ("credential_source_kind", ctypes.c_uint32),
        ("reload_mode", ctypes.c_uint32),
        ("reload_status", ctypes.c_uint32),
        ("credential_generation", ctypes.c_uint64),
        ("credential_id", ctypes.c_char_p),
    ]


class _TcpSecurityIdentityInfo(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("minimum_protocol_version", ctypes.c_uint32),
        ("maximum_protocol_version", ctypes.c_uint32),
        ("inbound_verification_flags", ctypes.c_uint64),
        ("outbound_verification_flags", ctypes.c_uint64),
        ("identity_not_before_unix_seconds", ctypes.c_int64),
        ("identity_not_after_unix_seconds", ctypes.c_int64),
        ("credential_id_value", ctypes.c_char * 128),
        ("identity_fingerprint_sha256", ctypes.c_char * 65),
    ]


class _TcpSecurityInfo(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("config", _TcpSecurityConfig),
        ("identity", _TcpSecurityIdentityInfo),
    ]


class _TcpSecurityApplyResult(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("apply_status", ctypes.c_int32),
        ("changed", ctypes.c_uint32),
        ("reason", ctypes.c_uint32),
        ("runtime_state", ctypes.c_uint32),
        ("validation", _TcpSecurityValidation),
        ("active_security", _TcpSecurityInfo),
    ]


TRANSPORT_ABI_SIZES = {
    "capabilities": ctypes.sizeof(_RuntimeCapabilities),
    "connection_options": ctypes.sizeof(_TcpConnectionOptions),
    "connection_validation": ctypes.sizeof(_TcpConnectionValidation),
    "connection_config": ctypes.sizeof(_TcpConnectionConfig),
    "connection_apply_result": ctypes.sizeof(_TcpConnectionApplyResult),
    "security_options": ctypes.sizeof(_TcpSecurityOptions),
    "security_validation": ctypes.sizeof(_TcpSecurityValidation),
    "security_config": ctypes.sizeof(_TcpSecurityConfig),
    "security_identity": ctypes.sizeof(_TcpSecurityIdentityInfo),
    "security_info": ctypes.sizeof(_TcpSecurityInfo),
    "security_apply_result": ctypes.sizeof(_TcpSecurityApplyResult),
}

_CONNECTION_MODE = 1 << 0
_CONNECTION_MAX_CONNECTIONS = 1 << 1
_CONNECTION_MAX_REQUESTS = 1 << 2
_CONNECTION_IDLE_TIMEOUT = 1 << 3
_SECURITY_MODE = 1 << 0
_SECURITY_SOURCE = 1 << 1
_SECURITY_RELOAD_MODE = 1 << 2
_SECURITY_GENERATION = 1 << 3
_SECURITY_CREDENTIAL_ID = 1 << 4
_SECURITY_CA_FILE = 1 << 5
_SECURITY_IDENTITY_FILE = 1 << 6
_SECURITY_KEY_FILE = 1 << 7
_SECURITY_ALL = (1 << 8) - 1
_CREDENTIAL_SOURCE_FILE = 1


class RuntimeTransportBindings:
    def __init__(self, lib: ctypes.CDLL):
        self._lib = lib
        lib.coakka_v2_runtime_get_capabilities.argtypes = [ctypes.POINTER(_RuntimeCapabilities)]
        lib.coakka_v2_runtime_get_capabilities.restype = ctypes.c_int
        lib.coakka_v2_runtime_apply_tcp_connection_options_ex.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(_TcpConnectionOptions),
            ctypes.POINTER(_TcpConnectionApplyResult),
        ]
        lib.coakka_v2_runtime_apply_tcp_connection_options_ex.restype = ctypes.c_int
        lib.coakka_v2_runtime_get_tcp_connection_config.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(_TcpConnectionConfig),
        ]
        lib.coakka_v2_runtime_get_tcp_connection_config.restype = ctypes.c_int
        lib.coakka_v2_runtime_apply_tcp_security_options_ex.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(_TcpSecurityOptions),
            ctypes.POINTER(_TcpSecurityApplyResult),
        ]
        lib.coakka_v2_runtime_apply_tcp_security_options_ex.restype = ctypes.c_int
        lib.coakka_v2_runtime_get_tcp_security_info.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(_TcpSecurityInfo),
        ]
        lib.coakka_v2_runtime_get_tcp_security_info.restype = ctypes.c_int
        lib.coakka_v2_transport_apply_reason_name.argtypes = [ctypes.c_uint32]
        lib.coakka_v2_transport_apply_reason_name.restype = ctypes.c_char_p

    def read_capabilities(self) -> RuntimeCapabilitiesSnapshot:
        native = _RuntimeCapabilities(struct_size=ctypes.sizeof(_RuntimeCapabilities))
        self._require_ok(
            self._lib.coakka_v2_runtime_get_capabilities(ctypes.byref(native)),
            "runtime_get_capabilities",
        )
        return RuntimeCapabilitiesSnapshot(
            edition=native.edition,
            license_status=native.license_status,
            compiled_capabilities=native.compiled_capabilities,
            entitled_capabilities=native.entitled_capabilities,
            effective_capabilities=native.effective_capabilities,
            tcp_connection_defaults_revision=native.tcp_connection_defaults_revision,
        )

    def apply_connection(
        self,
        runtime: int,
        spec: RuntimeTcpConnectionStrategySpec,
    ) -> RuntimeTcpConnectionApplyResult:
        options = _TcpConnectionOptions(
            struct_size=ctypes.sizeof(_TcpConnectionOptions),
            fields=_CONNECTION_MODE,
            mode=self._unsigned(spec.mode, "mode", 2**32 - 1),
        )
        if spec.max_connections is not None:
            options.fields |= _CONNECTION_MAX_CONNECTIONS
            options.max_connections = self._unsigned(
                spec.max_connections,
                "max_connections",
                2**32 - 1,
            )
        if spec.max_requests_per_connection is not None:
            options.fields |= _CONNECTION_MAX_REQUESTS
            options.max_requests_per_connection = self._unsigned(
                spec.max_requests_per_connection,
                "max_requests_per_connection",
            )
        if spec.idle_timeout_ms is not None:
            options.fields |= _CONNECTION_IDLE_TIMEOUT
            options.idle_timeout_ms = self._unsigned(spec.idle_timeout_ms, "idle_timeout_ms")
        native = _TcpConnectionApplyResult(
            struct_size=ctypes.sizeof(_TcpConnectionApplyResult)
        )
        rc = self._lib.coakka_v2_runtime_apply_tcp_connection_options_ex(
            runtime,
            ctypes.byref(options),
            ctypes.byref(native),
        )
        if rc != native.apply_status:
            raise RuntimeError(
                f"tcp connection apply returned rc={rc} but result status={native.apply_status}"
            )
        return RuntimeTcpConnectionApplyResult(
            status=native.apply_status,
            changed=bool(native.changed),
            reason=native.reason,
            reason_name=self._reason_name(native.reason),
            runtime_state=native.runtime_state,
            validation_code=native.validation.code,
            validation_field=native.validation.field,
            minimum_value=native.validation.minimum_value,
            maximum_value=native.validation.maximum_value,
            active_config=self._connection_snapshot(native.effective_config),
        )

    def get_connection(self, runtime: int) -> RuntimeTcpConnectionConfigSnapshot:
        native = _TcpConnectionConfig(struct_size=ctypes.sizeof(_TcpConnectionConfig))
        self._require_ok(
            self._lib.coakka_v2_runtime_get_tcp_connection_config(runtime, ctypes.byref(native)),
            "runtime_get_tcp_connection_config",
        )
        return self._connection_snapshot(native)

    def apply_security(
        self,
        runtime: int,
        spec: RuntimeTcpSecuritySpec,
    ) -> RuntimeTcpSecurityApplyResult:
        mode = self._unsigned(spec.mode, "mode", 2**32 - 1)
        reload_mode = self._unsigned(spec.reload_mode, "reload_mode", 2**32 - 1)
        credential_id = self._encoded_text(spec.credential_id, "credential_id")
        ca_certificate_file = self._encoded_text(
            spec.ca_certificate_file,
            "ca_certificate_file",
        )
        identity_certificate_file = self._encoded_text(
            spec.identity_certificate_file,
            "identity_certificate_file",
        )
        private_key_file = self._encoded_text(spec.private_key_file, "private_key_file")
        options = _TcpSecurityOptions(
            struct_size=ctypes.sizeof(_TcpSecurityOptions),
            fields=_SECURITY_MODE,
            mode=mode,
        )
        if mode != RuntimeTcpSecurityMode.PLAINTEXT:
            options.fields = _SECURITY_ALL
            options.credential_source_kind = _CREDENTIAL_SOURCE_FILE
            options.reload_mode = reload_mode
            options.credential_generation = self._unsigned(
                spec.credential_generation,
                "credential_generation",
            )
            options.credential_id = credential_id
            options.ca_certificate_file = ca_certificate_file
            options.identity_certificate_file = identity_certificate_file
            options.private_key_file = private_key_file
        else:
            if reload_mode != RuntimeTlsReloadMode.GRACEFUL:
                options.fields |= _SECURITY_RELOAD_MODE
                options.reload_mode = reload_mode
            if spec.credential_generation != 0:
                options.fields |= _SECURITY_GENERATION
                options.credential_generation = self._unsigned(
                    spec.credential_generation,
                    "credential_generation",
                )
            if spec.credential_id:
                options.fields |= _SECURITY_CREDENTIAL_ID
                options.credential_id = credential_id
            if (
                spec.ca_certificate_file
                or spec.identity_certificate_file
                or spec.private_key_file
            ):
                options.fields |= _SECURITY_SOURCE
                options.credential_source_kind = _CREDENTIAL_SOURCE_FILE
            if spec.ca_certificate_file:
                options.fields |= _SECURITY_CA_FILE
                options.ca_certificate_file = ca_certificate_file
            if spec.identity_certificate_file:
                options.fields |= _SECURITY_IDENTITY_FILE
                options.identity_certificate_file = identity_certificate_file
            if spec.private_key_file:
                options.fields |= _SECURITY_KEY_FILE
                options.private_key_file = private_key_file
        native = _TcpSecurityApplyResult(struct_size=ctypes.sizeof(_TcpSecurityApplyResult))
        rc = self._lib.coakka_v2_runtime_apply_tcp_security_options_ex(
            runtime,
            ctypes.byref(options),
            ctypes.byref(native),
        )
        if rc != native.apply_status:
            raise RuntimeError(
                f"tcp security apply returned rc={rc} but result status={native.apply_status}"
            )
        return RuntimeTcpSecurityApplyResult(
            status=native.apply_status,
            changed=bool(native.changed),
            reason=native.reason,
            reason_name=self._reason_name(native.reason),
            runtime_state=native.runtime_state,
            validation_code=native.validation.code,
            validation_field=native.validation.field,
            active_security=self._security_snapshot(native.active_security),
        )

    def get_security(self, runtime: int) -> RuntimeTcpSecurityInfoSnapshot:
        native = _TcpSecurityInfo(struct_size=ctypes.sizeof(_TcpSecurityInfo))
        self._require_ok(
            self._lib.coakka_v2_runtime_get_tcp_security_info(runtime, ctypes.byref(native)),
            "runtime_get_tcp_security_info",
        )
        return self._security_snapshot(native)

    def _reason_name(self, reason: int) -> str:
        value = self._lib.coakka_v2_transport_apply_reason_name(reason)
        return value.decode() if value else ""

    @staticmethod
    def _connection_snapshot(native: _TcpConnectionConfig) -> RuntimeTcpConnectionConfigSnapshot:
        return RuntimeTcpConnectionConfigSnapshot(
            defaults_revision=native.defaults_revision,
            mode=_enum_or_int(RuntimeTcpConnectionMode, native.mode),
            applicable_fields=native.applicable_fields,
            explicitly_configured_fields=native.explicitly_configured_fields,
            defaulted_fields=native.defaulted_fields,
            configurable_fields=native.configurable_fields,
            max_connections=native.max_connections,
            max_requests_per_connection=native.max_requests_per_connection,
            idle_timeout_ms=native.idle_timeout_ms,
        )

    @staticmethod
    def _security_snapshot(native: _TcpSecurityInfo) -> RuntimeTcpSecurityInfoSnapshot:
        return RuntimeTcpSecurityInfoSnapshot(
            mode=_enum_or_int(RuntimeTcpSecurityMode, native.config.mode),
            credential_source_kind=native.config.credential_source_kind,
            reload_mode=_enum_or_int(RuntimeTlsReloadMode, native.config.reload_mode),
            reload_status=native.config.reload_status,
            credential_generation=native.config.credential_generation,
            credential_id=_fixed_text(native.identity.credential_id_value),
            minimum_protocol_version=native.identity.minimum_protocol_version,
            maximum_protocol_version=native.identity.maximum_protocol_version,
            inbound_verification_flags=native.identity.inbound_verification_flags,
            outbound_verification_flags=native.identity.outbound_verification_flags,
            identity_not_before_unix_seconds=native.identity.identity_not_before_unix_seconds,
            identity_not_after_unix_seconds=native.identity.identity_not_after_unix_seconds,
            identity_fingerprint_sha256=_fixed_text(
                native.identity.identity_fingerprint_sha256
            ),
        )

    @staticmethod
    def _unsigned(value: int, field: str, maximum: int = 2**64 - 1) -> int:
        if (
            not isinstance(value, int)
            or isinstance(value, bool)
            or value < 0
            or value > maximum
        ):
            raise ValueError(f"{field} must be an integer in the range 0..{maximum}")
        return value

    @staticmethod
    def _encoded_text(value: str, field: str) -> bytes:
        if not isinstance(value, str):
            raise ValueError(f"{field} must be a string")
        if "\0" in value:
            raise ValueError(f"{field} must not contain NUL")
        return value.encode()

    @staticmethod
    def _require_ok(rc: int, what: str) -> None:
        if rc != CoakkaStatus.OK:
            raise RuntimeError(f"{what} failed rc={rc}")


def _fixed_text(value: bytes | ctypes.Array[ctypes.c_char]) -> str:
    return bytes(value).split(b"\0", 1)[0].decode()


def _enum_or_int(enum_type: type[IntEnum], value: int) -> IntEnum | int:
    try:
        return enum_type(value)
    except ValueError:
        return value
