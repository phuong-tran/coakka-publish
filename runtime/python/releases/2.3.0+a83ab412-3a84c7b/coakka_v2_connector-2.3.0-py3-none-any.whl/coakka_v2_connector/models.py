from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum, IntFlag, StrEnum
from typing import Sequence, TypeAlias

from .generated.coakka.v2 import control_pb2, transport_pb2
from .transport_config import RuntimeTcpConnectionStrategySpec, RuntimeTcpSecuritySpec


class MessageKind(IntEnum):
    """Wire-level envelope role."""
    UNSPECIFIED = transport_pb2.MESSAGE_KIND_UNSPECIFIED
    REQUEST = transport_pb2.MESSAGE_KIND_REQUEST
    RESPONSE = transport_pb2.MESSAGE_KIND_RESPONSE
    EVENT = transport_pb2.MESSAGE_KIND_EVENT


class BusinessStatus(IntEnum):
    """Application result carried by a response envelope."""
    UNSPECIFIED = transport_pb2.BUSINESS_STATUS_UNSPECIFIED
    OK = transport_pb2.BUSINESS_STATUS_OK
    ERROR = transport_pb2.BUSINESS_STATUS_ERROR


class DeliveryHint(IntEnum):
    """Caller routing constraint applied without changing message semantics."""
    UNSPECIFIED = transport_pb2.DELIVERY_HINT_UNSPECIFIED
    ROUTER_DEFAULT = transport_pb2.DELIVERY_HINT_ROUTER_DEFAULT
    PREFER_LOCAL = transport_pb2.DELIVERY_HINT_PREFER_LOCAL
    REQUIRE_LOCAL = transport_pb2.DELIVERY_HINT_REQUIRE_LOCAL
    REQUIRE_REMOTE = transport_pb2.DELIVERY_HINT_REQUIRE_REMOTE


class PayloadFormat(IntEnum):
    """Declared serialization format for typed payload bytes."""
    UNSPECIFIED = transport_pb2.PAYLOAD_FORMAT_UNSPECIFIED
    JSON = transport_pb2.PAYLOAD_FORMAT_JSON
    PROTOBUF = transport_pb2.PAYLOAD_FORMAT_PROTOBUF
    THRIFT = transport_pb2.PAYLOAD_FORMAT_THRIFT
    MSGPACK = transport_pb2.PAYLOAD_FORMAT_MSGPACK
    TEXT = transport_pb2.PAYLOAD_FORMAT_PLAIN_TEXT
    PLAIN_TEXT = transport_pb2.PAYLOAD_FORMAT_PLAIN_TEXT
    BINARY = transport_pb2.PAYLOAD_FORMAT_BINARY


class RouteStrategy(IntEnum):
    """App-host route resolution strategy for a target's endpoints."""
    UNSPECIFIED = control_pb2.ROUTE_RESOLUTION_STRATEGY_UNSPECIFIED
    SINGLE_OWNER = control_pb2.ROUTE_RESOLUTION_STRATEGY_SINGLE_OWNER
    WEIGHTED_ROUND_ROBIN = control_pb2.ROUTE_RESOLUTION_STRATEGY_WEIGHTED_ROUND_ROBIN
    RENDEZVOUS_HASH = control_pb2.ROUTE_RESOLUTION_STRATEGY_RENDEZVOUS_HASH


class OverloadMode(IntEnum):
    """Bounded-queue admission behavior under overload."""
    REJECT = control_pb2.OVERLOAD_MODE_REJECT
    DROP_EXPIRED_FIRST = control_pb2.OVERLOAD_MODE_DROP_EXPIRED_FIRST
    DROP_ONE_WAY_FIRST = control_pb2.OVERLOAD_MODE_DROP_ONE_WAY_FIRST


class EndpointFlag(IntFlag):
    """Endpoint availability and locality annotations."""
    NONE = 0
    LOCAL = 1
    UNAVAILABLE = 1 << 1


@dataclass(frozen=True)
class PayloadIdentity:
    """Stable message type, schema version, and serialization format."""
    message_type: str
    payload_schema_version: int = 1
    payload_format: PayloadFormat = PayloadFormat.UNSPECIFIED

    def is_typed(self) -> bool:
        """Return whether all fields required for a typed payload are present."""
        return (
            self.message_type.strip() != ""
            and self.payload_schema_version >= 1
            and self.payload_format != PayloadFormat.UNSPECIFIED
        )

    def require_typed(self, what: str = "payload identity") -> "PayloadIdentity":
        """Validate typed identity fields and return this immutable value."""
        if self.message_type.strip() == "":
            raise ValueError(f"{what} requires message_type")
        if self.payload_schema_version < 1:
            raise ValueError(f"{what} requires payload_schema_version >= 1")
        if self.payload_format == PayloadFormat.UNSPECIFIED:
            raise ValueError(f"{what} requires declared payload_format")
        return self

    @classmethod
    def text(cls, message_type: str, payload_schema_version: int = 1) -> "PayloadIdentity":
        """Build a plain-text identity for the named type and schema version."""
        return cls(
            message_type=message_type,
            payload_schema_version=payload_schema_version,
            payload_format=PayloadFormat.TEXT,
        )


@dataclass(frozen=True)
class EndpointSpec:
    """One route endpoint; port is 1..65535 and weight is strategy input."""
    host: str
    port: int
    weight: int = 1
    flags: int = int(EndpointFlag.NONE)


@dataclass(frozen=True)
class RouteSpec:
    """Target route plus one or more endpoints and its resolution strategy."""
    target: str
    endpoints: Sequence[EndpointSpec]
    strategy: RouteStrategy = RouteStrategy.SINGLE_OWNER
    route_key_hint: str = ""
    flags: int = 0

    def require_valid(self) -> "RouteSpec":
        """Reject an empty target or endpoint set and return this value."""
        if self.target.strip() == "":
            raise ValueError("route requires target")
        if not self.endpoints:
            raise ValueError(f"route target={self.target} requires at least one endpoint")
        return self


def local_route(target: str, port: int = 9001) -> RouteSpec:
    """Build a single-owner loopback route for ``target`` and ``port``."""
    return RouteSpec(
        target=target,
        endpoints=[
            EndpointSpec(
                host="127.0.0.1",
                port=port,
                flags=int(EndpointFlag.LOCAL),
            ),
        ],
    )


@dataclass(frozen=True)
class RuntimeOverloadPolicy:
    """Bounded admission policy; unsupported modes fail validation explicitly."""
    ingress_mode: OverloadMode = OverloadMode.REJECT
    local_delivery_mode: OverloadMode = OverloadMode.REJECT
    remote_outbound_mode: OverloadMode = OverloadMode.REJECT
    remote_outbound_reply_reserve_slots: int = 0

    def require_valid(self) -> "RuntimeOverloadPolicy":
        """Validate modes and reserve-slot bounds, then return this value."""
        if self.ingress_mode != OverloadMode.REJECT:
            raise ValueError("overload_policy ingress_mode currently supports only REJECT")
        if self.local_delivery_mode != OverloadMode.REJECT:
            raise ValueError("overload_policy local_delivery_mode currently supports only REJECT")
        if self.remote_outbound_reply_reserve_slots < 0:
            raise ValueError("overload_policy requires remote_outbound_reply_reserve_slots >= 0")
        return self


@dataclass(frozen=True)
class ConnectorConfig:
    """Validated runtime identity, routes, queue bounds, and transport policy.

    ``queue_capacity`` is a positive item count. ``generation`` is a strictly
    positive monotonic control-snapshot generation. TLS paths and credentials
    remain app-host secrets and must not enter logs.
    """
    system_name: str
    node_id: str
    routes: Sequence[RouteSpec]
    strict_no_drop: bool = True
    queue_capacity: int = 128
    enable_monitor: bool = True
    separate_delivered_request_lane: bool = True
    generation: int = 1
    overload_policy: RuntimeOverloadPolicy | None = None
    connection_strategy: RuntimeTcpConnectionStrategySpec | None = None
    security: RuntimeTcpSecuritySpec | None = None

    def require_valid(self) -> "ConnectorConfig":
        """Validate identity, bounds, routes, and optional policies."""
        if self.system_name.strip() == "":
            raise ValueError("connector config requires system_name")
        if self.node_id.strip() == "":
            raise ValueError("connector config requires node_id")
        if self.queue_capacity < 1:
            raise ValueError("connector config requires queue_capacity >= 1")
        if self.generation < 1:
            raise ValueError("connector config requires generation >= 1")
        if self.overload_policy is not None:
            self.overload_policy.require_valid()
        if not self.routes:
            raise ValueError("connector config requires at least one route")
        for route in self.routes:
            route.require_valid()
        return self


@dataclass(frozen=True)
class ConnectorStartSpec:
    """Production-shaped input used to create one owned runtime host.

    All values are copied into the connector/runtime startup contract. The
    connection strategy and security mode become immutable after start except
    for a supported newer TLS credential generation.
    """
    system_name: str
    node_id: str
    routes: Sequence[RouteSpec]
    strict_no_drop: bool = True
    queue_capacity: int = 128
    enable_monitor: bool = True
    separate_delivered_request_lane: bool = True
    generation: int = 1
    overload_policy: RuntimeOverloadPolicy | None = None
    connection_strategy: RuntimeTcpConnectionStrategySpec | None = None
    security: RuntimeTcpSecuritySpec | None = None

    def require_valid(self) -> "ConnectorStartSpec":
        """Validate the equivalent connector configuration and return this spec."""
        self.to_connector_config().require_valid()
        return self

    def to_connector_config(self) -> ConnectorConfig:
        """Project this start specification into the validated config model."""
        return ConnectorConfig(
            system_name=self.system_name,
            node_id=self.node_id,
            routes=self.routes,
            strict_no_drop=self.strict_no_drop,
            queue_capacity=self.queue_capacity,
            enable_monitor=self.enable_monitor,
            separate_delivered_request_lane=self.separate_delivered_request_lane,
            generation=self.generation,
            overload_policy=self.overload_policy,
            connection_strategy=self.connection_strategy,
            security=self.security,
        )


@dataclass(frozen=True)
class SubmittedRequest:
    """Correlation identifiers returned after bounded request admission."""
    message_id: str
    correlation_id: str


class RequestTerminalEventKind(StrEnum):
    """Discriminator for a response or deadletter terminal event."""
    RESPONSE = "response"
    DEADLETTER = "deadletter"


@dataclass(frozen=True)
class RequestTerminalResponse:
    """Copied successful terminal response for one submitted request."""
    request_message_id: str
    correlation_id: str
    envelope: transport_pb2.Envelope
    kind: RequestTerminalEventKind = field(default=RequestTerminalEventKind.RESPONSE, init=False)


@dataclass(frozen=True)
class RequestTerminalDeadletter:
    """Copied terminal delivery failure for one submitted request."""
    request_message_id: str
    correlation_id: str
    deadletter: transport_pb2.Deadletter
    kind: RequestTerminalEventKind = field(default=RequestTerminalEventKind.DEADLETTER, init=False)


RequestTerminalEvent: TypeAlias = RequestTerminalResponse | RequestTerminalDeadletter


@dataclass(frozen=True)
class ObservedDeadletter:
    """Deadletter plus optional correlation with a connector-owned request."""
    deadletter: transport_pb2.Deadletter
    request_message_id: str | None
    correlation_id: str | None
    matched_pending_request: bool
