from __future__ import annotations

import ctypes
import json
import os
import queue
import select
import threading
import time
import uuid
from concurrent.futures import Future, TimeoutError as FutureTimeoutError
from dataclasses import dataclass
from typing import Any, Callable, Iterator, Mapping

from .generated.coakka.v2 import control_pb2, transport_pb2
from .models import (
    BusinessStatus,
    ConnectorConfig,
    DeliveryHint,
    MessageKind,
    ObservedDeadletter,
    PayloadFormat,
    PayloadIdentity,
    RequestTerminalDeadletter,
    RequestTerminalEvent,
    RequestTerminalResponse,
    SubmittedRequest,
)
from .transport_config import (
    RuntimeCapabilitiesSnapshot,
    RuntimeTcpConnectionApplyError,
    RuntimeTcpConnectionApplyResult,
    RuntimeTcpConnectionConfigSnapshot,
    RuntimeTcpConnectionStrategySpec,
    RuntimeTcpSecurityApplyError,
    RuntimeTcpSecurityApplyResult,
    RuntimeTcpSecurityInfoSnapshot,
    RuntimeTcpSecuritySpec,
    RuntimeTransportBindings,
)

if os.name == "nt":
    import msvcrt

    _peek_named_pipe = ctypes.WinDLL("kernel32", use_last_error=True).PeekNamedPipe
    _peek_named_pipe.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_uint32,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint32),
        ctypes.c_void_p,
    ]
    _peek_named_pipe.restype = ctypes.c_int

COAKKA_OK = 0
COAKKA_ABI_VERSION = 1
HOST_HANDLES_ENABLE_MONITOR = 1 << 0
HOST_HANDLES_SEPARATE_DELIVERED_REQUEST_LANE = 1 << 1


class RuntimeConfig(ctypes.Structure):
    _fields_ = [
        ("system_name", ctypes.c_char_p),
        ("node_id", ctypes.c_char_p),
        ("strict_no_drop", ctypes.c_int),
        ("queue_capacity", ctypes.c_int),
    ]


class RuntimeInfo(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("abi_version", ctypes.c_uint32),
        ("feature_flags", ctypes.c_uint32),
        ("runtime_version", ctypes.c_char_p),
        ("git_commit", ctypes.c_char_p),
        ("southbound_backend", ctypes.c_char_p),
        ("allocator_backend", ctypes.c_char_p),
        ("docs_hint", ctypes.c_char_p),
    ]


class RuntimeConfigView(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("system_name", ctypes.c_char_p),
        ("node_id", ctypes.c_char_p),
        ("strict_no_drop", ctypes.c_int),
        ("queue_capacity", ctypes.c_int),
        ("request_max_frame_size", ctypes.c_size_t),
        ("local_dispatch_batch_limit", ctypes.c_size_t),
        ("runtime_state", ctypes.c_int),
        ("snapshot_present", ctypes.c_uint32),
        ("applied_generation", ctypes.c_uint64),
        ("route_count", ctypes.c_size_t),
        ("southbound_bind_host", ctypes.c_char_p),
        ("southbound_bind_port", ctypes.c_uint16),
        ("configured_ingress_overload_mode", ctypes.c_uint32),
        ("configured_local_delivery_overload_mode", ctypes.c_uint32),
        ("configured_remote_outbound_overload_mode", ctypes.c_uint32),
        ("configured_remote_outbound_reply_reserve_slots", ctypes.c_size_t),
        ("effective_ingress_overload_mode", ctypes.c_uint32),
        ("effective_local_delivery_overload_mode", ctypes.c_uint32),
        ("effective_remote_outbound_overload_mode", ctypes.c_uint32),
        ("effective_remote_outbound_reply_reserve_slots", ctypes.c_size_t),
    ]


class HostHandles(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("flags", ctypes.c_uint32),
        ("request_write_fd", ctypes.c_int),
        ("response_read_fd", ctypes.c_int),
        ("deadletter_read_fd", ctypes.c_int),
        ("control_write_fd", ctypes.c_int),
        ("monitor_read_fd", ctypes.c_int),
        ("delivered_request_read_fd", ctypes.c_int),
    ]


class RuntimeHealth(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("runtime_state", ctypes.c_int),
        ("flags", ctypes.c_uint32),
        ("applied_generation", ctypes.c_uint64),
    ]


class RuntimeStats(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("applied_generation", ctypes.c_uint64),
        ("route_count", ctypes.c_size_t),
        ("runtime_state", ctypes.c_int),
        ("ingress_queue_capacity", ctypes.c_size_t),
        ("ingress_queue_depth", ctypes.c_size_t),
        ("ingress_queue_high_watermark", ctypes.c_size_t),
        ("queue_rejected_count", ctypes.c_uint64),
        ("route_miss_count", ctypes.c_uint64),
        ("deadletter_count", ctypes.c_uint64),
        ("delivery_failed_count", ctypes.c_uint64),
        ("caf_send_failed_count", ctypes.c_uint64),
        ("southbound_submit_attempt_count", ctypes.c_uint64),
        ("southbound_probe_connect_success_count", ctypes.c_uint64),
        ("southbound_probe_connect_failure_count", ctypes.c_uint64),
        ("request_max_frame_size", ctypes.c_size_t),
        ("local_dispatch_batch_limit", ctypes.c_size_t),
        ("delivered_request_outbound_queue_capacity", ctypes.c_size_t),
        ("delivered_request_outbound_queue_depth", ctypes.c_size_t),
        ("delivered_request_outbound_queue_high_watermark", ctypes.c_size_t),
        ("delivered_request_outbound_enqueue_block_count", ctypes.c_uint64),
        ("response_outbound_queue_capacity", ctypes.c_size_t),
        ("response_outbound_queue_depth", ctypes.c_size_t),
        ("response_outbound_queue_high_watermark", ctypes.c_size_t),
        ("response_outbound_enqueue_block_count", ctypes.c_uint64),
        ("deadletter_outbound_queue_capacity", ctypes.c_size_t),
        ("deadletter_outbound_queue_depth", ctypes.c_size_t),
        ("deadletter_outbound_queue_high_watermark", ctypes.c_size_t),
        ("deadletter_outbound_enqueue_block_count", ctypes.c_uint64),
        ("remote_reply_timeout_count", ctypes.c_uint64),
        ("late_remote_reply_drop_count", ctypes.c_uint64),
        ("remote_outbound_queue_capacity", ctypes.c_size_t),
        ("remote_outbound_queue_depth", ctypes.c_size_t),
        ("remote_outbound_queue_high_watermark", ctypes.c_size_t),
        ("remote_outbound_queue_rejected_count", ctypes.c_uint64),
        ("remote_outbound_expired_drop_count", ctypes.c_uint64),
        ("endpoint_unavailable_count", ctypes.c_uint64),
        ("remote_response_forwarded_count", ctypes.c_uint64),
        ("remote_deadletter_forwarded_count", ctypes.c_uint64),
        ("drained_route_count", ctypes.c_size_t),
        ("control_rejected_count", ctypes.c_uint64),
        ("control_invalid_count", ctypes.c_uint64),
        ("control_stale_generation_count", ctypes.c_uint64),
        ("control_bad_state_count", ctypes.c_uint64),
        ("control_io_count", ctypes.c_uint64),
        ("remote_outbound_reply_reserve_slots", ctypes.c_size_t),
        ("remote_outbound_reply_reservation_reject_count", ctypes.c_uint64),
        ("ingress_overload_mode", ctypes.c_uint32),
        ("local_delivery_overload_mode", ctypes.c_uint32),
        ("remote_outbound_overload_mode", ctypes.c_uint32),
        ("monitor_event_emitted_count", ctypes.c_uint64),
        ("monitor_event_dropped_count", ctypes.c_uint64),
        ("monitor_event_emitted_lifetime_count", ctypes.c_uint64),
        ("monitor_event_dropped_lifetime_count", ctypes.c_uint64),
        ("local_work_queue_capacity", ctypes.c_size_t),
        ("local_work_queue_depth", ctypes.c_size_t),
        ("local_work_queue_high_watermark", ctypes.c_size_t),
        ("delivered_request_outbound_direct_write_count", ctypes.c_uint64),
        ("response_outbound_direct_write_count", ctypes.c_uint64),
        ("deadletter_outbound_direct_write_count", ctypes.c_uint64),
        ("remote_outbound_one_way_drop_count", ctypes.c_uint64),
    ]


class DeadletterError(RuntimeError):
    """Request failure carrying the runtime's copied deadletter projection."""
    def __init__(self, deadletter: transport_pb2.Deadletter):
        self.deadletter = deadletter
        super().__init__(f"deadletter reason={deadletter.reason} detail={deadletter.detail}")


@dataclass(frozen=True)
class RuntimeClientStats:
    """Copied connector request, response, deadletter, and observer counters."""
    pending_requests: int
    delivered_requests: int
    matched_responses: int
    matched_deadletters: int
    late_responses: int
    unhandled_deadletters: int
    terminal_event_drop_count: int
    deadletter_observation_drop_count: int = 0


@dataclass(frozen=True)
class MonitorSnapshot:
    """One consumed monitor signal plus matching health and stats projections."""
    signal_count: int
    health: dict[str, Any]
    stats: dict[str, Any]


HandlerFn = Callable[[transport_pb2.Envelope], transport_pb2.Envelope | None]


@dataclass(frozen=True)
class _RegisteredRequestHandler:
    handler: HandlerFn
    typed_replies: bool


@dataclass(frozen=True)
class _TrackedRequest:
    message_id: str
    correlation_id: str


class TerminalEventSubscription:
    """Owned bounded terminal-event subscription.

    ``get`` blocks for at most ``timeout_s`` seconds. ``close`` is idempotent,
    wakes iteration, and unregisters this subscription without closing the
    runtime client.
    """
    _CLOSED_SENTINEL = object()

    def __init__(
        self,
        subscriber_id: int,
        events: queue.Queue[RequestTerminalEvent | object],
        on_close: Callable[[int], None],
    ) -> None:
        self._subscriber_id = subscriber_id
        self._events = events
        self._on_close = on_close
        self._closed = False
        self._close_lock = threading.Lock()

    def get(self, timeout_s: float | None = None) -> RequestTerminalEvent | None:
        """Return the next event, or ``None`` on timeout or closed-and-drained."""
        if self._closed and self._events.empty():
            return None
        try:
            item = self._events.get(timeout=timeout_s)
        except queue.Empty:
            return None
        if item is self._CLOSED_SENTINEL:
            self._events.put_nowait(self._CLOSED_SENTINEL)
            return None
        return item

    def close(self) -> None:
        """Idempotently unregister this subscription and wake its iterator."""
        with self._close_lock:
            if self._closed:
                return
            self._closed = True
            self._on_close(self._subscriber_id)

    def __iter__(self) -> Iterator[RequestTerminalEvent]:
        while True:
            event = self.get()
            if event is None:
                return
            yield event

    def _enqueue_closed_sentinel(self) -> None:
        try:
            self._events.put_nowait(self._CLOSED_SENTINEL)
        except queue.Full:
            try:
                self._events.get_nowait()
            except queue.Empty:
                pass
            try:
                self._events.put_nowait(self._CLOSED_SENTINEL)
            except queue.Full:
                pass


class DeadletterSubscription:
    """Owned bounded subscription to all observed runtime deadletters.

    ``get`` blocks for at most ``timeout_s`` seconds. ``close`` is idempotent,
    wakes iteration, and unregisters only this observer.
    """
    _CLOSED_SENTINEL = object()

    def __init__(
        self,
        subscriber_id: int,
        events: queue.Queue[ObservedDeadletter | object],
        on_close: Callable[[int], None],
    ) -> None:
        self._subscriber_id = subscriber_id
        self._events = events
        self._on_close = on_close
        self._closed = False
        self._close_lock = threading.Lock()

    def get(self, timeout_s: float | None = None) -> ObservedDeadletter | None:
        """Return the next observation, or ``None`` on timeout or closure."""
        if self._closed and self._events.empty():
            return None
        try:
            item = self._events.get(timeout=timeout_s)
        except queue.Empty:
            return None
        if item is self._CLOSED_SENTINEL:
            self._events.put_nowait(self._CLOSED_SENTINEL)
            return None
        return item

    def close(self) -> None:
        """Idempotently unregister this subscription and wake its iterator."""
        with self._close_lock:
            if self._closed:
                return
            self._closed = True
            self._on_close(self._subscriber_id)

    def __iter__(self) -> Iterator[ObservedDeadletter]:
        while True:
            event = self.get()
            if event is None:
                return
            yield event

    def _enqueue_closed_sentinel(self) -> None:
        try:
            self._events.put_nowait(self._CLOSED_SENTINEL)
        except queue.Full:
            try:
                self._events.get_nowait()
            except queue.Empty:
                pass
            try:
                self._events.put_nowait(self._CLOSED_SENTINEL)
            except queue.Full:
                pass


class PythonRuntimeClient:
    """Own one started core-runtime instance and its connector worker threads.

    The constructor copies validated configuration, applies the initial control
    snapshot, and starts the runtime. Request waits use milliseconds; monitor
    subscription waits state their units explicitly. Call :meth:`close` once
    traffic stops; it is idempotent and joins workers before destroying native
    state. One instance must not be used after close.
    """
    def __init__(self, runtime_lib_path: str, config: ConnectorConfig):
        self._config = config.require_valid()
        self._lib = ctypes.CDLL(runtime_lib_path)
        self._configure_api()

        abi_version = self._lib.coakka_v2_runtime_get_abi_version()
        if abi_version != COAKKA_ABI_VERSION:
            raise RuntimeError(f"unexpected ABI version: {abi_version}")
        self._transport = RuntimeTransportBindings(self._lib)

        cfg = RuntimeConfig(
            system_name=self._config.system_name.encode(),
            node_id=self._config.node_id.encode(),
            strict_no_drop=1 if self._config.strict_no_drop else 0,
            queue_capacity=self._config.queue_capacity,
        )
        self._runtime = self._lib.coakka_v2_runtime_create(ctypes.byref(cfg))
        if not self._runtime:
            raise RuntimeError("coakka_v2_runtime_create returned null")

        self._transport_apply_lock = threading.Lock()
        self._startup_connection_result: RuntimeTcpConnectionApplyResult | None = None
        self._startup_security_result: RuntimeTcpSecurityApplyResult | None = None
        try:
            if self._config.connection_strategy is not None:
                result = self._transport.apply_connection(
                    self._runtime,
                    self._config.connection_strategy,
                )
                self._startup_connection_result = result
                if not result.applied():
                    raise RuntimeTcpConnectionApplyError(result)
            if self._config.security is not None:
                result = self._transport.apply_security(self._runtime, self._config.security)
                self._startup_security_result = result
                if not result.applied():
                    raise RuntimeTcpSecurityApplyError(result)
        except BaseException:
            self._lib.coakka_v2_runtime_destroy(self._runtime)
            raise

        self._handles = HostHandles()
        self._handles.struct_size = ctypes.sizeof(HostHandles)
        self._handles.flags = self._host_handle_flags()
        self._pending: dict[str, Future[transport_pb2.Envelope]] = {}
        self._tracked_requests_by_message_id: dict[str, _TrackedRequest] = {}
        self._tracked_request_message_ids_by_correlation_id: dict[str, str] = {}
        self._request_handlers: dict[str, _RegisteredRequestHandler] = {}
        self._terminal_event_subscribers: dict[int, queue.Queue[RequestTerminalEvent | object]] = {}
        self._deadletter_subscribers: dict[int, queue.Queue[ObservedDeadletter | object]] = {}
        self._pending_lock = threading.Lock()
        self._request_handlers_lock = threading.Lock()
        self._terminal_event_subscribers_lock = threading.Lock()
        self._deadletter_subscribers_lock = threading.Lock()
        self._submit_lock = threading.Lock()
        self._stopped = threading.Event()
        self._stats_lock = threading.Lock()
        self._delivered_requests = 0
        self._matched_responses = 0
        self._matched_deadletters = 0
        self._late_responses = 0
        self._unhandled_deadletters = 0
        self._terminal_event_drop_count = 0
        self._deadletter_observation_drop_count = 0
        self._next_terminal_subscriber_id = 1
        self._next_deadletter_subscriber_id = 1

        rc = self._lib.coakka_v2_runtime_get_host_handles(self._runtime, ctypes.byref(self._handles))
        self._require_ok(rc, "get_host_handles")

        control_bytes = self._build_control_envelope_bytes()
        rc = self._lib.coakka_v2_runtime_apply_control_envelope(
            self._runtime,
            control_bytes,
            len(control_bytes),
        )
        self._require_ok(rc, "apply_control_envelope")

        rc = self._lib.coakka_v2_runtime_start(self._runtime)
        self._require_ok(rc, "runtime_start")

        delivered_request_fd = self._handles.delivered_request_read_fd
        response_fd = self._handles.response_read_fd
        self._separate_delivered_request_lane = (
            delivered_request_fd >= 0 and delivered_request_fd != response_fd
        )
        self._request_read_fd = delivered_request_fd if delivered_request_fd >= 0 else response_fd
        self._response_thread = threading.Thread(target=self._response_loop, daemon=True)
        self._request_thread = threading.Thread(target=self._request_loop, daemon=True)
        self._deadletter_thread = threading.Thread(target=self._deadletter_loop, daemon=True)
        self._request_thread.start()
        self._response_thread.start()
        self._deadletter_thread.start()

    def ask_typed(
        self,
        source: str,
        target: str,
        payload: bytes,
        payload_identity: PayloadIdentity,
        timeout_ms: int = 5000,
        operation: str = "ask",
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> transport_pb2.Envelope:
        """Submit a typed request and block up to ``timeout_ms`` for its terminal response."""
        envelope = self.make_typed_request(
            source=source,
            target=target,
            payload=payload,
            payload_identity=payload_identity,
            timeout_ms=timeout_ms,
            operation=operation,
            delivery_hint=delivery_hint,
            headers=headers,
            message_id=self.next_message_id(source),
        )
        return self._submit_pending_request(
            request=envelope,
            timeout_ms=timeout_ms,
            submit=self.submit_typed_envelope,
            caller="ask_typed",
        )

    def ask_json(
        self,
        source: str,
        target: str,
        payload: Mapping[str, Any],
        payload_identity: PayloadIdentity,
        timeout_ms: int = 5000,
        operation: str = "ask",
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        """Encode a typed JSON request, wait in milliseconds, and decode its response."""
        response = self.ask_typed(
            source=source,
            target=target,
            payload=json.dumps(payload).encode(),
            payload_identity=payload_identity,
            timeout_ms=timeout_ms,
            operation=operation,
            delivery_hint=delivery_hint,
            headers=headers,
        )
        return json.loads(response.payload.decode())

    def send_one_way_typed(
        self,
        source: str,
        target: str,
        payload: bytes,
        payload_identity: PayloadIdentity,
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        """Submit typed bytes without creating a pending response waiter."""
        envelope = self.make_typed_request(
            source=source,
            target=target,
            payload=payload,
            payload_identity=payload_identity,
            timeout_ms=0,
            operation="one_way",
            delivery_hint=delivery_hint,
            headers=headers,
            message_id=self.next_message_id(source),
            one_way=True,
        )
        self.submit_typed_envelope(envelope)

    def send_one_way_json(
        self,
        source: str,
        target: str,
        payload: Mapping[str, Any],
        payload_identity: PayloadIdentity,
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        """Encode and submit typed JSON without creating a response waiter."""
        self.send_one_way_typed(
            source=source,
            target=target,
            payload=json.dumps(payload).encode(),
            payload_identity=payload_identity,
            delivery_hint=delivery_hint,
            headers=headers,
        )

    def submit_request_typed(
        self,
        source: str,
        target: str,
        payload: bytes,
        payload_identity: PayloadIdentity,
        timeout_ms: int = 5000,
        operation: str = "ask",
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> SubmittedRequest:
        """Admit a typed request and return IDs for terminal-event correlation."""
        envelope = self.make_typed_request(
            source=source,
            target=target,
            payload=payload,
            payload_identity=payload_identity,
            timeout_ms=timeout_ms,
            operation=operation,
            delivery_hint=delivery_hint,
            headers=headers,
            message_id=self.next_message_id(source),
        )
        return self._submit_tracked_request(
            request=envelope,
            submit=self.submit_typed_envelope,
            caller="submit_request_typed",
        )

    def submit_request_json(
        self,
        source: str,
        target: str,
        payload: Mapping[str, Any],
        payload_identity: PayloadIdentity,
        timeout_ms: int = 5000,
        operation: str = "ask",
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
    ) -> SubmittedRequest:
        """Encode and admit JSON, returning IDs for asynchronous correlation."""
        return self.submit_request_typed(
            source=source,
            target=target,
            payload=json.dumps(payload).encode(),
            payload_identity=payload_identity,
            timeout_ms=timeout_ms,
            operation=operation,
            delivery_hint=delivery_hint,
            headers=headers,
        )

    def submit_request_raw(self, request: transport_pb2.Envelope) -> SubmittedRequest:
        """Admit a caller-built request without enforcing typed payload metadata."""
        return self._submit_tracked_request(
            request=request,
            submit=self.submit_raw_envelope,
            caller="submit_request_raw",
        )

    def submit_raw_envelope(self, envelope: transport_pb2.Envelope) -> None:
        """Serialize and submit one envelope through bounded runtime admission."""
        data = envelope.SerializeToString()
        with self._submit_lock:
            rc = self._lib.coakka_v2_runtime_submit_envelope(self._runtime, data, len(data))
            self._require_ok(rc, f"submit_envelope {envelope.message_id}")

    def submit_typed_envelope(self, envelope: transport_pb2.Envelope) -> None:
        """Validate typed payload identity, then submit one envelope."""
        self.require_typed_payload_identity(envelope, "submit_typed_envelope")
        self.submit_raw_envelope(envelope)

    def submit_envelope(self, envelope: transport_pb2.Envelope) -> None:
        """Submit a raw envelope; retained for compatibility with earlier callers."""
        self.submit_raw_envelope(envelope)

    def apply_control_envelope_bytes(self, control_envelope_bytes: bytes) -> None:
        """Atomically apply serialized control bytes; stale/invalid input leaves state unchanged."""
        rc = self._lib.coakka_v2_runtime_apply_control_envelope(
            self._runtime,
            control_envelope_bytes,
            len(control_envelope_bytes),
        )
        self._require_ok(rc, "apply_control_envelope")

    def apply_snapshot(
        self,
        generation: int,
        routes: list | tuple,
        source_connector: str | None = None,
        seq: int = 1,
        overload_policy=None,
    ) -> None:
        """Build and atomically apply a strictly newer route/policy generation."""
        envelope_bytes = self._build_control_envelope_bytes(
            generation=generation,
            routes=routes,
            source_connector=source_connector or self._config.system_name,
            seq=seq,
            overload_policy=self._config.overload_policy if overload_policy is None else overload_policy,
        )
        self.apply_control_envelope_bytes(envelope_bytes)

    def ask_raw(
        self,
        request: transport_pb2.Envelope,
        timeout_ms: int | None = None,
    ) -> transport_pb2.Envelope:
        """Submit a caller-built request and block up to ``timeout_ms`` for a terminal result."""
        if request.kind != int(MessageKind.REQUEST):
            raise ValueError("ask_raw requires MESSAGE_KIND_REQUEST")
        if request.one_way:
            raise ValueError("ask_raw requires one_way=false")
        if request.message_id == "":
            raise ValueError("ask_raw requires message_id")

        normalized_request = transport_pb2.Envelope()
        normalized_request.CopyFrom(request)
        if normalized_request.correlation_id == "":
            normalized_request.correlation_id = normalized_request.message_id
        if timeout_ms is None:
            timeout_ms = normalized_request.timeout_ms if normalized_request.timeout_ms > 0 else 1000
        return self._submit_pending_request(
            request=normalized_request,
            timeout_ms=timeout_ms,
            submit=self.submit_raw_envelope,
            caller="ask_raw",
        )

    def register_handler(
        self,
        target: str,
        handler: HandlerFn,
        typed_replies: bool = True,
    ) -> None:
        """Register one bounded worker-thread handler for ``target``.

        The handler must return promptly and must not retain borrowed request
        state. With ``typed_replies=True``, returned envelopes require complete
        payload identity metadata.
        """
        registered = _RegisteredRequestHandler(handler=handler, typed_replies=typed_replies)
        with self._request_handlers_lock:
            if target in self._request_handlers:
                raise RuntimeError(f"handler already registered for target={target}")
            self._request_handlers[target] = registered

    def register_raw_handler(
        self,
        target: str,
        handler: HandlerFn,
    ) -> None:
        """Register a handler whose reply may omit typed payload metadata."""
        self.register_handler(target=target, handler=handler, typed_replies=False)

    def terminal_events(self, buffer_capacity: int = 16) -> TerminalEventSubscription:
        """Create a bounded response/deadletter stream; overflow increments drop counters."""
        if buffer_capacity < 1:
            raise ValueError("terminal_events requires buffer_capacity >= 1")
        subscriber_queue: queue.Queue[RequestTerminalEvent | object] = queue.Queue(maxsize=buffer_capacity)
        with self._terminal_event_subscribers_lock:
            subscriber_id = self._next_terminal_subscriber_id
            self._next_terminal_subscriber_id += 1
            self._terminal_event_subscribers[subscriber_id] = subscriber_queue
        return TerminalEventSubscription(
            subscriber_id=subscriber_id,
            events=subscriber_queue,
            on_close=self._remove_terminal_event_subscriber,
        )

    def deadletters(self, buffer_capacity: int = 128) -> DeadletterSubscription:
        """Create a bounded observer for copied deadletters from all requests."""
        if buffer_capacity < 1:
            raise ValueError("deadletters requires buffer_capacity >= 1")
        subscriber_queue: queue.Queue[ObservedDeadletter | object] = queue.Queue(maxsize=buffer_capacity)
        with self._deadletter_subscribers_lock:
            subscriber_id = self._next_deadletter_subscriber_id
            self._next_deadletter_subscriber_id += 1
            self._deadletter_subscribers[subscriber_id] = subscriber_queue
        return DeadletterSubscription(
            subscriber_id=subscriber_id,
            events=subscriber_queue,
            on_close=self._remove_deadletter_subscriber,
        )

    def snapshot_stats(self) -> RuntimeClientStats:
        """Return a copied point-in-time connector counter snapshot."""
        with self._pending_lock:
            pending_requests = len(self._pending)
        with self._stats_lock:
            return RuntimeClientStats(
                pending_requests=pending_requests,
                delivered_requests=self._delivered_requests,
                matched_responses=self._matched_responses,
                matched_deadletters=self._matched_deadletters,
                late_responses=self._late_responses,
                unhandled_deadletters=self._unhandled_deadletters,
                terminal_event_drop_count=self._terminal_event_drop_count,
                deadletter_observation_drop_count=self._deadletter_observation_drop_count,
            )

    def health_snapshot(self) -> dict[str, Any]:
        """Return copied runtime state, health flags, and applied generation."""
        self._require_open()
        health = RuntimeHealth()
        health.struct_size = ctypes.sizeof(RuntimeHealth)
        self._require_ok(self._lib.coakka_v2_runtime_get_health(self._runtime, ctypes.byref(health)), "runtime_get_health")
        return {
            "runtimeState": health.runtime_state,
            "flags": health.flags,
            "appliedGeneration": health.applied_generation,
        }

    def stats_snapshot(self) -> dict[str, Any]:
        """Return copied bounded-queue and delivery counters from the runtime."""
        self._require_open()
        stats = RuntimeStats()
        stats.struct_size = ctypes.sizeof(RuntimeStats)
        self._require_ok(self._lib.coakka_v2_runtime_get_stats(self._runtime, ctypes.byref(stats)), "runtime_get_stats")
        return {
            "appliedGeneration": stats.applied_generation,
            "routeCount": stats.route_count,
            "runtimeState": stats.runtime_state,
            "queueRejectedCount": stats.queue_rejected_count,
            "routeMissCount": stats.route_miss_count,
            "deadletterCount": stats.deadletter_count,
            "deliveryFailedCount": stats.delivery_failed_count,
            "controlRejectedCount": stats.control_rejected_count,
            "monitorEventEmittedCount": stats.monitor_event_emitted_count,
            "monitorEventDroppedCount": stats.monitor_event_dropped_count,
            "localWorkQueueCapacity": stats.local_work_queue_capacity,
            "localWorkQueueDepth": stats.local_work_queue_depth,
            "localWorkQueueHighWatermark": stats.local_work_queue_high_watermark,
            "deliveredRequestOutboundDirectWriteCount": stats.delivered_request_outbound_direct_write_count,
            "responseOutboundDirectWriteCount": stats.response_outbound_direct_write_count,
            "deadletterOutboundDirectWriteCount": stats.deadletter_outbound_direct_write_count,
            "remoteOutboundQueueCapacity": stats.remote_outbound_queue_capacity,
            "remoteOutboundQueueDepth": stats.remote_outbound_queue_depth,
            "remoteOutboundQueueHighWatermark": stats.remote_outbound_queue_high_watermark,
            "remoteOutboundQueueRejectedCount": stats.remote_outbound_queue_rejected_count,
            "remoteOutboundExpiredDropCount": stats.remote_outbound_expired_drop_count,
            "remoteOutboundReplyReserveSlots": stats.remote_outbound_reply_reserve_slots,
            "remoteOutboundReplyReservationRejectCount": stats.remote_outbound_reply_reservation_reject_count,
            "remoteOutboundOneWayDropCount": stats.remote_outbound_one_way_drop_count,
        }

    def monitor_is_enabled(self) -> bool:
        """Return whether this client requested and received a monitor handle."""
        return self._handles.monitor_read_fd >= 0

    def monitor_snapshot(self, signal_count: int = 0) -> MonitorSnapshot:
        """Read current health/stats and associate an already-consumed signal count."""
        return MonitorSnapshot(
            signal_count=signal_count,
            health=self.health_snapshot(),
            stats=self.stats_snapshot(),
        )

    def await_next_monitor(self, timeout_ms: int = 1000) -> MonitorSnapshot | None:
        """Wait up to ``timeout_ms`` for a monitor signal, returning ``None`` on timeout."""
        if not self.monitor_is_enabled():
            raise RuntimeError("runtime monitor is not enabled")
        if not self._wait_readable(self._handles.monitor_read_fd, timeout_s=timeout_ms / 1000.0):
            return None
        signal_count = ctypes.c_uint64()
        self._require_ok(
            self._lib.coakka_v2_monitor_consume(self._handles.monitor_read_fd, ctypes.byref(signal_count)),
            "monitor_consume",
        )
        return self.monitor_snapshot(signal_count=signal_count.value)

    def await_applied_generation_at_least(
        self,
        generation: int,
        timeout_ms: int = 1000,
    ) -> MonitorSnapshot | None:
        """Wait in milliseconds until the active control generation reaches ``generation``."""
        deadline = time.monotonic() + (timeout_ms / 1000.0)
        current = self.monitor_snapshot()
        if current.health["appliedGeneration"] >= generation:
            return current
        while time.monotonic() < deadline:
            remaining_ms = max(1, int((deadline - time.monotonic()) * 1000))
            snapshot = self.await_next_monitor(timeout_ms=remaining_ms)
            if snapshot is None:
                return None
            if snapshot.health["appliedGeneration"] >= generation:
                return snapshot
        return None

    def runtime_snapshot(self) -> dict[str, Any]:
        """Return one connector-oriented aggregate of copied runtime observations."""
        client_stats = self.snapshot_stats()
        health_snapshot = self.health_snapshot()
        stats_snapshot = self.stats_snapshot()
        return {
            "runtimeInfo": self.runtime_info_snapshot(),
            "runtimeConfig": self.runtime_config_snapshot(),
            "connector": {
                "pendingRequests": client_stats.pending_requests,
                "deliveredRequests": client_stats.delivered_requests,
                "matchedResponses": client_stats.matched_responses,
                "matchedDeadletters": client_stats.matched_deadletters,
                "lateResponses": client_stats.late_responses,
                "unhandledDeadletters": client_stats.unhandled_deadletters,
                "terminalEventDropCount": client_stats.terminal_event_drop_count,
                "separateDeliveredRequestLane": self._separate_delivered_request_lane,
                "systemName": self._config.system_name,
                "nodeId": self._config.node_id,
            },
            "health": health_snapshot,
            "stats": stats_snapshot,
        }

    def runtime_info_snapshot(self) -> dict[str, Any]:
        """Return immutable runtime identity, ABI, feature, backend, and build metadata."""
        runtime_info = RuntimeInfo()
        runtime_info.struct_size = ctypes.sizeof(RuntimeInfo)
        self._require_ok(self._lib.coakka_v2_runtime_get_info(ctypes.byref(runtime_info)), "runtime_get_info")
        return {
            "abiVersion": runtime_info.abi_version,
            "featureFlags": runtime_info.feature_flags,
            "runtimeVersion": self._decode_text(runtime_info.runtime_version),
            "gitCommit": self._decode_text(runtime_info.git_commit),
            "southboundBackend": self._decode_text(runtime_info.southbound_backend),
            "allocatorBackend": self._decode_text(runtime_info.allocator_backend),
            "docsHint": self._decode_text(runtime_info.docs_hint),
        }

    def runtime_config_snapshot(self) -> dict[str, Any]:
        """Return copied effective identity, route generation, and overload policy."""
        self._require_open()
        runtime_config = RuntimeConfigView()
        runtime_config.struct_size = ctypes.sizeof(RuntimeConfigView)
        self._require_ok(
            self._lib.coakka_v2_runtime_get_config(self._runtime, ctypes.byref(runtime_config)),
            "runtime_get_config",
        )
        return {
            "systemName": self._decode_text(runtime_config.system_name),
            "nodeId": self._decode_text(runtime_config.node_id),
            "runtimeState": runtime_config.runtime_state,
            "snapshotPresent": bool(runtime_config.snapshot_present),
            "appliedGeneration": runtime_config.applied_generation,
            "routeCount": runtime_config.route_count,
            "southboundBindHost": self._decode_text(runtime_config.southbound_bind_host),
            "southboundBindPort": runtime_config.southbound_bind_port,
            "effectiveIngressOverloadMode": runtime_config.effective_ingress_overload_mode,
            "effectiveLocalDeliveryOverloadMode": runtime_config.effective_local_delivery_overload_mode,
            "effectiveRemoteOutboundOverloadMode": runtime_config.effective_remote_outbound_overload_mode,
            "effectiveRemoteOutboundReplyReserveSlots": runtime_config.effective_remote_outbound_reply_reserve_slots,
        }

    def runtime_capabilities_snapshot(self) -> RuntimeCapabilitiesSnapshot:
        """Return compiled, entitled, and effective transport capabilities."""
        return self._transport.read_capabilities()

    def tcp_connection_config_snapshot(self) -> RuntimeTcpConnectionConfigSnapshot:
        """Return copied effective connection settings without exposing provider state."""
        self._require_open()
        with self._transport_apply_lock:
            self._require_open()
            return self._transport.get_connection(self._runtime)

    def tcp_security_info_snapshot(self) -> RuntimeTcpSecurityInfoSnapshot:
        """Return copied non-secret security metadata; paths and key bytes are excluded."""
        self._require_open()
        with self._transport_apply_lock:
            self._require_open()
            return self._transport.get_security(self._runtime)

    def startup_connection_result(self) -> RuntimeTcpConnectionApplyResult | None:
        """Return the startup connection apply result, or ``None`` when no override was supplied."""
        return self._startup_connection_result

    def startup_security_result(self) -> RuntimeTcpSecurityApplyResult | None:
        """Return the startup security apply result, or ``None`` when no override was supplied."""
        return self._startup_security_result

    def apply_tcp_connection_strategy(
        self,
        spec: RuntimeTcpConnectionStrategySpec,
    ) -> RuntimeTcpConnectionApplyResult:
        """Attempt an atomic strategy apply; a started runtime normally returns BAD_STATE."""
        self._require_open()
        with self._transport_apply_lock:
            self._require_open()
            return self._transport.apply_connection(self._runtime, spec)

    def apply_tcp_security(
        self,
        spec: RuntimeTcpSecuritySpec,
    ) -> RuntimeTcpSecurityApplyResult:
        """Atomically publish a supported newer credential generation in the active mode."""
        self._require_open()
        with self._transport_apply_lock:
            self._require_open()
            return self._transport.apply_security(self._runtime, spec)

    def close(self) -> None:
        """Idempotently stop workers, close handles, stop runtime, and destroy native state."""
        if self._stopped.is_set():
            return
        self._stopped.set()
        with self._pending_lock:
            for future in self._pending.values():
                future.set_exception(RuntimeError("runtime client closed"))
            self._pending.clear()
            self._tracked_requests_by_message_id.clear()
            self._tracked_request_message_ids_by_correlation_id.clear()
        with self._terminal_event_subscribers_lock:
            subscriber_ids = list(self._terminal_event_subscribers.keys())
        for subscriber_id in subscriber_ids:
            self._remove_terminal_event_subscriber(subscriber_id)
        with self._deadletter_subscribers_lock:
            deadletter_subscriber_ids = list(self._deadletter_subscribers.keys())
        for subscriber_id in deadletter_subscriber_ids:
            self._remove_deadletter_subscriber(subscriber_id)
        self._request_thread.join(timeout=0.5)
        self._response_thread.join(timeout=0.5)
        self._deadletter_thread.join(timeout=0.5)
        self._safe_close_fd(self._handles.response_read_fd)
        self._safe_close_fd(self._handles.deadletter_read_fd)
        self._safe_close_fd(self._handles.request_write_fd)
        self._safe_close_fd(self._handles.control_write_fd)
        self._safe_close_fd(self._handles.monitor_read_fd)
        self._safe_close_fd(self._handles.delivered_request_read_fd)
        with self._transport_apply_lock:
            self._lib.coakka_v2_runtime_stop(self._runtime)
            self._lib.coakka_v2_runtime_destroy(self._runtime)

    def _require_open(self) -> None:
        if self._stopped.is_set():
            raise RuntimeError("runtime client is closed")

    def __enter__(self) -> "PythonRuntimeClient":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()

    def _request_loop(self) -> None:
        while not self._stopped.is_set():
            if not self._wait_readable(self._request_read_fd):
                continue
            frame = self._read_frame(self._request_read_fd)
            if frame is None:
                return
            envelope = transport_pb2.Envelope()
            envelope.ParseFromString(frame)
            if self._separate_delivered_request_lane:
                if envelope.kind != int(MessageKind.REQUEST):
                    raise RuntimeError(f"unexpected envelope kind={envelope.kind} on delivered-request lane")
                self._dispatch_request(envelope)
                continue

            if envelope.kind == int(MessageKind.REQUEST):
                self._dispatch_request(envelope)
            elif envelope.kind == int(MessageKind.RESPONSE):
                self._dispatch_response(envelope)
            else:
                raise RuntimeError(f"unexpected envelope kind={envelope.kind}")

    def _response_loop(self) -> None:
        if not self._separate_delivered_request_lane:
            return
        while not self._stopped.is_set():
            if not self._wait_readable(self._handles.response_read_fd):
                continue
            frame = self._read_frame(self._handles.response_read_fd)
            if frame is None:
                return
            envelope = transport_pb2.Envelope()
            envelope.ParseFromString(frame)
            if envelope.kind == int(MessageKind.RESPONSE):
                self._dispatch_response(envelope)
            elif envelope.kind == int(MessageKind.REQUEST):
                raise RuntimeError("unexpected request on response-only lane")
            else:
                raise RuntimeError(f"unexpected envelope kind={envelope.kind}")

    def _deadletter_loop(self) -> None:
        while not self._stopped.is_set():
            if not self._wait_readable(self._handles.deadletter_read_fd):
                continue
            frame = self._read_frame(self._handles.deadletter_read_fd)
            if frame is None:
                return
            deadletter = transport_pb2.Deadletter()
            deadletter.ParseFromString(frame)
            self._dispatch_deadletter(deadletter)

    def _build_control_envelope_bytes(
        self,
        generation: int | None = None,
        routes: list | tuple | None = None,
        source_connector: str | None = None,
        seq: int = 1,
        overload_policy=None,
    ) -> bytes:
        effective_generation = self._config.generation if generation is None else generation
        effective_routes = self._config.routes if routes is None else routes
        effective_overload_policy = self._config.overload_policy if overload_policy is None else overload_policy
        if effective_overload_policy is not None:
            effective_overload_policy.require_valid()
        snapshot = control_pb2.RouteSnapshotPayload(
            generation=effective_generation,
            routes=[
                control_pb2.Route(
                    target=route.target,
                    strategy=int(route.strategy),
                    route_key_hint=route.route_key_hint,
                    flags=route.flags,
                    endpoints=[
                        control_pb2.Endpoint(
                            host=endpoint.host,
                            port=endpoint.port,
                            weight=endpoint.weight,
                            flags=endpoint.flags,
                        )
                        for endpoint in route.endpoints
                    ],
                )
                for route in effective_routes
            ],
        )
        if effective_overload_policy is not None:
            snapshot.overload_policy.ingress_mode = int(effective_overload_policy.ingress_mode)
            snapshot.overload_policy.local_delivery_mode = int(effective_overload_policy.local_delivery_mode)
            snapshot.overload_policy.remote_outbound_mode = int(effective_overload_policy.remote_outbound_mode)
            snapshot.overload_policy.remote_outbound_reply_reserve_slots = (
                effective_overload_policy.remote_outbound_reply_reserve_slots
            )
        envelope = control_pb2.ControlEnvelope(
            seq=seq,
            generation=effective_generation,
            kind=control_pb2.CONTROL_KIND_APPLY_SNAPSHOT,
            payload_format=control_pb2.CONFIG_FORMAT_PROTOBUF,
            payload_type=control_pb2.CONTROL_PAYLOAD_TYPE_ROUTE_SNAPSHOT,
            schema_version=1,
            payload=snapshot.SerializeToString(),
            metadata={"source_connector": source_connector or self._config.system_name},
        )
        return envelope.SerializeToString()

    def _configure_api(self) -> None:
        self._lib.coakka_v2_runtime_get_abi_version.restype = ctypes.c_uint32
        self._lib.coakka_v2_runtime_create.argtypes = [ctypes.POINTER(RuntimeConfig)]
        self._lib.coakka_v2_runtime_create.restype = ctypes.c_void_p
        self._lib.coakka_v2_runtime_destroy.argtypes = [ctypes.c_void_p]
        self._lib.coakka_v2_runtime_get_info.argtypes = [ctypes.POINTER(RuntimeInfo)]
        self._lib.coakka_v2_runtime_get_info.restype = ctypes.c_int
        self._lib.coakka_v2_runtime_get_config.argtypes = [ctypes.c_void_p, ctypes.POINTER(RuntimeConfigView)]
        self._lib.coakka_v2_runtime_get_config.restype = ctypes.c_int
        self._lib.coakka_v2_runtime_get_stats.argtypes = [ctypes.c_void_p, ctypes.POINTER(RuntimeStats)]
        self._lib.coakka_v2_runtime_get_stats.restype = ctypes.c_int
        self._lib.coakka_v2_runtime_get_health.argtypes = [ctypes.c_void_p, ctypes.POINTER(RuntimeHealth)]
        self._lib.coakka_v2_runtime_get_health.restype = ctypes.c_int
        self._lib.coakka_v2_runtime_get_host_handles.argtypes = [ctypes.c_void_p, ctypes.POINTER(HostHandles)]
        self._lib.coakka_v2_runtime_get_host_handles.restype = ctypes.c_int
        self._lib.coakka_v2_runtime_start.argtypes = [ctypes.c_void_p]
        self._lib.coakka_v2_runtime_start.restype = ctypes.c_int
        self._lib.coakka_v2_runtime_stop.argtypes = [ctypes.c_void_p]
        self._lib.coakka_v2_runtime_stop.restype = ctypes.c_int
        self._lib.coakka_v2_runtime_submit_envelope.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t]
        self._lib.coakka_v2_runtime_submit_envelope.restype = ctypes.c_int
        self._lib.coakka_v2_runtime_apply_control_envelope.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t]
        self._lib.coakka_v2_runtime_apply_control_envelope.restype = ctypes.c_int
        self._lib.coakka_v2_monitor_consume.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint64)]
        self._lib.coakka_v2_monitor_consume.restype = ctypes.c_int

    def _host_handle_flags(self) -> int:
        flags = 0
        if self._config.enable_monitor:
            flags |= HOST_HANDLES_ENABLE_MONITOR
        if self._config.separate_delivered_request_lane:
            flags |= HOST_HANDLES_SEPARATE_DELIVERED_REQUEST_LANE
        return flags

    def _dispatch_request(self, request: transport_pb2.Envelope) -> None:
        with self._stats_lock:
            self._delivered_requests += 1
        with self._request_handlers_lock:
            registered_handler = self._request_handlers.get(request.target)
        if registered_handler is None:
            return

        def run_handler() -> None:
            reply = registered_handler.handler(request)
            if not request.one_way and reply is not None:
                if registered_handler.typed_replies:
                    self.submit_typed_envelope(reply)
                else:
                    self.submit_raw_envelope(reply)

        threading.Thread(target=run_handler, daemon=True).start()

    def _dispatch_response(self, response: transport_pb2.Envelope) -> None:
        tracked_request = self._forget_tracked_request_by_correlation_id(response.correlation_id)
        if tracked_request is None:
            with self._stats_lock:
                self._late_responses += 1
            return
        self._publish_terminal_event(
            RequestTerminalResponse(
                request_message_id=tracked_request.message_id,
                correlation_id=tracked_request.correlation_id,
                envelope=response,
            )
        )
        with self._pending_lock:
            future = self._pending.pop(tracked_request.message_id, None)
        with self._stats_lock:
            self._matched_responses += 1
        if future is not None:
            future.set_result(response)

    def _dispatch_deadletter(self, deadletter: transport_pb2.Deadletter) -> None:
        tracked_request = self._forget_tracked_request(deadletter.original_envelope.message_id)
        self._publish_deadletter_observation(deadletter, tracked_request)
        if tracked_request is None:
            with self._stats_lock:
                self._unhandled_deadletters += 1
            return
        self._publish_terminal_event(
            RequestTerminalDeadletter(
                request_message_id=tracked_request.message_id,
                correlation_id=tracked_request.correlation_id,
                deadletter=deadletter,
            )
        )
        with self._pending_lock:
            future = self._pending.pop(tracked_request.message_id, None)
        with self._stats_lock:
            self._matched_deadletters += 1
        if future is not None:
            future.set_exception(DeadletterError(deadletter))

    @staticmethod
    def next_message_id(source: str) -> str:
        """Create a process-unique message ID prefixed with ``source``."""
        return f"{source}-{uuid.uuid4()}"

    @staticmethod
    def make_typed_request(
        source: str,
        target: str,
        payload: bytes,
        payload_identity: PayloadIdentity,
        timeout_ms: int,
        operation: str,
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
        message_id: str | None = None,
        one_way: bool = False,
    ) -> transport_pb2.Envelope:
        """Build a typed request/one-way envelope; ``timeout_ms`` is milliseconds."""
        identity = payload_identity.require_typed("typed request")
        request_message_id = message_id or PythonRuntimeClient.next_message_id(source)
        merged_headers = {"method": "POST", "operation": operation}
        if headers:
            merged_headers.update(headers)
        return transport_pb2.Envelope(
            message_id=request_message_id,
            correlation_id="" if one_way else request_message_id,
            source=source,
            target=target,
            reply_to="" if one_way else f"{source}/replies",
            kind=int(MessageKind.REQUEST),
            one_way=one_way,
            timeout_ms=timeout_ms,
            payload=payload,
            headers=merged_headers,
            status=int(BusinessStatus.OK),
            delivery_hint=int(delivery_hint),
            message_type=identity.message_type,
            payload_schema_version=identity.payload_schema_version,
            payload_format=int(identity.payload_format),
        )

    @staticmethod
    def make_json_request(
        source: str,
        target: str,
        payload: Mapping[str, Any],
        payload_identity: PayloadIdentity,
        timeout_ms: int,
        operation: str,
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
        headers: Mapping[str, str] | None = None,
        message_id: str | None = None,
        one_way: bool = False,
    ) -> transport_pb2.Envelope:
        """JSON-encode a mapping and build a typed request envelope."""
        return PythonRuntimeClient.make_typed_request(
            source=source,
            target=target,
            payload=json.dumps(payload).encode(),
            payload_identity=payload_identity,
            timeout_ms=timeout_ms,
            operation=operation,
            delivery_hint=delivery_hint,
            headers=headers,
            message_id=message_id,
            one_way=one_way,
        )

    @staticmethod
    def make_typed_reply(
        request: transport_pb2.Envelope,
        source: str,
        payload: bytes,
        payload_identity: PayloadIdentity,
    ) -> transport_pb2.Envelope:
        """Build a typed response correlated to ``request`` without retaining it."""
        identity = payload_identity.require_typed("typed reply")
        correlation_id = request.correlation_id or request.message_id
        return transport_pb2.Envelope(
            message_id=f"{request.message_id}.reply.{source}",
            correlation_id=correlation_id,
            source=source,
            target=request.source,
            kind=int(MessageKind.RESPONSE),
            one_way=False,
            timeout_ms=request.timeout_ms,
            payload=payload,
            status=int(BusinessStatus.OK),
            delivery_hint=int(DeliveryHint.ROUTER_DEFAULT),
            message_type=identity.message_type,
            payload_schema_version=identity.payload_schema_version,
            payload_format=int(identity.payload_format),
        )

    @staticmethod
    def make_json_reply(
        request: transport_pb2.Envelope,
        source: str,
        payload: Mapping[str, Any],
        payload_identity: PayloadIdentity,
    ) -> transport_pb2.Envelope:
        """JSON-encode a mapping and build a typed correlated response."""
        return PythonRuntimeClient.make_typed_reply(
            request=request,
            source=source,
            payload=json.dumps(payload).encode(),
            payload_identity=payload_identity,
        )

    @staticmethod
    def make_reply_from_request_identity(
        request: transport_pb2.Envelope,
        source: str,
        payload: bytes,
    ) -> transport_pb2.Envelope:
        """Build a reply reusing the request's validated type/schema/format identity."""
        PythonRuntimeClient.require_typed_payload_identity(request, "request")
        return PythonRuntimeClient.make_typed_reply(
            request=request,
            source=source,
            payload=payload,
            payload_identity=PayloadIdentity(
                message_type=request.message_type,
                payload_schema_version=request.payload_schema_version,
                payload_format=PayloadFormat(request.payload_format),
            ),
        )

    @staticmethod
    def make_json_reply_from_request_identity(
        request: transport_pb2.Envelope,
        source: str,
        payload: Mapping[str, Any],
    ) -> transport_pb2.Envelope:
        """Build a JSON reply using the request's validated payload identity."""
        return PythonRuntimeClient.make_reply_from_request_identity(
            request=request,
            source=source,
            payload=json.dumps(payload).encode(),
        )

    @staticmethod
    def make_raw_reply(
        request: transport_pb2.Envelope,
        source: str,
        payload: bytes,
    ) -> transport_pb2.Envelope:
        """Build a correlated response without typed payload metadata."""
        correlation_id = request.correlation_id or request.message_id
        return transport_pb2.Envelope(
            message_id=f"{request.message_id}.reply.{source}",
            correlation_id=correlation_id,
            source=source,
            target=request.source,
            kind=int(MessageKind.RESPONSE),
            one_way=False,
            timeout_ms=request.timeout_ms,
            payload=payload,
            status=int(BusinessStatus.OK),
            delivery_hint=int(DeliveryHint.ROUTER_DEFAULT),
        )

    @staticmethod
    def make_raw_request(
        message_id: str,
        source: str,
        target: str,
        reply_to: str,
        payload: bytes,
        timeout_ms: int = 1000,
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
    ) -> transport_pb2.Envelope:
        """Build an untyped request; ``timeout_ms`` is a positive millisecond deadline."""
        return transport_pb2.Envelope(
            message_id=message_id,
            correlation_id=message_id,
            source=source,
            target=target,
            reply_to=reply_to,
            kind=int(MessageKind.REQUEST),
            one_way=False,
            timeout_ms=timeout_ms,
            payload=payload,
            status=int(BusinessStatus.OK),
            delivery_hint=int(delivery_hint),
        )

    @staticmethod
    def make_raw_one_way(
        message_id: str,
        source: str,
        target: str,
        payload: bytes,
        timeout_ms: int = 1000,
        delivery_hint: DeliveryHint = DeliveryHint.ROUTER_DEFAULT,
    ) -> transport_pb2.Envelope:
        """Build an untyped one-way envelope with a millisecond delivery deadline."""
        return transport_pb2.Envelope(
            message_id=message_id,
            source=source,
            target=target,
            kind=int(MessageKind.REQUEST),
            one_way=True,
            timeout_ms=timeout_ms,
            payload=payload,
            status=int(BusinessStatus.OK),
            delivery_hint=int(delivery_hint),
        )

    @staticmethod
    def require_typed_payload_identity(envelope: transport_pb2.Envelope, what: str) -> None:
        """Raise ``ValueError`` unless the envelope declares type, schema, and format."""
        identity = PayloadIdentity(
            message_type=envelope.message_type,
            payload_schema_version=envelope.payload_schema_version,
            payload_format=PayloadFormat(envelope.payload_format),
        )
        identity.require_typed(what)

    @staticmethod
    def _require_ok(rc: int, what: str) -> None:
        if rc != COAKKA_OK:
            raise RuntimeError(f"{what} failed rc={rc}")

    @staticmethod
    def _decode_text(value: bytes | None) -> str:
        return value.decode() if value else ""

    @staticmethod
    def _wait_readable(fd: int, timeout_s: float = 0.1) -> bool:
        if os.name == "nt":
            # Windows select() accepts sockets, not the CRT pipe descriptors
            # exported by the runtime. Inspect the underlying pipe HANDLE and
            # retain the same bounded wait behavior as the POSIX select path.
            try:
                handle = msvcrt.get_osfhandle(fd)
            except OSError:
                return False
            deadline = time.monotonic() + max(0.0, timeout_s)
            while True:
                available = ctypes.c_uint32()
                if _peek_named_pipe(handle, None, 0, None, ctypes.byref(available), None):
                    if available.value > 0:
                        return True
                elif ctypes.get_last_error() in (109, 233):
                    return True
                else:
                    return False
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                time.sleep(min(0.005, remaining))
        try:
            readable, _, _ = select.select([fd], [], [], timeout_s)
        except OSError:
            return False
        return bool(readable)

    @staticmethod
    def _read_frame(fd: int) -> bytes | None:
        header = PythonRuntimeClient._read_exact(fd, 8)
        if not header:
            return None
        payload_length = int.from_bytes(header, byteorder="little", signed=False)
        return PythonRuntimeClient._read_exact(fd, payload_length)

    @staticmethod
    def _read_exact(fd: int, length: int) -> bytes:
        chunks = []
        remaining = length
        while remaining > 0:
            try:
                chunk = os.read(fd, remaining)
            except BlockingIOError:
                time.sleep(0.001)
                continue
            except OSError:
                return b""
            if not chunk:
                return b""
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    @staticmethod
    def _safe_close_fd(fd: int) -> None:
        if fd >= 0:
            try:
                os.close(fd)
            except OSError:
                pass

    def _submit_pending_request(
        self,
        request: transport_pb2.Envelope,
        timeout_ms: int,
        submit: Callable[[transport_pb2.Envelope], None],
        caller: str,
    ) -> transport_pb2.Envelope:
        tracked_request, normalized_request = self._track_request(request, caller)
        waiter: Future[transport_pb2.Envelope] = Future()
        duplicate_pending = False
        with self._pending_lock:
            if tracked_request.message_id in self._pending:
                duplicate_pending = True
            else:
                self._pending[tracked_request.message_id] = waiter
        if duplicate_pending:
            self._forget_tracked_request(tracked_request.message_id)
            raise RuntimeError(f"duplicate pending message_id={tracked_request.message_id}")

        try:
            submit(normalized_request)
            return waiter.result(timeout=timeout_ms / 1000.0)
        except FutureTimeoutError as exc:
            with self._pending_lock:
                self._pending.pop(tracked_request.message_id, None)
            self._forget_tracked_request(tracked_request.message_id)
            raise TimeoutError(f"timed out waiting for {tracked_request.message_id}") from exc
        except Exception:
            with self._pending_lock:
                self._pending.pop(tracked_request.message_id, None)
            self._forget_tracked_request(tracked_request.message_id)
            raise
        finally:
            with self._pending_lock:
                self._pending.pop(tracked_request.message_id, None)
            self._forget_tracked_request(tracked_request.message_id)

    def _submit_tracked_request(
        self,
        request: transport_pb2.Envelope,
        submit: Callable[[transport_pb2.Envelope], None],
        caller: str,
    ) -> SubmittedRequest:
        tracked_request, normalized_request = self._track_request(request, caller)
        try:
            submit(normalized_request)
            return SubmittedRequest(
                message_id=tracked_request.message_id,
                correlation_id=tracked_request.correlation_id,
            )
        except Exception:
            self._forget_tracked_request(tracked_request.message_id)
            raise

    def _track_request(
        self,
        request: transport_pb2.Envelope,
        caller: str,
    ) -> tuple[_TrackedRequest, transport_pb2.Envelope]:
        if request.kind != int(MessageKind.REQUEST):
            raise ValueError(f"{caller} requires MESSAGE_KIND_REQUEST")
        if request.one_way:
            raise ValueError(f"{caller} requires one_way=false")
        if request.message_id == "":
            raise ValueError(f"{caller} requires message_id")

        normalized_request = transport_pb2.Envelope()
        normalized_request.CopyFrom(request)
        if normalized_request.correlation_id == "":
            normalized_request.correlation_id = normalized_request.message_id

        tracked_request = _TrackedRequest(
            message_id=normalized_request.message_id,
            correlation_id=normalized_request.correlation_id,
        )
        with self._pending_lock:
            if tracked_request.message_id in self._tracked_requests_by_message_id:
                raise RuntimeError(f"duplicate tracked message_id={tracked_request.message_id}")
            if tracked_request.correlation_id in self._tracked_request_message_ids_by_correlation_id:
                raise RuntimeError(f"duplicate tracked correlation_id={tracked_request.correlation_id}")
            self._tracked_requests_by_message_id[tracked_request.message_id] = tracked_request
            self._tracked_request_message_ids_by_correlation_id[
                tracked_request.correlation_id
            ] = tracked_request.message_id
        return tracked_request, normalized_request

    def _forget_tracked_request(self, message_id: str) -> _TrackedRequest | None:
        with self._pending_lock:
            tracked_request = self._tracked_requests_by_message_id.pop(message_id, None)
            if tracked_request is not None:
                self._tracked_request_message_ids_by_correlation_id.pop(
                    tracked_request.correlation_id,
                    None,
                )
            return tracked_request

    def _forget_tracked_request_by_correlation_id(self, correlation_id: str) -> _TrackedRequest | None:
        with self._pending_lock:
            message_id = self._tracked_request_message_ids_by_correlation_id.pop(correlation_id, None)
            if message_id is None:
                return None
            return self._tracked_requests_by_message_id.pop(message_id, None)

    def _remove_terminal_event_subscriber(self, subscriber_id: int) -> None:
        with self._terminal_event_subscribers_lock:
            subscriber_queue = self._terminal_event_subscribers.pop(subscriber_id, None)
        if subscriber_queue is None:
            return
        try:
            subscriber_queue.put_nowait(TerminalEventSubscription._CLOSED_SENTINEL)
        except queue.Full:
            try:
                subscriber_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                subscriber_queue.put_nowait(TerminalEventSubscription._CLOSED_SENTINEL)
            except queue.Full:
                pass

    def _remove_deadletter_subscriber(self, subscriber_id: int) -> None:
        with self._deadletter_subscribers_lock:
            subscriber_queue = self._deadletter_subscribers.pop(subscriber_id, None)
        if subscriber_queue is None:
            return
        try:
            subscriber_queue.put_nowait(DeadletterSubscription._CLOSED_SENTINEL)
        except queue.Full:
            try:
                subscriber_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                subscriber_queue.put_nowait(DeadletterSubscription._CLOSED_SENTINEL)
            except queue.Full:
                pass

    def _publish_terminal_event(self, event: RequestTerminalEvent) -> None:
        with self._terminal_event_subscribers_lock:
            subscribers = list(self._terminal_event_subscribers.values())
        for subscriber_queue in subscribers:
            try:
                subscriber_queue.put_nowait(event)
            except queue.Full:
                with self._stats_lock:
                    self._terminal_event_drop_count += 1

    def _publish_deadletter_observation(
        self,
        deadletter: transport_pb2.Deadletter,
        tracked_request: _TrackedRequest | None,
    ) -> None:
        observed = ObservedDeadletter(
            deadletter=deadletter,
            request_message_id=(
                tracked_request.message_id
                if tracked_request is not None
                else deadletter.original_envelope.message_id or None
            ),
            correlation_id=(
                tracked_request.correlation_id
                if tracked_request is not None
                else deadletter.original_envelope.correlation_id or None
            ),
            matched_pending_request=tracked_request is not None,
        )
        with self._deadletter_subscribers_lock:
            subscribers = list(self._deadletter_subscribers.values())
        for subscriber_queue in subscribers:
            try:
                subscriber_queue.put_nowait(observed)
            except queue.Full:
                with self._stats_lock:
                    self._deadletter_observation_drop_count += 1
