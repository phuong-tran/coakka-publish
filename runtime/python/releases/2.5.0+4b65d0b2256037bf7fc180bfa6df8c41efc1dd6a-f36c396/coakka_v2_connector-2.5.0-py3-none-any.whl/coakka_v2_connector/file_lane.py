from __future__ import annotations

import ctypes
import os
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from enum import IntEnum, IntFlag
from pathlib import Path
from typing import Iterator

from .orchestrator import RuntimeLibraryResolver


SHA256_BYTES = 32
DETAIL_MAX_BYTES = 160


class FileLaneFlags(IntFlag):
    """Direction capabilities enabled on a file lane."""
    SENDER = 1
    RECEIVER = 1 << 1


class FileLaneSecurityMode(IntEnum):
    """Transport protection; per-transfer authorization remains mandatory."""
    DIRECT = 0
    TLS = 1
    MUTUAL_TLS = 2


class FileTransferDirection(IntEnum):
    """Side of a transfer record used by observation and control calls."""
    SEND = 1
    RECEIVE = 2


class FileTransferState(IntEnum):
    """Observable file-transfer lifecycle state."""
    PREPARED = 1
    QUEUED = 2
    CONNECTING = 3
    TRANSFERRING = 4
    VERIFYING = 5
    COMPLETED = 6
    PAUSED = 7
    REJECTED = 8
    FAILED = 9
    CANCELED = 10


class FileTransferResult(IntEnum):
    """Stable terminal outcome reported independently by each peer."""
    NONE = 0
    OK = 1
    NOT_PREPARED = 2
    TOKEN_MISMATCH = 3
    METADATA_MISMATCH = 4
    SIZE_LIMIT = 5
    STORAGE_IO = 6
    INTEGRITY_MISMATCH = 7
    NETWORK_IO = 8
    TIMEOUT = 9
    QUEUE_FULL = 10
    PROTOCOL_ERROR = 11
    SOURCE_CHANGED = 12
    INTERNAL_ERROR = 13
    CANCELED_BY_HOST = 14
    TLS_CONFIG_INVALID = 15
    TLS_HANDSHAKE_FAILED = 16
    PEER_CERT_UNTRUSTED = 17
    PEER_CERT_EXPIRED = 18
    PEER_IDENTITY_MISMATCH = 19
    CLIENT_CERT_REQUIRED = 20


TERMINAL_FILE_TRANSFER_STATES = frozenset(
    {
        FileTransferState.COMPLETED,
        FileTransferState.PAUSED,
        FileTransferState.REJECTED,
        FileTransferState.FAILED,
        FileTransferState.CANCELED,
    }
)


class FileLaneError(RuntimeError):
    """Native status failure for a named file-lane operation."""
    def __init__(self, operation: str, status: int) -> None:
        super().__init__(f"{operation} failed: native status {status}")
        self.operation = operation
        self.status = status


@dataclass(frozen=True)
class FileLaneSecurityConfig:
    """TLS material read at lane startup; key paths and tokens must not be logged.

    Attributes:
        mode: Direct, server-authenticated TLS, or mutual TLS.
        credential_generation: App-host generation used for diagnostics.
        credential_id: Non-secret credential identifier.
        ca_certificate_file: Trusted CA bundle path.
        identity_certificate_file: Local certificate-chain path.
        private_key_file: Local private-key path.
    """
    mode: FileLaneSecurityMode = FileLaneSecurityMode.DIRECT
    credential_generation: int = 0
    credential_id: str = ""
    ca_certificate_file: str = ""
    identity_certificate_file: str = ""
    private_key_file: str = ""


@dataclass(frozen=True)
class FileLaneConfig:
    """Bounded configuration; zero tuning fields select core-runtime defaults.

    Sizes are bytes, ``*_ms`` fields are milliseconds, and worker counts are
    bounded to four per direction. ``bind_port=0`` requests an ephemeral port.
    """
    flags: FileLaneFlags = FileLaneFlags.SENDER | FileLaneFlags.RECEIVER
    bind_host: str = "127.0.0.1"
    bind_port: int = 0
    queue_capacity: int = 0
    max_file_size: int = 0
    io_timeout_ms: int = 0
    checkpoint_bytes: int = 0
    progress_bytes: int = 0
    progress_interval_ms: int = 0
    sender_worker_count: int = 0
    receiver_worker_count: int = 0
    security: FileLaneSecurityConfig | None = None

    def require_valid(self) -> "FileLaneConfig":
        """Validate flags, native integer ranges, and the four-worker bound."""
        allowed_flags = int(FileLaneFlags.SENDER | FileLaneFlags.RECEIVER)
        if int(self.flags) == 0 or int(self.flags) & ~allowed_flags:
            raise ValueError("file lane requires valid sender or receiver flags")
        if not 0 <= self.bind_port <= 65535:
            raise ValueError("file lane bind_port must be in [0, 65535]")
        for field, value, maximum in (
            ("queue_capacity", self.queue_capacity, ctypes.c_size_t(-1).value),
            ("max_file_size", self.max_file_size, 0xFFFFFFFFFFFFFFFF),
            ("io_timeout_ms", self.io_timeout_ms, 0xFFFFFFFF),
            ("checkpoint_bytes", self.checkpoint_bytes, 0xFFFFFFFFFFFFFFFF),
            ("progress_bytes", self.progress_bytes, 0xFFFFFFFFFFFFFFFF),
            ("progress_interval_ms", self.progress_interval_ms, 0xFFFFFFFF),
        ):
            if not 0 <= value <= maximum:
                raise ValueError(f"{field} is outside the native unsigned range")
        if not 0 <= self.sender_worker_count <= 4:
            raise ValueError("sender_worker_count must be in [0, 4]")
        if not 0 <= self.receiver_worker_count <= 4:
            raise ValueError("receiver_worker_count must be in [0, 4]")
        return self


@dataclass(frozen=True)
class FileReceiveSpec:
    """Receiver authorization and exact content identity for one transfer.

    ``destination_path`` remains local to the receiver. The app-host returns
    only the transfer ID, one-use token, size, digest, host, and port to sender.
    """
    transfer_id: str
    authorization_token: str
    destination_path: str | os.PathLike[str]
    expected_size: int
    expected_sha256: bytes


@dataclass(frozen=True)
class FileSendSpec:
    """Source and receiver endpoint for one previously prepared transfer.

    ``timeout_ms=0`` selects the lane timeout. Size and SHA-256 must exactly
    match the receiver grant before the destination is committed.
    """
    transfer_id: str
    authorization_token: str
    remote_host: str
    remote_port: int
    source_path: str | os.PathLike[str]
    expected_size: int
    expected_sha256: bytes
    timeout_ms: int = 0


@dataclass(frozen=True)
class FileDigest:
    """SHA-256 plus exact byte count returned by :meth:`FileLane.sha256`."""
    sha256: bytes
    size: int


@dataclass(frozen=True)
class FileTransferSnapshot:
    """Immutable progress view with process-local monotonic timestamps.

    Byte fields describe this transfer side, ``progress_milli`` ranges from 0
    to 100000 (100.000%), and ``update_sequence`` advances whenever retained
    state changes.
    """
    direction: FileTransferDirection
    state: FileTransferState
    result: FileTransferResult
    expected_size: int
    transferred_bytes: int
    committed_offset: int
    progress_milli: int
    cancel_requested: bool
    update_sequence: int
    submitted_mono_ns: int
    started_mono_ns: int
    updated_mono_ns: int
    terminal_mono_ns: int
    detail: str

    @property
    def terminal(self) -> bool:
        """Return whether this side has reached a terminal state."""
        return self.state in TERMINAL_FILE_TRANSFER_STATES

    @property
    def completed(self) -> bool:
        """Return whether this side completed with an OK result."""
        return self.state == FileTransferState.COMPLETED and self.result == FileTransferResult.OK


@dataclass(frozen=True)
class FileLaneStats:
    """Bounded queue, active-work, terminal-count, and completed-byte counters.

    Values are copied at observation time; byte and terminal counters are
    cumulative since lane start.
    """
    queue_capacity: int
    queued_sends: int
    prepared_receives: int
    active_sends: int
    active_receives: int
    retained_records: int
    submitted_sends: int
    prepared_receive_count: int
    completed_sends: int
    completed_receives: int
    failed_sends: int
    failed_receives: int
    canceled_transfers: int
    completed_send_bytes: int
    completed_receive_bytes: int


class _SecurityConfig(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("mode", ctypes.c_uint32),
        ("reserved", ctypes.c_uint32),
        ("credential_generation", ctypes.c_uint64),
        ("credential_id", ctypes.c_char_p),
        ("ca_certificate_file", ctypes.c_char_p),
        ("identity_certificate_file", ctypes.c_char_p),
        ("private_key_file", ctypes.c_char_p),
    ]


class _LaneConfig(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("flags", ctypes.c_uint32),
        ("bind_host", ctypes.c_char_p),
        ("bind_port", ctypes.c_uint16),
        ("queue_capacity", ctypes.c_size_t),
        ("max_file_size", ctypes.c_uint64),
        ("io_timeout_ms", ctypes.c_uint32),
        ("checkpoint_bytes", ctypes.c_uint64),
        ("progress_bytes", ctypes.c_uint64),
        ("progress_interval_ms", ctypes.c_uint32),
        ("sender_worker_count", ctypes.c_uint32),
        ("receiver_worker_count", ctypes.c_uint32),
        ("security", ctypes.POINTER(_SecurityConfig)),
    ]


class _ReceiveSpec(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("transfer_id", ctypes.c_char_p),
        ("authorization_token", ctypes.c_char_p),
        ("destination_path", ctypes.c_char_p),
        ("expected_size", ctypes.c_uint64),
        ("expected_sha256", ctypes.c_uint8 * SHA256_BYTES),
    ]


class _SendSpec(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("transfer_id", ctypes.c_char_p),
        ("authorization_token", ctypes.c_char_p),
        ("remote_host", ctypes.c_char_p),
        ("remote_port", ctypes.c_uint16),
        ("source_path", ctypes.c_char_p),
        ("expected_size", ctypes.c_uint64),
        ("expected_sha256", ctypes.c_uint8 * SHA256_BYTES),
        ("timeout_ms", ctypes.c_uint32),
    ]


class _TransferSnapshot(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("direction", ctypes.c_uint32),
        ("state", ctypes.c_uint32),
        ("result", ctypes.c_uint32),
        ("expected_size", ctypes.c_uint64),
        ("transferred_bytes", ctypes.c_uint64),
        ("committed_offset", ctypes.c_uint64),
        ("progress_milli", ctypes.c_uint32),
        ("cancel_requested", ctypes.c_uint32),
        ("update_sequence", ctypes.c_uint64),
        ("submitted_mono_ns", ctypes.c_uint64),
        ("started_mono_ns", ctypes.c_uint64),
        ("updated_mono_ns", ctypes.c_uint64),
        ("terminal_mono_ns", ctypes.c_uint64),
        ("detail", ctypes.c_char * DETAIL_MAX_BYTES),
    ]


class _LaneStats(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("queue_capacity", ctypes.c_size_t),
        ("queued_sends", ctypes.c_size_t),
        ("prepared_receives", ctypes.c_size_t),
        ("active_sends", ctypes.c_size_t),
        ("active_receives", ctypes.c_size_t),
        ("retained_records", ctypes.c_size_t),
        ("submitted_sends", ctypes.c_uint64),
        ("prepared_receive_count", ctypes.c_uint64),
        ("completed_sends", ctypes.c_uint64),
        ("completed_receives", ctypes.c_uint64),
        ("failed_sends", ctypes.c_uint64),
        ("failed_receives", ctypes.c_uint64),
        ("canceled_transfers", ctypes.c_uint64),
        ("completed_send_bytes", ctypes.c_uint64),
        ("completed_receive_bytes", ctypes.c_uint64),
    ]


def _text(value: str | os.PathLike[str]) -> bytes:
    return os.fsencode(value)


def _optional_text(value: str) -> bytes | None:
    return value.encode("utf-8") if value else None


def _digest(value: bytes) -> ctypes.Array[ctypes.c_uint8]:
    if len(value) != SHA256_BYTES:
        raise ValueError(f"expected_sha256 must contain exactly {SHA256_BYTES} bytes")
    return (ctypes.c_uint8 * SHA256_BYTES).from_buffer_copy(value)


class _Bindings:
    def __init__(self, runtime_lib_path: str | os.PathLike[str] | None) -> None:
        self.path = RuntimeLibraryResolver.resolve(runtime_lib_path)
        self.lib = ctypes.CDLL(self.path)
        self._bind()

    def _bind(self) -> None:
        lib = self.lib
        lib.coakka_v2_file_lane_create_ex.argtypes = [ctypes.POINTER(_LaneConfig), ctypes.POINTER(ctypes.c_void_p)]
        lib.coakka_v2_file_lane_create_ex.restype = ctypes.c_int
        lib.coakka_v2_file_lane_destroy.argtypes = [ctypes.c_void_p]
        lib.coakka_v2_file_lane_destroy.restype = None
        lib.coakka_v2_file_lane_start.argtypes = [ctypes.c_void_p]
        lib.coakka_v2_file_lane_start.restype = ctypes.c_int
        lib.coakka_v2_file_lane_stop.argtypes = [ctypes.c_void_p]
        lib.coakka_v2_file_lane_stop.restype = ctypes.c_int
        lib.coakka_v2_file_lane_get_bound_port.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint16)]
        lib.coakka_v2_file_lane_get_bound_port.restype = ctypes.c_int
        lib.coakka_v2_file_lane_prepare_receive.argtypes = [ctypes.c_void_p, ctypes.POINTER(_ReceiveSpec)]
        lib.coakka_v2_file_lane_prepare_receive.restype = ctypes.c_int
        lib.coakka_v2_file_lane_submit_send.argtypes = [ctypes.c_void_p, ctypes.POINTER(_SendSpec)]
        lib.coakka_v2_file_lane_submit_send.restype = ctypes.c_int
        lib.coakka_v2_file_lane_get_transfer.argtypes = [
            ctypes.c_void_p,
            ctypes.c_char_p,
            ctypes.c_uint32,
            ctypes.POINTER(_TransferSnapshot),
        ]
        lib.coakka_v2_file_lane_get_transfer.restype = ctypes.c_int
        lib.coakka_v2_file_lane_wait_transfer.argtypes = [
            ctypes.c_void_p,
            ctypes.c_char_p,
            ctypes.c_uint32,
            ctypes.c_uint64,
            ctypes.c_uint32,
            ctypes.POINTER(_TransferSnapshot),
        ]
        lib.coakka_v2_file_lane_wait_transfer.restype = ctypes.c_int
        lib.coakka_v2_file_lane_cancel_transfer.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
        lib.coakka_v2_file_lane_cancel_transfer.restype = ctypes.c_int
        lib.coakka_v2_file_lane_forget_transfer.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
        lib.coakka_v2_file_lane_forget_transfer.restype = ctypes.c_int
        lib.coakka_v2_file_lane_get_stats.argtypes = [ctypes.c_void_p, ctypes.POINTER(_LaneStats)]
        lib.coakka_v2_file_lane_get_stats.restype = ctypes.c_int
        lib.coakka_v2_file_sha256_path.argtypes = [
            ctypes.c_char_p,
            ctypes.POINTER(ctypes.c_uint8),
            ctypes.POINTER(ctypes.c_uint64),
        ]
        lib.coakka_v2_file_sha256_path.restype = ctypes.c_int


def _require_status(status: int, operation: str) -> None:
    if status != 0:
        raise FileLaneError(operation, status)


def _snapshot(native: _TransferSnapshot) -> FileTransferSnapshot:
    return FileTransferSnapshot(
        direction=FileTransferDirection(native.direction),
        state=FileTransferState(native.state),
        result=FileTransferResult(native.result),
        expected_size=native.expected_size,
        transferred_bytes=native.transferred_bytes,
        committed_offset=native.committed_offset,
        progress_milli=native.progress_milli,
        cancel_requested=native.cancel_requested != 0,
        update_sequence=native.update_sequence,
        submitted_mono_ns=native.submitted_mono_ns,
        started_mono_ns=native.started_mono_ns,
        updated_mono_ns=native.updated_mono_ns,
        terminal_mono_ns=native.terminal_mono_ns,
        detail=bytes(native.detail).split(b"\0", 1)[0].decode("utf-8", errors="replace"),
    )


class FileLane:
    """Owns one independent bulk-file lane backed by the CoAkka core-runtime.

    Prepare the receiver before submitting the sender. Continue
    :meth:`wait_transfer` from each update sequence until both sides report a
    successful terminal snapshot, then :meth:`forget` retained records.

    Connector calls may run concurrently. :meth:`close` rejects new calls, stops
    the lane to wake blocked waits, drains in-flight calls, and destroys it.
    This resource is independent of ``RuntimeHost``; do not put file bytes in a
    runtime ``Envelope``.
    """

    def __init__(self, bindings: _Bindings, handle: int) -> None:
        self._bindings = bindings
        self._handle: int | None = handle
        self._condition = threading.Condition()
        self._active_calls = 0
        self._closing = False

    @classmethod
    def open(
        cls,
        config: FileLaneConfig = FileLaneConfig(),
        runtime_lib_path: str | os.PathLike[str] | None = None,
    ) -> "FileLane":
        """Open and start a lane.

        Args:
            config: Bounded capabilities, workers, progress, and security settings.
            runtime_lib_path: Explicit core-runtime path, or ``None`` for connector resolution.

        Raises:
            FileLaneError: If the core-runtime cannot create or start the lane.
        """
        config.require_valid()
        bindings = _Bindings(runtime_lib_path)
        security_native = None
        security_pointer = None
        if config.security is not None:
            security = config.security
            security_native = _SecurityConfig(
                ctypes.sizeof(_SecurityConfig),
                int(security.mode),
                0,
                security.credential_generation,
                _optional_text(security.credential_id),
                _optional_text(security.ca_certificate_file),
                _optional_text(security.identity_certificate_file),
                _optional_text(security.private_key_file),
            )
            security_pointer = ctypes.pointer(security_native)
        native = _LaneConfig(
            ctypes.sizeof(_LaneConfig),
            int(config.flags),
            _text(config.bind_host),
            config.bind_port,
            config.queue_capacity,
            config.max_file_size,
            config.io_timeout_ms,
            config.checkpoint_bytes,
            config.progress_bytes,
            config.progress_interval_ms,
            config.sender_worker_count,
            config.receiver_worker_count,
            security_pointer,
        )
        out_handle = ctypes.c_void_p()
        _require_status(bindings.lib.coakka_v2_file_lane_create_ex(native, out_handle), "file_lane_create")
        if out_handle.value is None:
            raise FileLaneError("file_lane_create", -2)
        lane = cls(bindings, out_handle.value)
        try:
            _require_status(bindings.lib.coakka_v2_file_lane_start(out_handle), "file_lane_start")
        except BaseException:
            bindings.lib.coakka_v2_file_lane_destroy(out_handle)
            lane._handle = None
            raise
        return lane

    @classmethod
    def sha256(
        cls,
        path: str | os.PathLike[str],
        runtime_lib_path: str | os.PathLike[str] | None = None,
    ) -> FileDigest:
        """Compute the exact source identity through the selected core-runtime.

        Args:
            path: Readable regular file to hash.
            runtime_lib_path: Explicit core-runtime path, or ``None`` for connector resolution.
        """
        bindings = _Bindings(runtime_lib_path)
        digest = (ctypes.c_uint8 * SHA256_BYTES)()
        size = ctypes.c_uint64()
        _require_status(bindings.lib.coakka_v2_file_sha256_path(_text(path), digest, size), "file_sha256_path")
        return FileDigest(bytes(digest), size.value)

    @contextmanager
    def _borrow_handle(self) -> Iterator[ctypes.c_void_p]:
        with self._condition:
            if self._handle is None or self._closing:
                raise RuntimeError("file lane is closed")
            self._active_calls += 1
            handle = ctypes.c_void_p(self._handle)
        try:
            yield handle
        finally:
            with self._condition:
                self._active_calls -= 1
                if self._active_calls == 0:
                    self._condition.notify_all()

    @property
    def bound_port(self) -> int:
        """Return the receiver port selected when the lane started."""
        port = ctypes.c_uint16()
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_file_lane_get_bound_port(handle, port), "file_lane_get_bound_port")
        return port.value

    def prepare_receive(self, spec: FileReceiveSpec) -> None:
        """Authorize one destination and expected content identity.

        Args:
            spec: Local destination, one-use grant, exact byte size, and SHA-256.
        """
        if not 0 <= spec.expected_size <= 0xFFFFFFFFFFFFFFFF:
            raise ValueError("expected_size must fit uint64")
        native = _ReceiveSpec(
            ctypes.sizeof(_ReceiveSpec),
            spec.transfer_id.encode(),
            spec.authorization_token.encode(),
            _text(spec.destination_path),
            spec.expected_size,
            _digest(spec.expected_sha256),
        )
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_file_lane_prepare_receive(handle, native), "file_lane_prepare_receive")

    def submit_send(self, spec: FileSendSpec) -> None:
        """Queue a send after the remote application prepares the receive.

        Args:
            spec: Source plus the endpoint and grant returned by the receiver.
        """
        if not 0 < spec.remote_port <= 65535:
            raise ValueError("remote_port must be in [1, 65535]")
        if not 0 <= spec.expected_size <= 0xFFFFFFFFFFFFFFFF:
            raise ValueError("expected_size must fit uint64")
        if not 0 <= spec.timeout_ms <= 0xFFFFFFFF:
            raise ValueError("timeout_ms must fit uint32")
        native = _SendSpec(
            ctypes.sizeof(_SendSpec),
            spec.transfer_id.encode(),
            spec.authorization_token.encode(),
            spec.remote_host.encode(),
            spec.remote_port,
            _text(spec.source_path),
            spec.expected_size,
            _digest(spec.expected_sha256),
            spec.timeout_ms,
        )
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_file_lane_submit_send(handle, native), "file_lane_submit_send")

    def transfer(self, transfer_id: str, direction: FileTransferDirection) -> FileTransferSnapshot:
        """Return the current copied snapshot without waiting.

        Args:
            transfer_id: Application correlation ID used by both peers.
            direction: Sender or receiver record to observe.
        """
        native = _TransferSnapshot(struct_size=ctypes.sizeof(_TransferSnapshot))
        with self._borrow_handle() as handle:
            _require_status(
                self._bindings.lib.coakka_v2_file_lane_get_transfer(handle, transfer_id.encode(), int(direction), native),
                "file_lane_get_transfer",
            )
        return _snapshot(native)

    def wait_transfer(
        self,
        transfer_id: str,
        direction: FileTransferDirection,
        after_update_sequence: int = 0,
        timeout_ms: int = 30_000,
    ) -> FileTransferSnapshot:
        """Wait for a newer sequence, timeout, or lane shutdown.

        Args:
            transfer_id: Application correlation ID used by both peers.
            direction: Sender or receiver record to observe.
            after_update_sequence: Last sequence already handled; zero requests current state.
            timeout_ms: Bounded wait in milliseconds; zero performs a non-blocking check.
        """
        if not 0 <= after_update_sequence <= 0xFFFFFFFFFFFFFFFF:
            raise ValueError("after_update_sequence must fit uint64")
        if not 0 <= timeout_ms <= 0xFFFFFFFF:
            raise ValueError("timeout_ms must fit uint32")
        native = _TransferSnapshot(struct_size=ctypes.sizeof(_TransferSnapshot))
        with self._borrow_handle() as handle:
            _require_status(
                self._bindings.lib.coakka_v2_file_lane_wait_transfer(
                    handle,
                    transfer_id.encode(),
                    int(direction),
                    after_update_sequence,
                    timeout_ms,
                    native,
                ),
                "file_lane_wait_transfer",
            )
        return _snapshot(native)

    def cancel(self, transfer_id: str, direction: FileTransferDirection) -> None:
        """Request cooperative cancellation; still observe the terminal state.

        Args:
            transfer_id: Application correlation ID used by both peers.
            direction: Local retained record to cancel.
        """
        with self._borrow_handle() as handle:
            _require_status(
                self._bindings.lib.coakka_v2_file_lane_cancel_transfer(handle, transfer_id.encode(), int(direction)),
                "file_lane_cancel_transfer",
            )

    def forget(self, transfer_id: str, direction: FileTransferDirection) -> None:
        """Release one retained terminal record after recording its outcome.

        Args:
            transfer_id: Application correlation ID used by both peers.
            direction: Local terminal record to release.
        """
        with self._borrow_handle() as handle:
            _require_status(
                self._bindings.lib.coakka_v2_file_lane_forget_transfer(handle, transfer_id.encode(), int(direction)),
                "file_lane_forget_transfer",
            )

    def stats(self) -> FileLaneStats:
        """Return a copied lane-level observability snapshot."""
        native = _LaneStats(struct_size=ctypes.sizeof(_LaneStats))
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_file_lane_get_stats(handle, native), "file_lane_get_stats")
        return FileLaneStats(*[getattr(native, field) for field, _ in _LaneStats._fields_[1:]])

    def close(self) -> None:
        """Stop, wake blocked waits, drain calls, and destroy the lane."""
        with self._condition:
            if self._handle is None:
                return
            if self._closing:
                while self._handle is not None:
                    self._condition.wait()
                return
            self._closing = True
            handle = ctypes.c_void_p(self._handle)

        status = self._bindings.lib.coakka_v2_file_lane_stop(handle)

        with self._condition:
            while self._active_calls != 0:
                self._condition.wait()
        try:
            if status not in (0, -7):
                raise FileLaneError("file_lane_stop", status)
        finally:
            self._bindings.lib.coakka_v2_file_lane_destroy(handle)
            with self._condition:
                self._handle = None
                self._condition.notify_all()

    def __enter__(self) -> "FileLane":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()
