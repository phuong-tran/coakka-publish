from __future__ import annotations

import ctypes
from dataclasses import dataclass


LANE_OWNER_GRANTS_FEATURE = 1 << 25


@dataclass(frozen=True)
class LaneOwnerConfig:
    """Stable identity and exact reachable address of one lane-owning process or pod."""

    owner_instance_id: str
    advertised_host: str

    def require_valid(self) -> "LaneOwnerConfig":
        _visible_ascii(self.owner_instance_id, 127, "owner_instance_id")
        _visible_ascii(self.advertised_host, 255, "advertised_host")
        return self


@dataclass(frozen=True)
class LaneOwnerEndpoint:
    """Copied endpoint for the exact owner of prepared lane state."""

    owner_instance_id: str
    advertised_host: str
    port: int

    def __post_init__(self) -> None:
        _visible_ascii(self.owner_instance_id, 127, "owner_instance_id")
        _visible_ascii(self.advertised_host, 255, "advertised_host")
        if not 1 <= self.port <= 65535:
            raise ValueError("port must be in [1, 65535]")


class LaneOwnerGrantUnavailableError(RuntimeError):
    """The selected native runtime cannot provide owner-pinned lane grants."""


class _OwnerConfig(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("owner_instance_id", ctypes.c_char_p),
        ("advertised_host", ctypes.c_char_p),
    ]


class _OwnerEndpoint(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("port", ctypes.c_uint16),
        ("reserved", ctypes.c_uint16),
        ("owner_instance_id", ctypes.c_char * 128),
        ("advertised_host", ctypes.c_char * 256),
    ]


class _RuntimeInfo(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("abi_version", ctypes.c_uint32),
        ("feature_flags", ctypes.c_uint32),
        ("runtime_version", ctypes.c_char_p),
        ("git_commit", ctypes.c_char_p),
        ("southbound_backend", ctypes.c_char_p),
        ("allocator_backend", ctypes.c_char_p),
        ("docs_hint", ctypes.c_char_p),
    ]


def _require_owner_grants(lib: ctypes.CDLL) -> None:
    get_info = lib.coakka_v2_runtime_get_info
    get_info.argtypes = [ctypes.POINTER(_RuntimeInfo)]
    get_info.restype = ctypes.c_int
    info = _RuntimeInfo(struct_size=ctypes.sizeof(_RuntimeInfo))
    status = get_info(info)
    if status != 0:
        raise LaneOwnerGrantUnavailableError(f"runtime_get_info failed: native status {status}")
    if not info.feature_flags & LANE_OWNER_GRANTS_FEATURE:
        raise LaneOwnerGrantUnavailableError("native runtime does not advertise lane_owner_grants feature bit 25")


def _endpoint(native: _OwnerEndpoint) -> LaneOwnerEndpoint:
    return LaneOwnerEndpoint(
        owner_instance_id=bytes(native.owner_instance_id).split(b"\0", 1)[0].decode("ascii"),
        advertised_host=bytes(native.advertised_host).split(b"\0", 1)[0].decode("ascii"),
        port=native.port,
    )


def _visible_ascii(value: str, maximum: int, field: str) -> bytes:
    try:
        encoded = value.encode("ascii")
    except UnicodeEncodeError as error:
        raise ValueError(f"{field} must contain visible ASCII only") from error
    if not encoded or len(encoded) > maximum or any(byte <= 0x20 or byte > 0x7E for byte in encoded):
        raise ValueError(f"{field} must contain 1..{maximum} visible ASCII bytes")
    return encoded
