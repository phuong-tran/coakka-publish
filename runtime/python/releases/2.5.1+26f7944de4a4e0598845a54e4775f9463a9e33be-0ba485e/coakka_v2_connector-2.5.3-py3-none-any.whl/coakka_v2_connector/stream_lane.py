from __future__ import annotations

import ctypes
import os
import threading
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import IntEnum, IntFlag
from typing import Callable, Iterator, TypeAlias

from .orchestrator import RuntimeLibraryResolver
from .lane_owner_grant import (
    LaneOwnerConfig,
    LaneOwnerEndpoint,
    LaneOwnerGrantUnavailableError,
    _OwnerConfig,
    _OwnerEndpoint,
    _endpoint,
    _require_owner_grants,
    _visible_ascii,
)


DETAIL_MAX_BYTES = 160
MAX_FRAME_BYTES = 4 * 1024 * 1024
MAX_WINDOW_BYTES = 16 * 1024 * 1024


class StreamLaneFlags(IntFlag):
    """Direction capabilities enabled on a stream lane."""

    PUBLISHER = 1
    SUBSCRIBER = 1 << 1


class StreamFrameFlags(IntFlag):
    """Transport-neutral frame annotations supplied by the app-host."""

    KEYFRAME = 1
    DISCONTINUITY = 1 << 1
    END_OF_SEGMENT = 1 << 2


class StreamPressureReasons(IntFlag):
    """Reasons constraining progress; multiple bits may be present."""

    CREDIT_WAIT = 1
    TRANSPORT_WRITE = 1 << 1
    CONSUMER_BUSY = 1 << 2
    TRANSPORT_READ = 1 << 3


class StreamLaneSecurityMode(IntEnum):
    """Transport protection; per-session authorization remains mandatory."""

    DIRECT = 0
    TLS = 1
    MUTUAL_TLS = 2


class StreamDirection(IntEnum):
    """Side of a retained stream session used by observation and control."""

    PUBLISH = 1
    SUBSCRIBE = 2


class StreamState(IntEnum):
    """Observable lifecycle state for one stream-session side."""

    PREPARED = 1
    QUEUED = 2
    CONNECTING = 3
    ACTIVE = 4
    STOPPING = 5
    ENDED = 6
    REJECTED = 7
    FAILED = 8
    CANCELED = 9


class StreamResult(IntEnum):
    """Stable terminal outcome reported independently by each peer."""

    NONE = 0
    OK = 1
    NOT_PREPARED = 2
    TOKEN_MISMATCH = 3
    FORMAT_MISMATCH = 4
    FRAME_LIMIT = 5
    NETWORK_IO = 6
    TIMEOUT = 7
    QUEUE_FULL = 8
    PROTOCOL_ERROR = 9
    SOURCE_ERROR = 10
    CONSUMER_ERROR = 11
    INTERNAL_ERROR = 12
    CANCELED_BY_HOST = 13
    TLS_CONFIG_INVALID = 14
    TLS_HANDSHAKE_FAILED = 15
    PEER_CERT_UNTRUSTED = 16
    PEER_CERT_EXPIRED = 17
    PEER_IDENTITY_MISMATCH = 18
    CLIENT_CERT_REQUIRED = 19


class StreamPressureState(IntEnum):
    """Coalesced transport state reported to app-host policy."""

    INACTIVE = 0
    FLOWING = 1
    PRESSURED = 2
    STALLED = 3
    RECOVERING = 4


class StreamSourceSignal(IntEnum):
    """Non-frame result from a bounded publisher callback."""

    WOULD_BLOCK = 1
    END = 2


class StreamConsumerDecision(IntEnum):
    """Subscriber action after consuming one borrowed frame."""

    CONTINUE = 1
    STOP = 2


TERMINAL_STREAM_STATES = frozenset(
    {StreamState.ENDED, StreamState.REJECTED, StreamState.FAILED, StreamState.CANCELED}
)


class StreamLaneError(RuntimeError):
    """Native status failure for a named stream-lane operation."""

    def __init__(self, operation: str, status: int) -> None:
        super().__init__(f"{operation} failed: native status {status}")
        self.operation = operation
        self.status = status


@dataclass(frozen=True)
class StreamLaneSecurityConfig:
    """TLS material read at startup; key paths and tokens must not be logged.

    Attributes:
        mode: Direct, server-authenticated TLS, or mutual TLS.
        credential_generation: App-host credential generation for diagnostics.
        credential_id: Non-secret credential identifier.
        ca_certificate_file: Trusted CA bundle path.
        identity_certificate_file: Local certificate-chain path.
        private_key_file: Local private-key path.
    """

    mode: StreamLaneSecurityMode = StreamLaneSecurityMode.DIRECT
    credential_generation: int = 0
    credential_id: str = ""
    ca_certificate_file: str = ""
    identity_certificate_file: str = ""
    private_key_file: str = ""


@dataclass(frozen=True)
class StreamLaneConfig:
    """Bounded stream settings; zero tuning values select core-runtime defaults.

    ``flags`` controls publisher/subscriber capability. ``capacity``, frame and
    window bounds, worker counts, progress cadence, I/O timeout, and pressure
    timings are copied during :meth:`StreamLane.open`.
    """

    flags: StreamLaneFlags = StreamLaneFlags.PUBLISHER | StreamLaneFlags.SUBSCRIBER
    bind_host: str = "127.0.0.1"
    bind_port: int = 0
    capacity: int = 0
    max_frame_bytes: int = 0
    max_window_bytes: int = 0
    io_timeout_ms: int = 0
    source_retry_ms: int = 0
    progress_frames: int = 0
    progress_interval_ms: int = 0
    publisher_worker_count: int = 0
    subscriber_worker_count: int = 0
    security: StreamLaneSecurityConfig | None = None
    pressure_after_ms: int = 0
    stalled_after_ms: int = 0
    recovery_after_ms: int = 0
    pressure_observation_ms: int = 0

    def require_valid(self) -> "StreamLaneConfig":
        """Validate ranges before any native resource is allocated."""
        allowed = int(StreamLaneFlags.PUBLISHER | StreamLaneFlags.SUBSCRIBER)
        if int(self.flags) == 0 or int(self.flags) & ~allowed:
            raise ValueError("stream lane requires valid publisher or subscriber flags")
        if not 0 <= self.bind_port <= 65535:
            raise ValueError("bind_port must be in [0, 65535]")
        if not 0 <= self.capacity <= 64:
            raise ValueError("capacity must be in [0, 64]")
        if not 0 <= self.max_frame_bytes <= MAX_FRAME_BYTES:
            raise ValueError("max_frame_bytes exceeds the native ceiling")
        if not 0 <= self.max_window_bytes <= MAX_WINDOW_BYTES:
            raise ValueError("max_window_bytes exceeds the native ceiling")
        if self.max_frame_bytes and self.max_window_bytes and self.max_window_bytes < self.max_frame_bytes:
            raise ValueError("max_window_bytes must cover one maximum frame")
        if not 0 <= self.io_timeout_ms <= 0xFFFFFFFF:
            raise ValueError("io_timeout_ms must fit uint32")
        if not 0 <= self.source_retry_ms <= 1000:
            raise ValueError("source_retry_ms must be in [0, 1000]")
        if not 0 <= self.progress_frames <= 0xFFFFFFFF or not 0 <= self.progress_interval_ms <= 0xFFFFFFFF:
            raise ValueError("progress settings must fit uint32")
        if not 0 <= self.publisher_worker_count <= 4 or not 0 <= self.subscriber_worker_count <= 4:
            raise ValueError("stream worker counts must be in [0, 4]")
        for name, value in (
            ("pressure_after_ms", self.pressure_after_ms),
            ("stalled_after_ms", self.stalled_after_ms),
            ("recovery_after_ms", self.recovery_after_ms),
            ("pressure_observation_ms", self.pressure_observation_ms),
        ):
            if not 0 <= value <= 60_000:
                raise ValueError(f"{name} must be in [0, 60000]")
        return self


@dataclass(frozen=True)
class StreamSourceFrame:
    """Metadata for bytes already written into the borrowed source buffer.

    Attributes:
        size: Positive byte count written by the callback.
        captured_mono_ns: Publisher monotonic capture time, or zero for native time.
        dropped_before: Source-side frames dropped before this frame.
        flags: Transport-neutral :class:`StreamFrameFlags` bits.
    """

    size: int
    captured_mono_ns: int = 0
    dropped_before: int = 0
    flags: StreamFrameFlags = StreamFrameFlags(0)


StreamSourceResult: TypeAlias = StreamSourceFrame | StreamSourceSignal
StreamSource: TypeAlias = Callable[[memoryview], StreamSourceResult]


@dataclass(frozen=True)
class StreamFrameMetadata:
    """Metadata paired with one borrowed subscriber frame.

    ``captured_mono_ns`` is publisher monotonic time, not wall-clock time;
    ``flags`` are app-host annotations transported without interpretation.
    """

    sequence: int
    captured_mono_ns: int
    dropped_before: int
    flags: StreamFrameFlags


StreamConsumer: TypeAlias = Callable[[memoryview, StreamFrameMetadata], StreamConsumerDecision | None]


@dataclass(frozen=True)
class StreamPublishSpec:
    """Service B authorization, opaque format contract, frame bound, and source."""

    session_id: str
    authorization_token: str = field(repr=False)
    format_id: int
    max_frame_bytes: int
    source: StreamSource


@dataclass(frozen=True)
class StreamSubscribeSpec:
    """Service A endpoint, authorization, flow-control window, and consumer."""

    session_id: str
    authorization_token: str = field(repr=False)
    remote_host: str
    remote_port: int
    format_id: int
    max_frame_bytes: int
    initial_window_bytes: int
    consumer: StreamConsumer
    timeout_ms: int = 0


@dataclass(frozen=True)
class StreamPublishGrant:
    """Single-admission stream capability pinned to the exact publisher owner."""

    owner: LaneOwnerEndpoint
    session_id: str
    authorization_token: str = field(repr=False)
    format_id: int
    max_frame_bytes: int

    def __post_init__(self) -> None:
        _visible_ascii(self.session_id, 64, "session_id")
        _visible_ascii(self.authorization_token, 128, "authorization_token")
        if not 1 <= self.format_id <= 0xFFFF_FFFF_FFFF_FFFF:
            raise ValueError("format_id must be in [1, uint64 max]")
        if not 1 <= self.max_frame_bytes <= MAX_FRAME_BYTES:
            raise ValueError(
                f"max_frame_bytes must be in [1, {MAX_FRAME_BYTES}]"
            )

    def to_subscribe_spec(
        self,
        initial_window_bytes: int,
        consumer: StreamConsumer,
        timeout_ms: int = 0,
    ) -> StreamSubscribeSpec:
        """Build the subscriber job directly from this immutable owner-pinned grant."""
        return StreamSubscribeSpec(
            session_id=self.session_id,
            authorization_token=self.authorization_token,
            remote_host=self.owner.advertised_host,
            remote_port=self.owner.port,
            format_id=self.format_id,
            max_frame_bytes=self.max_frame_bytes,
            initial_window_bytes=initial_window_bytes,
            consumer=consumer,
            timeout_ms=timeout_ms,
        )


@dataclass(frozen=True)
class StreamSessionSnapshot:
    """Copied session progress; monotonic timestamps are not wall-clock time.

    Frame and byte counters are cumulative for this session side, while
    ``update_sequence`` advances whenever retained state changes.
    """

    direction: StreamDirection
    state: StreamState
    result: StreamResult
    format_id: int
    frames: int
    bytes: int
    dropped_frames: int
    last_sequence: int
    negotiated_max_frame_bytes: int
    window_bytes: int
    cancel_requested: bool
    update_sequence: int
    submitted_mono_ns: int
    started_mono_ns: int
    updated_mono_ns: int
    terminal_mono_ns: int
    detail: str

    @property
    def terminal(self) -> bool:
        """Return whether this retained session side reached a terminal state."""
        return self.state in TERMINAL_STREAM_STATES

    @property
    def completed(self) -> bool:
        """Return whether the session ended normally with an OK result."""
        return self.state == StreamState.ENDED and self.result == StreamResult.OK


@dataclass(frozen=True)
class StreamPressureSnapshot:
    """Copied neutral pressure signal consumed by app-host policy.

    Durations and timestamps are nanoseconds; ``observed_delivery_bps`` is
    bytes per second. Reasons may contain multiple :class:`StreamPressureReasons`.
    """

    direction: StreamDirection
    state: StreamPressureState
    reason_bits: StreamPressureReasons
    available_credit_bytes: int
    window_capacity_bytes: int
    update_sequence: int
    transition_count: int
    observed_mono_ns: int
    state_started_mono_ns: int
    pressure_started_mono_ns: int
    last_progress_mono_ns: int
    observed_delivery_bps: int
    current_operation_ns: int
    last_operation_ns: int
    total_pressured_ns: int
    max_pressured_ns: int


@dataclass(frozen=True)
class StreamLaneStats:
    """Bounded queue, active-session, terminal, frame, byte, and drop counters."""

    capacity: int
    queued_subscribers: int
    prepared_publishers: int
    active_publishers: int
    active_subscribers: int
    retained_records: int
    submitted_subscribers: int
    prepared_publisher_count: int
    ended_publishers: int
    ended_subscribers: int
    failed_publishers: int
    failed_subscribers: int
    canceled_sessions: int
    published_frames: int
    published_bytes: int
    consumed_frames: int
    consumed_bytes: int
    source_reported_drops: int


class _Frame(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("sequence", ctypes.c_uint64),
        ("captured_mono_ns", ctypes.c_uint64),
        ("dropped_before", ctypes.c_uint64),
        ("flags", ctypes.c_uint32),
        ("size", ctypes.c_size_t),
    ]


_SourceNext = ctypes.CFUNCTYPE(
    ctypes.c_int,
    ctypes.c_void_p,
    ctypes.POINTER(ctypes.c_uint8),
    ctypes.c_size_t,
    ctypes.POINTER(_Frame),
)
_Consumer = ctypes.CFUNCTYPE(
    ctypes.c_int,
    ctypes.c_void_p,
    ctypes.POINTER(ctypes.c_uint8),
    ctypes.POINTER(_Frame),
)


class _SecurityConfig(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t), ("mode", ctypes.c_uint32), ("reserved", ctypes.c_uint32),
        ("credential_generation", ctypes.c_uint64), ("credential_id", ctypes.c_char_p),
        ("ca_certificate_file", ctypes.c_char_p), ("identity_certificate_file", ctypes.c_char_p),
        ("private_key_file", ctypes.c_char_p),
    ]


class _LaneConfig(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t), ("flags", ctypes.c_uint32), ("bind_host", ctypes.c_char_p),
        ("bind_port", ctypes.c_uint16), ("capacity", ctypes.c_size_t), ("max_frame_bytes", ctypes.c_uint32),
        ("max_window_bytes", ctypes.c_uint32), ("io_timeout_ms", ctypes.c_uint32),
        ("source_retry_ms", ctypes.c_uint32), ("progress_frames", ctypes.c_uint32),
        ("progress_interval_ms", ctypes.c_uint32), ("publisher_worker_count", ctypes.c_uint32),
        ("subscriber_worker_count", ctypes.c_uint32), ("security", ctypes.POINTER(_SecurityConfig)),
        ("pressure_after_ms", ctypes.c_uint32), ("stalled_after_ms", ctypes.c_uint32),
        ("recovery_after_ms", ctypes.c_uint32), ("pressure_observation_ms", ctypes.c_uint32),
    ]


class _OwnedLaneConfig(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("lane", _LaneConfig),
        ("owner", _OwnerConfig),
    ]


class _PublishSpec(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t), ("session_id", ctypes.c_char_p),
        ("authorization_token", ctypes.c_char_p), ("format_id", ctypes.c_uint64),
        ("max_frame_bytes", ctypes.c_uint32), ("source_next", _SourceNext), ("source_context", ctypes.c_void_p),
    ]


class _SubscribeSpec(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t), ("session_id", ctypes.c_char_p),
        ("authorization_token", ctypes.c_char_p), ("remote_host", ctypes.c_char_p),
        ("remote_port", ctypes.c_uint16), ("format_id", ctypes.c_uint64),
        ("max_frame_bytes", ctypes.c_uint32), ("initial_window_bytes", ctypes.c_uint32),
        ("timeout_ms", ctypes.c_uint32), ("consume", _Consumer), ("consumer_context", ctypes.c_void_p),
    ]


class _PublishGrant(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t),
        ("owner", _OwnerEndpoint),
        ("session_id", ctypes.c_char * 65),
        ("authorization_token", ctypes.c_char * 129),
        ("format_id", ctypes.c_uint64),
        ("max_frame_bytes", ctypes.c_uint32),
        ("reserved", ctypes.c_uint32),
    ]


class _SessionSnapshot(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t), ("direction", ctypes.c_uint32), ("state", ctypes.c_uint32),
        ("result", ctypes.c_uint32), ("format_id", ctypes.c_uint64), ("frames", ctypes.c_uint64),
        ("bytes", ctypes.c_uint64), ("dropped_frames", ctypes.c_uint64), ("last_sequence", ctypes.c_uint64),
        ("negotiated_max_frame_bytes", ctypes.c_uint32), ("window_bytes", ctypes.c_uint32),
        ("cancel_requested", ctypes.c_uint32), ("update_sequence", ctypes.c_uint64),
        ("submitted_mono_ns", ctypes.c_uint64), ("started_mono_ns", ctypes.c_uint64),
        ("updated_mono_ns", ctypes.c_uint64), ("terminal_mono_ns", ctypes.c_uint64),
        ("detail", ctypes.c_char * DETAIL_MAX_BYTES),
    ]


class _PressureSnapshot(ctypes.Structure):
    _fields_ = [
        ("struct_size", ctypes.c_size_t), ("direction", ctypes.c_uint32), ("state", ctypes.c_uint32),
        ("reason_bits", ctypes.c_uint32), ("available_credit_bytes", ctypes.c_uint32),
        ("window_capacity_bytes", ctypes.c_uint32), ("update_sequence", ctypes.c_uint64),
        ("transition_count", ctypes.c_uint64), ("observed_mono_ns", ctypes.c_uint64),
        ("state_started_mono_ns", ctypes.c_uint64), ("pressure_started_mono_ns", ctypes.c_uint64),
        ("last_progress_mono_ns", ctypes.c_uint64), ("observed_delivery_bps", ctypes.c_uint64),
        ("current_operation_ns", ctypes.c_uint64), ("last_operation_ns", ctypes.c_uint64),
        ("total_pressured_ns", ctypes.c_uint64), ("max_pressured_ns", ctypes.c_uint64),
    ]


class _LaneStats(ctypes.Structure):
    _fields_ = [("struct_size", ctypes.c_size_t)] + [
        (name, ctypes.c_size_t)
        for name in ("capacity", "queued_subscribers", "prepared_publishers", "active_publishers", "active_subscribers", "retained_records")
    ] + [
        (name, ctypes.c_uint64)
        for name in (
            "submitted_subscribers", "prepared_publisher_count", "ended_publishers", "ended_subscribers",
            "failed_publishers", "failed_subscribers", "canceled_sessions", "published_frames", "published_bytes",
            "consumed_frames", "consumed_bytes", "source_reported_drops",
        )
    ]


class _Bindings:
    def __init__(self, runtime_lib_path: str | os.PathLike[str] | None) -> None:
        self.path = RuntimeLibraryResolver.resolve(runtime_lib_path)
        self.lib = ctypes.CDLL(self.path)
        self._bind()

    def _bind(self) -> None:
        lib = self.lib
        signatures = {
            "coakka_v2_stream_lane_create_ex": ([ctypes.POINTER(_LaneConfig), ctypes.POINTER(ctypes.c_void_p)], ctypes.c_int),
            "coakka_v2_stream_lane_destroy": ([ctypes.c_void_p], None),
            "coakka_v2_stream_lane_start": ([ctypes.c_void_p], ctypes.c_int),
            "coakka_v2_stream_lane_stop": ([ctypes.c_void_p], ctypes.c_int),
            "coakka_v2_stream_lane_get_bound_port": ([ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint16)], ctypes.c_int),
            "coakka_v2_stream_lane_prepare_publish": ([ctypes.c_void_p, ctypes.POINTER(_PublishSpec)], ctypes.c_int),
            "coakka_v2_stream_lane_subscribe": ([ctypes.c_void_p, ctypes.POINTER(_SubscribeSpec)], ctypes.c_int),
            "coakka_v2_stream_lane_get_session": ([ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32, ctypes.POINTER(_SessionSnapshot)], ctypes.c_int),
            "coakka_v2_stream_lane_wait_session": ([ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32, ctypes.c_uint64, ctypes.c_uint32, ctypes.POINTER(_SessionSnapshot)], ctypes.c_int),
            "coakka_v2_stream_lane_get_pressure": ([ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32, ctypes.POINTER(_PressureSnapshot)], ctypes.c_int),
            "coakka_v2_stream_lane_wait_pressure": ([ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32, ctypes.c_uint64, ctypes.c_uint32, ctypes.POINTER(_PressureSnapshot)], ctypes.c_int),
            "coakka_v2_stream_lane_cancel_session": ([ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32], ctypes.c_int),
            "coakka_v2_stream_lane_forget_session": ([ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32], ctypes.c_int),
            "coakka_v2_stream_lane_get_stats": ([ctypes.c_void_p, ctypes.POINTER(_LaneStats)], ctypes.c_int),
        }
        for name, (argtypes, restype) in signatures.items():
            function = getattr(lib, name)
            function.argtypes = argtypes
            function.restype = restype

    def bind_owner_grants(self) -> None:
        _require_owner_grants(self.lib)
        try:
            create = self.lib.coakka_v2_stream_lane_create_owned_ex
            prepare = self.lib.coakka_v2_stream_lane_prepare_publish_grant
        except AttributeError as error:
            raise LaneOwnerGrantUnavailableError(
                "native runtime advertises lane_owner_grants but omits the Stream Lane owner-grant symbols"
            ) from error
        create.argtypes = [ctypes.POINTER(_OwnedLaneConfig), ctypes.POINTER(ctypes.c_void_p)]
        create.restype = ctypes.c_int
        prepare.argtypes = [ctypes.c_void_p, ctypes.POINTER(_PublishSpec), ctypes.POINTER(_PublishGrant)]
        prepare.restype = ctypes.c_int


def _require_status(status: int, operation: str) -> None:
    if status != 0:
        raise StreamLaneError(operation, status)


def _encoded(value: str, name: str, maximum: int) -> bytes:
    encoded = value.encode("utf-8")
    if not encoded or len(encoded) > maximum:
        raise ValueError(f"{name} must contain 1..{maximum} UTF-8 bytes")
    return encoded


def _optional(value: str) -> bytes | None:
    return value.encode("utf-8") if value else None


def _native_lane_config(config: StreamLaneConfig) -> tuple[_SecurityConfig | None, _LaneConfig]:
    security_native = None
    security_pointer = None
    if config.security is not None:
        security = config.security
        security_native = _SecurityConfig(
            ctypes.sizeof(_SecurityConfig), int(security.mode), 0, security.credential_generation,
            _optional(security.credential_id), _optional(security.ca_certificate_file),
            _optional(security.identity_certificate_file), _optional(security.private_key_file),
        )
        security_pointer = ctypes.pointer(security_native)
    return security_native, _LaneConfig(
        ctypes.sizeof(_LaneConfig), int(config.flags), config.bind_host.encode(), config.bind_port,
        config.capacity, config.max_frame_bytes, config.max_window_bytes, config.io_timeout_ms,
        config.source_retry_ms, config.progress_frames, config.progress_interval_ms,
        config.publisher_worker_count, config.subscriber_worker_count, security_pointer,
        config.pressure_after_ms, config.stalled_after_ms, config.recovery_after_ms,
        config.pressure_observation_ms,
    )


def _publish_native(spec: StreamPublishSpec) -> tuple[ctypes._CFuncPtr, _PublishSpec]:
    session = _encoded(spec.session_id, "session_id", 64)
    token = _encoded(spec.authorization_token, "authorization_token", 128)
    if spec.format_id == 0:
        raise ValueError("format_id must be non-zero")
    if not 1 <= spec.max_frame_bytes <= MAX_FRAME_BYTES:
        raise ValueError("max_frame_bytes must be in [1, 4194304]")

    def source_next(_context, destination, capacity, out_frame) -> int:
        try:
            storage = (ctypes.c_uint8 * capacity).from_address(ctypes.addressof(destination.contents))
            result = spec.source(memoryview(storage).cast("B"))
            if result == StreamSourceSignal.WOULD_BLOCK:
                return -6
            if result == StreamSourceSignal.END:
                return -7
            if not isinstance(result, StreamSourceFrame):
                return -1
            if not 1 <= result.size <= capacity or result.captured_mono_ns < 0 or result.dropped_before < 0:
                return -1
            frame = out_frame.contents
            frame.captured_mono_ns = result.captured_mono_ns
            frame.dropped_before = result.dropped_before
            frame.flags = int(result.flags)
            frame.size = result.size
            return 0
        except BaseException:
            return -5

    callback = _SourceNext(source_next)
    return callback, _PublishSpec(
        ctypes.sizeof(_PublishSpec), session, token, spec.format_id, spec.max_frame_bytes, callback, None,
    )


def _session_snapshot(native: _SessionSnapshot) -> StreamSessionSnapshot:
    return StreamSessionSnapshot(
        StreamDirection(native.direction), StreamState(native.state), StreamResult(native.result), native.format_id,
        native.frames, native.bytes, native.dropped_frames, native.last_sequence, native.negotiated_max_frame_bytes,
        native.window_bytes, native.cancel_requested != 0, native.update_sequence, native.submitted_mono_ns,
        native.started_mono_ns, native.updated_mono_ns, native.terminal_mono_ns,
        bytes(native.detail).split(b"\0", 1)[0].decode("utf-8", errors="replace"),
    )


def _pressure_snapshot(native: _PressureSnapshot) -> StreamPressureSnapshot:
    return StreamPressureSnapshot(
        StreamDirection(native.direction), StreamPressureState(native.state), StreamPressureReasons(native.reason_bits),
        native.available_credit_bytes, native.window_capacity_bytes, native.update_sequence, native.transition_count,
        native.observed_mono_ns, native.state_started_mono_ns, native.pressure_started_mono_ns,
        native.last_progress_mono_ns, native.observed_delivery_bps, native.current_operation_ns,
        native.last_operation_ns, native.total_pressured_ns, native.max_pressured_ns,
    )


class StreamLane:
    """Own one independent stream lane backed by the CoAkka core-runtime.

    Publisher and consumer buffers are borrowed only for the callback duration.
    CoAkka transports ordered bounded bytes and pressure observations; format,
    bitrate, resolution, drop, and sink policy remain in the app-host.
    :meth:`close` stops native workers, drains concurrent API calls and callbacks,
    then destroys the lane and releases callback references.
    """

    def __init__(self, bindings: _Bindings, handle: int, owner_aware: bool = False) -> None:
        self._bindings = bindings
        self._handle: int | None = handle
        self._condition = threading.Condition()
        self._active_calls = 0
        self._closing = False
        self._callbacks: dict[tuple[str, StreamDirection], ctypes._CFuncPtr] = {}
        self._owner_aware = owner_aware

    @classmethod
    def open(
        cls,
        config: StreamLaneConfig = StreamLaneConfig(),
        runtime_lib_path: str | os.PathLike[str] | None = None,
    ) -> "StreamLane":
        """Open and start a lane.

        Args:
            config: Bounded capabilities, workers, security, and pressure settings.
            runtime_lib_path: Explicit core-runtime path, or ``None`` for normal resolution.
        """
        config.require_valid()
        bindings = _Bindings(runtime_lib_path)
        security_native = None
        security_pointer = None
        if config.security is not None:
            security = config.security
            security_native = _SecurityConfig(
                ctypes.sizeof(_SecurityConfig), int(security.mode), 0, security.credential_generation,
                _optional(security.credential_id), _optional(security.ca_certificate_file),
                _optional(security.identity_certificate_file), _optional(security.private_key_file),
            )
            security_pointer = ctypes.pointer(security_native)
        native = _LaneConfig(
            ctypes.sizeof(_LaneConfig), int(config.flags), config.bind_host.encode(), config.bind_port,
            config.capacity, config.max_frame_bytes, config.max_window_bytes, config.io_timeout_ms,
            config.source_retry_ms, config.progress_frames, config.progress_interval_ms,
            config.publisher_worker_count, config.subscriber_worker_count, security_pointer,
            config.pressure_after_ms, config.stalled_after_ms, config.recovery_after_ms,
            config.pressure_observation_ms,
        )
        out = ctypes.c_void_p()
        _require_status(bindings.lib.coakka_v2_stream_lane_create_ex(native, out), "stream_lane_create")
        if out.value is None:
            raise StreamLaneError("stream_lane_create", -2)
        lane = cls(bindings, out.value)
        try:
            _require_status(bindings.lib.coakka_v2_stream_lane_start(out), "stream_lane_start")
        except BaseException:
            bindings.lib.coakka_v2_stream_lane_destroy(out)
            lane._handle = None
            raise
        return lane

    @classmethod
    def open_owned(
        cls,
        config: StreamLaneConfig,
        owner: LaneOwnerConfig,
        runtime_lib_path: str | os.PathLike[str] | None = None,
    ) -> "StreamLane":
        """Open an exact-owner publisher lane capable of issuing replica-pinned grants."""
        config.require_valid()
        owner.require_valid()
        if not config.flags & StreamLaneFlags.PUBLISHER:
            raise ValueError("owner-aware stream lane must enable PUBLISHER")
        bindings = _Bindings(runtime_lib_path)
        bindings.bind_owner_grants()
        security_native, lane_native = _native_lane_config(config)
        owner_native = _OwnerConfig(
            ctypes.sizeof(_OwnerConfig),
            _visible_ascii(owner.owner_instance_id, 127, "owner_instance_id"),
            _visible_ascii(owner.advertised_host, 255, "advertised_host"),
        )
        native = _OwnedLaneConfig(ctypes.sizeof(_OwnedLaneConfig), lane_native, owner_native)
        out = ctypes.c_void_p()
        _require_status(bindings.lib.coakka_v2_stream_lane_create_owned_ex(native, out), "stream_lane_create_owned")
        if out.value is None:
            raise StreamLaneError("stream_lane_create_owned", -2)
        lane = cls(bindings, out.value, owner_aware=True)
        try:
            _require_status(bindings.lib.coakka_v2_stream_lane_start(out), "stream_lane_start")
        except BaseException:
            bindings.lib.coakka_v2_stream_lane_destroy(out)
            lane._handle = None
            raise
        _ = security_native
        return lane

    @contextmanager
    def _borrow_handle(self) -> Iterator[ctypes.c_void_p]:
        with self._condition:
            if self._handle is None or self._closing:
                raise RuntimeError("stream lane is closed")
            self._active_calls += 1
            handle = ctypes.c_void_p(self._handle)
        try:
            yield handle
        finally:
            with self._condition:
                self._active_calls -= 1
                if self._active_calls == 0:
                    self._condition.notify_all()

    @property
    def bound_port(self) -> int:
        """Return the publisher port selected when the lane started."""
        port = ctypes.c_uint16()
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_stream_lane_get_bound_port(handle, port), "stream_lane_get_bound_port")
        return port.value

    def prepare_publish(self, spec: StreamPublishSpec) -> None:
        """Prepare one authorized publisher callback.

        Args:
            spec: Session/token identity, opaque format ID, frame bound, and bounded source callback.
        """
        callback, native = _publish_native(spec)
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_stream_lane_prepare_publish(handle, native), "stream_lane_prepare_publish")
            with self._condition:
                self._callbacks[(spec.session_id, StreamDirection.PUBLISH)] = callback

    def prepare_publish_grant(self, spec: StreamPublishSpec) -> StreamPublishGrant:
        """Prepare one publisher and copy its exact-owner single-admission grant."""
        if not self._owner_aware:
            raise RuntimeError("prepare_publish_grant requires StreamLane.open_owned")
        callback, native_spec = _publish_native(spec)
        native = _PublishGrant(struct_size=ctypes.sizeof(_PublishGrant))
        with self._borrow_handle() as handle:
            _require_status(
                self._bindings.lib.coakka_v2_stream_lane_prepare_publish_grant(handle, native_spec, native),
                "stream_lane_prepare_publish_grant",
            )
            with self._condition:
                self._callbacks[(spec.session_id, StreamDirection.PUBLISH)] = callback
        return StreamPublishGrant(
            owner=_endpoint(native.owner),
            session_id=bytes(native.session_id).split(b"\0", 1)[0].decode("utf-8"),
            authorization_token=bytes(native.authorization_token).split(b"\0", 1)[0].decode("utf-8"),
            format_id=native.format_id,
            max_frame_bytes=native.max_frame_bytes,
        )

    def subscribe(self, spec: StreamSubscribeSpec) -> None:
        """Queue one subscriber and retain its consumer callback.

        Args:
            spec: Session grant, publisher endpoint, format/frame contract,
                initial credit window, timeout, and bounded consumer callback.
        """
        session = _encoded(spec.session_id, "session_id", 64)
        token = _encoded(spec.authorization_token, "authorization_token", 128)
        if not spec.remote_host:
            raise ValueError("remote_host must not be empty")
        if not 1 <= spec.remote_port <= 65535:
            raise ValueError("remote_port must be in [1, 65535]")
        if not 1 <= spec.max_frame_bytes <= MAX_FRAME_BYTES:
            raise ValueError("max_frame_bytes must be in [1, 4194304]")
        if not spec.max_frame_bytes <= spec.initial_window_bytes <= MAX_WINDOW_BYTES:
            raise ValueError("initial_window_bytes must cover one frame and stay within 16777216")
        if not 0 <= spec.timeout_ms <= 0xFFFFFFFF:
            raise ValueError("timeout_ms must fit uint32")

        def consume(_context, data, frame_pointer) -> int:
            try:
                frame = frame_pointer.contents
                if frame.size == 0:
                    return -1
                storage = (ctypes.c_uint8 * frame.size).from_address(ctypes.addressof(data.contents))
                metadata = StreamFrameMetadata(
                    frame.sequence, frame.captured_mono_ns, frame.dropped_before, StreamFrameFlags(frame.flags)
                )
                decision = spec.consumer(memoryview(storage).cast("B").toreadonly(), metadata)
                return -7 if decision == StreamConsumerDecision.STOP else 0
            except BaseException:
                return -5

        callback = _Consumer(consume)
        native = _SubscribeSpec(
            ctypes.sizeof(_SubscribeSpec), session, token, spec.remote_host.encode(), spec.remote_port,
            spec.format_id, spec.max_frame_bytes, spec.initial_window_bytes, spec.timeout_ms, callback, None,
        )
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_stream_lane_subscribe(handle, native), "stream_lane_subscribe")
            with self._condition:
                self._callbacks[(spec.session_id, StreamDirection.SUBSCRIBE)] = callback

    def session(self, session_id: str, direction: StreamDirection) -> StreamSessionSnapshot:
        """Return the current copied session snapshot without waiting.

        Args:
            session_id: Correlation ID supplied to prepare or subscribe.
            direction: Publisher or subscriber record to observe.
        """
        native = _SessionSnapshot(struct_size=ctypes.sizeof(_SessionSnapshot))
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_stream_lane_get_session(handle, _encoded(session_id, "session_id", 64), int(direction), native), "stream_lane_get_session")
        return _session_snapshot(native)

    def wait_session(
        self, session_id: str, direction: StreamDirection, after_update_sequence: int = 0, timeout_ms: int = 30_000
    ) -> StreamSessionSnapshot:
        """Wait for session progress newer than ``after_update_sequence``.

        Args:
            session_id: Correlation ID supplied to prepare or subscribe.
            direction: Publisher or subscriber record to observe.
            after_update_sequence: Last session sequence already handled.
            timeout_ms: Bounded wait in milliseconds.
        """
        if after_update_sequence < 0 or not 0 <= timeout_ms <= 0xFFFFFFFF:
            raise ValueError("wait parameters must fit their native unsigned ranges")
        native = _SessionSnapshot(struct_size=ctypes.sizeof(_SessionSnapshot))
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_stream_lane_wait_session(handle, _encoded(session_id, "session_id", 64), int(direction), after_update_sequence, timeout_ms, native), "stream_lane_wait_session")
        return _session_snapshot(native)

    def pressure(self, session_id: str, direction: StreamDirection) -> StreamPressureSnapshot:
        """Return the current copied neutral pressure observation.

        Args:
            session_id: Correlation ID supplied to prepare or subscribe.
            direction: Publisher or subscriber signal to observe.
        """
        native = _PressureSnapshot(struct_size=ctypes.sizeof(_PressureSnapshot))
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_stream_lane_get_pressure(handle, _encoded(session_id, "session_id", 64), int(direction), native), "stream_lane_get_pressure")
        return _pressure_snapshot(native)

    def wait_pressure(
        self, session_id: str, direction: StreamDirection, after_update_sequence: int = 0, timeout_ms: int = 30_000
    ) -> StreamPressureSnapshot:
        """Wait for a coalesced pressure update newer than the supplied sequence.

        Args:
            session_id: Correlation ID supplied to prepare or subscribe.
            direction: Publisher or subscriber signal to observe.
            after_update_sequence: Last pressure sequence handled by app policy.
            timeout_ms: Bounded wait in milliseconds.
        """
        if after_update_sequence < 0 or not 0 <= timeout_ms <= 0xFFFFFFFF:
            raise ValueError("wait parameters must fit their native unsigned ranges")
        native = _PressureSnapshot(struct_size=ctypes.sizeof(_PressureSnapshot))
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_stream_lane_wait_pressure(handle, _encoded(session_id, "session_id", 64), int(direction), after_update_sequence, timeout_ms, native), "stream_lane_wait_pressure")
        return _pressure_snapshot(native)

    def cancel(self, session_id: str, direction: StreamDirection) -> None:
        """Request cooperative cancellation and retain the terminal record.

        Args:
            session_id: Correlation ID supplied to prepare or subscribe.
            direction: Local retained record to cancel.
        """
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_stream_lane_cancel_session(handle, _encoded(session_id, "session_id", 64), int(direction)), "stream_lane_cancel_session")

    def forget(self, session_id: str, direction: StreamDirection) -> None:
        """Release one terminal record and its connector-owned callback.

        Args:
            session_id: Correlation ID supplied to prepare or subscribe.
            direction: Local terminal record to release.
        """
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_stream_lane_forget_session(handle, _encoded(session_id, "session_id", 64), int(direction)), "stream_lane_forget_session")
            with self._condition:
                self._callbacks.pop((session_id, direction), None)

    def stats(self) -> StreamLaneStats:
        """Return a copied lane-level observability snapshot."""
        native = _LaneStats(struct_size=ctypes.sizeof(_LaneStats))
        with self._borrow_handle() as handle:
            _require_status(self._bindings.lib.coakka_v2_stream_lane_get_stats(handle, native), "stream_lane_get_stats")
        return StreamLaneStats(*[getattr(native, field) for field in StreamLaneStats.__dataclass_fields__])

    def close(self) -> None:
        """Stop workers, drain concurrent calls, destroy the lane, and release callbacks."""
        with self._condition:
            if self._handle is None:
                return
            if self._closing:
                while self._handle is not None:
                    self._condition.wait()
                return
            self._closing = True
            handle = ctypes.c_void_p(self._handle)
        status = self._bindings.lib.coakka_v2_stream_lane_stop(handle)
        with self._condition:
            while self._active_calls:
                self._condition.wait()
            self._bindings.lib.coakka_v2_stream_lane_destroy(handle)
            self._callbacks.clear()
            self._handle = None
            self._condition.notify_all()
        if status not in (0, -7):
            raise StreamLaneError("stream_lane_stop", status)

    def __enter__(self) -> "StreamLane":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()
