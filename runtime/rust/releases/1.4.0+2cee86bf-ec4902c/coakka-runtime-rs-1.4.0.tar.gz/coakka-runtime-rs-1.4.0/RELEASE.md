# Releasing The Rust Connector

Current source version `1.4.0` uses native generation
`1.4.0+2cee86bf`. Publisher signing is absent.

## Dry-Run Gates

```sh
cargo fmt --manifest-path rust/Cargo.toml --check
cargo clippy --manifest-path rust/Cargo.toml --all-targets -- -D warnings
cargo test --manifest-path rust/Cargo.toml
bash rust/scripts/check-package-readiness.sh
bash rust/scripts/smoke-packaged-package.sh
```

The package must contain exactly these native payloads:

- `native/macos-aarch64/libcoakka_runtime_v2.dylib`
- `native/linux-aarch64/libcoakka_runtime_v2.so`
- `native/windows-x86_64/libcoakka_runtime_v2.dll`

All three must match the candidate ledger. Package presence and source build do
not replace native Linux/Windows connector and consumer execution.

`Cargo.toml` keeps `publish = false`, so this source coordinate cannot be
requested from crates.io.
