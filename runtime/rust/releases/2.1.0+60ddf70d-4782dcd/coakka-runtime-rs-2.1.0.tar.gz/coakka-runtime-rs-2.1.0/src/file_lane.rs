//! Bounded point-to-point file transfer backed by the native file-lane ABI.
//!
//! Prepare the receiver before submitting the sender. Observe successful
//! terminal snapshots on both peers, then forget retained records. File bytes
//! do not belong in runtime `Envelope` payloads.

use crate::{status_to_result, CoAkkaError, NativeLibrary, Result, RuntimeLibraryResolver};
use std::ffi::{c_char, c_int, c_void, CStr, CString};
use std::path::Path;
use std::ptr;
use std::sync::{Condvar, Mutex};

/// Enables sender work on a lane.
pub const FILE_LANE_SENDER: u32 = 1;
/// Enables receiver work on a lane.
pub const FILE_LANE_RECEIVER: u32 = 1 << 1;

#[repr(u32)]
#[derive(Clone, Copy, Debug)]
/// Transport protection; per-transfer authorization remains mandatory.
pub enum FileLaneSecurityMode {
    Direct = 0,
    Tls = 1,
    MutualTls = 2,
}
#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
/// Side of a retained transfer record.
pub enum FileTransferDirection {
    Send = 1,
    Receive = 2,
}
#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
/// Observable file-transfer lifecycle state.
pub enum FileTransferState {
    Prepared = 1,
    Queued = 2,
    Connecting = 3,
    Transferring = 4,
    Verifying = 5,
    Completed = 6,
    Paused = 7,
    Rejected = 8,
    Failed = 9,
    Canceled = 10,
}
#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
/// Stable terminal outcome reported independently by each peer.
pub enum FileTransferResult {
    None = 0,
    Ok = 1,
    NotPrepared = 2,
    TokenMismatch = 3,
    MetadataMismatch = 4,
    SizeLimit = 5,
    StorageIo = 6,
    IntegrityMismatch = 7,
    NetworkIo = 8,
    Timeout = 9,
    QueueFull = 10,
    ProtocolError = 11,
    SourceChanged = 12,
    InternalError = 13,
    CanceledByHost = 14,
    TlsConfigInvalid = 15,
    TlsHandshakeFailed = 16,
    PeerCertUntrusted = 17,
    PeerCertExpired = 18,
    PeerIdentityMismatch = 19,
    ClientCertRequired = 20,
}

#[derive(Clone, Debug)]
/// TLS material read at lane startup. Never log key paths or transfer tokens.
pub struct FileLaneSecurityConfig {
    pub mode: FileLaneSecurityMode,
    pub credential_generation: u64,
    pub credential_id: String,
    pub ca_certificate_file: String,
    pub identity_certificate_file: String,
    pub private_key_file: String,
}
#[derive(Clone, Debug)]
/// Bounded lane configuration. Zero tuning fields select native defaults.
pub struct FileLaneConfig {
    pub flags: u32,
    pub bind_host: String,
    pub bind_port: u16,
    pub queue_capacity: usize,
    pub max_file_size: u64,
    pub io_timeout_ms: u32,
    pub checkpoint_bytes: u64,
    pub progress_bytes: u64,
    pub progress_interval_ms: u32,
    pub sender_worker_count: u32,
    pub receiver_worker_count: u32,
    pub security: Option<FileLaneSecurityConfig>,
}
impl Default for FileLaneConfig {
    fn default() -> Self {
        Self {
            flags: FILE_LANE_SENDER | FILE_LANE_RECEIVER,
            bind_host: "127.0.0.1".into(),
            bind_port: 0,
            queue_capacity: 0,
            max_file_size: 0,
            io_timeout_ms: 0,
            checkpoint_bytes: 0,
            progress_bytes: 0,
            progress_interval_ms: 0,
            sender_worker_count: 0,
            receiver_worker_count: 0,
            security: None,
        }
    }
}
#[derive(Clone, Debug)]
/// Receiver authorization and exact content identity for one transfer.
pub struct FileReceiveSpec {
    pub transfer_id: String,
    pub authorization_token: String,
    pub destination_path: String,
    pub expected_size: u64,
    pub expected_sha256: [u8; 32],
}
#[derive(Clone, Debug)]
/// Source and receiver endpoint for one previously prepared transfer.
pub struct FileSendSpec {
    pub transfer_id: String,
    pub authorization_token: String,
    pub remote_host: String,
    pub remote_port: u16,
    pub source_path: String,
    pub expected_size: u64,
    pub expected_sha256: [u8; 32],
    pub timeout_ms: u32,
}
#[derive(Clone, Debug, PartialEq, Eq)]
/// A file SHA-256 and exact byte count.
pub struct FileDigest {
    pub sha256: [u8; 32],
    pub size: u64,
}
#[derive(Clone, Debug)]
/// Immutable progress view with process-local monotonic timestamps.
pub struct FileTransferSnapshot {
    pub direction: FileTransferDirection,
    pub state: FileTransferState,
    pub result: FileTransferResult,
    pub expected_size: u64,
    pub transferred_bytes: u64,
    pub committed_offset: u64,
    pub progress_milli: u32,
    pub cancel_requested: bool,
    pub update_sequence: u64,
    pub submitted_mono_ns: u64,
    pub started_mono_ns: u64,
    pub updated_mono_ns: u64,
    pub terminal_mono_ns: u64,
    pub detail: String,
}
impl FileTransferSnapshot {
    /// Returns whether this side reached a terminal state.
    pub fn terminal(&self) -> bool {
        self.state >= FileTransferState::Completed
    }
    /// Returns whether this side reported `Completed` plus `Ok`.
    pub fn succeeded(&self) -> bool {
        self.state == FileTransferState::Completed && self.result == FileTransferResult::Ok
    }
}
#[derive(Clone, Debug)]
/// Bounded queue, active-work, terminal-count, and completed-byte counters.
pub struct FileLaneStats {
    pub queue_capacity: usize,
    pub queued_sends: usize,
    pub prepared_receives: usize,
    pub active_sends: usize,
    pub active_receives: usize,
    pub retained_records: usize,
    pub submitted_sends: u64,
    pub prepared_receive_count: u64,
    pub completed_sends: u64,
    pub completed_receives: u64,
    pub failed_sends: u64,
    pub failed_receives: u64,
    pub canceled_transfers: u64,
    pub completed_send_bytes: u64,
    pub completed_receive_bytes: u64,
}

#[repr(C)]
pub(crate) struct NativeSecurity {
    struct_size: usize,
    mode: u32,
    reserved: u32,
    generation: u64,
    id: *const c_char,
    ca: *const c_char,
    cert: *const c_char,
    key: *const c_char,
}
#[repr(C)]
pub(crate) struct NativeConfig {
    struct_size: usize,
    flags: u32,
    bind_host: *const c_char,
    bind_port: u16,
    queue_capacity: usize,
    max_file_size: u64,
    io_timeout_ms: u32,
    checkpoint_bytes: u64,
    progress_bytes: u64,
    progress_interval_ms: u32,
    sender_workers: u32,
    receiver_workers: u32,
    security: *const NativeSecurity,
}
#[repr(C)]
pub(crate) struct NativeReceive {
    struct_size: usize,
    id: *const c_char,
    token: *const c_char,
    path: *const c_char,
    size: u64,
    sha: [u8; 32],
}
#[repr(C)]
pub(crate) struct NativeSend {
    struct_size: usize,
    id: *const c_char,
    token: *const c_char,
    host: *const c_char,
    port: u16,
    path: *const c_char,
    size: u64,
    sha: [u8; 32],
    timeout: u32,
}
#[repr(C)]
pub(crate) struct NativeSnapshot {
    struct_size: usize,
    direction: u32,
    state: u32,
    result: u32,
    expected: u64,
    transferred: u64,
    committed: u64,
    progress: u32,
    cancel: u32,
    sequence: u64,
    submitted: u64,
    started: u64,
    updated: u64,
    terminal: u64,
    detail: [c_char; 160],
}
impl Default for NativeSnapshot {
    fn default() -> Self {
        // The C ABI defines zero initialization for every scalar and fixed buffer field.
        unsafe { std::mem::zeroed() }
    }
}
#[repr(C)]
#[derive(Default)]
pub(crate) struct NativeStats {
    struct_size: usize,
    queue_capacity: usize,
    queued_sends: usize,
    prepared_receives: usize,
    active_sends: usize,
    active_receives: usize,
    retained_records: usize,
    submitted_sends: u64,
    prepared_receive_count: u64,
    completed_sends: u64,
    completed_receives: u64,
    failed_sends: u64,
    failed_receives: u64,
    canceled_transfers: u64,
    completed_send_bytes: u64,
    completed_receive_bytes: u64,
}

pub(crate) type FileLaneCreateFn =
    unsafe extern "C" fn(*const NativeConfig, *mut *mut c_void) -> c_int;
pub(crate) type FileLaneDestroyFn = unsafe extern "C" fn(*mut c_void);
pub(crate) type FileLaneStartFn = unsafe extern "C" fn(*mut c_void) -> c_int;
pub(crate) type FileLaneStopFn = unsafe extern "C" fn(*mut c_void) -> c_int;
pub(crate) type FileLaneGetBoundPortFn = unsafe extern "C" fn(*mut c_void, *mut u16) -> c_int;
pub(crate) type FileLanePrepareReceiveFn =
    unsafe extern "C" fn(*mut c_void, *const NativeReceive) -> c_int;
pub(crate) type FileLaneSubmitSendFn =
    unsafe extern "C" fn(*mut c_void, *const NativeSend) -> c_int;
pub(crate) type FileLaneGetTransferFn =
    unsafe extern "C" fn(*mut c_void, *const c_char, u32, *mut NativeSnapshot) -> c_int;
pub(crate) type FileLaneWaitTransferFn =
    unsafe extern "C" fn(*mut c_void, *const c_char, u32, u64, u32, *mut NativeSnapshot) -> c_int;
pub(crate) type FileLaneTransferControlFn =
    unsafe extern "C" fn(*mut c_void, *const c_char, u32) -> c_int;
pub(crate) type FileLaneGetStatsFn = unsafe extern "C" fn(*mut c_void, *mut NativeStats) -> c_int;
pub(crate) type FileSha256PathFn = unsafe extern "C" fn(*const c_char, *mut u8, *mut u64) -> c_int;

struct Lifecycle {
    lane: *mut c_void,
    closing: bool,
    active: usize,
}
unsafe impl Send for Lifecycle {}
/// Independent native bulk-transfer lane with synchronized close/drain ownership.
pub struct FileLane {
    lib: NativeLibrary,
    lifecycle: Mutex<Lifecycle>,
    drained: Condvar,
}
unsafe impl Send for FileLane {}
unsafe impl Sync for FileLane {}

impl FileLane {
    /// Opens and starts a lane, failing when the native ABI is unavailable.
    pub fn open(config: FileLaneConfig, runtime_path: impl AsRef<str>) -> Result<Self> {
        if config.flags == 0
            || config.flags & !(FILE_LANE_SENDER | FILE_LANE_RECEIVER) != 0
            || config.sender_worker_count > 4
            || config.receiver_worker_count > 4
        {
            return Err(CoAkkaError::InvalidArgument(
                "invalid file-lane flags or worker count".into(),
            ));
        }
        let lib = NativeLibrary::open(&RuntimeLibraryResolver::resolve(runtime_path.as_ref())?)?;
        if lib.file_lane_create.is_none()
            || lib.file_lane_destroy.is_none()
            || lib.file_lane_start.is_none()
            || lib.file_lane_stop.is_none()
            || lib.file_lane_get_bound_port.is_none()
            || lib.file_lane_prepare_receive.is_none()
            || lib.file_lane_submit_send.is_none()
            || lib.file_lane_get_transfer.is_none()
            || lib.file_lane_wait_transfer.is_none()
            || lib.file_lane_cancel_transfer.is_none()
            || lib.file_lane_forget_transfer.is_none()
            || lib.file_lane_get_stats.is_none()
            || lib.file_sha256_path.is_none()
        {
            return Err(CoAkkaError::Native(
                "native runtime does not export the complete file-lane ABI".into(),
            ));
        }
        let create = lib.file_lane_create.ok_or_else(|| {
            CoAkkaError::Native("native runtime does not export file-lane ABI".into())
        })?;
        let destroy = lib.file_lane_destroy.expect("complete ABI checked above");
        let start = lib.file_lane_start.expect("complete ABI checked above");
        let bind = c(&config.bind_host)?;
        let security_strings = config
            .security
            .as_ref()
            .map(|s| {
                Ok::<_, CoAkkaError>((
                    c(&s.credential_id)?,
                    c(&s.ca_certificate_file)?,
                    c(&s.identity_certificate_file)?,
                    c(&s.private_key_file)?,
                ))
            })
            .transpose()?;
        let native_security =
            config
                .security
                .as_ref()
                .zip(security_strings.as_ref())
                .map(|(s, v)| NativeSecurity {
                    struct_size: std::mem::size_of::<NativeSecurity>(),
                    mode: s.mode as u32,
                    reserved: 0,
                    generation: s.credential_generation,
                    id: v.0.as_ptr(),
                    ca: v.1.as_ptr(),
                    cert: v.2.as_ptr(),
                    key: v.3.as_ptr(),
                });
        let native = NativeConfig {
            struct_size: std::mem::size_of::<NativeConfig>(),
            flags: config.flags,
            bind_host: bind.as_ptr(),
            bind_port: config.bind_port,
            queue_capacity: config.queue_capacity,
            max_file_size: config.max_file_size,
            io_timeout_ms: config.io_timeout_ms,
            checkpoint_bytes: config.checkpoint_bytes,
            progress_bytes: config.progress_bytes,
            progress_interval_ms: config.progress_interval_ms,
            sender_workers: config.sender_worker_count,
            receiver_workers: config.receiver_worker_count,
            security: native_security.as_ref().map_or(ptr::null(), |v| v),
        };
        let mut lane = ptr::null_mut();
        status_to_result(unsafe { create(&native, &mut lane) }, "file_lane_create")?;
        if lane.is_null() {
            return Err(CoAkkaError::Native("file_lane_create returned null".into()));
        }
        if let Err(error) = status_to_result(unsafe { start(lane) }, "file_lane_start") {
            unsafe { destroy(lane) };
            return Err(error);
        }
        Ok(Self {
            lib,
            lifecycle: Mutex::new(Lifecycle {
                lane,
                closing: false,
                active: 0,
            }),
            drained: Condvar::new(),
        })
    }
    /// Computes the exact source identity using the native implementation.
    pub fn sha256(path: impl AsRef<Path>, runtime_path: impl AsRef<str>) -> Result<FileDigest> {
        let lib = NativeLibrary::open(&RuntimeLibraryResolver::resolve(runtime_path.as_ref())?)?;
        let f = lib.file_sha256_path.ok_or_else(|| {
            CoAkkaError::Native("native runtime does not export file-lane ABI".into())
        })?;
        let path = c(&path.as_ref().to_string_lossy())?;
        let mut out = [0; 32];
        let mut size = 0;
        status_to_result(
            unsafe { f(path.as_ptr(), out.as_mut_ptr(), &mut size) },
            "file_sha256_path",
        )?;
        Ok(FileDigest { sha256: out, size })
    }
    fn call<T>(&self, action: impl FnOnce(&NativeLibrary, *mut c_void) -> Result<T>) -> Result<T> {
        let lane = {
            let mut s = self
                .lifecycle
                .lock()
                .map_err(|_| CoAkkaError::Native("file lane mutex poisoned".into()))?;
            if s.closing || s.lane.is_null() {
                return Err(CoAkkaError::Native("file lane is closed".into()));
            }
            s.active += 1;
            s.lane
        };
        let result = action(&self.lib, lane);
        let mut s = self.lifecycle.lock().unwrap();
        s.active -= 1;
        if s.active == 0 {
            self.drained.notify_all();
        }
        result
    }
    /// Returns the receiver port selected when the lane started.
    pub fn bound_port(&self) -> Result<u16> {
        self.call(|l, p| {
            let mut out = 0;
            status_to_result(
                unsafe { l.file_lane_get_bound_port.unwrap()(p, &mut out) },
                "file_lane_get_bound_port",
            )?;
            Ok(out)
        })
    }
    /// Authorizes one destination and expected content identity.
    pub fn prepare_receive(&self, s: &FileReceiveSpec) -> Result<()> {
        self.call(|l, p| {
            let id = c(&s.transfer_id)?;
            let token = c(&s.authorization_token)?;
            let path = c(&s.destination_path)?;
            let n = NativeReceive {
                struct_size: std::mem::size_of::<NativeReceive>(),
                id: id.as_ptr(),
                token: token.as_ptr(),
                path: path.as_ptr(),
                size: s.expected_size,
                sha: s.expected_sha256,
            };
            status_to_result(
                unsafe { l.file_lane_prepare_receive.unwrap()(p, &n) },
                "file_lane_prepare_receive",
            )
        })
    }
    /// Queues a send after the remote application prepares the receive.
    pub fn submit_send(&self, s: &FileSendSpec) -> Result<()> {
        if s.remote_port == 0 {
            return Err(CoAkkaError::InvalidArgument(
                "remote port must be nonzero".into(),
            ));
        }
        self.call(|l, p| {
            let id = c(&s.transfer_id)?;
            let token = c(&s.authorization_token)?;
            let host = c(&s.remote_host)?;
            let path = c(&s.source_path)?;
            let n = NativeSend {
                struct_size: std::mem::size_of::<NativeSend>(),
                id: id.as_ptr(),
                token: token.as_ptr(),
                host: host.as_ptr(),
                port: s.remote_port,
                path: path.as_ptr(),
                size: s.expected_size,
                sha: s.expected_sha256,
                timeout: s.timeout_ms,
            };
            status_to_result(
                unsafe { l.file_lane_submit_send.unwrap()(p, &n) },
                "file_lane_submit_send",
            )
        })
    }
    /// Returns the current copied snapshot without waiting.
    pub fn transfer(&self, id: &str, d: FileTransferDirection) -> Result<FileTransferSnapshot> {
        self.read(id, d, 0, 0, false)
    }
    /// Blocks until the sequence advances, the timeout expires, or the lane stops.
    pub fn wait_transfer(
        &self,
        id: &str,
        d: FileTransferDirection,
        seq: u64,
        ms: u32,
    ) -> Result<FileTransferSnapshot> {
        self.read(id, d, seq, ms, true)
    }
    fn read(
        &self,
        id: &str,
        d: FileTransferDirection,
        seq: u64,
        ms: u32,
        wait: bool,
    ) -> Result<FileTransferSnapshot> {
        self.call(|l, p| {
            let id = c(id)?;
            let mut n = NativeSnapshot::default();
            n.struct_size = std::mem::size_of::<NativeSnapshot>();
            let rc = unsafe {
                if wait {
                    l.file_lane_wait_transfer.unwrap()(p, id.as_ptr(), d as u32, seq, ms, &mut n)
                } else {
                    l.file_lane_get_transfer.unwrap()(p, id.as_ptr(), d as u32, &mut n)
                }
            };
            status_to_result(rc, "file_lane_transfer")?;
            snapshot(n)
        })
    }
    /// Requests cooperative cancellation; observe terminal state before forget.
    pub fn cancel(&self, id: &str, d: FileTransferDirection) -> Result<()> {
        self.control(id, d, false)
    }
    /// Releases one retained terminal record after recording its outcome.
    pub fn forget(&self, id: &str, d: FileTransferDirection) -> Result<()> {
        self.control(id, d, true)
    }
    fn control(&self, id: &str, d: FileTransferDirection, forget: bool) -> Result<()> {
        self.call(|l, p| {
            let id = c(id)?;
            let f = if forget {
                l.file_lane_forget_transfer.unwrap()
            } else {
                l.file_lane_cancel_transfer.unwrap()
            };
            status_to_result(
                unsafe { f(p, id.as_ptr(), d as u32) },
                "file_lane_transfer_control",
            )
        })
    }
    /// Returns a copied lane-level observability snapshot.
    pub fn stats(&self) -> Result<FileLaneStats> {
        self.call(|l, p| {
            let mut n = NativeStats::default();
            n.struct_size = std::mem::size_of::<NativeStats>();
            status_to_result(
                unsafe { l.file_lane_get_stats.unwrap()(p, &mut n) },
                "file_lane_get_stats",
            )?;
            Ok(FileLaneStats {
                queue_capacity: n.queue_capacity,
                queued_sends: n.queued_sends,
                prepared_receives: n.prepared_receives,
                active_sends: n.active_sends,
                active_receives: n.active_receives,
                retained_records: n.retained_records,
                submitted_sends: n.submitted_sends,
                prepared_receive_count: n.prepared_receive_count,
                completed_sends: n.completed_sends,
                completed_receives: n.completed_receives,
                failed_sends: n.failed_sends,
                failed_receives: n.failed_receives,
                canceled_transfers: n.canceled_transfers,
                completed_send_bytes: n.completed_send_bytes,
                completed_receive_bytes: n.completed_receive_bytes,
            })
        })
    }
    /// Stops the lane, wakes blocked waits, drains calls, and releases native state.
    pub fn close(&self) -> Result<()> {
        let lane = {
            let mut s = self.lifecycle.lock().unwrap();
            if s.lane.is_null() {
                return Ok(());
            }
            if s.closing {
                while !s.lane.is_null() {
                    s = self.drained.wait(s).unwrap();
                }
                return Ok(());
            }
            s.closing = true;
            s.lane
        };
        let rc = unsafe { self.lib.file_lane_stop.unwrap()(lane) };
        let mut s = self.lifecycle.lock().unwrap();
        while s.active != 0 {
            s = self.drained.wait(s).unwrap();
        }
        unsafe { self.lib.file_lane_destroy.unwrap()(lane) };
        s.lane = ptr::null_mut();
        self.drained.notify_all();
        if rc == 0 || rc == -7 {
            Ok(())
        } else {
            status_to_result(rc, "file_lane_stop")
        }
    }
}
impl Drop for FileLane {
    fn drop(&mut self) {
        let _ = self.close();
    }
}
fn c(value: &str) -> Result<CString> {
    CString::new(value)
        .map_err(|_| CoAkkaError::InvalidArgument("file-lane text contains NUL".into()))
}
fn snapshot(n: NativeSnapshot) -> Result<FileTransferSnapshot> {
    let direction = match n.direction {
        1 => FileTransferDirection::Send,
        2 => FileTransferDirection::Receive,
        value => return Err(invalid_snapshot_value("direction", value)),
    };
    let state = match n.state {
        1 => FileTransferState::Prepared,
        2 => FileTransferState::Queued,
        3 => FileTransferState::Connecting,
        4 => FileTransferState::Transferring,
        5 => FileTransferState::Verifying,
        6 => FileTransferState::Completed,
        7 => FileTransferState::Paused,
        8 => FileTransferState::Rejected,
        9 => FileTransferState::Failed,
        10 => FileTransferState::Canceled,
        value => return Err(invalid_snapshot_value("state", value)),
    };
    let result = match n.result {
        0 => FileTransferResult::None,
        1 => FileTransferResult::Ok,
        2 => FileTransferResult::NotPrepared,
        3 => FileTransferResult::TokenMismatch,
        4 => FileTransferResult::MetadataMismatch,
        5 => FileTransferResult::SizeLimit,
        6 => FileTransferResult::StorageIo,
        7 => FileTransferResult::IntegrityMismatch,
        8 => FileTransferResult::NetworkIo,
        9 => FileTransferResult::Timeout,
        10 => FileTransferResult::QueueFull,
        11 => FileTransferResult::ProtocolError,
        12 => FileTransferResult::SourceChanged,
        13 => FileTransferResult::InternalError,
        14 => FileTransferResult::CanceledByHost,
        15 => FileTransferResult::TlsConfigInvalid,
        16 => FileTransferResult::TlsHandshakeFailed,
        17 => FileTransferResult::PeerCertUntrusted,
        18 => FileTransferResult::PeerCertExpired,
        19 => FileTransferResult::PeerIdentityMismatch,
        20 => FileTransferResult::ClientCertRequired,
        value => return Err(invalid_snapshot_value("result", value)),
    };
    let detail = unsafe { CStr::from_ptr(n.detail.as_ptr()) }
        .to_string_lossy()
        .into_owned();
    Ok(FileTransferSnapshot {
        direction,
        state,
        result,
        expected_size: n.expected,
        transferred_bytes: n.transferred,
        committed_offset: n.committed,
        progress_milli: n.progress,
        cancel_requested: n.cancel != 0,
        update_sequence: n.sequence,
        submitted_mono_ns: n.submitted,
        started_mono_ns: n.started,
        updated_mono_ns: n.updated,
        terminal_mono_ns: n.terminal,
        detail,
    })
}

fn invalid_snapshot_value(field: &str, value: u32) -> CoAkkaError {
    CoAkkaError::Native(format!("invalid file-lane snapshot {field}: {value}"))
}
