mod file_lane;
mod platform;
mod transport;

pub use file_lane::*;
pub use transport::*;

use std::collections::{HashMap, HashSet};
use std::env;
use std::ffi::{CStr, CString};
use std::fmt;
use std::fs;
use std::os::raw::{c_char, c_int, c_void};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{mpsc, Arc, Mutex, OnceLock};
use std::thread::{self, JoinHandle};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

const ABI_VERSION: u32 = 1;
const WIRE_VARINT: u8 = 0;
const WIRE_LENGTH_DELIMITED: u8 = 2;
const ENDPOINT_FLAG_LOCAL: u32 = 1;

pub type Result<T> = std::result::Result<T, CoAkkaError>;

#[derive(Debug)]
pub enum CoAkkaError {
    InvalidArgument(String),
    Native(String),
    Io(String),
    WireCodec(String),
    Timeout(String),
    Deadletter(Box<RuntimeDeadletter>),
    TcpConnectionApply(Box<TcpConnectionApplyResult>),
    TcpSecurityApply(Box<TcpSecurityApplyResult>),
}

impl fmt::Display for CoAkkaError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CoAkkaError::InvalidArgument(value) => write!(f, "invalid argument: {value}"),
            CoAkkaError::Native(value) => write!(f, "native runtime error: {value}"),
            CoAkkaError::Io(value) => write!(f, "I/O error: {value}"),
            CoAkkaError::WireCodec(value) => write!(f, "wire codec error: {value}"),
            CoAkkaError::Timeout(value) => write!(f, "timeout: {value}"),
            CoAkkaError::Deadletter(deadletter) => write!(
                f,
                "deadletter reason={} target={} detail={}",
                deadletter.reason, deadletter.original.target, deadletter.detail
            ),
            CoAkkaError::TcpConnectionApply(result) => write!(
                f,
                "TCP connection apply failed status={} reason={} validation={}",
                result.status.0, result.reason_name, result.validation_code.0
            ),
            CoAkkaError::TcpSecurityApply(result) => write!(
                f,
                "TCP security apply failed status={} reason={} validation={}",
                result.status.0, result.reason_name, result.validation_code.0
            ),
        }
    }
}

impl std::error::Error for CoAkkaError {}

#[derive(Clone, Debug)]
pub struct ConnectorStartSpec {
    pub system_name: String,
    pub node_id: String,
    pub strict_no_drop: bool,
    pub queue_capacity: i32,
    pub generation: u64,
    pub routes: Vec<RouteSpec>,
    pub enable_monitor: bool,
    pub separate_delivered_request_lane: bool,
    pub connection_strategy: Option<TcpConnectionStrategySpec>,
    pub security: Option<TcpSecuritySpec>,
}

impl ConnectorStartSpec {
    pub fn new(system_name: impl Into<String>, node_id: impl Into<String>) -> Self {
        Self {
            system_name: system_name.into(),
            node_id: node_id.into(),
            strict_no_drop: true,
            queue_capacity: 1024,
            generation: 1,
            routes: Vec::new(),
            enable_monitor: false,
            separate_delivered_request_lane: true,
            connection_strategy: None,
            security: None,
        }
    }

    fn normalized(mut self) -> Self {
        self.system_name = self.system_name.trim().to_string();
        self.node_id = self.node_id.trim().to_string();
        for route in &mut self.routes {
            route.target = route.target.trim().to_string();
            route.route_key_hint = route.route_key_hint.trim().to_string();
            for endpoint in &mut route.endpoints {
                endpoint.host = endpoint.host.trim().to_string();
            }
        }
        self
    }

    fn require_valid(&self) -> Result<()> {
        if self.system_name.is_empty() {
            return Err(CoAkkaError::InvalidArgument(
                "system_name must not be blank".to_string(),
            ));
        }
        if self.node_id.is_empty() {
            return Err(CoAkkaError::InvalidArgument(
                "node_id must not be blank".to_string(),
            ));
        }
        if self.queue_capacity <= 0 {
            return Err(CoAkkaError::InvalidArgument(
                "queue_capacity must be positive".to_string(),
            ));
        }
        if self.generation == 0 {
            return Err(CoAkkaError::InvalidArgument(
                "generation must be positive".to_string(),
            ));
        }
        for route in &self.routes {
            route.require_valid()?;
        }
        Ok(())
    }
}

#[derive(Clone, Debug)]
pub struct RouteSpec {
    pub target: String,
    pub endpoints: Vec<EndpointSpec>,
    pub strategy: RouteStrategy,
    pub route_key_hint: String,
    pub flags: u32,
}

impl RouteSpec {
    pub fn single_local(target: impl Into<String>, host: impl Into<String>, port: u16) -> Self {
        Self {
            target: target.into(),
            endpoints: vec![EndpointSpec {
                host: host.into(),
                port,
                weight: 1,
                flags: ENDPOINT_FLAG_LOCAL,
            }],
            strategy: RouteStrategy::SingleOwner,
            route_key_hint: String::new(),
            flags: 0,
        }
    }

    fn require_valid(&self) -> Result<()> {
        if self.target.trim().is_empty() {
            return Err(CoAkkaError::InvalidArgument(
                "route target must not be blank".to_string(),
            ));
        }
        if self.endpoints.is_empty() {
            return Err(CoAkkaError::InvalidArgument(format!(
                "route target={} requires at least one endpoint",
                self.target
            )));
        }
        for endpoint in &self.endpoints {
            endpoint.require_valid(&self.target)?;
        }
        Ok(())
    }
}

#[derive(Clone, Debug)]
pub struct EndpointSpec {
    pub host: String,
    pub port: u16,
    pub weight: u32,
    pub flags: u32,
}

impl EndpointSpec {
    fn require_valid(&self, target: &str) -> Result<()> {
        if self.host.trim().is_empty() {
            return Err(CoAkkaError::InvalidArgument(format!(
                "route target={target} endpoint host must not be blank"
            )));
        }
        if self.weight == 0 {
            return Err(CoAkkaError::InvalidArgument(format!(
                "route target={target} endpoint weight must be positive"
            )));
        }
        Ok(())
    }
}

#[derive(Copy, Clone, Debug)]
#[repr(u64)]
pub enum RouteStrategy {
    SingleOwner = 1,
    WeightedRoundRobin = 2,
    RendezvousHash = 3,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(u64)]
pub enum MessageKind {
    Request = 1,
    Response = 2,
    Event = 3,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(u64)]
pub enum BusinessStatus {
    Ok = 1,
    Error = 2,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(u64)]
pub enum DeliveryHint {
    RouterDefault = 1,
    PreferLocal = 2,
    RequireLocal = 3,
    RequireRemote = 4,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(u64)]
pub enum PayloadFormat {
    Unspecified = 0,
    Json = 1,
    WireBinary = 2,
    Thrift = 3,
    MessagePack = 4,
    PlainText = 5,
    Binary = 6,
}

#[derive(Clone, Debug)]
pub struct PayloadIdentity {
    pub message_type: String,
    pub payload_schema_version: u32,
    pub payload_format: PayloadFormat,
}

impl PayloadIdentity {
    pub fn json(message_type: impl Into<String>, payload_schema_version: u32) -> Self {
        Self {
            message_type: message_type.into(),
            payload_schema_version,
            payload_format: PayloadFormat::Json,
        }
    }

    fn require_typed(&self, what: &str) -> Result<()> {
        if self.message_type.trim().is_empty() {
            return Err(CoAkkaError::InvalidArgument(format!(
                "{what} requires message_type"
            )));
        }
        if self.payload_schema_version == 0 {
            return Err(CoAkkaError::InvalidArgument(format!(
                "{what} requires payload_schema_version >= 1"
            )));
        }
        if self.payload_format == PayloadFormat::Unspecified {
            return Err(CoAkkaError::InvalidArgument(format!(
                "{what} requires payload_format"
            )));
        }
        Ok(())
    }
}

#[derive(Clone, Debug)]
pub struct TransportEnvelope {
    pub message_id: String,
    pub correlation_id: String,
    pub source: String,
    pub target: String,
    pub reply_to: String,
    pub kind: MessageKind,
    pub one_way: bool,
    pub timeout_ms: i32,
    pub payload: Vec<u8>,
    pub headers: HashMap<String, String>,
    pub status: BusinessStatus,
    pub error_code: String,
    pub error_message: String,
    pub delivery_hint: DeliveryHint,
    pub message_type: String,
    pub payload_schema_version: u32,
    pub payload_format: PayloadFormat,
}

impl TransportEnvelope {
    pub fn payload_utf8(&self) -> String {
        String::from_utf8_lossy(&self.payload).to_string()
    }

    pub fn payload_identity(&self) -> PayloadIdentity {
        PayloadIdentity {
            message_type: self.message_type.clone(),
            payload_schema_version: self.payload_schema_version,
            payload_format: self.payload_format,
        }
    }
}

#[derive(Clone, Debug)]
pub struct RuntimeDeadletter {
    pub original: TransportEnvelope,
    pub reason: String,
    pub detail: String,
    pub active_generation: u64,
    pub resolved_host: String,
    pub resolved_port: u32,
}

#[derive(Clone, Debug)]
pub struct RuntimeInfo {
    pub abi_version: u32,
    pub runtime_version: String,
    pub git_commit: String,
    pub southbound_backend: String,
}

#[derive(Clone, Debug)]
pub struct RuntimeConfigSnapshot {
    pub system_name: String,
    pub node_id: String,
    pub applied_generation: u64,
    pub route_count: usize,
    pub runtime_state: i32,
}

#[derive(Clone, Debug, Default)]
pub struct RuntimeClientStats {
    pub pending_requests: usize,
    pub delivered_requests: u64,
    pub matched_responses: u64,
    pub matched_deadletters: u64,
    pub late_responses: u64,
    pub unhandled_deadletters: u64,
}

type Handler = dyn Fn(TransportEnvelope) -> Option<TransportEnvelope> + Send + Sync + 'static;

pub struct RuntimeHost {
    inner: Arc<RuntimeInner>,
    readers: Vec<JoinHandle<()>>,
    host_handles: NativeHostHandles,
    startup_connection_result: Option<TcpConnectionApplyResult>,
    startup_security_result: Option<TcpSecurityApplyResult>,
}

struct RuntimeInner {
    lib: NativeLibrary,
    runtime: RuntimePtr,
    runtime_lib_path: PathBuf,
    closed: AtomicBool,
    transport_mu: Mutex<()>,
    submit_mu: Mutex<()>,
    pending: Mutex<HashMap<String, mpsc::Sender<Result<TransportEnvelope>>>>,
    handlers: Mutex<HashMap<String, Arc<Handler>>>,
    delivered_requests: AtomicU64,
    matched_responses: AtomicU64,
    matched_deadletters: AtomicU64,
    late_responses: AtomicU64,
    unhandled_deadletters: AtomicU64,
}

impl RuntimeHost {
    pub fn start(spec: ConnectorStartSpec) -> Result<Self> {
        Self::start_with_runtime_lib(spec, "")
    }

    pub fn start_with_runtime_lib(
        spec: ConnectorStartSpec,
        runtime_lib_path: impl AsRef<str>,
    ) -> Result<Self> {
        let spec = spec.normalized();
        spec.require_valid()?;
        let resolved_path = RuntimeLibraryResolver::resolve(runtime_lib_path.as_ref())?;
        let lib = NativeLibrary::open(&resolved_path)?;
        let abi = unsafe { (lib.get_abi_version)() };
        if abi != ABI_VERSION {
            return Err(CoAkkaError::Native(format!(
                "unexpected ABI version: {abi}"
            )));
        }

        let system_name = CString::new(spec.system_name.clone())
            .map_err(|_| CoAkkaError::InvalidArgument("system_name contains NUL".to_string()))?;
        let node_id = CString::new(spec.node_id.clone())
            .map_err(|_| CoAkkaError::InvalidArgument("node_id contains NUL".to_string()))?;
        let native_config = NativeRuntimeConfig {
            system_name: system_name.as_ptr(),
            node_id: node_id.as_ptr(),
            strict_no_drop: if spec.strict_no_drop { 1 } else { 0 },
            queue_capacity: spec.queue_capacity,
        };
        let runtime = unsafe { (lib.create_runtime)(&native_config as *const NativeRuntimeConfig) };
        if runtime.is_null() {
            return Err(CoAkkaError::Native(
                "coakka_v2_runtime_create returned null".to_string(),
            ));
        }
        let runtime = RuntimePtr(runtime);

        let mut exported_handles = None;
        let startup = (|| -> Result<(
            NativeHostHandles,
            Option<TcpConnectionApplyResult>,
            Option<TcpSecurityApplyResult>,
        )> {
            let startup_connection_result = if let Some(connection) = &spec.connection_strategy {
                let result = transport::apply_connection_native(&lib, runtime, connection)?;
                if !result.applied() {
                    return Err(CoAkkaError::TcpConnectionApply(Box::new(result)));
                }
                Some(result)
            } else {
                None
            };
            let startup_security_result = if let Some(security) = &spec.security {
                let result = transport::apply_security_native(&lib, runtime, security)?;
                if !result.applied() {
                    return Err(CoAkkaError::TcpSecurityApply(Box::new(result)));
                }
                Some(result)
            } else {
                None
            };

            let mut handles = NativeHostHandles {
                struct_size: std::mem::size_of::<NativeHostHandles>(),
                flags: host_handle_flags(&spec),
                ..NativeHostHandles::default()
            };
            status_to_result(
                unsafe {
                    (lib.get_host_handles)(runtime.0, &mut handles as *mut NativeHostHandles)
                },
                "coakka_v2_runtime_get_host_handles",
            )?;
            exported_handles = Some(handles);

            let control = encode_initial_snapshot(&spec);
            status_to_result(
                unsafe { (lib.apply_control_envelope)(runtime.0, control.as_ptr(), control.len()) },
                "coakka_v2_runtime_apply_control_envelope",
            )?;
            status_to_result(
                unsafe { (lib.start_runtime)(runtime.0) },
                "coakka_v2_runtime_start",
            )?;
            Ok((
                handles,
                startup_connection_result,
                startup_security_result,
            ))
        })();

        let (handles, startup_connection_result, startup_security_result) = match startup {
            Ok(value) => value,
            Err(error) => {
                if let Some(handles) = exported_handles {
                    close_host_handles(handles);
                }
                unsafe { (lib.destroy_runtime)(runtime.0) };
                return Err(error);
            }
        };

        let inner = Arc::new(RuntimeInner {
            lib,
            runtime,
            runtime_lib_path: resolved_path,
            closed: AtomicBool::new(false),
            transport_mu: Mutex::new(()),
            submit_mu: Mutex::new(()),
            pending: Mutex::new(HashMap::new()),
            handlers: Mutex::new(HashMap::new()),
            delivered_requests: AtomicU64::new(0),
            matched_responses: AtomicU64::new(0),
            matched_deadletters: AtomicU64::new(0),
            late_responses: AtomicU64::new(0),
            unhandled_deadletters: AtomicU64::new(0),
        });
        let mut readers = Vec::new();
        let request_fd = if handles.delivered_request_read_fd >= 0 {
            handles.delivered_request_read_fd
        } else {
            handles.response_read_fd
        };
        readers.push(spawn_frame_reader(
            inner.clone(),
            request_fd,
            on_request_frame,
        ));
        if handles.delivered_request_read_fd >= 0
            && handles.delivered_request_read_fd != handles.response_read_fd
        {
            readers.push(spawn_frame_reader(
                inner.clone(),
                handles.response_read_fd,
                on_response_frame,
            ));
        }
        readers.push(spawn_frame_reader(
            inner.clone(),
            handles.deadletter_read_fd,
            on_deadletter_frame,
        ));
        Ok(Self {
            inner,
            readers,
            host_handles: handles,
            startup_connection_result,
            startup_security_result,
        })
    }

    pub fn runtime_lib_path(&self) -> &Path {
        &self.inner.runtime_lib_path
    }

    pub fn register_handler<F>(&self, target: impl Into<String>, handler: F) -> Result<()>
    where
        F: Fn(TransportEnvelope) -> Option<TransportEnvelope> + Send + Sync + 'static,
    {
        let target = target.into();
        if target.trim().is_empty() {
            return Err(CoAkkaError::InvalidArgument(
                "handler target must not be blank".to_string(),
            ));
        }
        self.inner
            .handlers
            .lock()
            .map_err(|_| CoAkkaError::Native("handler mutex poisoned".to_string()))?
            .insert(target, Arc::new(handler));
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    pub fn ask_json(
        &self,
        source: impl AsRef<str>,
        target: impl AsRef<str>,
        payload_json: impl AsRef<str>,
        payload_identity: PayloadIdentity,
        timeout: Duration,
        operation: impl AsRef<str>,
        delivery_hint: DeliveryHint,
    ) -> Result<TransportEnvelope> {
        let envelope = make_json_request(
            source.as_ref(),
            target.as_ref(),
            payload_json.as_ref().as_bytes().to_vec(),
            payload_identity,
            timeout,
            operation.as_ref(),
            delivery_hint,
            false,
        )?;
        self.ask(envelope, timeout)
    }

    pub fn ask(&self, envelope: TransportEnvelope, timeout: Duration) -> Result<TransportEnvelope> {
        let key = if envelope.correlation_id.is_empty() {
            envelope.message_id.clone()
        } else {
            envelope.correlation_id.clone()
        };
        let (tx, rx) = mpsc::channel();
        self.inner
            .pending
            .lock()
            .map_err(|_| CoAkkaError::Native("pending mutex poisoned".to_string()))?
            .insert(key.clone(), tx);
        if let Err(error) = self.submit_envelope(&envelope) {
            let _ = self
                .inner
                .pending
                .lock()
                .map(|mut pending| pending.remove(&key));
            return Err(error);
        }
        match rx.recv_timeout(timeout) {
            Ok(result) => result,
            Err(mpsc::RecvTimeoutError::Timeout) => {
                let _ = self
                    .inner
                    .pending
                    .lock()
                    .map(|mut pending| pending.remove(&key));
                Err(CoAkkaError::Timeout(format!(
                    "request timed out target={}",
                    envelope.target
                )))
            }
            Err(mpsc::RecvTimeoutError::Disconnected) => Err(CoAkkaError::Native(
                "pending request channel disconnected".to_string(),
            )),
        }
    }

    pub fn submit_envelope(&self, envelope: &TransportEnvelope) -> Result<()> {
        self.inner.submit_envelope(envelope)
    }

    pub fn runtime_info(&self) -> Result<RuntimeInfo> {
        let mut info = NativeRuntimeInfo {
            struct_size: std::mem::size_of::<NativeRuntimeInfo>(),
            ..NativeRuntimeInfo::default()
        };
        status_to_result(
            unsafe { (self.inner.lib.get_info)(&mut info as *mut NativeRuntimeInfo) },
            "coakka_v2_runtime_get_info",
        )?;
        Ok(RuntimeInfo {
            abi_version: info.abi_version,
            runtime_version: ptr_to_string(info.runtime_version),
            git_commit: ptr_to_string(info.git_commit),
            southbound_backend: ptr_to_string(info.southbound_backend),
        })
    }

    pub fn runtime_config(&self) -> Result<RuntimeConfigSnapshot> {
        let mut config = NativeRuntimeConfigView {
            struct_size: std::mem::size_of::<NativeRuntimeConfigView>(),
            ..NativeRuntimeConfigView::default()
        };
        status_to_result(
            unsafe {
                (self.inner.lib.get_config)(
                    self.inner.runtime.0,
                    &mut config as *mut NativeRuntimeConfigView,
                )
            },
            "coakka_v2_runtime_get_config",
        )?;
        Ok(RuntimeConfigSnapshot {
            system_name: ptr_to_string(config.system_name),
            node_id: ptr_to_string(config.node_id),
            applied_generation: config.applied_generation,
            route_count: config.route_count,
            runtime_state: config.runtime_state,
        })
    }

    pub fn client_stats(&self) -> RuntimeClientStats {
        let pending_requests = self
            .inner
            .pending
            .lock()
            .map(|pending| pending.len())
            .unwrap_or(0);
        RuntimeClientStats {
            pending_requests,
            delivered_requests: self.inner.delivered_requests.load(Ordering::Relaxed),
            matched_responses: self.inner.matched_responses.load(Ordering::Relaxed),
            matched_deadletters: self.inner.matched_deadletters.load(Ordering::Relaxed),
            late_responses: self.inner.late_responses.load(Ordering::Relaxed),
            unhandled_deadletters: self.inner.unhandled_deadletters.load(Ordering::Relaxed),
        }
    }

    pub fn make_json_reply_from_request_identity(
        request: &TransportEnvelope,
        source: impl AsRef<str>,
        payload_json: impl AsRef<str>,
    ) -> Result<TransportEnvelope> {
        make_json_reply(
            request,
            source.as_ref(),
            payload_json.as_ref().as_bytes().to_vec(),
            request.payload_identity(),
        )
    }
}

impl Drop for RuntimeHost {
    fn drop(&mut self) {
        self.inner.closed.store(true, Ordering::Release);
        for reader in self.readers.drain(..) {
            let _ = reader.join();
        }
        let _transport_guard = self.inner.transport_mu.lock().ok();
        let _ = unsafe { (self.inner.lib.stop_runtime)(self.inner.runtime.0) };
        close_host_handles(self.host_handles);
        unsafe { (self.inner.lib.destroy_runtime)(self.inner.runtime.0) };
    }
}

impl RuntimeInner {
    fn require_open(&self) -> Result<()> {
        if self.closed.load(Ordering::Acquire) {
            Err(CoAkkaError::Native("runtime host is closed".to_string()))
        } else {
            Ok(())
        }
    }

    fn submit_envelope(&self, envelope: &TransportEnvelope) -> Result<()> {
        self.require_open()?;
        let _guard = self
            .submit_mu
            .lock()
            .map_err(|_| CoAkkaError::Native("submit mutex poisoned".to_string()))?;
        let bytes = encode_envelope(envelope);
        status_to_result(
            unsafe { (self.lib.submit_envelope)(self.runtime.0, bytes.as_ptr(), bytes.len()) },
            "coakka_v2_runtime_submit_envelope",
        )
    }
}

pub fn make_json_reply(
    request: &TransportEnvelope,
    source: &str,
    payload: Vec<u8>,
    payload_identity: PayloadIdentity,
) -> Result<TransportEnvelope> {
    payload_identity.require_typed("JSON reply")?;
    let correlation_id = if request.correlation_id.is_empty() {
        request.message_id.clone()
    } else {
        request.correlation_id.clone()
    };
    Ok(TransportEnvelope {
        message_id: format!("{}.reply.{}", request.message_id, source),
        correlation_id,
        source: source.to_string(),
        target: request.source.clone(),
        reply_to: String::new(),
        kind: MessageKind::Response,
        one_way: false,
        timeout_ms: request.timeout_ms,
        payload,
        headers: HashMap::new(),
        status: BusinessStatus::Ok,
        error_code: String::new(),
        error_message: String::new(),
        delivery_hint: DeliveryHint::RouterDefault,
        message_type: payload_identity.message_type,
        payload_schema_version: payload_identity.payload_schema_version,
        payload_format: payload_identity.payload_format,
    })
}

#[allow(clippy::too_many_arguments)]
fn make_json_request(
    source: &str,
    target: &str,
    payload: Vec<u8>,
    payload_identity: PayloadIdentity,
    timeout: Duration,
    operation: &str,
    delivery_hint: DeliveryHint,
    one_way: bool,
) -> Result<TransportEnvelope> {
    payload_identity.require_typed("JSON request")?;
    let message_id = next_message_id(source);
    let mut headers = HashMap::new();
    headers.insert("method".to_string(), "POST".to_string());
    headers.insert("operation".to_string(), operation.to_string());
    Ok(TransportEnvelope {
        message_id: message_id.clone(),
        correlation_id: if one_way { String::new() } else { message_id },
        source: source.to_string(),
        target: target.to_string(),
        reply_to: if one_way {
            String::new()
        } else {
            format!("{source}/replies")
        },
        kind: MessageKind::Request,
        one_way,
        timeout_ms: timeout.as_millis().min(i32::MAX as u128) as i32,
        payload,
        headers,
        status: BusinessStatus::Ok,
        error_code: String::new(),
        error_message: String::new(),
        delivery_hint,
        message_type: payload_identity.message_type,
        payload_schema_version: payload_identity.payload_schema_version,
        payload_format: payload_identity.payload_format,
    })
}

fn next_message_id(source: &str) -> String {
    static COUNTER: AtomicU64 = AtomicU64::new(1);
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_else(|_| Duration::from_secs(0))
        .as_nanos();
    let sequence = COUNTER.fetch_add(1, Ordering::Relaxed);
    format!("{source}-{now:x}-{sequence:x}")
}

fn spawn_frame_reader(
    inner: Arc<RuntimeInner>,
    fd: c_int,
    on_frame: fn(&Arc<RuntimeInner>, Vec<u8>) -> Result<()>,
) -> JoinHandle<()> {
    thread::spawn(move || {
        let mut pending = Vec::<u8>::new();
        let mut buffer = [0u8; 64 * 1024];
        while !inner.closed.load(Ordering::Acquire) {
            match native_read(fd, &mut buffer) {
                Ok(0) => thread::sleep(Duration::from_millis(5)),
                Ok(read) => {
                    pending.extend_from_slice(&buffer[..read]);
                    while pending.len() >= 8 {
                        let len = u64::from_le_bytes(pending[..8].try_into().unwrap()) as usize;
                        if pending.len() < 8 + len {
                            break;
                        }
                        let frame = pending[8..8 + len].to_vec();
                        pending.drain(..8 + len);
                        if let Err(error) = on_frame(&inner, frame) {
                            eprintln!("[coakka-rust] frame handler failed: {error}");
                        }
                    }
                }
                Err(error) => {
                    if !inner.closed.load(Ordering::Acquire) {
                        eprintln!("[coakka-rust] read fd={fd} failed: {error}");
                        thread::sleep(Duration::from_millis(25));
                    }
                }
            }
        }
    })
}

fn on_request_frame(inner: &Arc<RuntimeInner>, frame: Vec<u8>) -> Result<()> {
    let request = decode_envelope(&frame)?;
    let handler = {
        inner
            .handlers
            .lock()
            .map_err(|_| CoAkkaError::Native("handler mutex poisoned".to_string()))?
            .get(&request.target)
            .cloned()
    };
    if let Some(handler) = handler {
        inner.delivered_requests.fetch_add(1, Ordering::Relaxed);
        if let Some(reply) = handler(request) {
            inner.submit_envelope(&reply)?;
        }
    }
    Ok(())
}

fn on_response_frame(inner: &Arc<RuntimeInner>, frame: Vec<u8>) -> Result<()> {
    let response = decode_envelope(&frame)?;
    let key = if response.correlation_id.is_empty() {
        response.message_id.clone()
    } else {
        response.correlation_id.clone()
    };
    let sender = inner
        .pending
        .lock()
        .map_err(|_| CoAkkaError::Native("pending mutex poisoned".to_string()))?
        .remove(&key);
    if let Some(sender) = sender {
        inner.matched_responses.fetch_add(1, Ordering::Relaxed);
        let _ = sender.send(Ok(response));
    } else {
        inner.late_responses.fetch_add(1, Ordering::Relaxed);
    }
    Ok(())
}

fn on_deadletter_frame(inner: &Arc<RuntimeInner>, frame: Vec<u8>) -> Result<()> {
    let deadletter = decode_deadletter(&frame)?;
    let key = if deadletter.original.correlation_id.is_empty() {
        deadletter.original.message_id.clone()
    } else {
        deadletter.original.correlation_id.clone()
    };
    let sender = inner
        .pending
        .lock()
        .map_err(|_| CoAkkaError::Native("pending mutex poisoned".to_string()))?
        .remove(&key);
    if let Some(sender) = sender {
        inner.matched_deadletters.fetch_add(1, Ordering::Relaxed);
        let _ = sender.send(Err(CoAkkaError::Deadletter(Box::new(deadletter))));
    } else {
        inner.unhandled_deadletters.fetch_add(1, Ordering::Relaxed);
    }
    Ok(())
}

fn status_to_result(status: c_int, operation: &str) -> Result<()> {
    if status == 0 {
        Ok(())
    } else {
        Err(CoAkkaError::Native(format!(
            "{operation} returned status {status}"
        )))
    }
}

fn host_handle_flags(spec: &ConnectorStartSpec) -> u32 {
    let mut flags = 0;
    if spec.enable_monitor {
        flags |= 1 << 0;
    }
    if spec.separate_delivered_request_lane {
        flags |= 1 << 1;
    }
    flags
}

fn close_host_handles(handles: NativeHostHandles) {
    let mut closed = HashSet::new();
    for fd in [
        handles.request_write_fd,
        handles.response_read_fd,
        handles.deadletter_read_fd,
        handles.control_write_fd,
        handles.monitor_read_fd,
        handles.delivered_request_read_fd,
    ] {
        if fd >= 0 && closed.insert(fd) {
            platform::close_fd(fd);
        }
    }
}

fn ptr_to_string(value: *const c_char) -> String {
    if value.is_null() {
        String::new()
    } else {
        unsafe { CStr::from_ptr(value) }
            .to_string_lossy()
            .to_string()
    }
}

fn native_read(fd: c_int, buffer: &mut [u8]) -> Result<usize> {
    platform::read_fd(fd, buffer)
}

pub struct RuntimeLibraryResolver;

impl RuntimeLibraryResolver {
    pub fn resolve(explicit_path: &str) -> Result<PathBuf> {
        if !explicit_path.trim().is_empty() {
            return require_existing_library(
                PathBuf::from(explicit_path),
                "explicit runtime_lib_path",
            );
        }
        if let Ok(value) = env::var("COAKKA_RUNTIME_LIB") {
            if !value.trim().is_empty() {
                return require_existing_library(PathBuf::from(value), "$COAKKA_RUNTIME_LIB");
            }
        }
        for candidate in library_candidates()? {
            if candidate.is_file() {
                return fs::canonicalize(&candidate).map_err(|err| {
                    CoAkkaError::Io(format!("canonicalize {}: {err}", candidate.display()))
                });
            }
        }
        Err(CoAkkaError::Native(format!(
            "native runtime library not found for platform {}. Set COAKKA_RUNTIME_LIB or stage rust/native/<platform>",
            platform_id()
        )))
    }
}

fn require_existing_library(path: PathBuf, source: &str) -> Result<PathBuf> {
    if path.is_file() {
        fs::canonicalize(&path)
            .map_err(|err| CoAkkaError::Io(format!("canonicalize {}: {err}", path.display())))
    } else {
        Err(CoAkkaError::Native(format!(
            "{source} does not exist: {}",
            path.display()
        )))
    }
}

fn library_candidates() -> Result<Vec<PathBuf>> {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let repo_root = manifest
        .parent()
        .ok_or_else(|| CoAkkaError::Native("could not resolve repo root".to_string()))?
        .to_path_buf();
    let platform = platform_id();
    let names = runtime_library_names();
    let roots = [
        manifest.join("native").join(platform),
        repo_root.join("go").join("native").join(platform),
        repo_root
            .join("python")
            .join("coakka_v2_connector")
            .join("native")
            .join(platform),
        repo_root.join("lib"),
    ];
    let mut out = Vec::new();
    for root in roots {
        for name in &names {
            out.push(root.join(name));
        }
    }
    Ok(out)
}

fn platform_id() -> &'static str {
    match (std::env::consts::OS, std::env::consts::ARCH) {
        ("macos", "aarch64") => "macos-aarch64",
        ("linux", "aarch64") => "linux-aarch64",
        ("linux", "x86_64") => "linux-x86_64",
        ("windows", "aarch64") => "windows-aarch64",
        ("windows", "x86_64") => "windows-x86_64",
        _ => "unsupported",
    }
}

fn runtime_library_names() -> Vec<String> {
    match std::env::consts::OS {
        "macos" => vec![
            "libcoakka_runtime_v2.dylib".to_string(),
            "libcoakka_runtime_v2-2.1.0+60ddf70d.dylib".to_string(),
        ],
        "windows" => vec![
            "libcoakka_runtime_v2.dll".to_string(),
            "libcoakka_runtime_v2-2.1.0+60ddf70d.dll".to_string(),
        ],
        _ => vec![
            "libcoakka_runtime_v2.so".to_string(),
            "libcoakka_runtime_v2-2.1.0+60ddf70d.so".to_string(),
        ],
    }
}

fn encode_initial_snapshot(spec: &ConnectorStartSpec) -> Vec<u8> {
    let mut out = Vec::new();
    let payload = encode_route_snapshot_payload(spec);
    write_uint64(&mut out, 1, 1);
    write_uint64(&mut out, 2, spec.generation);
    write_uint64(&mut out, 3, 1);
    write_uint64(&mut out, 4, 2);
    write_uint64(&mut out, 5, 1);
    write_uint64(&mut out, 6, 1);
    write_bytes(&mut out, 7, &payload);
    write_bytes(
        &mut out,
        8,
        &encode_map_entry("source_connector", &spec.system_name),
    );
    out
}

fn encode_route_snapshot_payload(spec: &ConnectorStartSpec) -> Vec<u8> {
    let mut out = Vec::new();
    write_uint64(&mut out, 1, spec.generation);
    for route in &spec.routes {
        write_bytes(&mut out, 2, &encode_route(route));
    }
    out
}

fn encode_route(route: &RouteSpec) -> Vec<u8> {
    let mut out = Vec::new();
    write_string(&mut out, 1, &route.target);
    write_uint64(&mut out, 2, route.strategy as u64);
    if !route.route_key_hint.is_empty() {
        write_string(&mut out, 3, &route.route_key_hint);
    }
    if route.flags != 0 {
        write_uint64(&mut out, 4, route.flags as u64);
    }
    for endpoint in &route.endpoints {
        write_bytes(&mut out, 5, &encode_endpoint(endpoint));
    }
    out
}

fn encode_endpoint(endpoint: &EndpointSpec) -> Vec<u8> {
    let mut out = Vec::new();
    write_string(&mut out, 1, &endpoint.host);
    write_uint64(&mut out, 2, endpoint.port as u64);
    write_uint64(&mut out, 3, endpoint.weight as u64);
    if endpoint.flags != 0 {
        write_uint64(&mut out, 4, endpoint.flags as u64);
    }
    out
}

fn encode_map_entry(key: &str, value: &str) -> Vec<u8> {
    let mut out = Vec::new();
    write_string(&mut out, 1, key);
    write_string(&mut out, 2, value);
    out
}

fn encode_envelope(envelope: &TransportEnvelope) -> Vec<u8> {
    let mut out = Vec::new();
    write_string(&mut out, 1, &envelope.message_id);
    write_string(&mut out, 2, &envelope.correlation_id);
    write_string(&mut out, 3, &envelope.source);
    write_string(&mut out, 4, &envelope.target);
    write_string(&mut out, 5, &envelope.reply_to);
    write_uint64(&mut out, 6, envelope.kind as u64);
    write_uint64(&mut out, 7, if envelope.one_way { 1 } else { 0 });
    write_uint64(&mut out, 8, envelope.timeout_ms.max(0) as u64);
    write_bytes(&mut out, 9, &envelope.payload);
    for (key, value) in &envelope.headers {
        write_bytes(&mut out, 10, &encode_map_entry(key, value));
    }
    write_uint64(&mut out, 11, envelope.status as u64);
    write_string(&mut out, 12, &envelope.error_code);
    write_string(&mut out, 13, &envelope.error_message);
    write_uint64(&mut out, 14, envelope.delivery_hint as u64);
    write_string(&mut out, 15, &envelope.message_type);
    write_uint64(&mut out, 16, envelope.payload_schema_version as u64);
    write_uint64(&mut out, 17, envelope.payload_format as u64);
    out
}

fn decode_envelope(bytes: &[u8]) -> Result<TransportEnvelope> {
    let mut reader = WireReader::new(bytes);
    let mut envelope = TransportEnvelope {
        message_id: String::new(),
        correlation_id: String::new(),
        source: String::new(),
        target: String::new(),
        reply_to: String::new(),
        kind: MessageKind::Request,
        one_way: false,
        timeout_ms: 0,
        payload: Vec::new(),
        headers: HashMap::new(),
        status: BusinessStatus::Ok,
        error_code: String::new(),
        error_message: String::new(),
        delivery_hint: DeliveryHint::RouterDefault,
        message_type: String::new(),
        payload_schema_version: 0,
        payload_format: PayloadFormat::Unspecified,
    };
    while let Some((field, wire)) = reader.try_read_tag()? {
        match field {
            1 => envelope.message_id = reader.read_string(wire)?,
            2 => envelope.correlation_id = reader.read_string(wire)?,
            3 => envelope.source = reader.read_string(wire)?,
            4 => envelope.target = reader.read_string(wire)?,
            5 => envelope.reply_to = reader.read_string(wire)?,
            6 => {
                envelope.kind = match reader.read_uint64(wire)? {
                    2 => MessageKind::Response,
                    3 => MessageKind::Event,
                    _ => MessageKind::Request,
                }
            }
            7 => envelope.one_way = reader.read_uint64(wire)? != 0,
            8 => envelope.timeout_ms = reader.read_uint64(wire)? as i32,
            9 => envelope.payload = reader.read_bytes(wire)?,
            10 => {
                let entry = reader.read_bytes(wire)?;
                let (key, value) = decode_map_entry(&entry)?;
                if !key.is_empty() {
                    envelope.headers.insert(key, value);
                }
            }
            11 => {
                envelope.status = if reader.read_uint64(wire)? == 2 {
                    BusinessStatus::Error
                } else {
                    BusinessStatus::Ok
                }
            }
            12 => envelope.error_code = reader.read_string(wire)?,
            13 => envelope.error_message = reader.read_string(wire)?,
            14 => {
                envelope.delivery_hint = match reader.read_uint64(wire)? {
                    2 => DeliveryHint::PreferLocal,
                    3 => DeliveryHint::RequireLocal,
                    4 => DeliveryHint::RequireRemote,
                    _ => DeliveryHint::RouterDefault,
                }
            }
            15 => envelope.message_type = reader.read_string(wire)?,
            16 => envelope.payload_schema_version = reader.read_uint64(wire)? as u32,
            17 => {
                envelope.payload_format = match reader.read_uint64(wire)? {
                    1 => PayloadFormat::Json,
                    2 => PayloadFormat::WireBinary,
                    3 => PayloadFormat::Thrift,
                    4 => PayloadFormat::MessagePack,
                    5 => PayloadFormat::PlainText,
                    6 => PayloadFormat::Binary,
                    _ => PayloadFormat::Unspecified,
                }
            }
            _ => reader.skip(wire)?,
        }
    }
    Ok(envelope)
}

fn decode_deadletter(bytes: &[u8]) -> Result<RuntimeDeadletter> {
    let mut reader = WireReader::new(bytes);
    let mut original = None;
    let mut reason = "DEADLETTER_REASON_UNSPECIFIED".to_string();
    let mut detail = String::new();
    let mut active_generation = 0;
    let mut resolved_host = String::new();
    let mut resolved_port = 0;
    while let Some((field, wire)) = reader.try_read_tag()? {
        match field {
            1 => original = Some(decode_envelope(&reader.read_bytes(wire)?)?),
            2 => reason = deadletter_reason_name(reader.read_uint64(wire)?).to_string(),
            3 => detail = reader.read_string(wire)?,
            4 => active_generation = reader.read_uint64(wire)?,
            5 => resolved_host = reader.read_string(wire)?,
            6 => resolved_port = reader.read_uint64(wire)? as u32,
            _ => reader.skip(wire)?,
        }
    }
    Ok(RuntimeDeadletter {
        original: original.ok_or_else(|| {
            CoAkkaError::WireCodec("deadletter missing original envelope".to_string())
        })?,
        reason,
        detail,
        active_generation,
        resolved_host,
        resolved_port,
    })
}

fn deadletter_reason_name(reason: u64) -> &'static str {
    match reason {
        1 => "DEADLETTER_REASON_NO_ACTIVE_SNAPSHOT",
        2 => "DEADLETTER_REASON_ROUTE_MISS",
        3 => "DEADLETTER_REASON_NO_RESPONSIBLE_HOST",
        4 => "DEADLETTER_REASON_QUEUE_REJECTED",
        5 => "DEADLETTER_REASON_LOCAL_HANDOFF_FAILED",
        6 => "DEADLETTER_REASON_DELIVERY_FAILED",
        7 => "DEADLETTER_REASON_REMOTE_SEND_FAILED",
        8 => "DEADLETTER_REASON_RUNTIME_STOPPED",
        9 => "DEADLETTER_REASON_INVALID_ENVELOPE",
        10 => "DEADLETTER_REASON_ENDPOINT_UNAVAILABLE",
        11 => "DEADLETTER_REASON_REMOTE_REPLY_TIMEOUT",
        12 => "DEADLETTER_REASON_LOCALITY_MISMATCH",
        13 => "DEADLETTER_REASON_EXPIRED_BEFORE_DELIVERY",
        14 => "DEADLETTER_REASON_ONE_WAY_DROPPED_BY_POLICY",
        _ => "DEADLETTER_REASON_UNSPECIFIED",
    }
}

fn decode_map_entry(bytes: &[u8]) -> Result<(String, String)> {
    let mut reader = WireReader::new(bytes);
    let mut key = String::new();
    let mut value = String::new();
    while let Some((field, wire)) = reader.try_read_tag()? {
        match field {
            1 => key = reader.read_string(wire)?,
            2 => value = reader.read_string(wire)?,
            _ => reader.skip(wire)?,
        }
    }
    Ok((key, value))
}

fn write_uint64(out: &mut Vec<u8>, field: u64, value: u64) {
    write_tag(out, field, WIRE_VARINT);
    write_varint(out, value);
}

fn write_string(out: &mut Vec<u8>, field: u64, value: &str) {
    if !value.is_empty() {
        write_bytes(out, field, value.as_bytes());
    }
}

fn write_bytes(out: &mut Vec<u8>, field: u64, value: &[u8]) {
    if !value.is_empty() {
        write_tag(out, field, WIRE_LENGTH_DELIMITED);
        write_varint(out, value.len() as u64);
        out.extend_from_slice(value);
    }
}

fn write_tag(out: &mut Vec<u8>, field: u64, wire: u8) {
    write_varint(out, (field << 3) | wire as u64);
}

fn write_varint(out: &mut Vec<u8>, mut value: u64) {
    while value >= 0x80 {
        out.push(((value as u8) & 0x7f) | 0x80);
        value >>= 7;
    }
    out.push(value as u8);
}

struct WireReader<'a> {
    remaining: &'a [u8],
}

impl<'a> WireReader<'a> {
    fn new(bytes: &'a [u8]) -> Self {
        Self { remaining: bytes }
    }

    fn try_read_tag(&mut self) -> Result<Option<(u64, u8)>> {
        if self.remaining.is_empty() {
            return Ok(None);
        }
        let tag = self.read_varint()?;
        Ok(Some((tag >> 3, (tag & 0x7) as u8)))
    }

    fn read_uint64(&mut self, wire: u8) -> Result<u64> {
        require_wire(wire, WIRE_VARINT)?;
        self.read_varint()
    }

    fn read_string(&mut self, wire: u8) -> Result<String> {
        let bytes = self.read_bytes(wire)?;
        String::from_utf8(bytes)
            .map_err(|err| CoAkkaError::WireCodec(format!("invalid utf8: {err}")))
    }

    fn read_bytes(&mut self, wire: u8) -> Result<Vec<u8>> {
        require_wire(wire, WIRE_LENGTH_DELIMITED)?;
        let len = self.read_varint()? as usize;
        if self.remaining.len() < len {
            return Err(CoAkkaError::WireCodec(
                "truncated length-delimited field".to_string(),
            ));
        }
        let value = self.remaining[..len].to_vec();
        self.remaining = &self.remaining[len..];
        Ok(value)
    }

    fn skip(&mut self, wire: u8) -> Result<()> {
        match wire {
            WIRE_VARINT => {
                let _ = self.read_varint()?;
                Ok(())
            }
            WIRE_LENGTH_DELIMITED => {
                let _ = self.read_bytes(wire)?;
                Ok(())
            }
            _ => Err(CoAkkaError::WireCodec(format!(
                "unsupported wire type {wire}"
            ))),
        }
    }

    fn read_varint(&mut self) -> Result<u64> {
        let mut result = 0u64;
        let mut shift = 0;
        while !self.remaining.is_empty() && shift < 64 {
            let value = self.remaining[0];
            self.remaining = &self.remaining[1..];
            result |= ((value & 0x7f) as u64) << shift;
            if value & 0x80 == 0 {
                return Ok(result);
            }
            shift += 7;
        }
        Err(CoAkkaError::WireCodec("invalid varint".to_string()))
    }
}

fn require_wire(actual: u8, expected: u8) -> Result<()> {
    if actual == expected {
        Ok(())
    } else {
        Err(CoAkkaError::WireCodec(format!(
            "unexpected wire type {actual}; expected {expected}"
        )))
    }
}

#[repr(C)]
#[derive(Copy, Clone)]
struct RuntimePtr(*mut c_void);

unsafe impl Send for RuntimePtr {}
unsafe impl Sync for RuntimePtr {}

#[repr(C)]
struct NativeRuntimeConfig {
    system_name: *const c_char,
    node_id: *const c_char,
    strict_no_drop: c_int,
    queue_capacity: c_int,
}

#[repr(C)]
struct NativeRuntimeInfo {
    struct_size: usize,
    abi_version: u32,
    feature_flags: u32,
    runtime_version: *const c_char,
    git_commit: *const c_char,
    southbound_backend: *const c_char,
    allocator_backend: *const c_char,
    docs_hint: *const c_char,
    remote_wire_profile: *const c_char,
    remote_wire_profile_version: u32,
}

impl Default for NativeRuntimeInfo {
    fn default() -> Self {
        Self {
            struct_size: 0,
            abi_version: 0,
            feature_flags: 0,
            runtime_version: std::ptr::null(),
            git_commit: std::ptr::null(),
            southbound_backend: std::ptr::null(),
            allocator_backend: std::ptr::null(),
            docs_hint: std::ptr::null(),
            remote_wire_profile: std::ptr::null(),
            remote_wire_profile_version: 0,
        }
    }
}

#[repr(C)]
struct NativeRuntimeConfigView {
    struct_size: usize,
    system_name: *const c_char,
    node_id: *const c_char,
    strict_no_drop: c_int,
    queue_capacity: c_int,
    request_max_frame_size: usize,
    local_dispatch_batch_limit: usize,
    runtime_state: c_int,
    snapshot_present: u32,
    applied_generation: u64,
    route_count: usize,
    southbound_bind_host: *const c_char,
    southbound_bind_port: u16,
}

impl Default for NativeRuntimeConfigView {
    fn default() -> Self {
        Self {
            struct_size: 0,
            system_name: std::ptr::null(),
            node_id: std::ptr::null(),
            strict_no_drop: 0,
            queue_capacity: 0,
            request_max_frame_size: 0,
            local_dispatch_batch_limit: 0,
            runtime_state: 0,
            snapshot_present: 0,
            applied_generation: 0,
            route_count: 0,
            southbound_bind_host: std::ptr::null(),
            southbound_bind_port: 0,
        }
    }
}

#[repr(C)]
#[derive(Copy, Clone)]
struct NativeHostHandles {
    struct_size: usize,
    flags: u32,
    request_write_fd: c_int,
    response_read_fd: c_int,
    deadletter_read_fd: c_int,
    control_write_fd: c_int,
    monitor_read_fd: c_int,
    delivered_request_read_fd: c_int,
}

impl Default for NativeHostHandles {
    fn default() -> Self {
        Self {
            struct_size: 0,
            flags: 0,
            request_write_fd: -1,
            response_read_fd: -1,
            deadletter_read_fd: -1,
            control_write_fd: -1,
            monitor_read_fd: -1,
            delivered_request_read_fd: -1,
        }
    }
}

struct NativeLibrary {
    get_abi_version: unsafe extern "C" fn() -> u32,
    get_info: unsafe extern "C" fn(*mut NativeRuntimeInfo) -> c_int,
    get_config: unsafe extern "C" fn(*mut c_void, *mut NativeRuntimeConfigView) -> c_int,
    get_capabilities: transport::RuntimeGetCapabilities,
    create_runtime: unsafe extern "C" fn(*const NativeRuntimeConfig) -> *mut c_void,
    destroy_runtime: unsafe extern "C" fn(*mut c_void),
    get_host_handles: unsafe extern "C" fn(*mut c_void, *mut NativeHostHandles) -> c_int,
    start_runtime: unsafe extern "C" fn(*mut c_void) -> c_int,
    stop_runtime: unsafe extern "C" fn(*mut c_void) -> c_int,
    submit_envelope: unsafe extern "C" fn(*mut c_void, *const u8, usize) -> c_int,
    apply_control_envelope: unsafe extern "C" fn(*mut c_void, *const u8, usize) -> c_int,
    apply_tcp_connection_options: transport::RuntimeApplyTcpConnectionOptions,
    get_tcp_connection_config: transport::RuntimeGetTcpConnectionConfig,
    apply_tcp_security_options: transport::RuntimeApplyTcpSecurityOptions,
    get_tcp_security_info: transport::RuntimeGetTcpSecurityInfo,
    transport_apply_reason_name: transport::RuntimeTransportApplyReasonName,
    file_lane_create: Option<file_lane::FileLaneCreateFn>,
    file_lane_destroy: Option<file_lane::FileLaneDestroyFn>,
    file_lane_start: Option<file_lane::FileLaneStartFn>,
    file_lane_stop: Option<file_lane::FileLaneStopFn>,
    file_lane_get_bound_port: Option<file_lane::FileLaneGetBoundPortFn>,
    file_lane_prepare_receive: Option<file_lane::FileLanePrepareReceiveFn>,
    file_lane_submit_send: Option<file_lane::FileLaneSubmitSendFn>,
    file_lane_get_transfer: Option<file_lane::FileLaneGetTransferFn>,
    file_lane_wait_transfer: Option<file_lane::FileLaneWaitTransferFn>,
    file_lane_cancel_transfer: Option<file_lane::FileLaneTransferControlFn>,
    file_lane_forget_transfer: Option<file_lane::FileLaneTransferControlFn>,
    file_lane_get_stats: Option<file_lane::FileLaneGetStatsFn>,
    file_sha256_path: Option<file_lane::FileSha256PathFn>,
}

unsafe impl Send for NativeLibrary {}
unsafe impl Sync for NativeLibrary {}

impl NativeLibrary {
    fn open(path: &Path) -> Result<Self> {
        static PROCESS_LIBRARY: OnceLock<Mutex<Option<ProcessLibraryIdentity>>> = OnceLock::new();

        let mut identity = PROCESS_LIBRARY
            .get_or_init(|| Mutex::new(None))
            .lock()
            .map_err(|_| CoAkkaError::Native("process library mutex poisoned".to_string()))?;
        let (handle, opened_here) = if let Some(existing) = identity.as_ref() {
            if !same_library_path(&existing.path, path) {
                return Err(CoAkkaError::Native(format!(
                    "a different CoAkka runtime library is already loaded in this process: {}",
                    existing.path.display()
                )));
            }
            (existing.handle, false)
        } else {
            (platform::open_library(path)?, true)
        };

        let loaded = (|| -> Result<Self> {
            Ok(Self {
                get_abi_version: unsafe {
                    platform::load_symbol(handle, "coakka_v2_runtime_get_abi_version")?
                },
                get_info: unsafe { platform::load_symbol(handle, "coakka_v2_runtime_get_info")? },
                get_config: unsafe {
                    platform::load_symbol(handle, "coakka_v2_runtime_get_config")?
                },
                get_capabilities: unsafe {
                    platform::load_symbol(handle, "coakka_v2_runtime_get_capabilities")?
                },
                create_runtime: unsafe {
                    platform::load_symbol(handle, "coakka_v2_runtime_create")?
                },
                destroy_runtime: unsafe {
                    platform::load_symbol(handle, "coakka_v2_runtime_destroy")?
                },
                get_host_handles: unsafe {
                    platform::load_symbol(handle, "coakka_v2_runtime_get_host_handles")?
                },
                start_runtime: unsafe { platform::load_symbol(handle, "coakka_v2_runtime_start")? },
                stop_runtime: unsafe { platform::load_symbol(handle, "coakka_v2_runtime_stop")? },
                submit_envelope: unsafe {
                    platform::load_symbol(handle, "coakka_v2_runtime_submit_envelope")?
                },
                apply_control_envelope: unsafe {
                    platform::load_symbol(handle, "coakka_v2_runtime_apply_control_envelope")?
                },
                apply_tcp_connection_options: unsafe {
                    platform::load_symbol(
                        handle,
                        "coakka_v2_runtime_apply_tcp_connection_options_ex",
                    )?
                },
                get_tcp_connection_config: unsafe {
                    platform::load_symbol(handle, "coakka_v2_runtime_get_tcp_connection_config")?
                },
                apply_tcp_security_options: unsafe {
                    platform::load_symbol(
                        handle,
                        "coakka_v2_runtime_apply_tcp_security_options_ex",
                    )?
                },
                get_tcp_security_info: unsafe {
                    platform::load_symbol(handle, "coakka_v2_runtime_get_tcp_security_info")?
                },
                transport_apply_reason_name: unsafe {
                    platform::load_symbol(handle, "coakka_v2_transport_apply_reason_name")?
                },
                file_lane_create: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_create_ex").ok()
                },
                file_lane_destroy: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_destroy").ok()
                },
                file_lane_start: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_start").ok()
                },
                file_lane_stop: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_stop").ok()
                },
                file_lane_get_bound_port: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_get_bound_port").ok()
                },
                file_lane_prepare_receive: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_prepare_receive").ok()
                },
                file_lane_submit_send: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_submit_send").ok()
                },
                file_lane_get_transfer: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_get_transfer").ok()
                },
                file_lane_wait_transfer: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_wait_transfer").ok()
                },
                file_lane_cancel_transfer: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_cancel_transfer").ok()
                },
                file_lane_forget_transfer: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_forget_transfer").ok()
                },
                file_lane_get_stats: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_lane_get_stats").ok()
                },
                file_sha256_path: unsafe {
                    platform::load_symbol(handle, "coakka_v2_file_sha256_path").ok()
                },
            })
        })();

        match loaded {
            Ok(library) => {
                if opened_here {
                    *identity = Some(ProcessLibraryIdentity {
                        handle,
                        path: path.to_path_buf(),
                    });
                }
                Ok(library)
            }
            Err(error) => {
                if opened_here {
                    unsafe { platform::close_library(handle) };
                }
                Err(error)
            }
        }
    }
}

struct ProcessLibraryIdentity {
    handle: platform::LibraryHandle,
    path: PathBuf,
}

unsafe impl Send for ProcessLibraryIdentity {}
unsafe impl Sync for ProcessLibraryIdentity {}

fn same_library_path(left: &Path, right: &Path) -> bool {
    if cfg!(windows) {
        left.to_string_lossy()
            .eq_ignore_ascii_case(&right.to_string_lossy())
    } else {
        left == right
    }
}
