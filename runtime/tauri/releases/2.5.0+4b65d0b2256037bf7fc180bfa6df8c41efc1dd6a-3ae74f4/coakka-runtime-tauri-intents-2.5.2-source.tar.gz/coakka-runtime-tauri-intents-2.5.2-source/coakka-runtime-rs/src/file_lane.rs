//! Bounded point-to-point file transfer backed by the native file-lane ABI.
//!
//! Prepare the receiver before submitting the sender. Observe successful
//! terminal snapshots on both peers, then forget retained records. File bytes
//! do not belong in runtime `Envelope` payloads.

use crate::lane_owner::{endpoint, fixed, native_owner, NativeOwnerConfig, NativeOwnerEndpoint};
use crate::{
    status_to_result, CoAkkaError, LaneOwnerConfig, LaneOwnerEndpoint, NativeLibrary, Result,
    RuntimeLibraryResolver,
};
use std::ffi::{c_char, c_int, c_void, CStr, CString};
use std::fmt;
use std::path::Path;
use std::ptr;
use std::sync::{Condvar, Mutex};

/// Enables sender work on a lane.
pub const FILE_LANE_SENDER: u32 = 1;
/// Enables receiver work on a lane.
pub const FILE_LANE_RECEIVER: u32 = 1 << 1;

#[repr(u32)]
#[derive(Clone, Copy, Debug)]
/// Transport protection; per-transfer authorization remains mandatory.
pub enum FileLaneSecurityMode {
    /// Unencrypted transport inside a protected deployment network.
    Direct = 0,
    /// Server-authenticated encrypted transport.
    Tls = 1,
    /// Mutually authenticated encrypted transport.
    MutualTls = 2,
}
#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
/// Side of a retained transfer record.
pub enum FileTransferDirection {
    /// Sender-side retained record.
    Send = 1,
    /// Receiver-side retained record.
    Receive = 2,
}
#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
/// Observable file-transfer lifecycle state.
pub enum FileTransferState {
    /// Receiver authorization is prepared.
    Prepared = 1,
    /// Sender job is admitted and waiting for a worker.
    Queued = 2,
    /// Sender is establishing transport.
    Connecting = 3,
    /// Bytes are moving or being committed.
    Transferring = 4,
    /// Receiver is validating complete content.
    Verifying = 5,
    /// Transfer and final integrity checks succeeded.
    Completed = 6,
    /// Work is retained but not currently advancing.
    Paused = 7,
    /// Peer authorization or metadata rejected the transfer.
    Rejected = 8,
    /// Transfer ended with an operational failure.
    Failed = 9,
    /// Host cancellation reached terminal state.
    Canceled = 10,
}
#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
/// Stable terminal outcome reported independently by each peer.
pub enum FileTransferResult {
    /// No terminal result yet.
    None = 0,
    /// Transfer completed successfully.
    Ok = 1,
    /// Receiver did not prepare this transfer id.
    NotPrepared = 2,
    /// Authorization token did not match prepared state.
    TokenMismatch = 3,
    /// Size or digest metadata did not match prepared state.
    MetadataMismatch = 4,
    /// File exceeds the configured size bound.
    SizeLimit = 5,
    /// Source, staging, checkpoint, or destination storage failed.
    StorageIo = 6,
    /// Complete content did not match the expected SHA-256.
    IntegrityMismatch = 7,
    /// Network delivery failed.
    NetworkIo = 8,
    /// Connect or I/O budget expired.
    Timeout = 9,
    /// Bounded admission queue was full.
    QueueFull = 10,
    /// Peer violated the File Lane wire contract.
    ProtocolError = 11,
    /// Open source identity changed during transfer.
    SourceChanged = 12,
    /// Internal invariant or resource operation failed.
    InternalError = 13,
    /// App-host requested cancellation.
    CanceledByHost = 14,
    /// TLS/mTLS material or configuration was invalid.
    TlsConfigInvalid = 15,
    /// TLS/mTLS session establishment failed.
    TlsHandshakeFailed = 16,
    /// Peer certificate chain is not trusted.
    PeerCertUntrusted = 17,
    /// Peer certificate is outside its validity period.
    PeerCertExpired = 18,
    /// Peer certificate identity does not match the endpoint.
    PeerIdentityMismatch = 19,
    /// Mutual TLS peer did not present a required client certificate.
    ClientCertRequired = 20,
}

#[derive(Clone, Debug)]
/// TLS material read at lane startup. Never log key paths or transfer tokens.
pub struct FileLaneSecurityConfig {
    /// Selected protection mode.
    pub mode: FileLaneSecurityMode,
    /// App-host credential generation used for diagnostics.
    pub credential_generation: u64,
    /// Non-secret credential identity.
    pub credential_id: String,
    /// Trust-anchor bundle path.
    pub ca_certificate_file: String,
    /// Local certificate-chain path.
    pub identity_certificate_file: String,
    /// Local private-key path.
    pub private_key_file: String,
}
#[derive(Clone, Debug)]
/// Bounded lane configuration. Zero tuning fields select native defaults.
pub struct FileLaneConfig {
    /// Enabled sender/receiver role bits.
    pub flags: u32,
    /// Receiver bind address copied during open.
    pub bind_host: String,
    /// Receiver port; zero requests an ephemeral port.
    pub bind_port: u16,
    /// Bounded retained/queued transfer capacity; zero selects the default.
    pub queue_capacity: usize,
    /// Maximum accepted file bytes; zero selects the default.
    pub max_file_size: u64,
    /// Connect and I/O timeout in milliseconds; zero selects the default.
    pub io_timeout_ms: u32,
    /// Durable checkpoint byte interval; zero selects the default.
    pub checkpoint_bytes: u64,
    /// Progress publication byte interval; zero selects the default.
    pub progress_bytes: u64,
    /// Progress publication interval in milliseconds; zero selects the default.
    pub progress_interval_ms: u32,
    /// Sender worker count in 1..=4; zero selects one.
    pub sender_worker_count: u32,
    /// Receiver worker count in 1..=4; zero selects one.
    pub receiver_worker_count: u32,
    /// Optional immutable transport protection settings.
    pub security: Option<FileLaneSecurityConfig>,
}
impl Default for FileLaneConfig {
    fn default() -> Self {
        Self {
            flags: FILE_LANE_SENDER | FILE_LANE_RECEIVER,
            bind_host: "127.0.0.1".into(),
            bind_port: 0,
            queue_capacity: 0,
            max_file_size: 0,
            io_timeout_ms: 0,
            checkpoint_bytes: 0,
            progress_bytes: 0,
            progress_interval_ms: 0,
            sender_worker_count: 0,
            receiver_worker_count: 0,
            security: None,
        }
    }
}
#[derive(Clone, Debug)]
/// Receiver authorization and exact content identity for one transfer.
pub struct FileReceiveSpec {
    /// Stable transfer id, unique among retained receiver records.
    pub transfer_id: String,
    /// Opaque per-transfer authorization secret.
    pub authorization_token: String,
    /// Receiver-local final destination path; never sent to the peer.
    pub destination_path: String,
    /// Exact expected file size in bytes.
    pub expected_size: u64,
    /// Exact expected complete-file SHA-256.
    pub expected_sha256: [u8; 32],
}
#[derive(Clone, Debug)]
/// Source and receiver endpoint for one previously prepared transfer.
pub struct FileSendSpec {
    /// Stable id matching a prepared receiver record.
    pub transfer_id: String,
    /// Opaque authorization secret matching receiver state.
    pub authorization_token: String,
    /// Receiver host name or numeric address.
    pub remote_host: String,
    /// Non-zero receiver port.
    pub remote_port: u16,
    /// Sender-local source path opened during submission.
    pub source_path: String,
    /// Exact source size in bytes.
    pub expected_size: u64,
    /// Exact complete-file SHA-256.
    pub expected_sha256: [u8; 32],
    /// Per-job connect/I/O timeout in milliseconds; zero selects lane default.
    pub timeout_ms: u32,
}
/// Receiver-issued transfer capability pinned to one exact replica.
pub struct FileReceiveGrant {
    /// Exact owner endpoint; it must not be replaced by a load-balancing service.
    pub owner: LaneOwnerEndpoint,
    /// Transfer identity retained by the receiver.
    pub transfer_id: String,
    authorization_token: String,
    /// Exact expected file size.
    pub expected_size: u64,
    /// Exact expected complete-file SHA-256.
    pub expected_sha256: [u8; 32],
}
impl FileReceiveGrant {
    /// Reconstructs a grant received over the application's trusted control plane.
    pub fn from_control_plane(
        owner: LaneOwnerEndpoint,
        transfer_id: impl Into<String>,
        authorization_token: impl Into<String>,
        expected_size: u64,
        expected_sha256: [u8; 32],
    ) -> Result<Self> {
        let transfer_id = transfer_id.into();
        let authorization_token = authorization_token.into();
        if transfer_id.is_empty() || authorization_token.is_empty() {
            return Err(CoAkkaError::InvalidArgument(
                "transfer id and authorization token must not be empty".into(),
            ));
        }
        Ok(Self {
            owner,
            transfer_id,
            authorization_token,
            expected_size,
            expected_sha256,
        })
    }

    /// Returns the bearer token for trusted control-plane transport.
    pub fn authorization_token(&self) -> &str {
        &self.authorization_token
    }
    /// Builds a sender job without allowing owner endpoint or identity drift.
    pub fn to_send_spec(&self, source_path: impl Into<String>, timeout_ms: u32) -> FileSendSpec {
        FileSendSpec {
            transfer_id: self.transfer_id.clone(),
            authorization_token: self.authorization_token.clone(),
            remote_host: self.owner.advertised_host.clone(),
            remote_port: self.owner.port,
            source_path: source_path.into(),
            expected_size: self.expected_size,
            expected_sha256: self.expected_sha256,
            timeout_ms,
        }
    }
}
impl fmt::Debug for FileReceiveGrant {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FileReceiveGrant")
            .field("owner", &self.owner)
            .field("transfer_id", &self.transfer_id)
            .field("authorization_token", &"<redacted>")
            .field("expected_size", &self.expected_size)
            .field("expected_sha256", &self.expected_sha256)
            .finish()
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
/// A file SHA-256 and exact byte count.
pub struct FileDigest {
    /// Complete-file SHA-256.
    pub sha256: [u8; 32],
    /// File size in bytes observed during hashing.
    pub size: u64,
}
#[derive(Clone, Debug)]
/// Immutable progress view with process-local monotonic timestamps.
pub struct FileTransferSnapshot {
    /// Sender or receiver projection.
    pub direction: FileTransferDirection,
    /// Current lifecycle state.
    pub state: FileTransferState,
    /// Terminal result, or `None` before terminal state.
    pub result: FileTransferResult,
    /// Contracted complete file size in bytes.
    pub expected_size: u64,
    /// Bytes read or received by this peer.
    pub transferred_bytes: u64,
    /// Receiver bytes durably checkpointed for resume.
    pub committed_offset: u64,
    /// Progress in thousandths of one percent, from 0 through 100000.
    pub progress_milli: u32,
    /// Whether the app-host requested cancellation.
    pub cancel_requested: bool,
    /// Monotonic record update cursor used by `wait_transfer`.
    pub update_sequence: u64,
    /// Process-local monotonic submission timestamp in nanoseconds.
    pub submitted_mono_ns: u64,
    /// Process-local monotonic work-start timestamp in nanoseconds.
    pub started_mono_ns: u64,
    /// Process-local monotonic latest-update timestamp in nanoseconds.
    pub updated_mono_ns: u64,
    /// Process-local monotonic terminal timestamp, or zero before terminal state.
    pub terminal_mono_ns: u64,
    /// Bounded diagnostic detail; never use it as a stable programmatic code.
    pub detail: String,
}
impl FileTransferSnapshot {
    /// Returns whether this side reached a terminal state.
    pub fn terminal(&self) -> bool {
        self.state >= FileTransferState::Completed
    }
    /// Returns whether this side reported `Completed` plus `Ok`.
    pub fn succeeded(&self) -> bool {
        self.state == FileTransferState::Completed && self.result == FileTransferResult::Ok
    }
}
#[derive(Clone, Debug)]
/// Bounded queue, active-work, terminal-count, and completed-byte counters.
pub struct FileLaneStats {
    /// Configured admission/retention bound.
    pub queue_capacity: usize,
    /// Sender jobs currently waiting for workers.
    pub queued_sends: usize,
    /// Prepared receiver authorizations not yet forgotten.
    pub prepared_receives: usize,
    /// Sender jobs currently active.
    pub active_sends: usize,
    /// Receiver jobs currently active.
    pub active_receives: usize,
    /// Terminal and prepared records retained for observation.
    pub retained_records: usize,
    /// Cumulative admitted sender jobs.
    pub submitted_sends: u64,
    /// Cumulative prepared receiver authorizations.
    pub prepared_receive_count: u64,
    /// Cumulative successful sender records.
    pub completed_sends: u64,
    /// Cumulative successful receiver records.
    pub completed_receives: u64,
    /// Cumulative failed/rejected sender records, excluding cancellation.
    pub failed_sends: u64,
    /// Cumulative failed/rejected receiver records, excluding cancellation.
    pub failed_receives: u64,
    /// Cumulative host-canceled records.
    pub canceled_transfers: u64,
    /// Cumulative bytes from successful sends.
    pub completed_send_bytes: u64,
    /// Cumulative bytes from successful receives.
    pub completed_receive_bytes: u64,
}

#[repr(C)]
pub(crate) struct NativeSecurity {
    struct_size: usize,
    mode: u32,
    reserved: u32,
    generation: u64,
    id: *const c_char,
    ca: *const c_char,
    cert: *const c_char,
    key: *const c_char,
}
#[repr(C)]
pub(crate) struct NativeConfig {
    struct_size: usize,
    flags: u32,
    bind_host: *const c_char,
    bind_port: u16,
    queue_capacity: usize,
    max_file_size: u64,
    io_timeout_ms: u32,
    checkpoint_bytes: u64,
    progress_bytes: u64,
    progress_interval_ms: u32,
    sender_workers: u32,
    receiver_workers: u32,
    security: *const NativeSecurity,
}
#[repr(C)]
pub(crate) struct NativeOwnedConfig {
    struct_size: usize,
    lane: NativeConfig,
    owner: NativeOwnerConfig,
}
#[repr(C)]
pub(crate) struct NativeReceive {
    struct_size: usize,
    id: *const c_char,
    token: *const c_char,
    path: *const c_char,
    size: u64,
    sha: [u8; 32],
}
#[repr(C)]
pub(crate) struct NativeReceiveGrant {
    struct_size: usize,
    owner: NativeOwnerEndpoint,
    transfer_id: [c_char; 65],
    authorization_token: [c_char; 129],
    expected_size: u64,
    expected_sha256: [u8; 32],
}
impl Default for NativeReceiveGrant {
    fn default() -> Self {
        // SAFETY: zero is valid output initialization for the complete grant.
        unsafe { std::mem::zeroed() }
    }
}
#[repr(C)]
pub(crate) struct NativeSend {
    struct_size: usize,
    id: *const c_char,
    token: *const c_char,
    host: *const c_char,
    port: u16,
    path: *const c_char,
    size: u64,
    sha: [u8; 32],
    timeout: u32,
}
#[repr(C)]
pub(crate) struct NativeSnapshot {
    struct_size: usize,
    direction: u32,
    state: u32,
    result: u32,
    expected: u64,
    transferred: u64,
    committed: u64,
    progress: u32,
    cancel: u32,
    sequence: u64,
    submitted: u64,
    started: u64,
    updated: u64,
    terminal: u64,
    detail: [c_char; 160],
}
impl Default for NativeSnapshot {
    fn default() -> Self {
        // SAFETY: the matching C record defines zero as valid initialization
        // for every scalar and fixed-size character buffer.
        unsafe { std::mem::zeroed() }
    }
}
#[repr(C)]
#[derive(Default)]
pub(crate) struct NativeStats {
    struct_size: usize,
    queue_capacity: usize,
    queued_sends: usize,
    prepared_receives: usize,
    active_sends: usize,
    active_receives: usize,
    retained_records: usize,
    submitted_sends: u64,
    prepared_receive_count: u64,
    completed_sends: u64,
    completed_receives: u64,
    failed_sends: u64,
    failed_receives: u64,
    canceled_transfers: u64,
    completed_send_bytes: u64,
    completed_receive_bytes: u64,
}

pub(crate) type FileLaneCreateFn =
    unsafe extern "C" fn(*const NativeConfig, *mut *mut c_void) -> c_int;
pub(crate) type FileLaneCreateOwnedFn =
    unsafe extern "C" fn(*const NativeOwnedConfig, *mut *mut c_void) -> c_int;
pub(crate) type FileLaneDestroyFn = unsafe extern "C" fn(*mut c_void);
pub(crate) type FileLaneStartFn = unsafe extern "C" fn(*mut c_void) -> c_int;
pub(crate) type FileLaneStopFn = unsafe extern "C" fn(*mut c_void) -> c_int;
pub(crate) type FileLaneGetBoundPortFn = unsafe extern "C" fn(*mut c_void, *mut u16) -> c_int;
pub(crate) type FileLanePrepareReceiveFn =
    unsafe extern "C" fn(*mut c_void, *const NativeReceive) -> c_int;
pub(crate) type FileLanePrepareReceiveGrantFn =
    unsafe extern "C" fn(*mut c_void, *const NativeReceive, *mut NativeReceiveGrant) -> c_int;
pub(crate) type FileLaneSubmitSendFn =
    unsafe extern "C" fn(*mut c_void, *const NativeSend) -> c_int;
pub(crate) type FileLaneGetTransferFn =
    unsafe extern "C" fn(*mut c_void, *const c_char, u32, *mut NativeSnapshot) -> c_int;
pub(crate) type FileLaneWaitTransferFn =
    unsafe extern "C" fn(*mut c_void, *const c_char, u32, u64, u32, *mut NativeSnapshot) -> c_int;
pub(crate) type FileLaneTransferControlFn =
    unsafe extern "C" fn(*mut c_void, *const c_char, u32) -> c_int;
pub(crate) type FileLaneGetStatsFn = unsafe extern "C" fn(*mut c_void, *mut NativeStats) -> c_int;
pub(crate) type FileSha256PathFn = unsafe extern "C" fn(*const c_char, *mut u8, *mut u64) -> c_int;

struct Lifecycle {
    lane: *mut c_void,
    closing: bool,
    active: usize,
}
// SAFETY: the raw lane pointer is accessed only while protected by the
// lifecycle mutex. Active-call counting prevents destroy until all borrowers
// have returned.
unsafe impl Send for Lifecycle {}
/// Independent bulk-transfer lane with synchronized close/drain ownership.
pub struct FileLane {
    lib: NativeLibrary,
    lifecycle: Mutex<Lifecycle>,
    drained: Condvar,
    prepare_receive_grant: Option<FileLanePrepareReceiveGrantFn>,
}
// SAFETY: mutable lifecycle state is mutex-protected and the core lane accepts
// concurrent observations/control until coordinated stop.
unsafe impl Send for FileLane {}
// SAFETY: shared calls take a lifecycle borrow and close waits for all such
// borrows before destroying the lane.
unsafe impl Sync for FileLane {}

impl FileLane {
    /// Opens and starts a lane from owned configuration values.
    pub fn open(config: FileLaneConfig, runtime_path: impl AsRef<str>) -> Result<Self> {
        Self::open_internal(config, None, runtime_path.as_ref())
    }

    /// Opens a lane that can issue replica-pinned receive grants.
    pub fn open_owned(
        config: FileLaneConfig,
        owner: LaneOwnerConfig,
        runtime_path: impl AsRef<str>,
    ) -> Result<Self> {
        owner.validate()?;
        Self::open_internal(config, Some(owner), runtime_path.as_ref())
    }

    fn open_internal(
        config: FileLaneConfig,
        owner: Option<LaneOwnerConfig>,
        runtime_path: &str,
    ) -> Result<Self> {
        if config.flags == 0
            || config.flags & !(FILE_LANE_SENDER | FILE_LANE_RECEIVER) != 0
            || config.sender_worker_count > 4
            || config.receiver_worker_count > 4
        {
            return Err(CoAkkaError::InvalidArgument(
                "invalid file-lane flags or worker count".into(),
            ));
        }
        let lib = NativeLibrary::open(&RuntimeLibraryResolver::resolve(runtime_path)?)?;
        if lib.file_lane_create.is_none()
            || lib.file_lane_destroy.is_none()
            || lib.file_lane_start.is_none()
            || lib.file_lane_stop.is_none()
            || lib.file_lane_get_bound_port.is_none()
            || lib.file_lane_prepare_receive.is_none()
            || lib.file_lane_submit_send.is_none()
            || lib.file_lane_get_transfer.is_none()
            || lib.file_lane_wait_transfer.is_none()
            || lib.file_lane_cancel_transfer.is_none()
            || lib.file_lane_forget_transfer.is_none()
            || lib.file_lane_get_stats.is_none()
            || lib.file_sha256_path.is_none()
        {
            return Err(CoAkkaError::Native(
                "native runtime does not export the complete file-lane ABI".into(),
            ));
        }
        let create = lib.file_lane_create.ok_or_else(|| {
            CoAkkaError::Native("native runtime does not export file-lane ABI".into())
        })?;
        let destroy = lib.file_lane_destroy.expect("complete ABI checked above");
        let start = lib.file_lane_start.expect("complete ABI checked above");
        let bind = c(&config.bind_host)?;
        let security_strings = config
            .security
            .as_ref()
            .map(|s| {
                Ok::<_, CoAkkaError>((
                    c(&s.credential_id)?,
                    c(&s.ca_certificate_file)?,
                    c(&s.identity_certificate_file)?,
                    c(&s.private_key_file)?,
                ))
            })
            .transpose()?;
        let native_security =
            config
                .security
                .as_ref()
                .zip(security_strings.as_ref())
                .map(|(s, v)| NativeSecurity {
                    struct_size: std::mem::size_of::<NativeSecurity>(),
                    mode: s.mode as u32,
                    reserved: 0,
                    generation: s.credential_generation,
                    id: v.0.as_ptr(),
                    ca: v.1.as_ptr(),
                    cert: v.2.as_ptr(),
                    key: v.3.as_ptr(),
                });
        let native = NativeConfig {
            struct_size: std::mem::size_of::<NativeConfig>(),
            flags: config.flags,
            bind_host: bind.as_ptr(),
            bind_port: config.bind_port,
            queue_capacity: config.queue_capacity,
            max_file_size: config.max_file_size,
            io_timeout_ms: config.io_timeout_ms,
            checkpoint_bytes: config.checkpoint_bytes,
            progress_bytes: config.progress_bytes,
            progress_interval_ms: config.progress_interval_ms,
            sender_workers: config.sender_worker_count,
            receiver_workers: config.receiver_worker_count,
            security: native_security.as_ref().map_or(ptr::null(), |v| v),
        };
        let mut lane = ptr::null_mut();
        let prepare_receive_grant = if owner.is_some() {
            Some(lib.load_additive::<FileLanePrepareReceiveGrantFn>(
                "coakka_v2_file_lane_prepare_receive_grant",
            )?)
        } else {
            None
        };
        if let Some(owner) = owner.as_ref() {
            let (_owner_id, _advertised_host, native_owner) = native_owner(owner)?;
            let owned = NativeOwnedConfig {
                struct_size: std::mem::size_of::<NativeOwnedConfig>(),
                lane: native,
                owner: native_owner,
            };
            let create_owned =
                lib.load_additive::<FileLaneCreateOwnedFn>("coakka_v2_file_lane_create_owned_ex")?;
            // SAFETY: nested config pointers and owner strings remain live for
            // this synchronous copying call.
            status_to_result(
                unsafe { create_owned(&owned, &mut lane) },
                "file_lane_create_owned",
            )?;
        } else {
            // SAFETY: all pointers reference live local values for this synchronous
            // create call; the core copies configuration strings before returning.
            status_to_result(unsafe { create(&native, &mut lane) }, "file_lane_create")?;
        }
        if lane.is_null() {
            return Err(CoAkkaError::Native("file_lane_create returned null".into()));
        }
        // SAFETY: create returned a non-null owned lane and `start` belongs to
        // the same loaded module.
        if let Err(error) = status_to_result(unsafe { start(lane) }, "file_lane_start") {
            // SAFETY: start failed before ownership escaped; this path owns the
            // lane and destroys it exactly once.
            unsafe { destroy(lane) };
            return Err(error);
        }
        Ok(Self {
            lib,
            lifecycle: Mutex::new(Lifecycle {
                lane,
                closing: false,
                active: 0,
            }),
            drained: Condvar::new(),
            prepare_receive_grant,
        })
    }
    /// Computes exact source identity synchronously.
    pub fn sha256(path: impl AsRef<Path>, runtime_path: impl AsRef<str>) -> Result<FileDigest> {
        let lib = NativeLibrary::open(&RuntimeLibraryResolver::resolve(runtime_path.as_ref())?)?;
        let f = lib.file_sha256_path.ok_or_else(|| {
            CoAkkaError::Native("native runtime does not export file-lane ABI".into())
        })?;
        let path = c(&path.as_ref().to_string_lossy())?;
        let mut out = [0; 32];
        let mut size = 0;
        status_to_result(
            // SAFETY: path is a live NUL-terminated string and both output
            // buffers remain writable for this synchronous hashing call.
            unsafe { f(path.as_ptr(), out.as_mut_ptr(), &mut size) },
            "file_sha256_path",
        )?;
        Ok(FileDigest { sha256: out, size })
    }
    fn call<T>(&self, action: impl FnOnce(&NativeLibrary, *mut c_void) -> Result<T>) -> Result<T> {
        let lane = {
            let mut s = self
                .lifecycle
                .lock()
                .map_err(|_| CoAkkaError::Native("file lane mutex poisoned".into()))?;
            if s.closing || s.lane.is_null() {
                return Err(CoAkkaError::Native("file lane is closed".into()));
            }
            s.active += 1;
            s.lane
        };
        let result = action(&self.lib, lane);
        let mut s = self.lifecycle.lock().unwrap();
        s.active -= 1;
        if s.active == 0 {
            self.drained.notify_all();
        }
        result
    }
    /// Returns the receiver port selected when the lane started.
    pub fn bound_port(&self) -> Result<u16> {
        self.call(|l, p| {
            let mut out = 0;
            status_to_result(
                // SAFETY: `call` holds a live lane borrow and `out` is writable
                // for this synchronous getter.
                unsafe { l.file_lane_get_bound_port.unwrap()(p, &mut out) },
                "file_lane_get_bound_port",
            )?;
            Ok(out)
        })
    }
    /// Authorizes one destination and expected content identity.
    ///
    /// The lane copies the spec before return. Preparing does not create the
    /// final destination or move bytes.
    pub fn prepare_receive(&self, spec: &FileReceiveSpec) -> Result<()> {
        self.call(|l, p| {
            let id = c(&spec.transfer_id)?;
            let token = c(&spec.authorization_token)?;
            let path = c(&spec.destination_path)?;
            let n = NativeReceive {
                struct_size: std::mem::size_of::<NativeReceive>(),
                id: id.as_ptr(),
                token: token.as_ptr(),
                path: path.as_ptr(),
                size: spec.expected_size,
                sha: spec.expected_sha256,
            };
            // SAFETY: `call` holds a live lane borrow and all spec strings are
            // NUL-terminated and alive for this synchronous copying call.
            status_to_result(
                unsafe { l.file_lane_prepare_receive.unwrap()(p, &n) },
                "file_lane_prepare_receive",
            )
        })
    }
    /// Prepares one receive and returns its exact owner capability.
    pub fn prepare_receive_grant(&self, spec: &FileReceiveSpec) -> Result<FileReceiveGrant> {
        let function = self.prepare_receive_grant.ok_or_else(|| {
            CoAkkaError::InvalidArgument("file lane was not opened with open_owned".into())
        })?;
        self.call(|_, lane| {
            let id = c(&spec.transfer_id)?;
            let token = c(&spec.authorization_token)?;
            let path = c(&spec.destination_path)?;
            let native = NativeReceive {
                struct_size: std::mem::size_of::<NativeReceive>(),
                id: id.as_ptr(),
                token: token.as_ptr(),
                path: path.as_ptr(),
                size: spec.expected_size,
                sha: spec.expected_sha256,
            };
            let mut grant = NativeReceiveGrant {
                struct_size: std::mem::size_of::<NativeReceiveGrant>(),
                ..NativeReceiveGrant::default()
            };
            status_to_result(
                // SAFETY: the lane borrow, spec strings, and writable grant
                // remain live for this synchronous prepare operation.
                unsafe { function(lane, &native, &mut grant) },
                "file_lane_prepare_receive_grant",
            )?;
            Ok(FileReceiveGrant {
                owner: endpoint(&grant.owner)?,
                transfer_id: fixed(&grant.transfer_id)?,
                authorization_token: fixed(&grant.authorization_token)?,
                expected_size: grant.expected_size,
                expected_sha256: grant.expected_sha256,
            })
        })
    }
    /// Queues a send after the remote application prepares the receive.
    pub fn submit_send(&self, spec: &FileSendSpec) -> Result<()> {
        if spec.remote_port == 0 {
            return Err(CoAkkaError::InvalidArgument(
                "remote port must be nonzero".into(),
            ));
        }
        self.call(|l, p| {
            let id = c(&spec.transfer_id)?;
            let token = c(&spec.authorization_token)?;
            let host = c(&spec.remote_host)?;
            let path = c(&spec.source_path)?;
            let n = NativeSend {
                struct_size: std::mem::size_of::<NativeSend>(),
                id: id.as_ptr(),
                token: token.as_ptr(),
                host: host.as_ptr(),
                port: spec.remote_port,
                path: path.as_ptr(),
                size: spec.expected_size,
                sha: spec.expected_sha256,
                timeout: spec.timeout_ms,
            };
            // SAFETY: `call` holds a live lane borrow and all spec strings are
            // NUL-terminated and alive for synchronous source admission.
            status_to_result(
                unsafe { l.file_lane_submit_send.unwrap()(p, &n) },
                "file_lane_submit_send",
            )
        })
    }
    /// Returns the current copied snapshot without waiting.
    pub fn transfer(
        &self,
        transfer_id: &str,
        direction: FileTransferDirection,
    ) -> Result<FileTransferSnapshot> {
        self.read(transfer_id, direction, 0, 0, false)
    }
    /// Blocks until the sequence advances, the timeout expires, or the lane stops.
    pub fn wait_transfer(
        &self,
        transfer_id: &str,
        direction: FileTransferDirection,
        after_update_sequence: u64,
        timeout_ms: u32,
    ) -> Result<FileTransferSnapshot> {
        self.read(
            transfer_id,
            direction,
            after_update_sequence,
            timeout_ms,
            true,
        )
    }
    fn read(
        &self,
        id: &str,
        d: FileTransferDirection,
        seq: u64,
        ms: u32,
        wait: bool,
    ) -> Result<FileTransferSnapshot> {
        self.call(|l, p| {
            let id = c(id)?;
            let mut n = NativeSnapshot {
                struct_size: std::mem::size_of::<NativeSnapshot>(),
                ..NativeSnapshot::default()
            };
            // SAFETY: `call` holds a live lane borrow; `id` and the writable
            // snapshot remain alive throughout either synchronous call.
            let rc = unsafe {
                if wait {
                    l.file_lane_wait_transfer.unwrap()(p, id.as_ptr(), d as u32, seq, ms, &mut n)
                } else {
                    l.file_lane_get_transfer.unwrap()(p, id.as_ptr(), d as u32, &mut n)
                }
            };
            status_to_result(rc, "file_lane_transfer")?;
            snapshot(n)
        })
    }
    /// Requests cooperative cancellation; observe terminal state before forget.
    pub fn cancel(&self, transfer_id: &str, direction: FileTransferDirection) -> Result<()> {
        self.control(transfer_id, direction, false)
    }
    /// Releases one retained terminal record after recording its outcome.
    pub fn forget(&self, transfer_id: &str, direction: FileTransferDirection) -> Result<()> {
        self.control(transfer_id, direction, true)
    }
    fn control(&self, id: &str, d: FileTransferDirection, forget: bool) -> Result<()> {
        self.call(|l, p| {
            let id = c(id)?;
            let f = if forget {
                l.file_lane_forget_transfer.unwrap()
            } else {
                l.file_lane_cancel_transfer.unwrap()
            };
            // SAFETY: `call` holds a live lane borrow and `id` remains a live
            // NUL-terminated string for the synchronous control call.
            status_to_result(
                unsafe { f(p, id.as_ptr(), d as u32) },
                "file_lane_transfer_control",
            )
        })
    }
    /// Returns a copied lane-level observability snapshot.
    pub fn stats(&self) -> Result<FileLaneStats> {
        self.call(|l, p| {
            let mut n = NativeStats {
                struct_size: std::mem::size_of::<NativeStats>(),
                ..NativeStats::default()
            };
            status_to_result(
                // SAFETY: `call` holds a live lane borrow and `n` is writable
                // for this synchronous snapshot call.
                unsafe { l.file_lane_get_stats.unwrap()(p, &mut n) },
                "file_lane_get_stats",
            )?;
            Ok(FileLaneStats {
                queue_capacity: n.queue_capacity,
                queued_sends: n.queued_sends,
                prepared_receives: n.prepared_receives,
                active_sends: n.active_sends,
                active_receives: n.active_receives,
                retained_records: n.retained_records,
                submitted_sends: n.submitted_sends,
                prepared_receive_count: n.prepared_receive_count,
                completed_sends: n.completed_sends,
                completed_receives: n.completed_receives,
                failed_sends: n.failed_sends,
                failed_receives: n.failed_receives,
                canceled_transfers: n.canceled_transfers,
                completed_send_bytes: n.completed_send_bytes,
                completed_receive_bytes: n.completed_receive_bytes,
            })
        })
    }
    /// Stops the lane, wakes blocked waits, drains calls, and releases native state.
    pub fn close(&self) -> Result<()> {
        let lane = {
            let mut s = self.lifecycle.lock().unwrap();
            if s.lane.is_null() {
                return Ok(());
            }
            if s.closing {
                while !s.lane.is_null() {
                    s = self.drained.wait(s).unwrap();
                }
                return Ok(());
            }
            s.closing = true;
            s.lane
        };
        // SAFETY: this closer owns the lifecycle transition; stop keeps the
        // lane allocated and wakes worker/wait activity before drain.
        let rc = unsafe { self.lib.file_lane_stop.unwrap()(lane) };
        let mut s = self.lifecycle.lock().unwrap();
        while s.active != 0 {
            s = self.drained.wait(s).unwrap();
        }
        // SAFETY: stop completed and active-call count reached zero, so this
        // closer owns the only remaining lane pointer and destroys it once.
        unsafe { self.lib.file_lane_destroy.unwrap()(lane) };
        s.lane = ptr::null_mut();
        self.drained.notify_all();
        if rc == 0 || rc == -7 {
            Ok(())
        } else {
            status_to_result(rc, "file_lane_stop")
        }
    }
}
impl Drop for FileLane {
    fn drop(&mut self) {
        let _ = self.close();
    }
}
fn c(value: &str) -> Result<CString> {
    CString::new(value)
        .map_err(|_| CoAkkaError::InvalidArgument("file-lane text contains NUL".into()))
}
fn snapshot(n: NativeSnapshot) -> Result<FileTransferSnapshot> {
    let direction = match n.direction {
        1 => FileTransferDirection::Send,
        2 => FileTransferDirection::Receive,
        value => return Err(invalid_snapshot_value("direction", value)),
    };
    let state = match n.state {
        1 => FileTransferState::Prepared,
        2 => FileTransferState::Queued,
        3 => FileTransferState::Connecting,
        4 => FileTransferState::Transferring,
        5 => FileTransferState::Verifying,
        6 => FileTransferState::Completed,
        7 => FileTransferState::Paused,
        8 => FileTransferState::Rejected,
        9 => FileTransferState::Failed,
        10 => FileTransferState::Canceled,
        value => return Err(invalid_snapshot_value("state", value)),
    };
    let result = match n.result {
        0 => FileTransferResult::None,
        1 => FileTransferResult::Ok,
        2 => FileTransferResult::NotPrepared,
        3 => FileTransferResult::TokenMismatch,
        4 => FileTransferResult::MetadataMismatch,
        5 => FileTransferResult::SizeLimit,
        6 => FileTransferResult::StorageIo,
        7 => FileTransferResult::IntegrityMismatch,
        8 => FileTransferResult::NetworkIo,
        9 => FileTransferResult::Timeout,
        10 => FileTransferResult::QueueFull,
        11 => FileTransferResult::ProtocolError,
        12 => FileTransferResult::SourceChanged,
        13 => FileTransferResult::InternalError,
        14 => FileTransferResult::CanceledByHost,
        15 => FileTransferResult::TlsConfigInvalid,
        16 => FileTransferResult::TlsHandshakeFailed,
        17 => FileTransferResult::PeerCertUntrusted,
        18 => FileTransferResult::PeerCertExpired,
        19 => FileTransferResult::PeerIdentityMismatch,
        20 => FileTransferResult::ClientCertRequired,
        value => return Err(invalid_snapshot_value("result", value)),
    };
    // SAFETY: the fixed C buffer is zero-initialized before the call and the
    // core preserves NUL termination within its declared bound.
    let detail = unsafe { CStr::from_ptr(n.detail.as_ptr()) }
        .to_string_lossy()
        .into_owned();
    Ok(FileTransferSnapshot {
        direction,
        state,
        result,
        expected_size: n.expected,
        transferred_bytes: n.transferred,
        committed_offset: n.committed,
        progress_milli: n.progress,
        cancel_requested: n.cancel != 0,
        update_sequence: n.sequence,
        submitted_mono_ns: n.submitted,
        started_mono_ns: n.started,
        updated_mono_ns: n.updated,
        terminal_mono_ns: n.terminal,
        detail,
    })
}

fn invalid_snapshot_value(field: &str, value: u32) -> CoAkkaError {
    CoAkkaError::Native(format!("invalid file-lane snapshot {field}: {value}"))
}
