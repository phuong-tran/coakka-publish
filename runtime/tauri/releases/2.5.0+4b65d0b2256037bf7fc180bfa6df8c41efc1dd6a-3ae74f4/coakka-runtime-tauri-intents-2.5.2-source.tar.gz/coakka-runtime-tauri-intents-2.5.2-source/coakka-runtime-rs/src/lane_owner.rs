use crate::{CoAkkaError, Result};
use std::ffi::{c_char, CStr, CString};

pub(crate) const LANE_OWNER_GRANTS_FEATURE: u32 = 1 << 25;

/// Stable identity and directly reachable host for one exact lane replica.
#[derive(Clone, Debug)]
pub struct LaneOwnerConfig {
    /// Process or pod incarnation that owns prepared lane state.
    pub owner_instance_id: String,
    /// Host that reaches this exact owner, never a load-balancing service.
    pub advertised_host: String,
}

impl LaneOwnerConfig {
    pub(crate) fn validate(&self) -> Result<()> {
        visible_ascii(&self.owner_instance_id, 127, "owner_instance_id")?;
        visible_ascii(&self.advertised_host, 255, "advertised_host")
    }
}

/// Direct endpoint of the owner retaining one prepared lane record.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct LaneOwnerEndpoint {
    /// Process or pod incarnation identity.
    pub owner_instance_id: String,
    /// Directly reachable owner host.
    pub advertised_host: String,
    /// Actual listener port selected when the lane started.
    pub port: u16,
}

impl LaneOwnerEndpoint {
    /// Reconstructs an exact owner endpoint received over a trusted control plane.
    pub fn from_control_plane(
        owner_instance_id: impl Into<String>,
        advertised_host: impl Into<String>,
        port: u16,
    ) -> Result<Self> {
        let owner_instance_id = owner_instance_id.into();
        let advertised_host = advertised_host.into();
        visible_ascii(&owner_instance_id, 127, "owner_instance_id")?;
        visible_ascii(&advertised_host, 255, "advertised_host")?;
        if port == 0 {
            return Err(CoAkkaError::InvalidArgument(
                "owner port must be non-zero".into(),
            ));
        }
        Ok(Self {
            owner_instance_id,
            advertised_host,
            port,
        })
    }
}

#[repr(C)]
pub(crate) struct NativeOwnerConfig {
    pub(crate) struct_size: usize,
    pub(crate) owner_instance_id: *const c_char,
    pub(crate) advertised_host: *const c_char,
}

#[repr(C)]
pub(crate) struct NativeOwnerEndpoint {
    pub(crate) struct_size: usize,
    pub(crate) port: u16,
    pub(crate) reserved: u16,
    pub(crate) owner_instance_id: [c_char; 128],
    pub(crate) advertised_host: [c_char; 256],
}

impl Default for NativeOwnerEndpoint {
    fn default() -> Self {
        // SAFETY: zero is the documented initialization for every scalar and
        // fixed-size character array in the native endpoint record.
        unsafe { std::mem::zeroed() }
    }
}

pub(crate) fn native_owner(
    owner: &LaneOwnerConfig,
) -> Result<(CString, CString, NativeOwnerConfig)> {
    owner.validate()?;
    let id = CString::new(owner.owner_instance_id.as_str())
        .map_err(|_| CoAkkaError::InvalidArgument("owner_instance_id contains NUL".into()))?;
    let host = CString::new(owner.advertised_host.as_str())
        .map_err(|_| CoAkkaError::InvalidArgument("advertised_host contains NUL".into()))?;
    let native = NativeOwnerConfig {
        struct_size: std::mem::size_of::<NativeOwnerConfig>(),
        owner_instance_id: id.as_ptr(),
        advertised_host: host.as_ptr(),
    };
    Ok((id, host, native))
}

pub(crate) fn endpoint(native: &NativeOwnerEndpoint) -> Result<LaneOwnerEndpoint> {
    if native.port == 0 {
        return Err(CoAkkaError::Native("owner grant returned port zero".into()));
    }
    Ok(LaneOwnerEndpoint {
        owner_instance_id: fixed(&native.owner_instance_id)?,
        advertised_host: fixed(&native.advertised_host)?,
        port: native.port,
    })
}

pub(crate) fn fixed(bytes: &[c_char]) -> Result<String> {
    // SAFETY: native fixed-size outputs are required to be NUL-terminated on
    // success and remain borrowed for this immediate copy.
    unsafe { CStr::from_ptr(bytes.as_ptr()) }
        .to_str()
        .map(str::to_owned)
        .map_err(|_| CoAkkaError::Native("owner grant returned invalid UTF-8".into()))
}

fn visible_ascii(value: &str, maximum: usize, name: &str) -> Result<()> {
    if value.is_empty()
        || value.len() > maximum
        || value.bytes().any(|byte| !(0x21..=0x7e).contains(&byte))
    {
        return Err(CoAkkaError::InvalidArgument(format!(
            "{name} must contain 1..={maximum} visible ASCII bytes"
        )));
    }
    Ok(())
}
