use std::ffi::{c_char, c_int, c_void, CString};
use std::path::Path;

#[cfg(unix)]
use std::ffi::CStr;

use crate::{CoAkkaError, Result};

pub(crate) type LibraryHandle = *mut c_void;

pub(crate) fn open_library(path: &Path) -> Result<LibraryHandle> {
    open_library_impl(path)
}

pub(crate) unsafe fn load_symbol<T>(handle: LibraryHandle, symbol: &str) -> Result<T>
where
    T: Copy,
{
    let symbol = CString::new(symbol)
        .map_err(|_| CoAkkaError::Native("native symbol contains NUL".to_string()))?;
    // SAFETY: `handle` is required by this function's contract to be an open
    // module handle, and `symbol` is a live NUL-terminated CString.
    let pointer = unsafe { load_symbol_impl(handle, symbol.as_ptr()) };
    if pointer.is_null() {
        Err(CoAkkaError::Native(format!(
            "load native symbol {} failed: {}",
            symbol.to_string_lossy(),
            loader_error()
        )))
    } else {
        if std::mem::size_of::<T>() != std::mem::size_of::<LibraryHandle>() {
            return Err(CoAkkaError::Native(format!(
                "symbol {} has unsupported pointer representation",
                symbol.to_string_lossy()
            )));
        }
        // SAFETY: callers select `T` to match the named exported function. All
        // supported CoAkka targets represent data and function pointers with
        // the same size; the assertion catches an unsupported representation.
        Ok(unsafe { std::mem::transmute_copy(&pointer) })
    }
}

pub(crate) unsafe fn close_library(handle: LibraryHandle) {
    if !handle.is_null() {
        // SAFETY: the caller guarantees this is a live handle it owns.
        unsafe { close_library_impl(handle) };
    }
}

pub(crate) fn read_fd(fd: c_int, buffer: &mut [u8]) -> Result<usize> {
    read_fd_impl(fd, buffer)
}

pub(crate) fn close_fd(fd: c_int) {
    if fd >= 0 {
        close_fd_impl(fd);
    }
}

#[cfg(unix)]
fn open_library_impl(path: &Path) -> Result<LibraryHandle> {
    use std::os::unix::ffi::OsStrExt;

    let path = CString::new(path.as_os_str().as_bytes())
        .map_err(|_| CoAkkaError::Native("runtime library path contains NUL".to_string()))?;
    // SAFETY: `path` is NUL-terminated and remains alive for the call.
    let handle = unsafe { dlopen(path.as_ptr(), RTLD_NOW | RTLD_LOCAL) };
    if handle.is_null() {
        Err(CoAkkaError::Native(format!(
            "dlopen failed: {}",
            loader_error()
        )))
    } else {
        Ok(handle)
    }
}

#[cfg(windows)]
fn open_library_impl(path: &Path) -> Result<LibraryHandle> {
    use std::os::windows::ffi::OsStrExt;

    let wide: Vec<u16> = path.as_os_str().encode_wide().chain(Some(0)).collect();
    // SAFETY: `wide` is explicitly NUL-terminated and remains alive for the call.
    let handle = unsafe { LoadLibraryW(wide.as_ptr()) };
    if handle.is_null() {
        Err(CoAkkaError::Native(format!(
            "LoadLibraryW {} failed: {}",
            path.display(),
            loader_error()
        )))
    } else {
        Ok(handle)
    }
}

#[cfg(unix)]
unsafe fn load_symbol_impl(handle: LibraryHandle, symbol: *const c_char) -> *mut c_void {
    // SAFETY: forwarded from `load_symbol`, which validates handle ownership
    // and supplies a live NUL-terminated symbol pointer.
    unsafe { dlsym(handle, symbol) }
}

#[cfg(windows)]
unsafe fn load_symbol_impl(handle: LibraryHandle, symbol: *const c_char) -> *mut c_void {
    // SAFETY: forwarded from `load_symbol`, which validates handle ownership
    // and supplies a live NUL-terminated symbol pointer.
    unsafe { GetProcAddress(handle, symbol) }
}

#[cfg(unix)]
unsafe fn close_library_impl(handle: LibraryHandle) {
    // SAFETY: forwarded from `close_library` for its live owned handle.
    let _ = unsafe { dlclose(handle) };
}

#[cfg(windows)]
unsafe fn close_library_impl(handle: LibraryHandle) {
    // SAFETY: forwarded from `close_library` for its live owned handle.
    let _ = unsafe { FreeLibrary(handle) };
}

#[cfg(unix)]
fn loader_error() -> String {
    // SAFETY: `dlerror` has no pointer arguments and returns loader-owned text.
    let pointer = unsafe { dlerror() };
    if pointer.is_null() {
        "unknown loader error".to_string()
    } else {
        // SAFETY: non-null `dlerror` results are NUL-terminated and remain
        // valid until the next loader operation on this thread.
        unsafe { CStr::from_ptr(pointer) }
            .to_string_lossy()
            .to_string()
    }
}

#[cfg(windows)]
fn loader_error() -> String {
    std::io::Error::last_os_error().to_string()
}

#[cfg(unix)]
fn read_fd_impl(fd: c_int, buffer: &mut [u8]) -> Result<usize> {
    // SAFETY: `buffer` provides writable storage for exactly `buffer.len()`
    // bytes and `fd` is only borrowed for this call.
    let result = unsafe { read(fd, buffer.as_mut_ptr().cast(), buffer.len()) };
    if result >= 0 {
        return Ok(result as usize);
    }
    let errno = last_errno();
    if errno == 4 || errno == 11 || errno == 35 {
        return Ok(0);
    }
    Err(CoAkkaError::Io(format!("read fd={fd} errno={errno}")))
}

#[cfg(windows)]
fn read_fd_impl(fd: c_int, buffer: &mut [u8]) -> Result<usize> {
    // SAFETY: `_get_osfhandle` borrows the CRT descriptor and does not close it.
    let handle = unsafe { _get_osfhandle(fd) };
    if handle == -1 {
        return Err(CoAkkaError::Io(format!(
            "_get_osfhandle fd={fd} errno={}",
            last_errno()
        )));
    }

    let mut available = 0u32;
    // SAFETY: `handle` was validated above, output pointers are either null or
    // point to initialized writable locals, and no buffer bytes are requested.
    let peeked = unsafe {
        PeekNamedPipe(
            handle as LibraryHandle,
            std::ptr::null_mut(),
            0,
            std::ptr::null_mut(),
            &mut available,
            std::ptr::null_mut(),
        )
    };
    if peeked == 0 {
        let error = std::io::Error::last_os_error();
        if error.raw_os_error() == Some(109) || error.raw_os_error() == Some(233) {
            return Ok(0);
        }
        return Err(CoAkkaError::Io(format!(
            "PeekNamedPipe fd={fd} failed: {error}"
        )));
    }
    if available == 0 {
        return Ok(0);
    }

    let count = available.min(buffer.len().min(u32::MAX as usize) as u32);
    // SAFETY: `count` is bounded by `buffer.len()` and the writable slice stays
    // alive for the synchronous CRT read.
    let result = unsafe { _read(fd, buffer.as_mut_ptr().cast(), count) };
    if result >= 0 {
        return Ok(result as usize);
    }
    let errno = last_errno();
    if errno == 4 || errno == 11 || errno == 35 {
        return Ok(0);
    }
    Err(CoAkkaError::Io(format!("_read fd={fd} errno={errno}")))
}

#[cfg(unix)]
fn close_fd_impl(fd: c_int) {
    // SAFETY: the caller transfers ownership of one non-negative descriptor.
    let _ = unsafe { close(fd) };
}

#[cfg(windows)]
fn close_fd_impl(fd: c_int) {
    // SAFETY: the caller transfers ownership of one non-negative CRT descriptor.
    let _ = unsafe { _close(fd) };
}

#[cfg(target_os = "linux")]
fn last_errno() -> c_int {
    // SAFETY: libc returns a valid thread-local errno pointer.
    unsafe { *__errno_location() }
}

#[cfg(target_os = "macos")]
fn last_errno() -> c_int {
    // SAFETY: libc returns a valid thread-local errno pointer.
    unsafe { *__error() }
}

#[cfg(windows)]
fn last_errno() -> c_int {
    let mut errno = -1;
    // SAFETY: the output pointer targets a live writable integer.
    let status = unsafe { _get_errno(&mut errno) };
    if status == 0 {
        errno
    } else {
        -1
    }
}

#[cfg(target_os = "linux")]
const RTLD_LOCAL: c_int = 0;
#[cfg(target_os = "macos")]
const RTLD_LOCAL: c_int = 4;
#[cfg(unix)]
const RTLD_NOW: c_int = 2;

#[cfg(target_os = "linux")]
#[link(name = "dl")]
extern "C" {
    fn dlopen(filename: *const c_char, flags: c_int) -> LibraryHandle;
    fn dlsym(handle: LibraryHandle, symbol: *const c_char) -> *mut c_void;
    fn dlclose(handle: LibraryHandle) -> c_int;
    fn dlerror() -> *const c_char;
    fn read(fd: c_int, buf: *mut c_void, count: usize) -> isize;
    fn close(fd: c_int) -> c_int;
    fn __errno_location() -> *mut c_int;
}

#[cfg(target_os = "macos")]
extern "C" {
    fn dlopen(filename: *const c_char, flags: c_int) -> LibraryHandle;
    fn dlsym(handle: LibraryHandle, symbol: *const c_char) -> *mut c_void;
    fn dlclose(handle: LibraryHandle) -> c_int;
    fn dlerror() -> *const c_char;
    fn read(fd: c_int, buf: *mut c_void, count: usize) -> isize;
    fn close(fd: c_int) -> c_int;
    fn __error() -> *mut c_int;
}

#[cfg(windows)]
#[link(name = "kernel32")]
extern "system" {
    fn LoadLibraryW(filename: *const u16) -> LibraryHandle;
    fn GetProcAddress(handle: LibraryHandle, symbol: *const c_char) -> *mut c_void;
    fn FreeLibrary(handle: LibraryHandle) -> c_int;
    fn PeekNamedPipe(
        named_pipe: LibraryHandle,
        buffer: *mut c_void,
        buffer_size: u32,
        bytes_read: *mut u32,
        total_bytes_available: *mut u32,
        bytes_left_this_message: *mut u32,
    ) -> c_int;
}

#[cfg(windows)]
#[link(name = "ucrt")]
extern "C" {
    fn _read(fd: c_int, buffer: *mut c_void, count: u32) -> c_int;
    fn _close(fd: c_int) -> c_int;
    fn _get_errno(out_errno: *mut c_int) -> c_int;
    fn _get_osfhandle(fd: c_int) -> isize;
}
