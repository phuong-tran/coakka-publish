//! Ordered bounded streaming through the CoAkka core runtime.
//!
//! Callback buffers are borrowed for one call. CoAkka transports bytes and
//! neutral pressure observations; application format and adaptation policy stay
//! in the app-host.

use crate::lane_owner::{endpoint, fixed, native_owner, NativeOwnerConfig, NativeOwnerEndpoint};
use crate::{
    status_to_result, CoAkkaError, LaneOwnerConfig, LaneOwnerEndpoint, NativeLibrary, Result,
    RuntimeLibraryResolver,
};
use std::collections::HashMap;
use std::ffi::{c_char, c_int, c_void, CStr, CString};
use std::fmt;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::ptr;
use std::sync::{Condvar, Mutex};

/// Enables prepared publishers and a listener.
pub const STREAM_LANE_PUBLISHER: u32 = 1;
/// Enables queued outbound subscribers.
pub const STREAM_LANE_SUBSCRIBER: u32 = 1 << 1;
/// Keyframe annotation supplied by the app-host.
pub const STREAM_FRAME_KEYFRAME: u32 = 1;
/// Source discontinuity annotation supplied by the app-host.
pub const STREAM_FRAME_DISCONTINUITY: u32 = 1 << 1;
/// Logical end-of-segment annotation supplied by the app-host.
pub const STREAM_FRAME_END_OF_SEGMENT: u32 = 1 << 2;
/// Publisher is waiting for receive credit.
pub const STREAM_PRESSURE_CREDIT_WAIT: u32 = 1;
/// Transport write exceeded the configured pressure threshold.
pub const STREAM_PRESSURE_TRANSPORT_WRITE: u32 = 1 << 1;
/// Consumer callback exceeded the configured pressure threshold.
pub const STREAM_PRESSURE_CONSUMER_BUSY: u32 = 1 << 2;
/// Transport read exceeded the configured pressure threshold.
pub const STREAM_PRESSURE_TRANSPORT_READ: u32 = 1 << 3;

#[repr(u32)]
#[derive(Clone, Copy, Debug)]
/// Transport protection; per-session authorization remains mandatory.
pub enum StreamLaneSecurityMode {
    /// Unencrypted transport inside a protected deployment network.
    Direct = 0,
    /// Server-authenticated encrypted transport.
    Tls = 1,
    /// Mutually authenticated encrypted transport.
    MutualTls = 2,
}

#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
/// Side of a retained session used by observation and lifecycle calls.
pub enum StreamDirection {
    /// Source/publisher record.
    Publish = 1,
    /// Consumer/subscriber record.
    Subscribe = 2,
}

#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
/// Observable lifecycle state for one stream-session side.
pub enum StreamState {
    /// Publisher authorization is prepared.
    Prepared = 1,
    /// Subscriber job is admitted and waiting for a worker.
    Queued = 2,
    /// Subscriber is establishing transport.
    Connecting = 3,
    /// Frames may be produced or consumed.
    Active = 4,
    /// Cooperative stop is in progress.
    Stopping = 5,
    /// Source or consumer ended normally.
    Ended = 6,
    /// Peer authorization or stream contract rejected the session.
    Rejected = 7,
    /// Session ended with an operational failure.
    Failed = 8,
    /// Host cancellation reached terminal state.
    Canceled = 9,
}

#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
/// Stable terminal outcome reported independently by each peer.
pub enum StreamResult {
    /// No terminal result yet.
    None = 0,
    /// Session ended successfully.
    Ok = 1,
    /// Publisher was not prepared for this id.
    NotPrepared = 2,
    /// Authorization token did not match.
    TokenMismatch = 3,
    /// Opaque application format ids did not match.
    FormatMismatch = 4,
    /// A frame exceeded the negotiated bound.
    FrameLimit = 5,
    /// Network delivery failed.
    NetworkIo = 6,
    /// Connect or I/O budget expired.
    Timeout = 7,
    /// Bounded admission queue was full.
    QueueFull = 8,
    /// Peer violated the Stream Lane wire contract.
    ProtocolError = 9,
    /// Publisher callback reported failure or invalid output.
    SourceError = 10,
    /// Consumer callback reported failure.
    ConsumerError = 11,
    /// Internal invariant or resource operation failed.
    InternalError = 12,
    /// App-host requested cancellation.
    CanceledByHost = 13,
    /// TLS/mTLS material or configuration was invalid.
    TlsConfigInvalid = 14,
    /// TLS/mTLS session establishment failed.
    TlsHandshakeFailed = 15,
    /// Peer certificate chain is not trusted.
    PeerCertUntrusted = 16,
    /// Peer certificate is outside its validity period.
    PeerCertExpired = 17,
    /// Peer certificate identity does not match the endpoint.
    PeerIdentityMismatch = 18,
    /// Mutual TLS peer did not present a required client certificate.
    ClientCertRequired = 19,
}

#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
/// Coalesced neutral pressure state consumed by app-host policy.
pub enum StreamPressureState {
    /// No active delivery observation exists.
    Inactive = 0,
    /// Delivery is advancing without sustained pressure.
    Flowing = 1,
    /// A configured pressure threshold has been exceeded.
    Pressured = 2,
    /// Lack of progress exceeded the stall threshold.
    Stalled = 3,
    /// Delivery resumed but has not yet satisfied the recovery interval.
    Recovering = 4,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
/// Subscriber action after one borrowed frame has been consumed.
pub enum StreamConsumerDecision {
    /// Accept the frame and continue the session.
    Continue,
    /// End this subscriber cleanly after the frame.
    Stop,
}

#[derive(Clone, Copy, Debug)]
/// Result returned by a bounded publisher callback.
pub enum StreamSourceResult {
    /// `size` bytes were written into the borrowed destination.
    Frame {
        /// Bytes initialized in the borrowed destination, in `1..=capacity`.
        size: usize,
        /// Source capture time from a process-local monotonic clock, or zero.
        captured_mono_ns: u64,
        /// Frames discarded by the source before this frame.
        dropped_before: u64,
        /// Application annotations such as keyframe or discontinuity.
        flags: u32,
    },
    /// No frame is ready; native retries after its bounded delay.
    WouldBlock,
    /// The source ended normally.
    End,
}

/// Bounded publisher callback. The mutable slice is borrowed for one call.
pub type StreamSource = Box<dyn FnMut(&mut [u8]) -> StreamSourceResult + Send + 'static>;

#[derive(Clone, Copy, Debug)]
/// Immutable metadata paired with one subscriber frame.
pub struct StreamFrameMetadata {
    /// Lane-assigned sequence, increasing by one for delivered frames.
    pub sequence: u64,
    /// Source capture time from its process-local monotonic clock, or zero.
    pub captured_mono_ns: u64,
    /// Source-reported drops before this frame.
    pub dropped_before: u64,
    /// Opaque application frame annotations.
    pub flags: u32,
}

/// Bounded subscriber callback. The byte slice is borrowed for one call.
pub type StreamConsumer =
    Box<dyn FnMut(&[u8], StreamFrameMetadata) -> StreamConsumerDecision + Send + 'static>;

#[derive(Clone, Debug)]
/// TLS material copied at startup. Never log key paths or session tokens.
pub struct StreamLaneSecurityConfig {
    /// Selected protection mode.
    pub mode: StreamLaneSecurityMode,
    /// App-host credential generation used for diagnostics.
    pub credential_generation: u64,
    /// Non-secret credential identity.
    pub credential_id: String,
    /// Trust-anchor bundle path.
    pub ca_certificate_file: String,
    /// Local certificate-chain path.
    pub identity_certificate_file: String,
    /// Local private-key path.
    pub private_key_file: String,
}

#[derive(Clone, Debug)]
/// Bounded stream settings. Zero tuning values select core-runtime defaults.
pub struct StreamLaneConfig {
    /// Enabled publisher/subscriber role bits.
    pub flags: u32,
    /// Publisher bind address copied during open.
    pub bind_host: String,
    /// Publisher port; zero requests an ephemeral port.
    pub bind_port: u16,
    /// Bounded retained/queued session capacity; zero selects the default.
    pub capacity: usize,
    /// Per-frame byte limit; zero selects the default.
    pub max_frame_bytes: u32,
    /// Maximum receive-credit window in bytes; zero selects the default.
    pub max_window_bytes: u32,
    /// Connect and I/O timeout in milliseconds; zero selects the default.
    pub io_timeout_ms: u32,
    /// Delay before retrying `WouldBlock`, in milliseconds; zero selects default.
    pub source_retry_ms: u32,
    /// Session update interval in frames; zero selects the default.
    pub progress_frames: u32,
    /// Session update interval in milliseconds; zero selects the default.
    pub progress_interval_ms: u32,
    /// Publisher worker count in 1..=4; zero selects one.
    pub publisher_worker_count: u32,
    /// Subscriber worker count in 1..=4; zero selects one.
    pub subscriber_worker_count: u32,
    /// Optional immutable transport protection settings.
    pub security: Option<StreamLaneSecurityConfig>,
    /// Sustained-operation pressure threshold in milliseconds.
    pub pressure_after_ms: u32,
    /// No-progress stall threshold in milliseconds.
    pub stalled_after_ms: u32,
    /// Stable-progress recovery interval in milliseconds.
    pub recovery_after_ms: u32,
    /// Minimum coalesced pressure publication interval in milliseconds.
    pub pressure_observation_ms: u32,
}

impl Default for StreamLaneConfig {
    fn default() -> Self {
        Self {
            flags: STREAM_LANE_PUBLISHER | STREAM_LANE_SUBSCRIBER,
            bind_host: "127.0.0.1".into(),
            bind_port: 0,
            capacity: 0,
            max_frame_bytes: 0,
            max_window_bytes: 0,
            io_timeout_ms: 0,
            source_retry_ms: 0,
            progress_frames: 0,
            progress_interval_ms: 0,
            publisher_worker_count: 0,
            subscriber_worker_count: 0,
            security: None,
            pressure_after_ms: 0,
            stalled_after_ms: 0,
            recovery_after_ms: 0,
            pressure_observation_ms: 0,
        }
    }
}

/// Service B authorization, opaque format contract, frame bound, and source.
pub struct StreamPublishSpec {
    /// Stable session id, unique among retained publisher records.
    pub session_id: String,
    /// Opaque per-session authorization secret.
    pub authorization_token: String,
    /// Non-zero opaque application format identity.
    pub format_id: u64,
    /// Per-session frame bound not exceeding the lane bound.
    pub max_frame_bytes: u32,
    /// Bounded callback retained until forget or lane close.
    pub source: StreamSource,
}

/// Service A endpoint, authorization, flow-control window, and consumer.
pub struct StreamSubscribeSpec {
    /// Stable id matching a prepared publisher record.
    pub session_id: String,
    /// Opaque authorization secret matching publisher state.
    pub authorization_token: String,
    /// Publisher host name or numeric address.
    pub remote_host: String,
    /// Non-zero publisher port.
    pub remote_port: u16,
    /// Non-zero opaque application format identity.
    pub format_id: u64,
    /// Per-session frame bound not exceeding the lane bound.
    pub max_frame_bytes: u32,
    /// Initial receive credit in bytes; must cover at least one frame.
    pub initial_window_bytes: u32,
    /// Per-job connect/I/O timeout in milliseconds; zero selects lane default.
    pub timeout_ms: u32,
    /// Bounded callback retained until forget or lane close.
    pub consumer: StreamConsumer,
}

/// Single-admission publisher capability pinned to one exact replica.
pub struct StreamPublishGrant {
    /// Exact publisher owner endpoint.
    pub owner: LaneOwnerEndpoint,
    /// Prepared session identity.
    pub session_id: String,
    authorization_token: String,
    /// Opaque application format identity.
    pub format_id: u64,
    /// Negotiated maximum frame size.
    pub max_frame_bytes: u32,
}
impl StreamPublishGrant {
    /// Reconstructs a grant received over the application's trusted control plane.
    pub fn from_control_plane(
        owner: LaneOwnerEndpoint,
        session_id: impl Into<String>,
        authorization_token: impl Into<String>,
        format_id: u64,
        max_frame_bytes: u32,
    ) -> Result<Self> {
        let session_id = session_id.into();
        let authorization_token = authorization_token.into();
        if session_id.is_empty()
            || authorization_token.is_empty()
            || format_id == 0
            || max_frame_bytes == 0
        {
            return Err(CoAkkaError::InvalidArgument(
                "session id, token, format id, and frame bound must be non-zero".into(),
            ));
        }
        Ok(Self {
            owner,
            session_id,
            authorization_token,
            format_id,
            max_frame_bytes,
        })
    }

    /// Returns the bearer token for trusted control-plane transport.
    pub fn authorization_token(&self) -> &str {
        &self.authorization_token
    }
    /// Builds a subscriber job using this exact owner endpoint.
    pub fn to_subscribe_spec(
        &self,
        initial_window_bytes: u32,
        timeout_ms: u32,
        consumer: StreamConsumer,
    ) -> StreamSubscribeSpec {
        StreamSubscribeSpec {
            session_id: self.session_id.clone(),
            authorization_token: self.authorization_token.clone(),
            remote_host: self.owner.advertised_host.clone(),
            remote_port: self.owner.port,
            format_id: self.format_id,
            max_frame_bytes: self.max_frame_bytes,
            initial_window_bytes,
            timeout_ms,
            consumer,
        }
    }
}
impl fmt::Debug for StreamPublishGrant {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("StreamPublishGrant")
            .field("owner", &self.owner)
            .field("session_id", &self.session_id)
            .field("authorization_token", &"<redacted>")
            .field("format_id", &self.format_id)
            .field("max_frame_bytes", &self.max_frame_bytes)
            .finish()
    }
}

#[derive(Clone, Debug)]
/// Copied session progress with process-local monotonic timestamps.
pub struct StreamSessionSnapshot {
    /// Publisher or subscriber projection.
    pub direction: StreamDirection,
    /// Current lifecycle state.
    pub state: StreamState,
    /// Terminal result, or `None` before terminal state.
    pub result: StreamResult,
    /// Negotiated opaque application format identity.
    pub format_id: u64,
    /// Cumulative frames produced or consumed by this record.
    pub frames: u64,
    /// Cumulative frame bytes produced or consumed by this record.
    pub bytes: u64,
    /// Cumulative source-reported dropped frames.
    pub dropped_frames: u64,
    /// Most recent lane-assigned sequence, or zero before the first frame.
    pub last_sequence: u64,
    /// Negotiated per-frame byte bound.
    pub negotiated_max_frame_bytes: u32,
    /// Negotiated receive-credit window in bytes.
    pub window_bytes: u32,
    /// Whether the app-host requested cancellation.
    pub cancel_requested: bool,
    /// Monotonic record update cursor used by `wait_session`.
    pub update_sequence: u64,
    /// Process-local monotonic submission timestamp in nanoseconds.
    pub submitted_mono_ns: u64,
    /// Process-local monotonic work-start timestamp in nanoseconds.
    pub started_mono_ns: u64,
    /// Process-local monotonic latest-update timestamp in nanoseconds.
    pub updated_mono_ns: u64,
    /// Process-local monotonic terminal timestamp, or zero before terminal state.
    pub terminal_mono_ns: u64,
    /// Bounded diagnostic detail; never use it as a stable programmatic code.
    pub detail: String,
}

impl StreamSessionSnapshot {
    /// Returns whether this session side reached a terminal state.
    pub fn terminal(&self) -> bool {
        self.state >= StreamState::Ended
    }

    /// Returns whether this session side ended normally.
    pub fn succeeded(&self) -> bool {
        self.state == StreamState::Ended && self.result == StreamResult::Ok
    }
}

#[derive(Clone, Debug)]
/// Copied transport-pressure observation for app-host policy.
pub struct StreamPressureSnapshot {
    /// Publisher or subscriber observation.
    pub direction: StreamDirection,
    /// Coalesced neutral delivery state.
    pub state: StreamPressureState,
    /// Combined `STREAM_PRESSURE_*` reason bits.
    pub reason_bits: u32,
    /// Current sender credit in bytes.
    pub available_credit_bytes: u32,
    /// Negotiated credit-window capacity in bytes.
    pub window_capacity_bytes: u32,
    /// Monotonic pressure update cursor used by `wait_pressure`.
    pub update_sequence: u64,
    /// Cumulative pressure-state transitions.
    pub transition_count: u64,
    /// Process-local monotonic observation timestamp in nanoseconds.
    pub observed_mono_ns: u64,
    /// Process-local monotonic start of the current state.
    pub state_started_mono_ns: u64,
    /// Process-local monotonic start of current pressure history, or zero.
    pub pressure_started_mono_ns: u64,
    /// Process-local monotonic timestamp of latest delivery progress.
    pub last_progress_mono_ns: u64,
    /// Observed delivery throughput in bytes per second.
    pub observed_delivery_bps: u64,
    /// Duration in nanoseconds of the operation currently being observed.
    pub current_operation_ns: u64,
    /// Duration in nanoseconds of the most recently completed operation.
    pub last_operation_ns: u64,
    /// Cumulative duration spent pressured, in nanoseconds.
    pub total_pressured_ns: u64,
    /// Longest continuous pressured duration in nanoseconds.
    pub max_pressured_ns: u64,
}

#[derive(Clone, Debug)]
/// Bounded queue, active-session, terminal, frame, byte, and drop counters.
pub struct StreamLaneStats {
    /// Configured admission/retention bound.
    pub capacity: usize,
    /// Subscriber jobs waiting for workers.
    pub queued_subscribers: usize,
    /// Prepared publisher authorizations not yet forgotten.
    pub prepared_publishers: usize,
    /// Publisher sessions currently active.
    pub active_publishers: usize,
    /// Subscriber sessions currently active.
    pub active_subscribers: usize,
    /// Terminal and prepared records retained for observation.
    pub retained_records: usize,
    /// Cumulative admitted subscriber jobs.
    pub submitted_subscribers: u64,
    /// Cumulative prepared publisher authorizations.
    pub prepared_publisher_count: u64,
    /// Cumulative publishers which ended normally.
    pub ended_publishers: u64,
    /// Cumulative subscribers which ended normally.
    pub ended_subscribers: u64,
    /// Cumulative failed/rejected publishers, excluding cancellation.
    pub failed_publishers: u64,
    /// Cumulative failed/rejected subscribers, excluding cancellation.
    pub failed_subscribers: u64,
    /// Cumulative host-canceled records.
    pub canceled_sessions: u64,
    /// Cumulative frames accepted from sources.
    pub published_frames: u64,
    /// Cumulative bytes accepted from sources.
    pub published_bytes: u64,
    /// Cumulative frames delivered to consumers.
    pub consumed_frames: u64,
    /// Cumulative bytes delivered to consumers.
    pub consumed_bytes: u64,
    /// Cumulative drops reported by sources.
    pub source_reported_drops: u64,
}

#[repr(C)]
#[derive(Default)]
pub(crate) struct NativeStreamFrame {
    struct_size: usize,
    sequence: u64,
    captured_mono_ns: u64,
    dropped_before: u64,
    flags: u32,
    size: usize,
}

#[repr(C)]
pub(crate) struct NativeStreamSecurity {
    struct_size: usize,
    mode: u32,
    reserved: u32,
    generation: u64,
    id: *const c_char,
    ca: *const c_char,
    cert: *const c_char,
    key: *const c_char,
}

#[repr(C)]
pub(crate) struct NativeStreamConfig {
    struct_size: usize,
    flags: u32,
    bind_host: *const c_char,
    bind_port: u16,
    capacity: usize,
    max_frame_bytes: u32,
    max_window_bytes: u32,
    io_timeout_ms: u32,
    source_retry_ms: u32,
    progress_frames: u32,
    progress_interval_ms: u32,
    publisher_workers: u32,
    subscriber_workers: u32,
    security: *const NativeStreamSecurity,
    pressure_after_ms: u32,
    stalled_after_ms: u32,
    recovery_after_ms: u32,
    pressure_observation_ms: u32,
}
#[repr(C)]
pub(crate) struct NativeStreamOwnedConfig {
    struct_size: usize,
    lane: NativeStreamConfig,
    owner: NativeOwnerConfig,
}

pub(crate) type SourceNextFn =
    unsafe extern "C" fn(*mut c_void, *mut u8, usize, *mut NativeStreamFrame) -> c_int;
pub(crate) type ConsumerFn =
    unsafe extern "C" fn(*mut c_void, *const u8, *const NativeStreamFrame) -> c_int;

#[repr(C)]
pub(crate) struct NativePublishSpec {
    struct_size: usize,
    id: *const c_char,
    token: *const c_char,
    format_id: u64,
    max_frame_bytes: u32,
    source_next: Option<SourceNextFn>,
    source_context: *mut c_void,
}
#[repr(C)]
pub(crate) struct NativePublishGrant {
    struct_size: usize,
    owner: NativeOwnerEndpoint,
    session_id: [c_char; 65],
    authorization_token: [c_char; 129],
    format_id: u64,
    max_frame_bytes: u32,
    reserved: u32,
}
impl Default for NativePublishGrant {
    fn default() -> Self {
        // SAFETY: zero is valid output initialization for the complete grant.
        unsafe { std::mem::zeroed() }
    }
}

#[repr(C)]
pub(crate) struct NativeSubscribeSpec {
    struct_size: usize,
    id: *const c_char,
    token: *const c_char,
    host: *const c_char,
    port: u16,
    format_id: u64,
    max_frame_bytes: u32,
    initial_window_bytes: u32,
    timeout_ms: u32,
    consume: Option<ConsumerFn>,
    consumer_context: *mut c_void,
}

#[repr(C)]
pub(crate) struct NativeSessionSnapshot {
    struct_size: usize,
    direction: u32,
    state: u32,
    result: u32,
    format_id: u64,
    frames: u64,
    bytes: u64,
    dropped_frames: u64,
    last_sequence: u64,
    max_frame_bytes: u32,
    window_bytes: u32,
    cancel_requested: u32,
    update_sequence: u64,
    submitted_mono_ns: u64,
    started_mono_ns: u64,
    updated_mono_ns: u64,
    terminal_mono_ns: u64,
    detail: [c_char; 160],
}

impl Default for NativeSessionSnapshot {
    fn default() -> Self {
        // SAFETY: the matching C record defines zero as valid initialization
        // for every scalar and fixed-size character buffer.
        unsafe { std::mem::zeroed() }
    }
}

#[repr(C)]
#[derive(Default)]
pub(crate) struct NativePressureSnapshot {
    struct_size: usize,
    direction: u32,
    state: u32,
    reason_bits: u32,
    available_credit_bytes: u32,
    window_capacity_bytes: u32,
    update_sequence: u64,
    transition_count: u64,
    observed_mono_ns: u64,
    state_started_mono_ns: u64,
    pressure_started_mono_ns: u64,
    last_progress_mono_ns: u64,
    observed_delivery_bps: u64,
    current_operation_ns: u64,
    last_operation_ns: u64,
    total_pressured_ns: u64,
    max_pressured_ns: u64,
}

#[repr(C)]
#[derive(Default)]
pub(crate) struct NativeStreamStats {
    struct_size: usize,
    capacity: usize,
    queued_subscribers: usize,
    prepared_publishers: usize,
    active_publishers: usize,
    active_subscribers: usize,
    retained_records: usize,
    submitted_subscribers: u64,
    prepared_publisher_count: u64,
    ended_publishers: u64,
    ended_subscribers: u64,
    failed_publishers: u64,
    failed_subscribers: u64,
    canceled_sessions: u64,
    published_frames: u64,
    published_bytes: u64,
    consumed_frames: u64,
    consumed_bytes: u64,
    source_reported_drops: u64,
}

pub(crate) type StreamLaneCreateFn =
    unsafe extern "C" fn(*const NativeStreamConfig, *mut *mut c_void) -> c_int;
pub(crate) type StreamLaneCreateOwnedFn =
    unsafe extern "C" fn(*const NativeStreamOwnedConfig, *mut *mut c_void) -> c_int;
pub(crate) type StreamLaneDestroyFn = unsafe extern "C" fn(*mut c_void);
pub(crate) type StreamLaneStartFn = unsafe extern "C" fn(*mut c_void) -> c_int;
pub(crate) type StreamLaneStopFn = unsafe extern "C" fn(*mut c_void) -> c_int;
pub(crate) type StreamLaneGetBoundPortFn = unsafe extern "C" fn(*mut c_void, *mut u16) -> c_int;
pub(crate) type StreamLanePreparePublishFn =
    unsafe extern "C" fn(*mut c_void, *const NativePublishSpec) -> c_int;
pub(crate) type StreamLanePreparePublishGrantFn =
    unsafe extern "C" fn(*mut c_void, *const NativePublishSpec, *mut NativePublishGrant) -> c_int;
pub(crate) type StreamLaneSubscribeFn =
    unsafe extern "C" fn(*mut c_void, *const NativeSubscribeSpec) -> c_int;
pub(crate) type StreamLaneGetSessionFn =
    unsafe extern "C" fn(*mut c_void, *const c_char, u32, *mut NativeSessionSnapshot) -> c_int;
pub(crate) type StreamLaneWaitSessionFn = unsafe extern "C" fn(
    *mut c_void,
    *const c_char,
    u32,
    u64,
    u32,
    *mut NativeSessionSnapshot,
) -> c_int;
pub(crate) type StreamLaneGetPressureFn =
    unsafe extern "C" fn(*mut c_void, *const c_char, u32, *mut NativePressureSnapshot) -> c_int;
pub(crate) type StreamLaneWaitPressureFn = unsafe extern "C" fn(
    *mut c_void,
    *const c_char,
    u32,
    u64,
    u32,
    *mut NativePressureSnapshot,
) -> c_int;
pub(crate) type StreamLaneControlFn =
    unsafe extern "C" fn(*mut c_void, *const c_char, u32) -> c_int;
pub(crate) type StreamLaneGetStatsFn =
    unsafe extern "C" fn(*mut c_void, *mut NativeStreamStats) -> c_int;

struct SourceHolder(Mutex<StreamSource>);
struct ConsumerHolder(Mutex<StreamConsumer>);

enum CallbackRoot {
    Source(*mut SourceHolder),
    Consumer(*mut ConsumerHolder),
}

// SAFETY: each pointer originates from `Box::into_raw`, is accessed only by a
// worker through its holder mutex, and is reclaimed exactly once after the
// lane releases the callback reference.
unsafe impl Send for CallbackRoot {}

impl Drop for CallbackRoot {
    fn drop(&mut self) {
        // SAFETY: ownership of each pointer was transferred into this enum by
        // `Box::into_raw`; successful insertion creates exactly one root and
        // removal/drop occurs only after the lane stops invoking the callback.
        unsafe {
            match self {
                Self::Source(pointer) => drop(Box::from_raw(*pointer)),
                Self::Consumer(pointer) => drop(Box::from_raw(*pointer)),
            }
        }
    }
}

unsafe extern "C" fn source_trampoline(
    context: *mut c_void,
    destination: *mut u8,
    capacity: usize,
    out_frame: *mut NativeStreamFrame,
) -> c_int {
    if context.is_null() || destination.is_null() || out_frame.is_null() {
        return -1;
    }
    catch_unwind(AssertUnwindSafe(|| {
        // SAFETY: prepare_publish supplies a live `SourceHolder` box as this
        // context and retains its root until callback execution has drained.
        let holder = unsafe { &*(context.cast::<SourceHolder>()) };
        let mut source = match holder.0.lock() {
            Ok(value) => value,
            Err(_) => return -5,
        };
        // SAFETY: the callback contract supplies writable runtime-owned storage
        // for `capacity` bytes, borrowed exclusively for this invocation.
        let destination = unsafe { std::slice::from_raw_parts_mut(destination, capacity) };
        // SAFETY: null was rejected and the callback contract supplies one
        // writable frame record for this invocation.
        let out_frame = unsafe { &mut *out_frame };
        match source(destination) {
            StreamSourceResult::WouldBlock => -6,
            StreamSourceResult::End => -7,
            StreamSourceResult::Frame {
                size,
                captured_mono_ns,
                dropped_before,
                flags,
            } if size > 0 && size <= capacity => {
                out_frame.captured_mono_ns = captured_mono_ns;
                out_frame.dropped_before = dropped_before;
                out_frame.flags = flags;
                out_frame.size = size;
                0
            }
            StreamSourceResult::Frame { .. } => -1,
        }
    }))
    .unwrap_or(-5)
}

unsafe extern "C" fn consumer_trampoline(
    context: *mut c_void,
    data: *const u8,
    frame: *const NativeStreamFrame,
) -> c_int {
    if context.is_null() || data.is_null() || frame.is_null() {
        return -1;
    }
    // SAFETY: null was rejected and the callback contract supplies a readable
    // frame record for the duration of this invocation.
    let frame = unsafe { &*frame };
    if frame.size == 0 {
        return -1;
    }
    catch_unwind(AssertUnwindSafe(|| {
        // SAFETY: subscribe supplies a live `ConsumerHolder` box as this
        // context and retains its root until callback execution has drained.
        let holder = unsafe { &*(context.cast::<ConsumerHolder>()) };
        let mut consumer = match holder.0.lock() {
            Ok(value) => value,
            Err(_) => return -5,
        };
        // SAFETY: the callback contract supplies `frame.size` readable bytes
        // at `data`, borrowed only for this invocation.
        let bytes = unsafe { std::slice::from_raw_parts(data, frame.size) };
        let metadata = StreamFrameMetadata {
            sequence: frame.sequence,
            captured_mono_ns: frame.captured_mono_ns,
            dropped_before: frame.dropped_before,
            flags: frame.flags,
        };
        match consumer(bytes, metadata) {
            StreamConsumerDecision::Continue => 0,
            StreamConsumerDecision::Stop => -7,
        }
    }))
    .unwrap_or(-5)
}

struct Lifecycle {
    lane: *mut c_void,
    closing: bool,
    active: usize,
}

// SAFETY: the raw lane pointer is accessed only while protected by the
// lifecycle mutex. Active-call counting prevents destroy until all borrowers
// have returned.
unsafe impl Send for Lifecycle {}

/// Independent Stream Lane with synchronized callback and close ownership.
pub struct StreamLane {
    lib: NativeLibrary,
    lifecycle: Mutex<Lifecycle>,
    callbacks: Mutex<HashMap<(String, StreamDirection), CallbackRoot>>,
    drained: Condvar,
    prepare_publish_grant: Option<StreamLanePreparePublishGrantFn>,
}

// SAFETY: all mutable lifecycle and callback-root state is mutex-protected;
// the core lane accepts concurrent observations/control until coordinated stop.
unsafe impl Send for StreamLane {}
// SAFETY: shared calls take a lifecycle borrow and close waits for all such
// borrows before destroying the lane or callback roots.
unsafe impl Sync for StreamLane {}

impl StreamLane {
    /// Opens and starts a lane.
    ///
    /// `config` supplies bounded capabilities, workers, security, flow-control,
    /// and pressure settings. `runtime_path` selects an explicit core runtime;
    /// an empty value enables packaged resolution.
    pub fn open(config: StreamLaneConfig, runtime_path: impl AsRef<str>) -> Result<Self> {
        Self::open_internal(config, None, runtime_path.as_ref())
    }

    /// Opens a lane that can issue replica-pinned publish grants.
    pub fn open_owned(
        config: StreamLaneConfig,
        owner: LaneOwnerConfig,
        runtime_path: impl AsRef<str>,
    ) -> Result<Self> {
        owner.validate()?;
        Self::open_internal(config, Some(owner), runtime_path.as_ref())
    }

    fn open_internal(
        config: StreamLaneConfig,
        owner: Option<LaneOwnerConfig>,
        runtime_path: &str,
    ) -> Result<Self> {
        if config.flags == 0
            || config.flags & !(STREAM_LANE_PUBLISHER | STREAM_LANE_SUBSCRIBER) != 0
            || config.capacity > 64
            || config.max_frame_bytes > 4 * 1024 * 1024
            || config.max_window_bytes > 16 * 1024 * 1024
            || config.source_retry_ms > 1000
            || config.publisher_worker_count > 4
            || config.subscriber_worker_count > 4
            || [
                config.pressure_after_ms,
                config.stalled_after_ms,
                config.recovery_after_ms,
                config.pressure_observation_ms,
            ]
            .into_iter()
            .any(|value| value > 60_000)
            || (config.max_frame_bytes != 0
                && config.max_window_bytes != 0
                && config.max_window_bytes < config.max_frame_bytes)
        {
            return Err(CoAkkaError::InvalidArgument(
                "invalid stream-lane bounds or worker count".into(),
            ));
        }
        let lib = NativeLibrary::open(&RuntimeLibraryResolver::resolve(runtime_path)?)?;
        if !lib.has_stream_lane() {
            return Err(CoAkkaError::Native(
                "native runtime does not export the complete stream-lane ABI".into(),
            ));
        }
        let bind = c(&config.bind_host)?;
        let security_strings = config
            .security
            .as_ref()
            .map(|security| {
                Ok::<_, CoAkkaError>((
                    c(&security.credential_id)?,
                    c(&security.ca_certificate_file)?,
                    c(&security.identity_certificate_file)?,
                    c(&security.private_key_file)?,
                ))
            })
            .transpose()?;
        let native_security =
            config
                .security
                .as_ref()
                .zip(security_strings.as_ref())
                .map(|(security, strings)| NativeStreamSecurity {
                    struct_size: std::mem::size_of::<NativeStreamSecurity>(),
                    mode: security.mode as u32,
                    reserved: 0,
                    generation: security.credential_generation,
                    id: strings.0.as_ptr(),
                    ca: strings.1.as_ptr(),
                    cert: strings.2.as_ptr(),
                    key: strings.3.as_ptr(),
                });
        let native = NativeStreamConfig {
            struct_size: std::mem::size_of::<NativeStreamConfig>(),
            flags: config.flags,
            bind_host: bind.as_ptr(),
            bind_port: config.bind_port,
            capacity: config.capacity,
            max_frame_bytes: config.max_frame_bytes,
            max_window_bytes: config.max_window_bytes,
            io_timeout_ms: config.io_timeout_ms,
            source_retry_ms: config.source_retry_ms,
            progress_frames: config.progress_frames,
            progress_interval_ms: config.progress_interval_ms,
            publisher_workers: config.publisher_worker_count,
            subscriber_workers: config.subscriber_worker_count,
            security: native_security.as_ref().map_or(ptr::null(), |value| value),
            pressure_after_ms: config.pressure_after_ms,
            stalled_after_ms: config.stalled_after_ms,
            recovery_after_ms: config.recovery_after_ms,
            pressure_observation_ms: config.pressure_observation_ms,
        };
        let mut lane = ptr::null_mut();
        let prepare_publish_grant = if owner.is_some() {
            Some(lib.load_additive::<StreamLanePreparePublishGrantFn>(
                "coakka_v2_stream_lane_prepare_publish_grant",
            )?)
        } else {
            None
        };
        if let Some(owner) = owner.as_ref() {
            let (_owner_id, _advertised_host, native_owner) = native_owner(owner)?;
            let owned = NativeStreamOwnedConfig {
                struct_size: std::mem::size_of::<NativeStreamOwnedConfig>(),
                lane: native,
                owner: native_owner,
            };
            let create = lib.load_additive::<StreamLaneCreateOwnedFn>(
                "coakka_v2_stream_lane_create_owned_ex",
            )?;
            status_to_result(
                // SAFETY: nested config and owner strings remain live for this
                // synchronous copying call.
                unsafe { create(&owned, &mut lane) },
                "stream_lane_create_owned",
            )?;
        } else {
            status_to_result(
                // SAFETY: all pointers reference live local values for this
                // synchronous create; the core copies strings before returning.
                unsafe { lib.stream_lane_create.unwrap()(&native, &mut lane) },
                "stream_lane_create",
            )?;
        }
        if lane.is_null() {
            return Err(CoAkkaError::Native(
                "stream_lane_create returned null".into(),
            ));
        }
        if let Err(error) = status_to_result(
            // SAFETY: create returned a non-null owned lane and the resolved
            // start function belongs to the same loaded module.
            unsafe { lib.stream_lane_start.unwrap()(lane) },
            "stream_lane_start",
        ) {
            // SAFETY: start failed before ownership escaped; this path owns the
            // non-null lane and destroys it exactly once.
            unsafe { lib.stream_lane_destroy.unwrap()(lane) };
            return Err(error);
        }
        Ok(Self {
            lib,
            lifecycle: Mutex::new(Lifecycle {
                lane,
                closing: false,
                active: 0,
            }),
            callbacks: Mutex::new(HashMap::new()),
            drained: Condvar::new(),
            prepare_publish_grant,
        })
    }

    fn call<T>(&self, action: impl FnOnce(&NativeLibrary, *mut c_void) -> Result<T>) -> Result<T> {
        let lane = {
            let mut state = self
                .lifecycle
                .lock()
                .map_err(|_| CoAkkaError::Native("stream lane mutex poisoned".into()))?;
            if state.closing || state.lane.is_null() {
                return Err(CoAkkaError::Native("stream lane is closed".into()));
            }
            state.active += 1;
            state.lane
        };
        let result = action(&self.lib, lane);
        let mut state = self.lifecycle.lock().unwrap();
        state.active -= 1;
        if state.active == 0 {
            self.drained.notify_all();
        }
        result
    }

    /// Returns the publisher port selected when the lane started.
    pub fn bound_port(&self) -> Result<u16> {
        self.call(|lib, lane| {
            let mut port = 0;
            status_to_result(
                // SAFETY: `call` holds a live lane borrow and `port` is
                // writable for this synchronous getter.
                unsafe { lib.stream_lane_get_bound_port.unwrap()(lane, &mut port) },
                "stream_lane_get_bound_port",
            )?;
            Ok(port)
        })
    }

    /// Prepares one authorized publisher and retains its callback until forget or close.
    pub fn prepare_publish(&self, spec: StreamPublishSpec) -> Result<()> {
        self.prepare_publish_internal(spec, false).map(|_| ())
    }

    /// Prepares one publisher and returns its exact single-admission owner capability.
    pub fn prepare_publish_grant(&self, spec: StreamPublishSpec) -> Result<StreamPublishGrant> {
        self.prepare_publish_internal(spec, true)?
            .ok_or_else(|| CoAkkaError::Native("stream grant output missing".into()))
    }

    fn prepare_publish_internal(
        &self,
        spec: StreamPublishSpec,
        grant_requested: bool,
    ) -> Result<Option<StreamPublishGrant>> {
        if grant_requested && self.prepare_publish_grant.is_none() {
            return Err(CoAkkaError::InvalidArgument(
                "stream lane was not opened with open_owned".into(),
            ));
        }
        validate_identity(&spec.session_id, &spec.authorization_token)?;
        if spec.max_frame_bytes == 0 || spec.max_frame_bytes > 4 * 1024 * 1024 {
            return Err(CoAkkaError::InvalidArgument(
                "max_frame_bytes must be in [1, 4194304]".into(),
            ));
        }
        let id_key = spec.session_id.clone();
        let id = c(&spec.session_id)?;
        let token = c(&spec.authorization_token)?;
        let holder = Box::new(SourceHolder(Mutex::new(spec.source)));
        let pointer = Box::into_raw(holder);
        let native = NativePublishSpec {
            struct_size: std::mem::size_of::<NativePublishSpec>(),
            id: id.as_ptr(),
            token: token.as_ptr(),
            format_id: spec.format_id,
            max_frame_bytes: spec.max_frame_bytes,
            source_next: Some(source_trampoline),
            source_context: pointer.cast(),
        };
        let result = self.call(|lib, lane| {
            let mut grant = NativePublishGrant {
                struct_size: std::mem::size_of::<NativePublishGrant>(),
                ..NativePublishGrant::default()
            };
            // SAFETY: `call` holds a live lane borrow; native spec text remains
            // alive for the call and the callback root remains allocated.
            if grant_requested {
                status_to_result(
                    unsafe { self.prepare_publish_grant.unwrap()(lane, &native, &mut grant) },
                    "stream_lane_prepare_publish_grant",
                )?;
                Ok(Some(StreamPublishGrant {
                    owner: endpoint(&grant.owner)?,
                    session_id: fixed(&grant.session_id)?,
                    authorization_token: fixed(&grant.authorization_token)?,
                    format_id: grant.format_id,
                    max_frame_bytes: grant.max_frame_bytes,
                }))
            } else {
                status_to_result(
                    unsafe { lib.stream_lane_prepare_publish.unwrap()(lane, &native) },
                    "stream_lane_prepare_publish",
                )?;
                Ok(None)
            }
        });
        if result.is_ok() {
            self.callbacks.lock().unwrap().insert(
                (id_key, StreamDirection::Publish),
                CallbackRoot::Source(pointer),
            );
        } else {
            // SAFETY: admission failed, so the core did not retain the context;
            // this path still owns the box created above.
            unsafe { drop(Box::from_raw(pointer)) };
        }
        result
    }

    /// Queues one subscriber and retains its callback until forget or close.
    pub fn subscribe(&self, spec: StreamSubscribeSpec) -> Result<()> {
        validate_identity(&spec.session_id, &spec.authorization_token)?;
        if spec.remote_host.is_empty()
            || spec.remote_port == 0
            || spec.max_frame_bytes == 0
            || spec.max_frame_bytes > 4 * 1024 * 1024
            || spec.initial_window_bytes < spec.max_frame_bytes
            || spec.initial_window_bytes > 16 * 1024 * 1024
        {
            return Err(CoAkkaError::InvalidArgument(
                "invalid stream subscriber endpoint or frame/window bounds".into(),
            ));
        }
        let id_key = spec.session_id.clone();
        let id = c(&spec.session_id)?;
        let token = c(&spec.authorization_token)?;
        let host = c(&spec.remote_host)?;
        let holder = Box::new(ConsumerHolder(Mutex::new(spec.consumer)));
        let pointer = Box::into_raw(holder);
        let native = NativeSubscribeSpec {
            struct_size: std::mem::size_of::<NativeSubscribeSpec>(),
            id: id.as_ptr(),
            token: token.as_ptr(),
            host: host.as_ptr(),
            port: spec.remote_port,
            format_id: spec.format_id,
            max_frame_bytes: spec.max_frame_bytes,
            initial_window_bytes: spec.initial_window_bytes,
            timeout_ms: spec.timeout_ms,
            consume: Some(consumer_trampoline),
            consumer_context: pointer.cast(),
        };
        let result = self.call(|lib, lane| {
            // SAFETY: `call` holds a live lane borrow; native spec text remains
            // alive for the call and the callback root remains allocated.
            status_to_result(
                unsafe { lib.stream_lane_subscribe.unwrap()(lane, &native) },
                "stream_lane_subscribe",
            )
        });
        if result.is_ok() {
            self.callbacks.lock().unwrap().insert(
                (id_key, StreamDirection::Subscribe),
                CallbackRoot::Consumer(pointer),
            );
        } else {
            // SAFETY: admission failed, so the core did not retain the context;
            // this path still owns the box created above.
            unsafe { drop(Box::from_raw(pointer)) };
        }
        result
    }

    /// Returns the current copied session snapshot without waiting.
    pub fn session(&self, id: &str, direction: StreamDirection) -> Result<StreamSessionSnapshot> {
        self.read_session(id, direction, 0, 0, false)
    }

    /// Blocks until session progress advances, timeout expires, or the lane stops.
    ///
    /// `id` and `direction` select a retained record.
    /// `after_update_sequence` is the latest cursor already handled.
    /// `timeout_ms=0` performs a non-blocking observation and returns a
    /// `CoAkkaError::Native` carrying WOULD_BLOCK when no update exists.
    pub fn wait_session(
        &self,
        id: &str,
        direction: StreamDirection,
        after_update_sequence: u64,
        timeout_ms: u32,
    ) -> Result<StreamSessionSnapshot> {
        self.read_session(id, direction, after_update_sequence, timeout_ms, true)
    }

    fn read_session(
        &self,
        id: &str,
        direction: StreamDirection,
        sequence: u64,
        timeout_ms: u32,
        wait: bool,
    ) -> Result<StreamSessionSnapshot> {
        self.call(|lib, lane| {
            let id = c(id)?;
            let mut native = NativeSessionSnapshot {
                struct_size: std::mem::size_of::<NativeSessionSnapshot>(),
                ..NativeSessionSnapshot::default()
            };
            // SAFETY: `call` holds a live lane borrow; `id` and the writable
            // snapshot remain alive throughout either synchronous call.
            let status = unsafe {
                if wait {
                    lib.stream_lane_wait_session.unwrap()(
                        lane,
                        id.as_ptr(),
                        direction as u32,
                        sequence,
                        timeout_ms,
                        &mut native,
                    )
                } else {
                    lib.stream_lane_get_session.unwrap()(
                        lane,
                        id.as_ptr(),
                        direction as u32,
                        &mut native,
                    )
                }
            };
            status_to_result(
                status,
                if wait {
                    "stream_lane_wait_session"
                } else {
                    "stream_lane_get_session"
                },
            )?;
            session_snapshot(native)
        })
    }

    /// Returns the current copied transport-pressure observation.
    pub fn pressure(&self, id: &str, direction: StreamDirection) -> Result<StreamPressureSnapshot> {
        self.read_pressure(id, direction, 0, 0, false)
    }

    /// Blocks for a coalesced pressure update newer than `after_update_sequence`.
    ///
    /// `timeout_ms=0` performs a non-blocking observation. Pressure reports
    /// transport facts only; the app-host owns all adaptation policy.
    pub fn wait_pressure(
        &self,
        id: &str,
        direction: StreamDirection,
        after_update_sequence: u64,
        timeout_ms: u32,
    ) -> Result<StreamPressureSnapshot> {
        self.read_pressure(id, direction, after_update_sequence, timeout_ms, true)
    }

    fn read_pressure(
        &self,
        id: &str,
        direction: StreamDirection,
        sequence: u64,
        timeout_ms: u32,
        wait: bool,
    ) -> Result<StreamPressureSnapshot> {
        self.call(|lib, lane| {
            let id = c(id)?;
            let mut native = NativePressureSnapshot {
                struct_size: std::mem::size_of::<NativePressureSnapshot>(),
                ..NativePressureSnapshot::default()
            };
            // SAFETY: `call` holds a live lane borrow; `id` and the writable
            // snapshot remain alive throughout either synchronous call.
            let status = unsafe {
                if wait {
                    lib.stream_lane_wait_pressure.unwrap()(
                        lane,
                        id.as_ptr(),
                        direction as u32,
                        sequence,
                        timeout_ms,
                        &mut native,
                    )
                } else {
                    lib.stream_lane_get_pressure.unwrap()(
                        lane,
                        id.as_ptr(),
                        direction as u32,
                        &mut native,
                    )
                }
            };
            status_to_result(
                status,
                if wait {
                    "stream_lane_wait_pressure"
                } else {
                    "stream_lane_get_pressure"
                },
            )?;
            pressure_snapshot(native)
        })
    }

    /// Requests cooperative cancellation; observe terminal state before forgetting.
    pub fn cancel(&self, id: &str, direction: StreamDirection) -> Result<()> {
        self.control(id, direction, false)
    }

    /// Releases one terminal record and its connector-owned callback root.
    pub fn forget(&self, id: &str, direction: StreamDirection) -> Result<()> {
        self.control(id, direction, true)
    }

    fn control(&self, id: &str, direction: StreamDirection, forget: bool) -> Result<()> {
        self.call(|lib, lane| {
            let native_id = c(id)?;
            let function = if forget {
                lib.stream_lane_forget_session.unwrap()
            } else {
                lib.stream_lane_cancel_session.unwrap()
            };
            status_to_result(
                // SAFETY: `call` holds a live lane borrow and `native_id`
                // remains alive for the synchronous control call.
                unsafe { function(lane, native_id.as_ptr(), direction as u32) },
                if forget {
                    "stream_lane_forget_session"
                } else {
                    "stream_lane_cancel_session"
                },
            )?;
            if forget {
                self.callbacks
                    .lock()
                    .unwrap()
                    .remove(&(id.to_owned(), direction));
            }
            Ok(())
        })
    }

    /// Returns a copied lane-level observability snapshot.
    pub fn stats(&self) -> Result<StreamLaneStats> {
        self.call(|lib, lane| {
            let mut native = NativeStreamStats {
                struct_size: std::mem::size_of::<NativeStreamStats>(),
                ..NativeStreamStats::default()
            };
            status_to_result(
                // SAFETY: `call` holds a live lane borrow and `native` is
                // writable for the synchronous snapshot call.
                unsafe { lib.stream_lane_get_stats.unwrap()(lane, &mut native) },
                "stream_lane_get_stats",
            )?;
            Ok(StreamLaneStats {
                capacity: native.capacity,
                queued_subscribers: native.queued_subscribers,
                prepared_publishers: native.prepared_publishers,
                active_publishers: native.active_publishers,
                active_subscribers: native.active_subscribers,
                retained_records: native.retained_records,
                submitted_subscribers: native.submitted_subscribers,
                prepared_publisher_count: native.prepared_publisher_count,
                ended_publishers: native.ended_publishers,
                ended_subscribers: native.ended_subscribers,
                failed_publishers: native.failed_publishers,
                failed_subscribers: native.failed_subscribers,
                canceled_sessions: native.canceled_sessions,
                published_frames: native.published_frames,
                published_bytes: native.published_bytes,
                consumed_frames: native.consumed_frames,
                consumed_bytes: native.consumed_bytes,
                source_reported_drops: native.source_reported_drops,
            })
        })
    }

    /// Performs native stop, drains calls/callbacks, destroys, and releases callback roots.
    pub fn close(&self) -> Result<()> {
        let lane = {
            let mut state = self.lifecycle.lock().unwrap();
            if state.lane.is_null() {
                return Ok(());
            }
            if state.closing {
                while !state.lane.is_null() {
                    state = self.drained.wait(state).unwrap();
                }
                return Ok(());
            }
            state.closing = true;
            state.lane
        };
        // SAFETY: this closer owns the lifecycle transition; stop keeps the
        // lane allocated and wakes worker/wait activity before drain.
        let status = unsafe { self.lib.stream_lane_stop.unwrap()(lane) };
        let mut state = self.lifecycle.lock().unwrap();
        while state.active != 0 {
            state = self.drained.wait(state).unwrap();
        }
        // SAFETY: stop completed and active-call count reached zero, so this
        // closer owns the only remaining lane pointer and destroys it once.
        unsafe { self.lib.stream_lane_destroy.unwrap()(lane) };
        self.callbacks.lock().unwrap().clear();
        state.lane = ptr::null_mut();
        self.drained.notify_all();
        if status == 0 || status == -7 {
            Ok(())
        } else {
            status_to_result(status, "stream_lane_stop")
        }
    }
}

impl Drop for StreamLane {
    fn drop(&mut self) {
        let _ = self.close();
    }
}

fn c(value: &str) -> Result<CString> {
    CString::new(value)
        .map_err(|_| CoAkkaError::InvalidArgument("stream-lane text contains NUL".into()))
}

fn validate_identity(id: &str, token: &str) -> Result<()> {
    if id.is_empty() || id.len() > 64 || token.is_empty() || token.len() > 128 {
        return Err(CoAkkaError::InvalidArgument(
            "stream session ID/token exceed their UTF-8 bounds".into(),
        ));
    }
    Ok(())
}

fn session_snapshot(native: NativeSessionSnapshot) -> Result<StreamSessionSnapshot> {
    let direction = direction(native.direction)?;
    let state = match native.state {
        1 => StreamState::Prepared,
        2 => StreamState::Queued,
        3 => StreamState::Connecting,
        4 => StreamState::Active,
        5 => StreamState::Stopping,
        6 => StreamState::Ended,
        7 => StreamState::Rejected,
        8 => StreamState::Failed,
        9 => StreamState::Canceled,
        value => return Err(invalid_value("session state", value)),
    };
    let result = result(native.result)?;
    // SAFETY: the fixed C buffer is zero-initialized before the call and the
    // core preserves NUL termination within its declared bound.
    let detail = unsafe { CStr::from_ptr(native.detail.as_ptr()) }
        .to_string_lossy()
        .into_owned();
    Ok(StreamSessionSnapshot {
        direction,
        state,
        result,
        format_id: native.format_id,
        frames: native.frames,
        bytes: native.bytes,
        dropped_frames: native.dropped_frames,
        last_sequence: native.last_sequence,
        negotiated_max_frame_bytes: native.max_frame_bytes,
        window_bytes: native.window_bytes,
        cancel_requested: native.cancel_requested != 0,
        update_sequence: native.update_sequence,
        submitted_mono_ns: native.submitted_mono_ns,
        started_mono_ns: native.started_mono_ns,
        updated_mono_ns: native.updated_mono_ns,
        terminal_mono_ns: native.terminal_mono_ns,
        detail,
    })
}

fn pressure_snapshot(native: NativePressureSnapshot) -> Result<StreamPressureSnapshot> {
    let state = match native.state {
        0 => StreamPressureState::Inactive,
        1 => StreamPressureState::Flowing,
        2 => StreamPressureState::Pressured,
        3 => StreamPressureState::Stalled,
        4 => StreamPressureState::Recovering,
        value => return Err(invalid_value("pressure state", value)),
    };
    Ok(StreamPressureSnapshot {
        direction: direction(native.direction)?,
        state,
        reason_bits: native.reason_bits,
        available_credit_bytes: native.available_credit_bytes,
        window_capacity_bytes: native.window_capacity_bytes,
        update_sequence: native.update_sequence,
        transition_count: native.transition_count,
        observed_mono_ns: native.observed_mono_ns,
        state_started_mono_ns: native.state_started_mono_ns,
        pressure_started_mono_ns: native.pressure_started_mono_ns,
        last_progress_mono_ns: native.last_progress_mono_ns,
        observed_delivery_bps: native.observed_delivery_bps,
        current_operation_ns: native.current_operation_ns,
        last_operation_ns: native.last_operation_ns,
        total_pressured_ns: native.total_pressured_ns,
        max_pressured_ns: native.max_pressured_ns,
    })
}

fn direction(value: u32) -> Result<StreamDirection> {
    match value {
        1 => Ok(StreamDirection::Publish),
        2 => Ok(StreamDirection::Subscribe),
        value => Err(invalid_value("direction", value)),
    }
}

fn result(value: u32) -> Result<StreamResult> {
    match value {
        0 => Ok(StreamResult::None),
        1 => Ok(StreamResult::Ok),
        2 => Ok(StreamResult::NotPrepared),
        3 => Ok(StreamResult::TokenMismatch),
        4 => Ok(StreamResult::FormatMismatch),
        5 => Ok(StreamResult::FrameLimit),
        6 => Ok(StreamResult::NetworkIo),
        7 => Ok(StreamResult::Timeout),
        8 => Ok(StreamResult::QueueFull),
        9 => Ok(StreamResult::ProtocolError),
        10 => Ok(StreamResult::SourceError),
        11 => Ok(StreamResult::ConsumerError),
        12 => Ok(StreamResult::InternalError),
        13 => Ok(StreamResult::CanceledByHost),
        14 => Ok(StreamResult::TlsConfigInvalid),
        15 => Ok(StreamResult::TlsHandshakeFailed),
        16 => Ok(StreamResult::PeerCertUntrusted),
        17 => Ok(StreamResult::PeerCertExpired),
        18 => Ok(StreamResult::PeerIdentityMismatch),
        19 => Ok(StreamResult::ClientCertRequired),
        value => Err(invalid_value("result", value)),
    }
}

fn invalid_value(field: &str, value: u32) -> CoAkkaError {
    CoAkkaError::Native(format!("invalid stream-lane {field}: {value}"))
}
