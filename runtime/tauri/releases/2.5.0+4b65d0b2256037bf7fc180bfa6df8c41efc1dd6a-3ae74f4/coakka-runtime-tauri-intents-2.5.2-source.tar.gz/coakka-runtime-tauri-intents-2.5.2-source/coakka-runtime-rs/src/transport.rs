use std::ffi::{c_char, c_int, c_void, CStr, CString};
use std::mem::size_of;

use crate::{
    status_to_result, CoAkkaError, NativeLibrary, Result, RuntimeHost, RuntimePtr, ABI_VERSION,
};

const CONNECTION_FIELD_MODE: u64 = 1 << 0;
const CONNECTION_FIELD_MAX_CONNECTIONS: u64 = 1 << 1;
const CONNECTION_FIELD_MAX_REQUESTS: u64 = 1 << 2;
const CONNECTION_FIELD_IDLE_TIMEOUT: u64 = 1 << 3;
const SECURITY_FIELD_MODE: u64 = 1 << 0;
const SECURITY_FIELD_SOURCE: u64 = 1 << 1;
const SECURITY_FIELD_RELOAD_MODE: u64 = 1 << 2;
const SECURITY_FIELD_GENERATION: u64 = 1 << 3;
const SECURITY_FIELD_CREDENTIAL_ID: u64 = 1 << 4;
const SECURITY_FIELD_CA_FILE: u64 = 1 << 5;
const SECURITY_FIELD_IDENTITY_FILE: u64 = 1 << 6;
const SECURITY_FIELD_KEY_FILE: u64 = 1 << 7;
const SECURITY_ALL_FIELDS: u64 = (1 << 8) - 1;
const CREDENTIAL_SOURCE_FILE: u32 = 1;

/// Stable status returned by the runtime C ABI.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(transparent)]
pub struct CoAkkaStatus(pub i32);

impl CoAkkaStatus {
    /// Operation completed successfully.
    pub const OK: Self = Self(0);
    /// One or more arguments violate the operation contract.
    pub const INVALID_ARGUMENT: Self = Self(-1);
    /// Required bounded storage could not be allocated.
    pub const NO_MEMORY: Self = Self(-2);
    /// Operation is not valid in the current lifecycle state.
    pub const BAD_STATE: Self = Self(-3);
    /// Requested generation is not newer than active state.
    pub const STALE_GENERATION: Self = Self(-4);
    /// Transport or operating-system I/O failed.
    pub const IO: Self = Self(-5);
    /// Non-blocking observation has no new value.
    pub const WOULD_BLOCK: Self = Self(-6);
    /// Runtime or lane has closed.
    pub const CLOSED: Self = Self(-7);
    /// Loaded build does not implement the requested capability.
    pub const FEATURE_UNAVAILABLE: Self = Self(-8);
    /// Loaded distribution does not entitle the requested capability.
    pub const FEATURE_NOT_ENTITLED: Self = Self(-9);
}

/// Capability bits copied from the loaded runtime instead of inferred from package names.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(transparent)]
pub struct RuntimeCapabilities(pub u64);

impl RuntimeCapabilities {
    /// Empty capability set.
    pub const NONE: Self = Self(0);
    /// Bounded TCP connection pooling is effective.
    pub const TCP_BOUNDED_POOL: Self = Self(1 << 0);
    /// Pool limits may be configured by the host.
    pub const TCP_POOL_TUNING: Self = Self(1 << 1);
    /// Server-authenticated TLS is effective.
    pub const TCP_TLS: Self = Self(1 << 2);
    /// Mutual TLS is effective.
    pub const TCP_MUTUAL_TLS: Self = Self(1 << 3);
    /// Same-mode credential generations may be reloaded.
    pub const TLS_CREDENTIAL_RELOAD: Self = Self(1 << 4);
    /// External credential provider integration is effective.
    pub const TLS_EXTERNAL_PROVIDER: Self = Self(1 << 5);
    /// One retained single-flight connection per endpoint is effective.
    pub const TCP_PERSISTENT_SINGLE_FLIGHT: Self = Self(1 << 6);
    /// Multiplexed retained connections are effective.
    pub const TCP_MULTIPLEXING: Self = Self(1 << 7);

    /// Returns true only when every requested capability bit is effective.
    pub const fn supports(self, requested: Self) -> bool {
        self.0 & requested.0 == requested.0
    }
}

/// Startup-only TCP connection ownership strategy.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(transparent)]
pub struct TcpConnectionMode(pub u32);

impl TcpConnectionMode {
    /// Opens a connection for each exchange.
    pub const PER_EXCHANGE: Self = Self(0);
    /// Reuses a bounded pool with optional host tuning.
    pub const BOUNDED_POOL: Self = Self(1);
    /// Retains one connection per endpoint and serializes exchanges.
    pub const PERSISTENT_SINGLE_FLIGHT: Self = Self(2);
    /// Permits bounded concurrent exchanges on retained connections.
    pub const MULTIPLEXING: Self = Self(3);
}

/// TCP security policy independent from connection reuse.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(transparent)]
pub struct TcpSecurityMode(pub u32);

impl TcpSecurityMode {
    /// No transport encryption; requires a protected deployment network.
    pub const PLAINTEXT: Self = Self(0);
    /// Authenticates the server and encrypts transport.
    pub const TLS: Self = Self(1);
    /// Authenticates both peers and encrypts transport.
    pub const MUTUAL_TLS: Self = Self(2);
}

/// Retirement policy for connections using an older TLS context.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(transparent)]
pub struct TlsReloadMode(pub u32);

impl TlsReloadMode {
    /// Keeps established connections while new connections use new credentials.
    pub const GRACEFUL: Self = Self(0);
    /// Retires connections which use the previous credential generation.
    pub const DRAIN_EXISTING_CONNECTIONS: Self = Self(1);
}

/// Stable high-level reason for one transport apply attempt.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(transparent)]
pub struct TransportApplyReason(pub u32);

impl TransportApplyReason {
    /// No rejection reason.
    pub const NONE: Self = Self(0);
    /// Option shape or value is invalid.
    pub const INVALID_ARGUMENT: Self = Self(1);
    /// Loaded build lacks the requested feature.
    pub const FEATURE_UNAVAILABLE: Self = Self(2);
    /// Loaded distribution does not entitle the feature.
    pub const FEATURE_NOT_ENTITLED: Self = Self(3);
    /// Runtime lifecycle no longer accepts this change.
    pub const RUNTIME_NOT_CONFIGURABLE: Self = Self(4);
    /// Security mode cannot change without recreating the runtime.
    pub const SECURITY_MODE_CHANGE_REQUIRES_RECREATE: Self = Self(5);
    /// Credential generation does not advance active state.
    pub const STALE_CREDENTIAL_GENERATION: Self = Self(6);
    /// Credential material could not be accepted.
    pub const CREDENTIAL_REJECTED: Self = Self(7);
    /// Required bounded resource could not be created.
    pub const RESOURCE_FAILURE: Self = Self(8);
    /// Selected transport adapter rejected the configuration.
    pub const ADAPTER_REJECTED: Self = Self(9);
}

/// Field-level validation code for a connection strategy.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(transparent)]
pub struct TcpConnectionValidationCode(pub u32);

impl TcpConnectionValidationCode {
    /// Options are valid.
    pub const VALID: Self = Self(0);
    /// Structure prefix is too small.
    pub const INVALID_STRUCT_SIZE: Self = Self(1);
    /// Presence mask contains an unknown field.
    pub const UNKNOWN_FIELD: Self = Self(2);
    /// Connection mode was omitted.
    pub const MODE_REQUIRED: Self = Self(3);
    /// Connection mode is not recognized.
    pub const UNKNOWN_MODE: Self = Self(4);
    /// Field is not meaningful for the selected mode.
    pub const FIELD_NOT_APPLICABLE: Self = Self(5);
    /// Field value is outside its reported bounds.
    pub const VALUE_OUT_OF_RANGE: Self = Self(6);
    /// Loaded build lacks the requested feature.
    pub const FEATURE_UNAVAILABLE: Self = Self(7);
    /// Loaded distribution does not entitle the feature.
    pub const FEATURE_NOT_ENTITLED: Self = Self(8);
    /// Reserved storage is non-zero.
    pub const RESERVED_NONZERO: Self = Self(9);
    /// Presence mask selects a field outside the supplied structure prefix.
    pub const FIELD_OUTSIDE_STRUCT: Self = Self(10);
    /// Non-zero value was supplied without its presence bit.
    pub const VALUE_WITHOUT_FIELD: Self = Self(11);
}

/// Field-level validation code for a security policy.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(transparent)]
pub struct TcpSecurityValidationCode(pub u32);

impl TcpSecurityValidationCode {
    /// Options are valid.
    pub const VALID: Self = Self(0);
    /// Structure prefix is too small.
    pub const INVALID_STRUCT_SIZE: Self = Self(1);
    /// Presence mask contains an unknown field.
    pub const UNKNOWN_FIELD: Self = Self(2);
    /// Security mode was omitted.
    pub const MODE_REQUIRED: Self = Self(3);
    /// Security mode is not recognized.
    pub const UNKNOWN_MODE: Self = Self(4);
    /// Reserved storage is non-zero.
    pub const RESERVED_NONZERO: Self = Self(5);
    /// Presence mask selects a field outside the supplied structure prefix.
    pub const FIELD_OUTSIDE_STRUCT: Self = Self(6);
    /// Field is not meaningful for the selected mode.
    pub const FIELD_NOT_APPLICABLE: Self = Self(7);
    /// Selected mode requires a missing credential field.
    pub const REQUIRED_FIELD_MISSING: Self = Self(8);
    /// Selected credential source is unavailable.
    pub const SOURCE_UNAVAILABLE: Self = Self(9);
    /// Loaded build lacks the requested feature.
    pub const FEATURE_UNAVAILABLE: Self = Self(10);
    /// Credential generation is invalid.
    pub const INVALID_GENERATION: Self = Self(11);
    /// Diagnostic credential id exceeds its bound.
    pub const CREDENTIAL_ID_TOO_LONG: Self = Self(12);
    /// Non-empty value was supplied without its presence bit.
    pub const VALUE_WITHOUT_FIELD: Self = Self(13);
}

/// Connection strategy selected before runtime start; absent tuning preserves core defaults.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TcpConnectionStrategySpec {
    /// Required connection ownership mode.
    pub mode: TcpConnectionMode,
    /// Optional positive pool connection bound.
    pub max_connections: Option<u32>,
    /// Optional positive retirement count for a pooled connection.
    pub max_requests_per_connection: Option<u64>,
    /// Optional idle retirement timeout in milliseconds.
    pub idle_timeout_ms: Option<u64>,
}

impl TcpConnectionStrategySpec {
    /// Creates a mode-only spec so the runtime owns all applicable defaults.
    pub const fn new(mode: TcpConnectionMode) -> Self {
        Self {
            mode,
            max_connections: None,
            max_requests_per_connection: None,
            idle_timeout_ms: None,
        }
    }
}

impl Default for TcpConnectionStrategySpec {
    fn default() -> Self {
        Self::new(TcpConnectionMode::PER_EXCHANGE)
    }
}

/// Startup security policy or same-mode TLS/mTLS credential reload request.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TcpSecuritySpec {
    /// Required transport protection mode.
    pub mode: TcpSecurityMode,
    /// Retirement policy for connections using older credentials.
    pub reload_mode: TlsReloadMode,
    /// Positive monotonic credential generation for TLS/mTLS.
    pub credential_generation: u64,
    /// Non-secret credential identity used in diagnostics.
    pub credential_id: String,
    /// Trust-anchor bundle path required by verifying peers.
    pub ca_certificate_file: String,
    /// Local certificate-chain path required by authenticating peers.
    pub identity_certificate_file: String,
    /// Local private-key path paired with the identity certificate.
    pub private_key_file: String,
}

impl TcpSecuritySpec {
    /// Creates a policy with graceful reload and no credential fields.
    pub fn new(mode: TcpSecurityMode) -> Self {
        Self {
            mode,
            reload_mode: TlsReloadMode::GRACEFUL,
            credential_generation: 0,
            credential_id: String::new(),
            ca_certificate_file: String::new(),
            identity_certificate_file: String::new(),
            private_key_file: String::new(),
        }
    }
}

impl Default for TcpSecuritySpec {
    fn default() -> Self {
        Self::new(TcpSecurityMode::PLAINTEXT)
    }
}

/// Copied distribution and capability truth for the loaded runtime.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RuntimeCapabilitySnapshot {
    /// Stable distribution edition value.
    pub edition: u32,
    /// Stable license-state value.
    pub license_status: u32,
    /// Capabilities compiled into the loaded runtime.
    pub compiled_capabilities: RuntimeCapabilities,
    /// Capabilities allowed by the active entitlement.
    pub entitled_capabilities: RuntimeCapabilities,
    /// Intersection available to this process.
    pub effective_capabilities: RuntimeCapabilities,
    /// Revision of built-in TCP connection defaults.
    pub tcp_connection_defaults_revision: u32,
}

/// Copied effective connection policy and explicit/default provenance.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TcpConnectionConfigSnapshot {
    /// Revision governing defaulted field values.
    pub defaults_revision: u32,
    /// Effective connection ownership mode.
    pub mode: TcpConnectionMode,
    /// Fields meaningful for the effective mode.
    pub applicable_fields: u64,
    /// Fields explicitly supplied by the host.
    pub explicitly_configured_fields: u64,
    /// Fields selected from runtime defaults.
    pub defaulted_fields: u64,
    /// Fields this distribution permits the host to tune.
    pub configurable_fields: u64,
    /// Effective connection bound for pooled mode.
    pub max_connections: u32,
    /// Effective request retirement count per pooled connection.
    pub max_requests_per_connection: u64,
    /// Effective idle retirement timeout in milliseconds.
    pub idle_timeout_ms: u64,
}

/// Structured result and active state after a connection apply attempt.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TcpConnectionApplyResult {
    /// Stable operation status.
    pub status: CoAkkaStatus,
    /// True only when active state changed.
    pub changed: bool,
    /// Stable high-level decision reason.
    pub reason: TransportApplyReason,
    /// Human-readable stable reason name.
    pub reason_name: String,
    /// Runtime lifecycle state observed by apply.
    pub runtime_state: u32,
    /// Field-level validation result.
    pub validation_code: TcpConnectionValidationCode,
    /// Presence-mask bit associated with validation failure.
    pub validation_field: u64,
    /// Reported inclusive lower bound when relevant.
    pub minimum_value: u64,
    /// Reported inclusive upper bound when relevant.
    pub maximum_value: u64,
    /// Effective state remaining after the attempt, including rejection.
    pub active_config: TcpConnectionConfigSnapshot,
}

impl TcpConnectionApplyResult {
    /// Returns true when the native apply status is `OK`; changed may still be false.
    pub const fn applied(&self) -> bool {
        self.status.0 == CoAkkaStatus::OK.0
    }
}

/// Copied active non-secret TLS/mTLS configuration and certificate identity.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TcpSecurityInfoSnapshot {
    /// Effective transport protection mode.
    pub mode: TcpSecurityMode,
    /// Stable credential source kind.
    pub credential_source_kind: u32,
    /// Active credential retirement policy.
    pub reload_mode: TlsReloadMode,
    /// Stable reload lifecycle status.
    pub reload_status: u32,
    /// Active credential generation.
    pub credential_generation: u64,
    /// Non-secret active credential identity.
    pub credential_id: String,
    /// Minimum accepted TLS protocol version.
    pub minimum_protocol_version: u32,
    /// Maximum accepted TLS protocol version.
    pub maximum_protocol_version: u32,
    /// Active inbound peer-verification flags.
    pub inbound_verification_flags: u64,
    /// Active outbound peer-verification flags.
    pub outbound_verification_flags: u64,
    /// Certificate validity start as Unix seconds, or zero when unavailable.
    pub identity_not_before_unix_seconds: i64,
    /// Certificate validity end as Unix seconds, or zero when unavailable.
    pub identity_not_after_unix_seconds: i64,
    /// Lowercase SHA-256 certificate fingerprint without secret material.
    pub identity_fingerprint_sha256: String,
}

/// Structured result and active non-secret state after a security apply attempt.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TcpSecurityApplyResult {
    /// Stable operation status.
    pub status: CoAkkaStatus,
    /// True only when active immutable security state changed.
    pub changed: bool,
    /// Stable high-level decision reason.
    pub reason: TransportApplyReason,
    /// Human-readable stable reason name.
    pub reason_name: String,
    /// Runtime lifecycle state observed by apply.
    pub runtime_state: u32,
    /// Field-level validation result.
    pub validation_code: TcpSecurityValidationCode,
    /// Presence-mask bit associated with validation failure.
    pub validation_field: u64,
    /// Effective non-secret state remaining after the attempt.
    pub active_security: TcpSecurityInfoSnapshot,
}

impl TcpSecurityApplyResult {
    /// Returns true when the native apply status is `OK`; changed may still be false.
    pub const fn applied(&self) -> bool {
        self.status.0 == CoAkkaStatus::OK.0
    }
}

/// Rust sizes for the eleven public transport ABI blocks on the current target.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RuntimeTransportAbiSizes {
    /// Runtime capability block size.
    pub capabilities: usize,
    /// Connection options block size.
    pub connection_options: usize,
    /// Connection validation block size.
    pub connection_validation: usize,
    /// Connection snapshot block size.
    pub connection_config: usize,
    /// Connection apply-result block size.
    pub connection_apply_result: usize,
    /// Security options block size.
    pub security_options: usize,
    /// Security validation block size.
    pub security_validation: usize,
    /// Security config prefix size.
    pub security_config: usize,
    /// Security identity block size.
    pub security_identity: usize,
    /// Security info block size.
    pub security_info: usize,
    /// Security apply-result block size.
    pub security_apply_result: usize,
}

/// Layout diagnostics for conformance gates; sizes alone are not target execution evidence.
pub struct RuntimeTransportAbi;

impl RuntimeTransportAbi {
    /// Returns the exact Rust structure sizes compiled for the current target.
    pub fn sizes() -> RuntimeTransportAbiSizes {
        RuntimeTransportAbiSizes {
            capabilities: size_of::<NativeRuntimeCapabilities>(),
            connection_options: size_of::<NativeTcpConnectionOptions>(),
            connection_validation: size_of::<NativeTcpConnectionValidation>(),
            connection_config: size_of::<NativeTcpConnectionConfig>(),
            connection_apply_result: size_of::<NativeTcpConnectionApplyResult>(),
            security_options: size_of::<NativeTcpSecurityOptions>(),
            security_validation: size_of::<NativeTcpSecurityValidation>(),
            security_config: size_of::<NativeTcpSecurityConfig>(),
            security_identity: size_of::<NativeTcpSecurityIdentity>(),
            security_info: size_of::<NativeTcpSecurityInfo>(),
            security_apply_result: size_of::<NativeTcpSecurityApplyResult>(),
        }
    }
}

impl RuntimeHost {
    /// Resolves one runtime library and copies capability truth before a host starts.
    ///
    /// The call is synchronous and available in every edition. The first resolved
    /// module identity remains loaded for process lifetime; a different later path
    /// is rejected.
    pub fn read_runtime_capabilities(
        runtime_lib_path: impl AsRef<str>,
    ) -> Result<RuntimeCapabilitySnapshot> {
        let path = crate::RuntimeLibraryResolver::resolve(runtime_lib_path.as_ref())?;
        let library = NativeLibrary::open(&path)?;
        // SAFETY: the loader resolved this exact symbol to its reviewed
        // zero-argument function-pointer type and keeps the module loaded.
        let abi = unsafe { (library.get_abi_version)() };
        if abi != ABI_VERSION {
            return Err(CoAkkaError::Native(format!(
                "unexpected ABI version: {abi}"
            )));
        }
        read_capabilities_native(&library)
    }

    /// Copies compiled, entitled, and effective capabilities while this host is open.
    pub fn runtime_capabilities(&self) -> Result<RuntimeCapabilitySnapshot> {
        let _guard = self
            .inner
            .transport_mu
            .lock()
            .map_err(|_| CoAkkaError::Native("transport mutex poisoned".to_string()))?;
        self.inner.require_open()?;
        read_capabilities_native(&self.inner.lib)
    }

    /// Copies the effective connection policy and default provenance.
    pub fn tcp_connection_config(&self) -> Result<TcpConnectionConfigSnapshot> {
        let _guard = self
            .inner
            .transport_mu
            .lock()
            .map_err(|_| CoAkkaError::Native("transport mutex poisoned".to_string()))?;
        self.inner.require_open()?;
        read_connection_config_native(&self.inner.lib, self.inner.runtime)
    }

    /// Copies active non-secret TLS/mTLS state and certificate identity metadata.
    pub fn tcp_security_info(&self) -> Result<TcpSecurityInfoSnapshot> {
        let _guard = self
            .inner
            .transport_mu
            .lock()
            .map_err(|_| CoAkkaError::Native("transport mutex poisoned".to_string()))?;
        self.inner.require_open()?;
        read_security_info_native(&self.inner.lib, self.inner.runtime)
    }

    /// Returns the copied explicit startup connection result, or `None` when omitted.
    pub fn startup_tcp_connection_result(&self) -> Option<TcpConnectionApplyResult> {
        self.startup_connection_result.clone()
    }

    /// Returns the copied explicit startup security result, or `None` when omitted.
    pub fn startup_tcp_security_result(&self) -> Option<TcpSecurityApplyResult> {
        self.startup_security_result.clone()
    }

    /// Attempts an atomic connection apply and returns the active state remaining afterward.
    ///
    /// The call is serialized with transport getters and teardown. Connection mode is
    /// startup-only, so a started host normally returns `BAD_STATE` without mutation.
    pub fn apply_tcp_connection_strategy(
        &self,
        spec: &TcpConnectionStrategySpec,
    ) -> Result<TcpConnectionApplyResult> {
        let _guard = self
            .inner
            .transport_mu
            .lock()
            .map_err(|_| CoAkkaError::Native("transport mutex poisoned".to_string()))?;
        self.inner.require_open()?;
        apply_connection_native(&self.inner.lib, self.inner.runtime, spec)
    }

    /// Applies startup-shaped security or reloads a newer generation in the same mode.
    ///
    /// Credential strings are borrowed only during this synchronous call. File loading
    /// may block. Rejection preserves the active immutable TLS context and copied result.
    pub fn apply_tcp_security(&self, spec: &TcpSecuritySpec) -> Result<TcpSecurityApplyResult> {
        let _guard = self
            .inner
            .transport_mu
            .lock()
            .map_err(|_| CoAkkaError::Native("transport mutex poisoned".to_string()))?;
        self.inner.require_open()?;
        apply_security_native(&self.inner.lib, self.inner.runtime, spec)
    }
}

pub(crate) fn read_capabilities_native(
    library: &NativeLibrary,
) -> Result<RuntimeCapabilitySnapshot> {
    let mut native = NativeRuntimeCapabilities {
        struct_size: size_of::<NativeRuntimeCapabilities>(),
        ..NativeRuntimeCapabilities::default()
    };
    status_to_result(
        // SAFETY: the symbol type matches the contract and `native` is a live
        // writable record with its structure size initialized.
        unsafe { (library.get_capabilities)(&mut native) },
        "coakka_v2_runtime_get_capabilities",
    )?;
    Ok(RuntimeCapabilitySnapshot {
        edition: native.edition,
        license_status: native.license_status,
        compiled_capabilities: RuntimeCapabilities(native.compiled_capabilities),
        entitled_capabilities: RuntimeCapabilities(native.entitled_capabilities),
        effective_capabilities: RuntimeCapabilities(native.effective_capabilities),
        tcp_connection_defaults_revision: native.tcp_connection_defaults_revision,
    })
}

pub(crate) fn apply_connection_native(
    library: &NativeLibrary,
    runtime: RuntimePtr,
    spec: &TcpConnectionStrategySpec,
) -> Result<TcpConnectionApplyResult> {
    let mut options = NativeTcpConnectionOptions {
        struct_size: size_of::<NativeTcpConnectionOptions>(),
        fields: CONNECTION_FIELD_MODE,
        mode: spec.mode.0,
        ..NativeTcpConnectionOptions::default()
    };
    if let Some(value) = spec.max_connections {
        options.fields |= CONNECTION_FIELD_MAX_CONNECTIONS;
        options.max_connections = value;
    }
    if let Some(value) = spec.max_requests_per_connection {
        options.fields |= CONNECTION_FIELD_MAX_REQUESTS;
        options.max_requests_per_connection = value;
    }
    if let Some(value) = spec.idle_timeout_ms {
        options.fields |= CONNECTION_FIELD_IDLE_TIMEOUT;
        options.idle_timeout_ms = value;
    }

    let mut native = NativeTcpConnectionApplyResult {
        struct_size: size_of::<NativeTcpConnectionApplyResult>(),
        ..NativeTcpConnectionApplyResult::default()
    };
    // SAFETY: runtime remains live under the host transport mutex; options are
    // borrowed for the call and `native` is writable.
    let status =
        unsafe { (library.apply_tcp_connection_options)(runtime.0, &options, &mut native) };
    if status != native.apply_status {
        return Err(CoAkkaError::Native(format!(
            "connection apply status mismatch return={status} result={}",
            native.apply_status
        )));
    }
    Ok(TcpConnectionApplyResult {
        status: CoAkkaStatus(native.apply_status),
        changed: native.changed != 0,
        reason: TransportApplyReason(native.reason),
        reason_name: reason_name(library, native.reason),
        runtime_state: native.runtime_state,
        validation_code: TcpConnectionValidationCode(native.validation.code),
        validation_field: native.validation.field,
        minimum_value: native.validation.minimum_value,
        maximum_value: native.validation.maximum_value,
        active_config: connection_config_from_native(native.effective_config),
    })
}

pub(crate) fn apply_security_native(
    library: &NativeLibrary,
    runtime: RuntimePtr,
    spec: &TcpSecuritySpec,
) -> Result<TcpSecurityApplyResult> {
    let credential_id = transport_c_string(&spec.credential_id, "credential_id")?;
    let ca_file = transport_c_string(&spec.ca_certificate_file, "ca_certificate_file")?;
    let identity_file =
        transport_c_string(&spec.identity_certificate_file, "identity_certificate_file")?;
    let key_file = transport_c_string(&spec.private_key_file, "private_key_file")?;

    let mut options = NativeTcpSecurityOptions {
        struct_size: size_of::<NativeTcpSecurityOptions>(),
        fields: SECURITY_FIELD_MODE,
        mode: spec.mode.0,
        ..NativeTcpSecurityOptions::default()
    };
    if spec.mode != TcpSecurityMode::PLAINTEXT {
        options.fields = SECURITY_ALL_FIELDS;
        options.credential_source_kind = CREDENTIAL_SOURCE_FILE;
        options.reload_mode = spec.reload_mode.0;
        options.credential_generation = spec.credential_generation;
        options.credential_id = credential_id.as_ptr();
        options.ca_certificate_file = ca_file.as_ptr();
        options.identity_certificate_file = identity_file.as_ptr();
        options.private_key_file = key_file.as_ptr();
    } else {
        if spec.reload_mode != TlsReloadMode::GRACEFUL {
            options.fields |= SECURITY_FIELD_RELOAD_MODE;
            options.reload_mode = spec.reload_mode.0;
        }
        if spec.credential_generation != 0 {
            options.fields |= SECURITY_FIELD_GENERATION;
            options.credential_generation = spec.credential_generation;
        }
        if !spec.credential_id.is_empty() {
            options.fields |= SECURITY_FIELD_CREDENTIAL_ID;
            options.credential_id = credential_id.as_ptr();
        }
        if !spec.ca_certificate_file.is_empty()
            || !spec.identity_certificate_file.is_empty()
            || !spec.private_key_file.is_empty()
        {
            options.fields |= SECURITY_FIELD_SOURCE;
            options.credential_source_kind = CREDENTIAL_SOURCE_FILE;
        }
        if !spec.ca_certificate_file.is_empty() {
            options.fields |= SECURITY_FIELD_CA_FILE;
            options.ca_certificate_file = ca_file.as_ptr();
        }
        if !spec.identity_certificate_file.is_empty() {
            options.fields |= SECURITY_FIELD_IDENTITY_FILE;
            options.identity_certificate_file = identity_file.as_ptr();
        }
        if !spec.private_key_file.is_empty() {
            options.fields |= SECURITY_FIELD_KEY_FILE;
            options.private_key_file = key_file.as_ptr();
        }
    }

    let mut native = NativeTcpSecurityApplyResult {
        struct_size: size_of::<NativeTcpSecurityApplyResult>(),
        ..NativeTcpSecurityApplyResult::default()
    };
    // SAFETY: runtime remains live under the host transport mutex; every
    // optional string is NUL-terminated and live for this synchronous call.
    let status = unsafe { (library.apply_tcp_security_options)(runtime.0, &options, &mut native) };
    if status != native.apply_status {
        return Err(CoAkkaError::Native(format!(
            "security apply status mismatch return={status} result={}",
            native.apply_status
        )));
    }
    Ok(TcpSecurityApplyResult {
        status: CoAkkaStatus(native.apply_status),
        changed: native.changed != 0,
        reason: TransportApplyReason(native.reason),
        reason_name: reason_name(library, native.reason),
        runtime_state: native.runtime_state,
        validation_code: TcpSecurityValidationCode(native.validation.code),
        validation_field: native.validation.field,
        active_security: security_info_from_native(native.active_security),
    })
}

fn read_connection_config_native(
    library: &NativeLibrary,
    runtime: RuntimePtr,
) -> Result<TcpConnectionConfigSnapshot> {
    let mut native = NativeTcpConnectionConfig {
        struct_size: size_of::<NativeTcpConnectionConfig>(),
        ..NativeTcpConnectionConfig::default()
    };
    status_to_result(
        // SAFETY: runtime remains live under the host transport mutex and
        // `native` is writable for this synchronous snapshot call.
        unsafe { (library.get_tcp_connection_config)(runtime.0, &mut native) },
        "coakka_v2_runtime_get_tcp_connection_config",
    )?;
    Ok(connection_config_from_native(native))
}

fn read_security_info_native(
    library: &NativeLibrary,
    runtime: RuntimePtr,
) -> Result<TcpSecurityInfoSnapshot> {
    let mut native = NativeTcpSecurityInfo {
        struct_size: size_of::<NativeTcpSecurityInfo>(),
        ..NativeTcpSecurityInfo::default()
    };
    status_to_result(
        // SAFETY: runtime remains live under the host transport mutex and
        // `native` is writable for this synchronous snapshot call.
        unsafe { (library.get_tcp_security_info)(runtime.0, &mut native) },
        "coakka_v2_runtime_get_tcp_security_info",
    )?;
    Ok(security_info_from_native(native))
}

fn connection_config_from_native(native: NativeTcpConnectionConfig) -> TcpConnectionConfigSnapshot {
    TcpConnectionConfigSnapshot {
        defaults_revision: native.defaults_revision,
        mode: TcpConnectionMode(native.mode),
        applicable_fields: native.applicable_fields,
        explicitly_configured_fields: native.explicitly_configured_fields,
        defaulted_fields: native.defaulted_fields,
        configurable_fields: native.configurable_fields,
        max_connections: native.max_connections,
        max_requests_per_connection: native.max_requests_per_connection,
        idle_timeout_ms: native.idle_timeout_ms,
    }
}

fn security_info_from_native(native: NativeTcpSecurityInfo) -> TcpSecurityInfoSnapshot {
    TcpSecurityInfoSnapshot {
        mode: TcpSecurityMode(native.config.mode),
        credential_source_kind: native.config.credential_source_kind,
        reload_mode: TlsReloadMode(native.config.reload_mode),
        reload_status: native.config.reload_status,
        credential_generation: native.config.credential_generation,
        credential_id: fixed_string(&native.identity.credential_id_value),
        minimum_protocol_version: native.identity.minimum_protocol_version,
        maximum_protocol_version: native.identity.maximum_protocol_version,
        inbound_verification_flags: native.identity.inbound_verification_flags,
        outbound_verification_flags: native.identity.outbound_verification_flags,
        identity_not_before_unix_seconds: native.identity.identity_not_before_unix_seconds,
        identity_not_after_unix_seconds: native.identity.identity_not_after_unix_seconds,
        identity_fingerprint_sha256: fixed_string(&native.identity.identity_fingerprint_sha256),
    }
}

fn transport_c_string(value: &str, name: &str) -> Result<CString> {
    CString::new(value)
        .map_err(|_| CoAkkaError::InvalidArgument(format!("{name} must not contain NUL")))
}

fn reason_name(library: &NativeLibrary, reason: u32) -> String {
    // SAFETY: the loaded function takes a value and returns module-owned static
    // text or null; the module remains loaded for process lifetime.
    let pointer = unsafe { (library.transport_apply_reason_name)(reason) };
    if pointer.is_null() {
        String::new()
    } else {
        // SAFETY: a non-null result is a NUL-terminated module-owned string.
        unsafe { CStr::from_ptr(pointer) }
            .to_string_lossy()
            .to_string()
    }
}

fn fixed_string<const N: usize>(value: &[c_char; N]) -> String {
    let bytes: Vec<u8> = value
        .iter()
        .take_while(|value| **value != 0)
        .map(|value| *value as u8)
        .collect();
    String::from_utf8_lossy(&bytes).to_string()
}

macro_rules! native_default {
    ($type_name:ty) => {
        impl Default for $type_name {
            fn default() -> Self {
                // SAFETY: these repr(C) transport records contain only integer,
                // pointer, and fixed-buffer fields for which zero is valid.
                unsafe { std::mem::zeroed() }
            }
        }
    };
}

#[repr(C)]
pub(crate) struct NativeRuntimeCapabilities {
    struct_size: usize,
    edition: u32,
    license_status: u32,
    compiled_capabilities: u64,
    entitled_capabilities: u64,
    effective_capabilities: u64,
    tcp_connection_defaults_revision: u32,
    reserved: u32,
}
native_default!(NativeRuntimeCapabilities);

#[repr(C)]
pub(crate) struct NativeTcpConnectionOptions {
    struct_size: usize,
    fields: u64,
    mode: u32,
    reserved: u32,
    max_connections: u32,
    reserved2: u32,
    max_requests_per_connection: u64,
    idle_timeout_ms: u64,
}
native_default!(NativeTcpConnectionOptions);

#[repr(C)]
pub(crate) struct NativeTcpConnectionValidation {
    struct_size: usize,
    code: u32,
    reserved: u32,
    field: u64,
    minimum_value: u64,
    maximum_value: u64,
}
native_default!(NativeTcpConnectionValidation);

#[repr(C)]
pub(crate) struct NativeTcpConnectionConfig {
    struct_size: usize,
    defaults_revision: u32,
    mode: u32,
    applicable_fields: u64,
    explicitly_configured_fields: u64,
    defaulted_fields: u64,
    configurable_fields: u64,
    max_connections: u32,
    reserved: u32,
    max_requests_per_connection: u64,
    idle_timeout_ms: u64,
}
native_default!(NativeTcpConnectionConfig);

#[repr(C)]
pub(crate) struct NativeTcpConnectionApplyResult {
    struct_size: usize,
    apply_status: c_int,
    changed: u32,
    reason: u32,
    runtime_state: u32,
    validation: NativeTcpConnectionValidation,
    effective_config: NativeTcpConnectionConfig,
}
native_default!(NativeTcpConnectionApplyResult);

#[repr(C)]
pub(crate) struct NativeTcpSecurityOptions {
    struct_size: usize,
    fields: u64,
    mode: u32,
    credential_source_kind: u32,
    reload_mode: u32,
    reserved: u32,
    credential_generation: u64,
    credential_id: *const c_char,
    ca_certificate_file: *const c_char,
    identity_certificate_file: *const c_char,
    private_key_file: *const c_char,
}
native_default!(NativeTcpSecurityOptions);

#[repr(C)]
pub(crate) struct NativeTcpSecurityValidation {
    struct_size: usize,
    code: u32,
    reserved: u32,
    field: u64,
}
native_default!(NativeTcpSecurityValidation);

#[repr(C)]
pub(crate) struct NativeTcpSecurityConfig {
    struct_size: usize,
    mode: u32,
    credential_source_kind: u32,
    reload_mode: u32,
    reload_status: u32,
    credential_generation: u64,
    credential_id: *const c_char,
}
native_default!(NativeTcpSecurityConfig);

#[repr(C)]
pub(crate) struct NativeTcpSecurityIdentity {
    struct_size: usize,
    minimum_protocol_version: u32,
    maximum_protocol_version: u32,
    inbound_verification_flags: u64,
    outbound_verification_flags: u64,
    identity_not_before_unix_seconds: i64,
    identity_not_after_unix_seconds: i64,
    credential_id_value: [c_char; 128],
    identity_fingerprint_sha256: [c_char; 65],
}
native_default!(NativeTcpSecurityIdentity);

#[repr(C)]
pub(crate) struct NativeTcpSecurityInfo {
    struct_size: usize,
    config: NativeTcpSecurityConfig,
    identity: NativeTcpSecurityIdentity,
}
native_default!(NativeTcpSecurityInfo);

#[repr(C)]
pub(crate) struct NativeTcpSecurityApplyResult {
    struct_size: usize,
    apply_status: c_int,
    changed: u32,
    reason: u32,
    runtime_state: u32,
    validation: NativeTcpSecurityValidation,
    active_security: NativeTcpSecurityInfo,
}
native_default!(NativeTcpSecurityApplyResult);

pub(crate) type RuntimeGetCapabilities =
    unsafe extern "C" fn(*mut NativeRuntimeCapabilities) -> c_int;
pub(crate) type RuntimeApplyTcpConnectionOptions = unsafe extern "C" fn(
    *mut c_void,
    *const NativeTcpConnectionOptions,
    *mut NativeTcpConnectionApplyResult,
) -> c_int;
pub(crate) type RuntimeGetTcpConnectionConfig =
    unsafe extern "C" fn(*mut c_void, *mut NativeTcpConnectionConfig) -> c_int;
pub(crate) type RuntimeApplyTcpSecurityOptions = unsafe extern "C" fn(
    *mut c_void,
    *const NativeTcpSecurityOptions,
    *mut NativeTcpSecurityApplyResult,
) -> c_int;
pub(crate) type RuntimeGetTcpSecurityInfo =
    unsafe extern "C" fn(*mut c_void, *mut NativeTcpSecurityInfo) -> c_int;
pub(crate) type RuntimeTransportApplyReasonName = unsafe extern "C" fn(u32) -> *const c_char;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transport_abi_sizes_match_the_frozen_64_bit_contract() {
        assert_eq!(
            RuntimeTransportAbi::sizes(),
            RuntimeTransportAbiSizes {
                capabilities: 48,
                connection_options: 48,
                connection_validation: 40,
                connection_config: 72,
                connection_apply_result: 136,
                security_options: 72,
                security_validation: 24,
                security_config: 40,
                security_identity: 248,
                security_info: 296,
                security_apply_result: 344,
            }
        );
    }

    #[test]
    fn capability_support_requires_every_requested_bit() {
        let effective = RuntimeCapabilities(
            RuntimeCapabilities::TCP_BOUNDED_POOL.0 | RuntimeCapabilities::TCP_TLS.0,
        );
        assert!(effective.supports(RuntimeCapabilities::TCP_BOUNDED_POOL));
        assert!(effective.supports(RuntimeCapabilities::NONE));
        assert!(!effective.supports(RuntimeCapabilities::TCP_MUTUAL_TLS));
    }
}
