use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;

use coakka_runtime::{
    CoAkkaError, ConnectorStartSpec, DeliveryHint, PayloadFormat, PayloadIdentity, RuntimeHost,
    TransportEnvelope,
};
use serde::{Deserialize, Serialize};
use serde_json::Value;

pub type Result<T> = std::result::Result<T, IntentError>;

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum IntentPayloadFormat {
    Json,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct IntentPayloadIdentity {
    pub message_type: String,
    pub schema_version: u32,
    pub format: IntentPayloadFormat,
}

impl IntentPayloadIdentity {
    pub fn json(message_type: impl Into<String>, schema_version: u32) -> Self {
        Self {
            message_type: message_type.into(),
            schema_version,
            format: IntentPayloadFormat::Json,
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct IntentEnvelope {
    pub intent_id: String,
    pub source: String,
    pub target: String,
    pub operation: String,
    pub payload: Value,
    pub payload_identity: IntentPayloadIdentity,
    #[serde(default)]
    pub timeout_ms: Option<u64>,
    #[serde(default)]
    pub headers: HashMap<String, String>,
}

impl IntentEnvelope {
    pub fn require_valid(&self) -> Result<()> {
        require_non_blank("intentId", &self.intent_id)?;
        require_non_blank("source", &self.source)?;
        require_non_blank("target", &self.target)?;
        require_non_blank("operation", &self.operation)?;
        require_non_blank("payloadIdentity.messageType", &self.payload_identity.message_type)?;
        for (key, value) in &self.headers {
            require_non_blank("headers.key", key)?;
            require_non_blank("headers.value", value)?;
        }
        if self.payload_identity.schema_version == 0 {
            return Err(IntentError::invalid_intent(
                "payloadIdentity.schemaVersion must be >= 1".to_string(),
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct IntentHandlerRequest {
    pub source: String,
    pub target: String,
    pub operation: String,
    pub payload: Value,
    pub payload_identity: IntentPayloadIdentity,
    #[serde(default)]
    pub headers: HashMap<String, String>,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct IntentResult {
    pub intent_id: String,
    pub target: String,
    pub operation: String,
    pub payload: Value,
    pub runtime: IntentRuntimeProjection,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct IntentRuntimeProjection {
    pub message_type: String,
    pub schema_version: u32,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct IntentError {
    pub code: String,
    pub message: String,
    #[serde(default)]
    pub target: Option<String>,
}

impl IntentError {
    pub fn invalid_intent(message: impl Into<String>) -> Self {
        Self {
            code: "INVALID_INTENT".to_string(),
            message: message.into(),
            target: None,
        }
    }

    pub fn runtime(message: impl Into<String>, target: Option<String>) -> Self {
        Self {
            code: "RUNTIME_ERROR".to_string(),
            message: message.into(),
            target,
        }
    }
}

pub struct RuntimeIntentDispatcher {
    runtime: Arc<RuntimeHost>,
    default_timeout: Duration,
    max_timeout: Duration,
    delivery_hint: DeliveryHint,
}

impl Clone for RuntimeIntentDispatcher {
    fn clone(&self) -> Self {
        Self {
            runtime: self.runtime.clone(),
            default_timeout: self.default_timeout,
            max_timeout: self.max_timeout,
            delivery_hint: self.delivery_hint,
        }
    }
}

impl RuntimeIntentDispatcher {
    pub fn start(spec: ConnectorStartSpec) -> Result<Self> {
        let runtime = RuntimeHost::start(spec)
            .map_err(|error| IntentError::runtime(error.to_string(), None))?;
        Ok(Self::new(runtime))
    }

    pub fn new(runtime: RuntimeHost) -> Self {
        Self {
            runtime: Arc::new(runtime),
            default_timeout: Duration::from_secs(2),
            max_timeout: Duration::from_secs(30),
            delivery_hint: DeliveryHint::RouterDefault,
        }
    }

    pub fn register_json_handler<F>(&self, target: impl Into<String>, handler: F) -> Result<()>
    where
        F: Fn(IntentHandlerRequest) -> Result<Value> + Send + Sync + 'static,
    {
        let target = target.into();
        require_non_blank("target", &target)?;
        let reply_source = target.clone();
        self.runtime
            .register_handler(target, move |request| {
                let intent_request = match IntentHandlerRequest::from_transport_request(&request) {
                    Ok(intent_request) => intent_request,
                    Err(error) => {
                        eprintln!("[coakka-tauri-intents] invalid handler request: {error:?}");
                        return None;
                    }
                };
                let payload = match handler(intent_request)
                    .and_then(|payload| {
                        serde_json::to_string(&payload)
                            .map_err(|error| IntentError::runtime(error.to_string(), None))
                    }) {
                    Ok(payload) => payload,
                    Err(error) => {
                        eprintln!("[coakka-tauri-intents] handler failed: {error:?}");
                        return None;
                    }
                };
                RuntimeHost::make_json_reply_from_request_identity(&request, &reply_source, payload)
                    .ok()
            })
            .map_err(|error| IntentError::runtime(error.to_string(), None))
    }

    pub fn ask_intent(&self, intent: IntentEnvelope) -> Result<IntentResult> {
        intent.require_valid()?;
        let timeout = self.timeout_for(&intent);
        let payload_json = serde_json::to_string(&intent.payload)
            .map_err(|error| IntentError::invalid_intent(error.to_string()))?;
        let response = self
            .runtime
            .ask_json(
                &intent.source,
                &intent.target,
                payload_json,
                self.payload_identity_for(&intent)?,
                timeout,
                &intent.operation,
                self.delivery_hint,
            )
            .map_err(|error| map_runtime_error(error, &intent.target))?;
        let payload = serde_json::from_str::<Value>(&response.payload_utf8())
            .map_err(|error| IntentError::runtime(error.to_string(), Some(intent.target.clone())))?;
        Ok(IntentResult {
            intent_id: intent.intent_id,
            target: intent.target,
            operation: intent.operation,
            payload,
            runtime: IntentRuntimeProjection {
                message_type: response.message_type,
                schema_version: response.payload_schema_version,
            },
        })
    }

    fn timeout_for(&self, intent: &IntentEnvelope) -> Duration {
        let requested = intent
            .timeout_ms
            .map(Duration::from_millis)
            .unwrap_or(self.default_timeout);
        requested.min(self.max_timeout)
    }

    fn payload_identity_for(&self, intent: &IntentEnvelope) -> Result<PayloadIdentity> {
        match intent.payload_identity.format {
            IntentPayloadFormat::Json => Ok(PayloadIdentity {
                message_type: intent.payload_identity.message_type.clone(),
                payload_schema_version: intent.payload_identity.schema_version,
                payload_format: PayloadFormat::Json,
            }),
        }
    }
}

pub fn coakka_ask_intent_command(
    dispatcher: &RuntimeIntentDispatcher,
    intent: IntentEnvelope,
) -> Result<IntentResult> {
    dispatcher.ask_intent(intent)
}

impl IntentHandlerRequest {
    fn from_transport_request(request: &TransportEnvelope) -> Result<Self> {
        if request.payload_format != PayloadFormat::Json {
            return Err(IntentError::runtime(
                "intent handler received a non-JSON runtime request",
                Some(request.target.clone()),
            ));
        }
        let payload = serde_json::from_str::<Value>(&request.payload_utf8())
            .map_err(|error| IntentError::runtime(error.to_string(), Some(request.target.clone())))?;
        Ok(Self {
            source: request.source.clone(),
            target: request.target.clone(),
            operation: request
                .headers
                .get("operation")
                .cloned()
                .unwrap_or_default(),
            payload,
            payload_identity: IntentPayloadIdentity {
                message_type: request.message_type.clone(),
                schema_version: request.payload_schema_version,
                format: IntentPayloadFormat::Json,
            },
            headers: request.headers.clone(),
        })
    }
}

fn require_non_blank(name: &str, value: &str) -> Result<()> {
    if value.trim().is_empty() {
        return Err(IntentError::invalid_intent(format!("{name} must not be blank")));
    }
    Ok(())
}

fn map_runtime_error(error: CoAkkaError, target: &str) -> IntentError {
    match error {
        CoAkkaError::Deadletter(deadletter) => IntentError {
            code: deadletter.reason,
            message: deadletter.detail,
            target: Some(deadletter.original.target),
        },
        other => IntentError::runtime(other.to_string(), Some(target.to_string())),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use coakka_runtime::RouteSpec;
    use serde_json::json;

    #[test]
    fn ask_intent_roundtrips_through_native_runtime() {
        let target = "tauri.intent.echo";
        let mut spec = ConnectorStartSpec::new("tauri-intent-test", "tauri-intent-test-node");
        spec.queue_capacity = 64;
        spec.routes = vec![RouteSpec::single_local(target, "127.0.0.1", 19411)];

        let dispatcher = RuntimeIntentDispatcher::start(spec).expect("start dispatcher");
        dispatcher
            .register_json_handler(target, |request| {
                Ok(json!({
                    "handledBy": "rust",
                    "operation": request.operation,
                    "echo": request.payload
                }))
            })
            .expect("register handler");

        let result = coakka_ask_intent_command(
            &dispatcher,
            IntentEnvelope {
                intent_id: "intent-1".to_string(),
                source: "tauri-ui".to_string(),
                target: target.to_string(),
                operation: "echo".to_string(),
                payload: json!({"message":"hello-tauri-intent"}),
                payload_identity: IntentPayloadIdentity::json("samples.tauri.echo.request.v1", 1),
                timeout_ms: Some(2_000),
                headers: HashMap::new(),
            },
        )
            .expect("ask intent");

        assert_eq!(result.intent_id, "intent-1");
        assert_eq!(result.payload["handledBy"], "rust");
        assert_eq!(result.payload["operation"], "echo");
        assert_eq!(result.payload["echo"]["message"], "hello-tauri-intent");
        assert_eq!(
            result.runtime.message_type,
            "samples.tauri.echo.request.v1"
        );
    }

    #[test]
    fn rejects_blank_intent_before_runtime_boundary() {
        let intent = IntentEnvelope {
            intent_id: String::new(),
            source: "tauri-ui".to_string(),
            target: "svc.echo".to_string(),
            operation: "echo".to_string(),
            payload: json!({}),
            payload_identity: IntentPayloadIdentity::json("samples.tauri.echo.request.v1", 1),
            timeout_ms: None,
            headers: HashMap::new(),
        };

        let error = intent.require_valid().expect_err("blank intent id rejected");
        assert_eq!(error.code, "INVALID_INTENT");
    }

    #[test]
    fn rejects_blank_header_before_runtime_boundary() {
        let mut headers = HashMap::new();
        headers.insert("".to_string(), "trace-1".to_string());
        let intent = IntentEnvelope {
            intent_id: "intent-1".to_string(),
            source: "tauri-ui".to_string(),
            target: "svc.echo".to_string(),
            operation: "echo".to_string(),
            payload: json!({}),
            payload_identity: IntentPayloadIdentity::json("samples.tauri.echo.request.v1", 1),
            timeout_ms: None,
            headers,
        };

        let error = intent.require_valid().expect_err("blank header rejected");
        assert_eq!(error.code, "INVALID_INTENT");
    }
}
