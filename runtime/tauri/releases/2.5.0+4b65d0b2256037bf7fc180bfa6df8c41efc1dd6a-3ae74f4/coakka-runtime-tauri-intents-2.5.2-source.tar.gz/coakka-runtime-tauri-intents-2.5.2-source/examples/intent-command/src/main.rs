use std::collections::HashMap;

use coakka_runtime::{ConnectorStartSpec, RouteSpec};
use coakka_tauri_intents::{
    coakka_ask_intent_command, IntentEnvelope, IntentPayloadIdentity, RuntimeIntentDispatcher,
};
use serde_json::json;

fn main() -> coakka_tauri_intents::Result<()> {
    let target = "samples.tauri.intent.echo";
    let mut spec = ConnectorStartSpec::new("tauri-intent-package-smoke", "tauri-intent-package-node");
    spec.queue_capacity = 64;
    spec.routes = vec![RouteSpec::single_local(target, "127.0.0.1", 19441)];

    let dispatcher = RuntimeIntentDispatcher::start(spec)?;
    dispatcher.register_json_handler(target, |request| {
        Ok(json!({
            "handledBy": "rust-command",
            "operation": request.operation,
            "echo": request.payload
        }))
    })?;

    let result = coakka_ask_intent_command(
        &dispatcher,
        IntentEnvelope {
            intent_id: "package-intent-1".to_string(),
            source: "tauri-webview".to_string(),
            target: target.to_string(),
            operation: "echo".to_string(),
            payload: json!({"message":"hello-tauri-package"}),
            payload_identity: IntentPayloadIdentity::json("samples.tauri.echo.request.v1", 1),
            timeout_ms: Some(2_000),
            headers: HashMap::new(),
        },
    )?;

    println!(
        "coakka_tauri_package_smoke ok {}",
        serde_json::to_string(&result).unwrap_or_else(|_| "{}".to_string())
    );
    Ok(())
}
