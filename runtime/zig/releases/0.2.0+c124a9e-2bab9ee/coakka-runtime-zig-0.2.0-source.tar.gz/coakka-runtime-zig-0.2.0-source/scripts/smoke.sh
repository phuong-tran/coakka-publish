#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
zig_root="$(cd "${script_dir}/.." && pwd)"

if ! command -v zig >/dev/null 2>&1; then
  echo "[zig-runtime-smoke] skip: zig toolchain not found"
  exit 0
fi

runtime_lib="${COAKKA_RUNTIME_LIB:-}"
if [[ -z "${runtime_lib}" ]]; then
  case "$(uname -s)" in
    Darwin) runtime_lib="${zig_root}/../v2/staging/native/0.2.0+94a5729/macos-aarch64/libcoakka_runtime_v2.dylib" ;;
    Linux)
      case "$(uname -m)" in
        x86_64) runtime_lib="${zig_root}/../v2/staging/native/0.2.0+94a5729/linux-x86_64/libcoakka_runtime_v2.so" ;;
        aarch64|arm64) runtime_lib="${zig_root}/../v2/staging/native/0.2.0+94a5729/linux-aarch64/libcoakka_runtime_v2.so" ;;
        *) echo "[zig-runtime-smoke] unsupported arch: $(uname -m)" >&2; exit 64 ;;
      esac
      ;;
    *) echo "[zig-runtime-smoke] unsupported os: $(uname -s)" >&2; exit 64 ;;
  esac
fi

COAKKA_RUNTIME_LIB="${runtime_lib}" zig build --build-file "${zig_root}/build.zig" smoke
