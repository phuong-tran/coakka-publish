const std = @import("std");

/// Native runtime ABI version expected by this Zig connector source package.
pub const AbiVersion: u32 = 1;

const StatusOk: c_int = 0;
const StatusWouldBlock: c_int = -6;
const StateStarted: c_int = 1;
const RouteStrategySingleOwner: c_int = 1;
const EndpointFlagLocal: u32 = 1 << 0;
const HostHandlesEnableMonitor: u32 = 1 << 0;
const HostHandlesSeparateDeliveredRequestLane: u32 = 1 << 1;
const ClientResultResponse: u32 = 1;
const ClientResultDeadletter: u32 = 2;
const DeliveryHintRouterDefault: u32 = 1;

extern "c" fn close(fd: c_int) c_int;
extern "c" fn usleep(useconds: c_uint) c_int;

/// Opaque native runtime instance owned by RuntimeHost.
pub const Runtime = opaque {};
/// Opaque connector-side ask client used for request/reply matching.
pub const AskClient = opaque {};
/// Opaque ask ticket returned for one pending request.
pub const AskTicket = opaque {};
/// Opaque framed-pipe reader. It does not own the fd passed to native code.
pub const FrameReader = opaque {};

/// Runtime creation config passed to the native C ABI.
pub const RuntimeConfig = extern struct {
    system_name: [*:0]const u8,
    node_id: [*:0]const u8,
    strict_no_drop: c_int,
    queue_capacity: c_int,
};

/// Immutable runtime build and feature information.
pub const RuntimeInfo = extern struct {
    struct_size: usize,
    abi_version: u32,
    feature_flags: u32,
    runtime_version: ?[*:0]const u8,
    git_commit: ?[*:0]const u8,
};

/// Host-owned fd lanes returned by the native runtime.
///
/// Every non-negative fd must be closed by the host. The native runtime does
/// not create a Zig event loop or hidden polling thread.
pub const HostHandles = extern struct {
    struct_size: usize,
    flags: u32,
    request_write_fd: c_int,
    response_read_fd: c_int,
    deadletter_read_fd: c_int,
    control_write_fd: c_int,
    monitor_read_fd: c_int,
    delivered_request_read_fd: c_int,
};

/// Endpoint metadata inside a runtime route snapshot.
///
/// For local endpoints, host/port are diagnostic metadata, not a socket
/// listener owned by this connector.
pub const Endpoint = extern struct {
    host: [*:0]const u8,
    port: u16,
    weight: u32,
    flags: u32,
};

/// Target-to-endpoints route-table entry.
pub const Route = extern struct {
    target: [*:0]const u8,
    strategy: c_int,
    route_key_hint: ?[*:0]const u8,
    flags: u32,
    endpoints: *const Endpoint,
    endpoint_count: usize,
};

/// Complete route snapshot applied under one generation.
pub const ControlSnapshot = extern struct {
    generation: u64,
    routes: *const Route,
    route_count: usize,
};

/// Small stats view used by the Zig source-first smoke lane.
pub const RuntimeStats = extern struct {
    struct_size: usize,
    applied_generation: u64,
    route_count: usize,
    runtime_state: c_int,
};

/// Raw request envelope builder input.
///
/// The native builder copies the provided strings/payload into a returned
/// frame. Release returned buffers with client_bytes_release.
pub const RawRequestSpec = extern struct {
    struct_size: usize,
    message_id: [*:0]const u8,
    source: [*:0]const u8,
    target: [*:0]const u8,
    reply_to: [*:0]const u8,
    payload: [*]const u8,
    payload_len: usize,
    timeout_ms: u32,
    delivery_hint: u32,
    one_way: u32,
};

/// Raw reply envelope builder input built from one delivered request frame.
pub const RawReplySpec = extern struct {
    struct_size: usize,
    request_buf: [*]const u8,
    request_len: usize,
    source: [*:0]const u8,
    payload: [*]const u8,
    payload_len: usize,
};

/// Same-process runtime start spec used by the Zig connector wrapper.
///
/// `host` and `port` are route metadata for diagnostics. A local route does
/// not bind or listen on that address.
pub const StartSpec = struct {
    system_name: [*:0]const u8,
    node_id: [*:0]const u8,
    target: [*:0]const u8,
    host: [*:0]const u8,
    port: u16,
    generation: u64 = 1,
    strict_no_drop: bool = true,
    queue_capacity: c_int = 32,
};

/// Snapshot returned by createSnapshot() for smoke and package verification.
pub const RuntimeSnapshot = struct {
    abi_version: u32,
    runtime_version: []const u8,
    git_commit: []const u8,
    system_name: []const u8,
    node_id: []const u8,
    generation: u64,
    routes: usize,
    state: c_int,
};

const GetInfoFn = *const fn (*RuntimeInfo) callconv(.c) c_int;
const CreateFn = *const fn (*const RuntimeConfig) callconv(.c) ?*Runtime;
const DestroyFn = *const fn (?*Runtime) callconv(.c) void;
const GetHostHandlesFn = *const fn (?*Runtime, *HostHandles) callconv(.c) c_int;
const ApplyControlSnapshotFn = *const fn (?*Runtime, *const ControlSnapshot) callconv(.c) c_int;
const StartFn = *const fn (?*Runtime) callconv(.c) c_int;
const StopFn = *const fn (?*Runtime) callconv(.c) c_int;
const GetStatsFn = *const fn (?*Runtime, *RuntimeStats) callconv(.c) c_int;
const SubmitEnvelopeFn = *const fn (?*Runtime, [*]const u8, usize) callconv(.c) c_int;
const AskClientCreateFn = *const fn (?*Runtime, *const HostHandles) callconv(.c) ?*AskClient;
const AskClientDestroyFn = *const fn (?*AskClient) callconv(.c) void;
const AskClientBeginFn = *const fn (?*AskClient, [*]const u8, usize, *?*AskTicket) callconv(.c) c_int;
const AskTicketAwaitFn = *const fn (?*AskTicket, u32, *u32, *?[*]u8, *usize) callconv(.c) c_int;
const AskTicketDestroyFn = *const fn (?*AskTicket) callconv(.c) void;
const BuildRawRequestFn = *const fn (*const RawRequestSpec, *?[*]u8, *usize) callconv(.c) c_int;
const BuildRawReplyFn = *const fn (*const RawReplySpec, *?[*]u8, *usize) callconv(.c) c_int;
const ClientBytesReleaseFn = *const fn (?[*]u8) callconv(.c) void;
const FrameReaderCreateFn = *const fn (c_int, usize) callconv(.c) ?*FrameReader;
const FrameReaderDestroyFn = *const fn (?*FrameReader) callconv(.c) void;
const FrameReadTryFn = *const fn (?*FrameReader, *?[*]u8, *usize) callconv(.c) c_int;
const FrameReleaseFn = *const fn (?[*]u8) callconv(.c) void;

/// Dynamically loaded native runtime symbol table.
pub const NativeRuntime = struct {
    lib: std.DynLib,
    get_info: GetInfoFn,
    create: CreateFn,
    destroy: DestroyFn,
    get_host_handles: GetHostHandlesFn,
    apply_control_snapshot: ApplyControlSnapshotFn,
    start_runtime: StartFn,
    stop_runtime: StopFn,
    get_stats: GetStatsFn,
    submit_envelope: SubmitEnvelopeFn,
    ask_client_create: AskClientCreateFn,
    ask_client_destroy: AskClientDestroyFn,
    ask_client_begin: AskClientBeginFn,
    ask_ticket_await: AskTicketAwaitFn,
    ask_ticket_destroy: AskTicketDestroyFn,
    build_raw_request: BuildRawRequestFn,
    build_raw_reply: BuildRawReplyFn,
    client_bytes_release: ClientBytesReleaseFn,
    frame_reader_create: FrameReaderCreateFn,
    frame_reader_destroy: FrameReaderDestroyFn,
    frame_read_try: FrameReadTryFn,
    frame_release: FrameReleaseFn,

    /// Opens the native runtime library and resolves the symbols required by this lane.
    pub fn open(path: []const u8) !NativeRuntime {
        var lib = try std.DynLib.open(path);
        errdefer lib.close();

        return .{
            .lib = lib,
            .get_info = lib.lookup(GetInfoFn, "coakka_v2_runtime_get_info") orelse return error.MissingSymbol,
            .create = lib.lookup(CreateFn, "coakka_v2_runtime_create") orelse return error.MissingSymbol,
            .destroy = lib.lookup(DestroyFn, "coakka_v2_runtime_destroy") orelse return error.MissingSymbol,
            .get_host_handles = lib.lookup(GetHostHandlesFn, "coakka_v2_runtime_get_host_handles") orelse return error.MissingSymbol,
            .apply_control_snapshot = lib.lookup(ApplyControlSnapshotFn, "coakka_v2_runtime_apply_control_snapshot") orelse return error.MissingSymbol,
            .start_runtime = lib.lookup(StartFn, "coakka_v2_runtime_start") orelse return error.MissingSymbol,
            .stop_runtime = lib.lookup(StopFn, "coakka_v2_runtime_stop") orelse return error.MissingSymbol,
            .get_stats = lib.lookup(GetStatsFn, "coakka_v2_runtime_get_stats") orelse return error.MissingSymbol,
            .submit_envelope = lib.lookup(SubmitEnvelopeFn, "coakka_v2_runtime_submit_envelope") orelse return error.MissingSymbol,
            .ask_client_create = lib.lookup(AskClientCreateFn, "coakka_v2_ask_client_create") orelse return error.MissingSymbol,
            .ask_client_destroy = lib.lookup(AskClientDestroyFn, "coakka_v2_ask_client_destroy") orelse return error.MissingSymbol,
            .ask_client_begin = lib.lookup(AskClientBeginFn, "coakka_v2_ask_client_begin") orelse return error.MissingSymbol,
            .ask_ticket_await = lib.lookup(AskTicketAwaitFn, "coakka_v2_ask_ticket_await") orelse return error.MissingSymbol,
            .ask_ticket_destroy = lib.lookup(AskTicketDestroyFn, "coakka_v2_ask_ticket_destroy") orelse return error.MissingSymbol,
            .build_raw_request = lib.lookup(BuildRawRequestFn, "coakka_v2_client_build_raw_request") orelse return error.MissingSymbol,
            .build_raw_reply = lib.lookup(BuildRawReplyFn, "coakka_v2_client_build_raw_reply") orelse return error.MissingSymbol,
            .client_bytes_release = lib.lookup(ClientBytesReleaseFn, "coakka_v2_client_bytes_release") orelse return error.MissingSymbol,
            .frame_reader_create = lib.lookup(FrameReaderCreateFn, "coakka_v2_frame_reader_create") orelse return error.MissingSymbol,
            .frame_reader_destroy = lib.lookup(FrameReaderDestroyFn, "coakka_v2_frame_reader_destroy") orelse return error.MissingSymbol,
            .frame_read_try = lib.lookup(FrameReadTryFn, "coakka_v2_frame_read_try") orelse return error.MissingSymbol,
            .frame_release = lib.lookup(FrameReleaseFn, "coakka_v2_frame_release") orelse return error.MissingSymbol,
        };
    }

    /// Closes the dynamic library handle. No RuntimeHost may outlive this call.
    pub fn close(self: *NativeRuntime) void {
        self.lib.close();
    }

    /// Reads runtime info and verifies the expected ABI version.
    pub fn readInfo(self: *NativeRuntime) !RuntimeInfo {
        var info = std.mem.zeroes(RuntimeInfo);
        info.struct_size = @sizeOf(RuntimeInfo);
        if (self.get_info(&info) != StatusOk) return error.NativeCallFailed;
        if (info.abi_version != AbiVersion) return error.UnsupportedAbiVersion;
        return info;
    }

    /// Creates, configures, and starts one same-process runtime host.
    pub fn startHost(self: *NativeRuntime, spec: StartSpec) !RuntimeHost {
        _ = try self.readInfo();
        const config = RuntimeConfig{
            .system_name = spec.system_name,
            .node_id = spec.node_id,
            .strict_no_drop = if (spec.strict_no_drop) 1 else 0,
            .queue_capacity = spec.queue_capacity,
        };
        const runtime = self.create(&config) orelse return error.NativeCallFailed;
        var host = RuntimeHost{
            .native = self,
            .runtime = runtime,
            .handles = initHostHandles(),
            .started = false,
        };
        errdefer host.deinit();

        if (self.get_host_handles(runtime, &host.handles) != StatusOk) {
            return error.NativeCallFailed;
        }
        try host.applySingleLocalRoute(spec);
        if (self.start_runtime(runtime) != StatusOk) {
            return error.NativeCallFailed;
        }
        host.started = true;
        return host;
    }

    /// Starts a smoke host, reads stats/info, and returns a compact snapshot.
    pub fn createSnapshot(self: *NativeRuntime) !RuntimeSnapshot {
        const info = try self.readInfo();
        var host = try self.startHost(smokeSpec());
        defer host.deinit();
        const stats = try host.stats();

        return .{
            .abi_version = info.abi_version,
            .runtime_version = cstr(info.runtime_version),
            .git_commit = cstr(info.git_commit),
            .system_name = std.mem.span(smokeSpec().system_name),
            .node_id = std.mem.span(smokeSpec().node_id),
            .generation = stats.applied_generation,
            .routes = stats.route_count,
            .state = stats.runtime_state,
        };
    }
};

/// Owner of one native runtime instance and its host fd lanes.
pub const RuntimeHost = struct {
    native: *NativeRuntime,
    runtime: ?*Runtime,
    handles: HostHandles,
    started: bool,

    /// Stops the runtime, destroys the native instance, and closes host-owned fds.
    pub fn deinit(self: *RuntimeHost) void {
        if (self.runtime) |runtime| {
            if (self.started) {
                _ = self.native.stop_runtime(runtime);
                self.started = false;
            }
            self.native.destroy(runtime);
            self.runtime = null;
        }
        closeHostHandles(&self.handles);
    }

    /// Reads the runtime stats view used by this connector lane.
    pub fn stats(self: *RuntimeHost) !RuntimeStats {
        var out = std.mem.zeroes(RuntimeStats);
        out.struct_size = @sizeOf(RuntimeStats);
        if (self.native.get_stats(self.runtime, &out) != StatusOk) {
            return error.NativeCallFailed;
        }
        return out;
    }

    /// Proves one local raw request/reply through the delivered-request lane.
    pub fn smokeRawRoundTrip(self: *RuntimeHost) !void {
        if (self.runtime == null or self.handles.delivered_request_read_fd < 0) {
            return error.NativeCallFailed;
        }

        const client = self.native.ask_client_create(self.runtime, &self.handles) orelse return error.NativeCallFailed;
        defer self.native.ask_client_destroy(client);

        const request_payload = "hello";
        var request_spec = RawRequestSpec{
            .struct_size = @sizeOf(RawRequestSpec),
            .message_id = "req-zig-raw-1",
            .source = "zig-client",
            .target = smokeSpec().target,
            .reply_to = "zig-client/replies",
            .payload = request_payload.ptr,
            .payload_len = request_payload.len,
            .timeout_ms = 1000,
            .delivery_hint = DeliveryHintRouterDefault,
            .one_way = 0,
        };
        var request_buf: ?[*]u8 = null;
        var request_len: usize = 0;
        if (self.native.build_raw_request(&request_spec, &request_buf, &request_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(request_buf);
        if (request_buf == null or request_len == 0) return error.NativeCallFailed;

        var ticket: ?*AskTicket = null;
        if (self.native.ask_client_begin(client, request_buf.?, request_len, &ticket) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.ask_ticket_destroy(ticket);

        const reader = self.native.frame_reader_create(self.handles.delivered_request_read_fd, 64 * 1024) orelse return error.NativeCallFailed;
        defer self.native.frame_reader_destroy(reader);

        const delivered_buf = try self.readDeliveredFrame(reader);
        defer self.native.frame_release(delivered_buf.ptr);

        const reply_payload = "reply";
        var reply_spec = RawReplySpec{
            .struct_size = @sizeOf(RawReplySpec),
            .request_buf = delivered_buf.ptr.?,
            .request_len = delivered_buf.len,
            .source = smokeSpec().target,
            .payload = reply_payload.ptr,
            .payload_len = reply_payload.len,
        };
        var reply_buf: ?[*]u8 = null;
        var reply_len: usize = 0;
        if (self.native.build_raw_reply(&reply_spec, &reply_buf, &reply_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(reply_buf);
        if (reply_buf == null or reply_len == 0) return error.NativeCallFailed;

        if (self.native.submit_envelope(self.runtime, reply_buf.?, reply_len) != StatusOk) {
            return error.NativeCallFailed;
        }

        var result_kind: u32 = 0;
        var result_buf: ?[*]u8 = null;
        var result_len: usize = 0;
        if (self.native.ask_ticket_await(ticket, 1000, &result_kind, &result_buf, &result_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(result_buf);
        if (result_kind != ClientResultResponse or result_buf == null or result_len == 0) {
            return error.NativeCallFailed;
        }
    }

    /// Proves a route miss returns a matched deadletter through the ask path.
    pub fn smokeRouteMissDeadletter(self: *RuntimeHost) !void {
        if (self.runtime == null) {
            return error.NativeCallFailed;
        }

        const client = self.native.ask_client_create(self.runtime, &self.handles) orelse return error.NativeCallFailed;
        defer self.native.ask_client_destroy(client);

        const request_payload = "missing";
        var request_spec = RawRequestSpec{
            .struct_size = @sizeOf(RawRequestSpec),
            .message_id = "req-zig-missing-1",
            .source = "zig-client",
            .target = "svc.missing",
            .reply_to = "zig-client/replies",
            .payload = request_payload.ptr,
            .payload_len = request_payload.len,
            .timeout_ms = 1000,
            .delivery_hint = DeliveryHintRouterDefault,
            .one_way = 0,
        };
        var request_buf: ?[*]u8 = null;
        var request_len: usize = 0;
        if (self.native.build_raw_request(&request_spec, &request_buf, &request_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(request_buf);
        if (request_buf == null or request_len == 0) return error.NativeCallFailed;

        var ticket: ?*AskTicket = null;
        if (self.native.ask_client_begin(client, request_buf.?, request_len, &ticket) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.ask_ticket_destroy(ticket);

        var result_kind: u32 = 0;
        var result_buf: ?[*]u8 = null;
        var result_len: usize = 0;
        if (self.native.ask_ticket_await(ticket, 1000, &result_kind, &result_buf, &result_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(result_buf);
        if (result_kind != ClientResultDeadletter or result_buf == null or result_len == 0) {
            return error.NativeCallFailed;
        }
    }

    fn applySingleLocalRoute(self: *RuntimeHost, spec: StartSpec) !void {
        const endpoint = Endpoint{
            .host = spec.host,
            .port = spec.port,
            .weight = 1,
            .flags = EndpointFlagLocal,
        };
        const route = Route{
            .target = spec.target,
            .strategy = RouteStrategySingleOwner,
            .route_key_hint = null,
            .flags = 0,
            .endpoints = &endpoint,
            .endpoint_count = 1,
        };
        const snapshot = ControlSnapshot{
            .generation = spec.generation,
            .routes = &route,
            .route_count = 1,
        };
        if (self.native.apply_control_snapshot(self.runtime, &snapshot) != StatusOk) {
            return error.NativeCallFailed;
        }
    }

    fn readDeliveredFrame(self: *RuntimeHost, reader: *FrameReader) !struct { ptr: ?[*]u8, len: usize } {
        var attempts: usize = 0;
        while (attempts < 1000) : (attempts += 1) {
            var buf: ?[*]u8 = null;
            var len: usize = 0;
            const rc = self.native.frame_read_try(reader, &buf, &len);
            if (rc == StatusOk) {
                if (buf == null or len == 0) return error.NativeCallFailed;
                return .{ .ptr = buf, .len = len };
            }
            if (rc != StatusWouldBlock) {
                return error.NativeCallFailed;
            }
            _ = usleep(1000);
        }
        return error.Timeout;
    }
};

/// Returns the default same-process smoke spec.
pub fn smokeSpec() StartSpec {
    return .{
        .system_name = "zig-runtime-smoke",
        .node_id = "zig-runtime-smoke-node",
        .target = "svc.echo",
        .host = "127.0.0.1",
        .port = 9041,
        .generation = 1,
        .strict_no_drop = true,
        .queue_capacity = 32,
    };
}

/// Creates a same-process local start spec for a single target.
pub fn localStartSpec(system_name: [*:0]const u8, node_id: [*:0]const u8, target: [*:0]const u8) StartSpec {
    return .{
        .system_name = system_name,
        .node_id = node_id,
        .target = target,
        .host = "127.0.0.1",
        .port = 1,
    };
}

/// Returns true when stats show a started runtime with the expected route snapshot.
pub fn isStarted(stats: RuntimeStats, generation: u64, route_count: usize) bool {
    return stats.runtime_state == StateStarted and
        stats.applied_generation == generation and
        stats.route_count == route_count;
}

fn initHostHandles() HostHandles {
    return .{
        .struct_size = @sizeOf(HostHandles),
        .flags = HostHandlesEnableMonitor | HostHandlesSeparateDeliveredRequestLane,
        .request_write_fd = -1,
        .response_read_fd = -1,
        .deadletter_read_fd = -1,
        .control_write_fd = -1,
        .monitor_read_fd = -1,
        .delivered_request_read_fd = -1,
    };
}

fn closeHostHandles(handles: *HostHandles) void {
    closeIfOpen(&handles.request_write_fd);
    closeIfOpen(&handles.response_read_fd);
    closeIfOpen(&handles.deadletter_read_fd);
    closeIfOpen(&handles.control_write_fd);
    closeIfOpen(&handles.monitor_read_fd);
    closeIfOpen(&handles.delivered_request_read_fd);
}

fn closeIfOpen(fd: *c_int) void {
    if (fd.* >= 0) {
        _ = close(fd.*);
        fd.* = -1;
    }
}

fn cstr(value: ?[*:0]const u8) []const u8 {
    if (value) |ptr| return std.mem.span(ptr);
    return "";
}
