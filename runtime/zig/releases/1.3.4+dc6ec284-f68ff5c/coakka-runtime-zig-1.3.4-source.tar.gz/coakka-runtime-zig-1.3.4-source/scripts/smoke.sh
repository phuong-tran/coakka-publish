#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
zig_root="$(cd "${script_dir}/.." && pwd)"
native_package_version="1.3.4+dc6ec284"

if ! command -v zig >/dev/null 2>&1; then
  echo "[zig-runtime-smoke] skip: zig toolchain not found"
  exit 0
fi

runtime_lib="${COAKKA_RUNTIME_LIB:-}"
if [[ -z "${runtime_lib}" ]]; then
  case "$(uname -s)" in
    Darwin)
      if [[ -f "${zig_root}/native/macos-aarch64/libcoakka_runtime_v2-${native_package_version}.dylib" ]]; then
        runtime_lib="${zig_root}/native/macos-aarch64/libcoakka_runtime_v2-${native_package_version}.dylib"
      else
        runtime_lib="${zig_root}/../v2/staging/native/${native_package_version}/macos-aarch64/libcoakka_runtime_v2.dylib"
      fi
      ;;
    Linux)
      case "$(uname -m)" in
        x86_64)
          if [[ -f "${zig_root}/native/linux-x86_64/libcoakka_runtime_v2-${native_package_version}.so" ]]; then
            runtime_lib="${zig_root}/native/linux-x86_64/libcoakka_runtime_v2-${native_package_version}.so"
          else
            runtime_lib="${zig_root}/../v2/staging/native/${native_package_version}/linux-x86_64/libcoakka_runtime_v2.so"
          fi
          ;;
        aarch64|arm64)
          if [[ -f "${zig_root}/native/linux-aarch64/libcoakka_runtime_v2-${native_package_version}.so" ]]; then
            runtime_lib="${zig_root}/native/linux-aarch64/libcoakka_runtime_v2-${native_package_version}.so"
          else
            runtime_lib="${zig_root}/../v2/staging/native/${native_package_version}/linux-aarch64/libcoakka_runtime_v2.so"
          fi
          ;;
        *) echo "[zig-runtime-smoke] unsupported arch: $(uname -m)" >&2; exit 64 ;;
      esac
      ;;
    *) echo "[zig-runtime-smoke] unsupported os: $(uname -s)" >&2; exit 64 ;;
  esac
fi

COAKKA_RUNTIME_LIB="${runtime_lib}" zig build --build-file "${zig_root}/build.zig" smoke
