const std = @import("std");
pub const transport = @import("transport.zig");

/// Native runtime ABI version expected by this Zig connector source package.
pub const AbiVersion: u32 = 1;

const StatusOk: c_int = 0;
const StatusWouldBlock: c_int = -6;
const StateStarted: c_int = 1;
const RouteStrategySingleOwner: c_int = 1;
const EndpointFlagLocal: u32 = 1 << 0;
const HostHandlesEnableMonitor: u32 = 1 << 0;
const HostHandlesSeparateDeliveredRequestLane: u32 = 1 << 1;
const ClientResultResponse: u32 = 1;
const ClientResultDeadletter: u32 = 2;
const DeliveryHintRouterDefault: u32 = 1;

pub const Status = transport.Status;
pub const Capabilities = transport.Capabilities;
pub const TcpConnectionMode = transport.TcpConnectionMode;
pub const TcpSecurityMode = transport.TcpSecurityMode;
pub const TlsReloadMode = transport.TlsReloadMode;
pub const TcpConnectionStrategySpec = transport.TcpConnectionStrategySpec;
pub const TcpSecuritySpec = transport.TcpSecuritySpec;
pub const CapabilitySnapshot = transport.CapabilitySnapshot;
pub const ConnectionConfigSnapshot = transport.ConnectionConfigSnapshot;
pub const ConnectionApplyResult = transport.ConnectionApplyResult;
pub const SecurityInfoSnapshot = transport.SecurityInfoSnapshot;
pub const SecurityApplyResult = transport.SecurityApplyResult;

const PlatformLibrary = opaque {};
extern "c" fn coakka_zig_library_open(
    path: [*:0]const u8,
    error_buf: [*]u8,
    error_buf_len: usize,
) ?*PlatformLibrary;
extern "c" fn coakka_zig_library_close(library: ?*PlatformLibrary) void;
extern "c" fn coakka_zig_library_symbol(
    library: ?*PlatformLibrary,
    name: [*:0]const u8,
) ?*anyopaque;
extern "c" fn coakka_zig_fd_close(fd: c_int) void;
extern "c" fn coakka_zig_sleep_milliseconds(milliseconds: c_uint) void;

var process_library_lock: std.atomic.Mutex = .unlocked;
var process_library: ?*PlatformLibrary = null;
var process_library_path: [4096]u8 = undefined;
var process_library_path_len: usize = 0;
var process_host_active = false;

/// Opaque native runtime instance owned by RuntimeHost.
pub const Runtime = opaque {};
/// Opaque connector-side ask client used for request/reply matching.
pub const AskClient = opaque {};
/// Opaque ask ticket returned for one pending request.
pub const AskTicket = opaque {};
/// Opaque framed-pipe reader. It does not own the fd passed to native code.
pub const FrameReader = opaque {};

/// Runtime creation config passed to the native C ABI.
pub const RuntimeConfig = extern struct {
    system_name: [*:0]const u8,
    node_id: [*:0]const u8,
    strict_no_drop: c_int,
    queue_capacity: c_int,
};

/// Immutable runtime build and feature information.
pub const RuntimeInfo = extern struct {
    struct_size: usize,
    abi_version: u32,
    feature_flags: u32,
    runtime_version: ?[*:0]const u8,
    git_commit: ?[*:0]const u8,
};

/// Host-owned fd lanes returned by the native runtime.
///
/// Every non-negative fd must be closed by the host. The native runtime does
/// not create a Zig event loop or hidden polling thread.
pub const HostHandles = extern struct {
    struct_size: usize,
    flags: u32,
    request_write_fd: c_int,
    response_read_fd: c_int,
    deadletter_read_fd: c_int,
    control_write_fd: c_int,
    monitor_read_fd: c_int,
    delivered_request_read_fd: c_int,
};

/// Endpoint metadata inside a runtime route snapshot.
///
/// For local endpoints, host/port are diagnostic metadata, not a socket
/// listener owned by this connector.
pub const Endpoint = extern struct {
    host: [*:0]const u8,
    port: u16,
    weight: u32,
    flags: u32,
};

/// Target-to-endpoints route-table entry.
pub const Route = extern struct {
    target: [*:0]const u8,
    strategy: c_int,
    route_key_hint: ?[*:0]const u8,
    flags: u32,
    endpoints: *const Endpoint,
    endpoint_count: usize,
};

/// Complete route snapshot applied under one generation.
pub const ControlSnapshot = extern struct {
    generation: u64,
    routes: *const Route,
    route_count: usize,
};

/// Small stats view used by the Zig source-first smoke lane.
pub const RuntimeStats = extern struct {
    struct_size: usize,
    applied_generation: u64,
    route_count: usize,
    runtime_state: c_int,
};

/// Raw request envelope builder input.
///
/// The native builder copies the provided strings/payload into a returned
/// frame. Release returned buffers with client_bytes_release.
pub const RawRequestSpec = extern struct {
    struct_size: usize,
    message_id: [*:0]const u8,
    source: [*:0]const u8,
    target: [*:0]const u8,
    reply_to: [*:0]const u8,
    payload: [*]const u8,
    payload_len: usize,
    timeout_ms: u32,
    delivery_hint: u32,
    one_way: u32,
};

/// Raw reply envelope builder input built from one delivered request frame.
pub const RawReplySpec = extern struct {
    struct_size: usize,
    request_buf: [*]const u8,
    request_len: usize,
    source: [*:0]const u8,
    payload: [*]const u8,
    payload_len: usize,
};

/// Same-process runtime start spec used by the Zig connector wrapper.
///
/// `host` and `port` are route metadata for diagnostics. A local route does
/// not bind or listen on that address.
pub const StartSpec = struct {
    system_name: [*:0]const u8,
    node_id: [*:0]const u8,
    target: [*:0]const u8,
    host: [*:0]const u8,
    port: u16,
    generation: u64 = 1,
    strict_no_drop: bool = true,
    queue_capacity: c_int = 32,
    connection_strategy: ?TcpConnectionStrategySpec = null,
    security: ?TcpSecuritySpec = null,
};

/// Snapshot returned by createSnapshot() for smoke and package verification.
pub const RuntimeSnapshot = struct {
    abi_version: u32,
    runtime_version: []const u8,
    git_commit: []const u8,
    system_name: []const u8,
    node_id: []const u8,
    generation: u64,
    routes: usize,
    state: c_int,
};

/// Result of startup without erasing structured native transport rejection.
pub const StartHostResult = union(enum) {
    started: RuntimeHost,
    connection_rejected: ConnectionApplyResult,
    security_rejected: SecurityApplyResult,
};

const GetAbiVersionFn = *const fn () callconv(.c) u32;
const GetInfoFn = *const fn (*RuntimeInfo) callconv(.c) c_int;
const CreateFn = *const fn (*const RuntimeConfig) callconv(.c) ?*Runtime;
const DestroyFn = *const fn (?*Runtime) callconv(.c) void;
const GetHostHandlesFn = *const fn (?*Runtime, *HostHandles) callconv(.c) c_int;
const ApplyControlSnapshotFn = *const fn (?*Runtime, *const ControlSnapshot) callconv(.c) c_int;
const StartFn = *const fn (?*Runtime) callconv(.c) c_int;
const StopFn = *const fn (?*Runtime) callconv(.c) c_int;
const GetStatsFn = *const fn (?*Runtime, *RuntimeStats) callconv(.c) c_int;
const GetCapabilitiesFn = *const fn (*transport.NativeCapabilities) callconv(.c) c_int;
const ApplyConnectionFn = *const fn (
    ?*Runtime,
    *const transport.NativeConnectionOptions,
    *transport.NativeConnectionApplyResult,
) callconv(.c) c_int;
const GetConnectionConfigFn = *const fn (?*Runtime, *transport.NativeConnectionConfig) callconv(.c) c_int;
const ApplySecurityFn = *const fn (
    ?*Runtime,
    *const transport.NativeSecurityOptions,
    *transport.NativeSecurityApplyResult,
) callconv(.c) c_int;
const GetSecurityInfoFn = *const fn (?*Runtime, *transport.NativeSecurityInfo) callconv(.c) c_int;
const ApplyReasonNameFn = *const fn (u32) callconv(.c) ?[*:0]const u8;
const SubmitEnvelopeFn = *const fn (?*Runtime, [*]const u8, usize) callconv(.c) c_int;
const AskClientCreateFn = *const fn (?*Runtime, *const HostHandles) callconv(.c) ?*AskClient;
const AskClientDestroyFn = *const fn (?*AskClient) callconv(.c) void;
const AskClientBeginFn = *const fn (?*AskClient, [*]const u8, usize, *?*AskTicket) callconv(.c) c_int;
const AskTicketAwaitFn = *const fn (?*AskTicket, u32, *u32, *?[*]u8, *usize) callconv(.c) c_int;
const AskTicketDestroyFn = *const fn (?*AskTicket) callconv(.c) void;
const BuildRawRequestFn = *const fn (*const RawRequestSpec, *?[*]u8, *usize) callconv(.c) c_int;
const BuildRawReplyFn = *const fn (*const RawReplySpec, *?[*]u8, *usize) callconv(.c) c_int;
const ClientBytesReleaseFn = *const fn (?[*]u8) callconv(.c) void;
const FrameReaderCreateFn = *const fn (c_int, usize) callconv(.c) ?*FrameReader;
const FrameReaderDestroyFn = *const fn (?*FrameReader) callconv(.c) void;
const FrameReadTryFn = *const fn (?*FrameReader, *?[*]u8, *usize) callconv(.c) c_int;
const FrameReleaseFn = *const fn (?[*]u8) callconv(.c) void;

/// Dynamically loaded native runtime symbol table.
pub const NativeRuntime = struct {
    lib: *PlatformLibrary,
    get_abi_version: GetAbiVersionFn,
    get_info: GetInfoFn,
    create: CreateFn,
    destroy: DestroyFn,
    get_host_handles: GetHostHandlesFn,
    apply_control_snapshot: ApplyControlSnapshotFn,
    start_runtime: StartFn,
    stop_runtime: StopFn,
    get_stats: GetStatsFn,
    get_capabilities: GetCapabilitiesFn,
    apply_connection: ApplyConnectionFn,
    get_connection_config: GetConnectionConfigFn,
    apply_security: ApplySecurityFn,
    get_security_info: GetSecurityInfoFn,
    apply_reason_name: ApplyReasonNameFn,
    submit_envelope: SubmitEnvelopeFn,
    ask_client_create: AskClientCreateFn,
    ask_client_destroy: AskClientDestroyFn,
    ask_client_begin: AskClientBeginFn,
    ask_ticket_await: AskTicketAwaitFn,
    ask_ticket_destroy: AskTicketDestroyFn,
    build_raw_request: BuildRawRequestFn,
    build_raw_reply: BuildRawReplyFn,
    client_bytes_release: ClientBytesReleaseFn,
    frame_reader_create: FrameReaderCreateFn,
    frame_reader_destroy: FrameReaderDestroyFn,
    frame_read_try: FrameReadTryFn,
    frame_release: FrameReleaseFn,

    /// Opens the native runtime library and resolves the symbols required by this lane.
    pub fn open(path: []const u8) !NativeRuntime {
        if (path.len == 0 or path.len >= process_library_path.len) {
            return error.InvalidRuntimeLibraryPath;
        }
        lockProcessLibrary();
        defer process_library_lock.unlock();

        if (process_library) |library| {
            if (!std.mem.eql(u8, process_library_path[0..process_library_path_len], path)) {
                return error.DifferentRuntimeLibraryAlreadyLoaded;
            }
            const out = try resolveSymbols(library);
            if (out.get_abi_version() != AbiVersion) return error.UnsupportedAbiVersion;
            return out;
        }

        var path_z: [4096:0]u8 = undefined;
        @memcpy(path_z[0..path.len], path);
        path_z[path.len] = 0;
        var error_buf = [_]u8{0} ** 512;
        const library = coakka_zig_library_open(&path_z, &error_buf, error_buf.len) orelse {
            return error.NativeLibraryLoadFailed;
        };
        errdefer coakka_zig_library_close(library);
        const out = try resolveSymbols(library);
        if (out.get_abi_version() != AbiVersion) return error.UnsupportedAbiVersion;
        @memcpy(process_library_path[0..path.len], path);
        process_library_path_len = path.len;
        process_library = library;
        return out;
    }

    fn resolveSymbols(lib: *PlatformLibrary) !NativeRuntime {
        return .{
            .lib = lib,
            .get_abi_version = try lookupSymbol(lib, GetAbiVersionFn, "coakka_v2_runtime_get_abi_version"),
            .get_info = try lookupSymbol(lib, GetInfoFn, "coakka_v2_runtime_get_info"),
            .create = try lookupSymbol(lib, CreateFn, "coakka_v2_runtime_create"),
            .destroy = try lookupSymbol(lib, DestroyFn, "coakka_v2_runtime_destroy"),
            .get_host_handles = try lookupSymbol(lib, GetHostHandlesFn, "coakka_v2_runtime_get_host_handles"),
            .apply_control_snapshot = try lookupSymbol(lib, ApplyControlSnapshotFn, "coakka_v2_runtime_apply_control_snapshot"),
            .start_runtime = try lookupSymbol(lib, StartFn, "coakka_v2_runtime_start"),
            .stop_runtime = try lookupSymbol(lib, StopFn, "coakka_v2_runtime_stop"),
            .get_stats = try lookupSymbol(lib, GetStatsFn, "coakka_v2_runtime_get_stats"),
            .get_capabilities = try lookupSymbol(lib, GetCapabilitiesFn, "coakka_v2_runtime_get_capabilities"),
            .apply_connection = try lookupSymbol(lib, ApplyConnectionFn, "coakka_v2_runtime_apply_tcp_connection_options_ex"),
            .get_connection_config = try lookupSymbol(lib, GetConnectionConfigFn, "coakka_v2_runtime_get_tcp_connection_config"),
            .apply_security = try lookupSymbol(lib, ApplySecurityFn, "coakka_v2_runtime_apply_tcp_security_options_ex"),
            .get_security_info = try lookupSymbol(lib, GetSecurityInfoFn, "coakka_v2_runtime_get_tcp_security_info"),
            .apply_reason_name = try lookupSymbol(lib, ApplyReasonNameFn, "coakka_v2_transport_apply_reason_name"),
            .submit_envelope = try lookupSymbol(lib, SubmitEnvelopeFn, "coakka_v2_runtime_submit_envelope"),
            .ask_client_create = try lookupSymbol(lib, AskClientCreateFn, "coakka_v2_ask_client_create"),
            .ask_client_destroy = try lookupSymbol(lib, AskClientDestroyFn, "coakka_v2_ask_client_destroy"),
            .ask_client_begin = try lookupSymbol(lib, AskClientBeginFn, "coakka_v2_ask_client_begin"),
            .ask_ticket_await = try lookupSymbol(lib, AskTicketAwaitFn, "coakka_v2_ask_ticket_await"),
            .ask_ticket_destroy = try lookupSymbol(lib, AskTicketDestroyFn, "coakka_v2_ask_ticket_destroy"),
            .build_raw_request = try lookupSymbol(lib, BuildRawRequestFn, "coakka_v2_client_build_raw_request"),
            .build_raw_reply = try lookupSymbol(lib, BuildRawReplyFn, "coakka_v2_client_build_raw_reply"),
            .client_bytes_release = try lookupSymbol(lib, ClientBytesReleaseFn, "coakka_v2_client_bytes_release"),
            .frame_reader_create = try lookupSymbol(lib, FrameReaderCreateFn, "coakka_v2_frame_reader_create"),
            .frame_reader_destroy = try lookupSymbol(lib, FrameReaderDestroyFn, "coakka_v2_frame_reader_destroy"),
            .frame_read_try = try lookupSymbol(lib, FrameReadTryFn, "coakka_v2_frame_read_try"),
            .frame_release = try lookupSymbol(lib, FrameReleaseFn, "coakka_v2_frame_release"),
        };
    }

    /// Releases this value; the first native module stays loaded for process lifetime.
    pub fn close(self: *NativeRuntime) void {
        _ = self;
    }

    /// Reads runtime info and verifies the expected ABI version.
    pub fn readInfo(self: *NativeRuntime) !RuntimeInfo {
        var info = std.mem.zeroes(RuntimeInfo);
        info.struct_size = @sizeOf(RuntimeInfo);
        if (self.get_info(&info) != StatusOk) return error.NativeCallFailed;
        if (info.abi_version != AbiVersion) return error.UnsupportedAbiVersion;
        return info;
    }

    /// Copies capability and edition truth before or during host lifecycle.
    ///
    /// This synchronous call is available in every edition and does not infer
    /// support from package metadata.
    pub fn readCapabilities(self: *NativeRuntime) !CapabilitySnapshot {
        var native = std.mem.zeroes(transport.NativeCapabilities);
        native.struct_size = @sizeOf(transport.NativeCapabilities);
        if (self.get_capabilities(&native) != StatusOk) {
            return error.NativeCallFailed;
        }
        return transport.capabilitySnapshot(native);
    }

    /// Creates and atomically configures one host before exporting handles/start.
    ///
    /// The returned union retains a structured connection/security rejection.
    /// Credential loading is synchronous and may block on file I/O.
    pub fn startHost(self: *NativeRuntime, spec: StartSpec) !StartHostResult {
        _ = try self.readInfo();
        lockProcessLibrary();
        if (process_host_active) {
            process_library_lock.unlock();
            return error.RuntimeHostAlreadyActive;
        }
        process_host_active = true;
        process_library_lock.unlock();
        const config = RuntimeConfig{
            .system_name = spec.system_name,
            .node_id = spec.node_id,
            .strict_no_drop = if (spec.strict_no_drop) 1 else 0,
            .queue_capacity = spec.queue_capacity,
        };
        const runtime = self.create(&config) orelse {
            releaseActiveHost();
            return error.NativeCallFailed;
        };
        var host = RuntimeHost{
            .native = self,
            .runtime = runtime,
            .handles = initHostHandles(),
            .start_attempted = false,
            .transport_lock = .unlocked,
            .startup_connection_result = null,
            .startup_security_result = null,
            .owns_active_slot = true,
        };
        errdefer host.deinit();

        if (spec.connection_strategy) |connection| {
            const result = try host.applyConnectionStrategy(connection);
            host.startup_connection_result = result;
            if (!result.applied()) {
                host.deinit();
                return .{ .connection_rejected = result };
            }
        }
        if (spec.security) |security| {
            const result = try host.applySecurity(security);
            host.startup_security_result = result;
            if (!result.applied()) {
                host.deinit();
                return .{ .security_rejected = result };
            }
        }
        try host.applySingleLocalRoute(spec);
        if (self.get_host_handles(runtime, &host.handles) != StatusOk) {
            return error.NativeCallFailed;
        }
        host.start_attempted = true;
        if (self.start_runtime(runtime) != StatusOk) {
            return error.NativeCallFailed;
        }
        return .{ .started = host };
    }

    /// Starts a smoke host, reads stats/info, and returns a compact snapshot.
    pub fn createSnapshot(self: *NativeRuntime) !RuntimeSnapshot {
        const info = try self.readInfo();
        var host = switch (try self.startHost(smokeSpec())) {
            .started => |started| started,
            else => return error.TransportConfigurationRejected,
        };
        defer host.deinit();
        const stats = try host.stats();

        return .{
            .abi_version = info.abi_version,
            .runtime_version = cstr(info.runtime_version),
            .git_commit = cstr(info.git_commit),
            .system_name = std.mem.span(smokeSpec().system_name),
            .node_id = std.mem.span(smokeSpec().node_id),
            .generation = stats.applied_generation,
            .routes = stats.route_count,
            .state = stats.runtime_state,
        };
    }
};

/// Owner of one native runtime instance and its host fd lanes.
pub const RuntimeHost = struct {
    native: *NativeRuntime,
    runtime: ?*Runtime,
    handles: HostHandles,
    start_attempted: bool,
    transport_lock: std.atomic.Mutex,
    startup_connection_result: ?ConnectionApplyResult,
    startup_security_result: ?SecurityApplyResult,
    owns_active_slot: bool,

    /// Stops the runtime, destroys the native instance, and closes host-owned fds.
    pub fn deinit(self: *RuntimeHost) void {
        self.lockTransport();
        defer self.transport_lock.unlock();
        if (self.runtime) |runtime| {
            if (self.start_attempted) {
                _ = self.native.stop_runtime(runtime);
                self.start_attempted = false;
            }
            closeHostHandles(&self.handles);
            self.native.destroy(runtime);
            self.runtime = null;
        }
        closeHostHandles(&self.handles);
        if (self.owns_active_slot) {
            self.owns_active_slot = false;
            releaseActiveHost();
        }
    }

    /// Copies compiled, entitled, and effective capabilities for this module.
    ///
    /// The call is synchronous, serialized with apply/teardown, available in
    /// every edition, and returns owned numeric data only.
    pub fn capabilities(self: *RuntimeHost) !CapabilitySnapshot {
        self.lockTransport();
        defer self.transport_lock.unlock();
        if (self.runtime == null) return error.RuntimeClosed;
        return try self.native.readCapabilities();
    }

    /// Copies the effective connection policy and default provenance.
    pub fn connectionConfig(self: *RuntimeHost) !ConnectionConfigSnapshot {
        self.lockTransport();
        defer self.transport_lock.unlock();
        const runtime = self.runtime orelse return error.RuntimeClosed;
        var native = std.mem.zeroes(transport.NativeConnectionConfig);
        native.struct_size = @sizeOf(transport.NativeConnectionConfig);
        if (self.native.get_connection_config(runtime, &native) != StatusOk) {
            return error.NativeCallFailed;
        }
        return transport.connectionConfig(native);
    }

    /// Copies active non-secret TLS/mTLS identity and generation metadata.
    pub fn securityInfo(self: *RuntimeHost) !SecurityInfoSnapshot {
        self.lockTransport();
        defer self.transport_lock.unlock();
        const runtime = self.runtime orelse return error.RuntimeClosed;
        var native = std.mem.zeroes(transport.NativeSecurityInfo);
        native.struct_size = @sizeOf(transport.NativeSecurityInfo);
        if (self.native.get_security_info(runtime, &native) != StatusOk) {
            return error.NativeCallFailed;
        }
        return transport.securityInfo(native);
    }

    /// Attempts an atomic startup-shaped connection apply.
    ///
    /// Nil tuning fields preserve core defaults. The call is synchronous and
    /// serialized with transport getters/teardown. After start, core normally
    /// returns `bad_state` with the unchanged active config.
    pub fn applyConnectionStrategy(
        self: *RuntimeHost,
        spec: TcpConnectionStrategySpec,
    ) !ConnectionApplyResult {
        self.lockTransport();
        defer self.transport_lock.unlock();
        const runtime = self.runtime orelse return error.RuntimeClosed;
        var options = transport.connectionOptions(spec);
        var native = std.mem.zeroes(transport.NativeConnectionApplyResult);
        native.struct_size = @sizeOf(transport.NativeConnectionApplyResult);
        const status = self.native.apply_connection(runtime, &options, &native);
        if (status != native.apply_status) return error.ApplyStatusMismatch;
        return transport.connectionResult(native, self.native.apply_reason_name(native.reason));
    }

    /// Applies startup security or reloads newer same-mode TLS credentials.
    ///
    /// Sentinel strings are borrowed only during this synchronous call; file
    /// loading may block. Invalid/stale material leaves active state unchanged.
    pub fn applySecurity(self: *RuntimeHost, spec: TcpSecuritySpec) !SecurityApplyResult {
        self.lockTransport();
        defer self.transport_lock.unlock();
        const runtime = self.runtime orelse return error.RuntimeClosed;
        var options = try transport.securityOptions(spec);
        var native = std.mem.zeroes(transport.NativeSecurityApplyResult);
        native.struct_size = @sizeOf(transport.NativeSecurityApplyResult);
        const status = self.native.apply_security(runtime, &options, &native);
        if (status != native.apply_status) return error.ApplyStatusMismatch;
        return transport.securityResult(native, self.native.apply_reason_name(native.reason));
    }

    fn lockTransport(self: *RuntimeHost) void {
        while (!self.transport_lock.tryLock()) std.atomic.spinLoopHint();
    }

    /// Reads the runtime stats view used by this connector lane.
    pub fn stats(self: *RuntimeHost) !RuntimeStats {
        var out = std.mem.zeroes(RuntimeStats);
        out.struct_size = @sizeOf(RuntimeStats);
        if (self.native.get_stats(self.runtime, &out) != StatusOk) {
            return error.NativeCallFailed;
        }
        return out;
    }

    /// Proves one local raw request/reply through the delivered-request lane.
    pub fn smokeRawRoundTrip(self: *RuntimeHost) !void {
        if (self.runtime == null or self.handles.delivered_request_read_fd < 0) {
            return error.NativeCallFailed;
        }

        const client = self.native.ask_client_create(self.runtime, &self.handles) orelse return error.NativeCallFailed;
        defer self.native.ask_client_destroy(client);

        const request_payload = "hello";
        var request_spec = RawRequestSpec{
            .struct_size = @sizeOf(RawRequestSpec),
            .message_id = "req-zig-raw-1",
            .source = "zig-client",
            .target = smokeSpec().target,
            .reply_to = "zig-client/replies",
            .payload = request_payload.ptr,
            .payload_len = request_payload.len,
            .timeout_ms = 1000,
            .delivery_hint = DeliveryHintRouterDefault,
            .one_way = 0,
        };
        var request_buf: ?[*]u8 = null;
        var request_len: usize = 0;
        if (self.native.build_raw_request(&request_spec, &request_buf, &request_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(request_buf);
        if (request_buf == null or request_len == 0) return error.NativeCallFailed;

        var ticket: ?*AskTicket = null;
        if (self.native.ask_client_begin(client, request_buf.?, request_len, &ticket) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.ask_ticket_destroy(ticket);

        const reader = self.native.frame_reader_create(self.handles.delivered_request_read_fd, 64 * 1024) orelse return error.NativeCallFailed;
        defer self.native.frame_reader_destroy(reader);

        const delivered_buf = try self.readDeliveredFrame(reader);
        defer self.native.frame_release(delivered_buf.ptr);

        const reply_payload = "reply";
        var reply_spec = RawReplySpec{
            .struct_size = @sizeOf(RawReplySpec),
            .request_buf = delivered_buf.ptr.?,
            .request_len = delivered_buf.len,
            .source = smokeSpec().target,
            .payload = reply_payload.ptr,
            .payload_len = reply_payload.len,
        };
        var reply_buf: ?[*]u8 = null;
        var reply_len: usize = 0;
        if (self.native.build_raw_reply(&reply_spec, &reply_buf, &reply_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(reply_buf);
        if (reply_buf == null or reply_len == 0) return error.NativeCallFailed;

        if (self.native.submit_envelope(self.runtime, reply_buf.?, reply_len) != StatusOk) {
            return error.NativeCallFailed;
        }

        var result_kind: u32 = 0;
        var result_buf: ?[*]u8 = null;
        var result_len: usize = 0;
        if (self.native.ask_ticket_await(ticket, 1000, &result_kind, &result_buf, &result_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(result_buf);
        if (result_kind != ClientResultResponse or result_buf == null or result_len == 0) {
            return error.NativeCallFailed;
        }
    }

    /// Proves a route miss returns a matched deadletter through the ask path.
    pub fn smokeRouteMissDeadletter(self: *RuntimeHost) !void {
        if (self.runtime == null) {
            return error.NativeCallFailed;
        }

        const client = self.native.ask_client_create(self.runtime, &self.handles) orelse return error.NativeCallFailed;
        defer self.native.ask_client_destroy(client);

        const request_payload = "missing";
        var request_spec = RawRequestSpec{
            .struct_size = @sizeOf(RawRequestSpec),
            .message_id = "req-zig-missing-1",
            .source = "zig-client",
            .target = "svc.missing",
            .reply_to = "zig-client/replies",
            .payload = request_payload.ptr,
            .payload_len = request_payload.len,
            .timeout_ms = 1000,
            .delivery_hint = DeliveryHintRouterDefault,
            .one_way = 0,
        };
        var request_buf: ?[*]u8 = null;
        var request_len: usize = 0;
        if (self.native.build_raw_request(&request_spec, &request_buf, &request_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(request_buf);
        if (request_buf == null or request_len == 0) return error.NativeCallFailed;

        var ticket: ?*AskTicket = null;
        if (self.native.ask_client_begin(client, request_buf.?, request_len, &ticket) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.ask_ticket_destroy(ticket);

        var result_kind: u32 = 0;
        var result_buf: ?[*]u8 = null;
        var result_len: usize = 0;
        if (self.native.ask_ticket_await(ticket, 1000, &result_kind, &result_buf, &result_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(result_buf);
        if (result_kind != ClientResultDeadletter or result_buf == null or result_len == 0) {
            return error.NativeCallFailed;
        }
    }

    fn applySingleLocalRoute(self: *RuntimeHost, spec: StartSpec) !void {
        const endpoint = Endpoint{
            .host = spec.host,
            .port = spec.port,
            .weight = 1,
            .flags = EndpointFlagLocal,
        };
        const route = Route{
            .target = spec.target,
            .strategy = RouteStrategySingleOwner,
            .route_key_hint = null,
            .flags = 0,
            .endpoints = &endpoint,
            .endpoint_count = 1,
        };
        const snapshot = ControlSnapshot{
            .generation = spec.generation,
            .routes = &route,
            .route_count = 1,
        };
        if (self.native.apply_control_snapshot(self.runtime, &snapshot) != StatusOk) {
            return error.NativeCallFailed;
        }
    }

    fn readDeliveredFrame(self: *RuntimeHost, reader: *FrameReader) !struct { ptr: ?[*]u8, len: usize } {
        var attempts: usize = 0;
        while (attempts < 1000) : (attempts += 1) {
            var buf: ?[*]u8 = null;
            var len: usize = 0;
            const rc = self.native.frame_read_try(reader, &buf, &len);
            if (rc == StatusOk) {
                if (buf == null or len == 0) return error.NativeCallFailed;
                return .{ .ptr = buf, .len = len };
            }
            if (rc != StatusWouldBlock) {
                return error.NativeCallFailed;
            }
            coakka_zig_sleep_milliseconds(1);
        }
        return error.Timeout;
    }
};

/// Returns the default same-process smoke spec.
pub fn smokeSpec() StartSpec {
    return .{
        .system_name = "zig-runtime-smoke",
        .node_id = "zig-runtime-smoke-node",
        .target = "svc.echo",
        .host = "127.0.0.1",
        .port = 9041,
        .generation = 1,
        .strict_no_drop = true,
        .queue_capacity = 32,
    };
}

/// Creates a same-process local start spec for a single target.
pub fn localStartSpec(system_name: [*:0]const u8, node_id: [*:0]const u8, target: [*:0]const u8) StartSpec {
    return .{
        .system_name = system_name,
        .node_id = node_id,
        .target = target,
        .host = "127.0.0.1",
        .port = 1,
    };
}

/// Returns true when stats show a started runtime with the expected route snapshot.
pub fn isStarted(stats: RuntimeStats, generation: u64, route_count: usize) bool {
    return stats.runtime_state == StateStarted and
        stats.applied_generation == generation and
        stats.route_count == route_count;
}

fn initHostHandles() HostHandles {
    return .{
        .struct_size = @sizeOf(HostHandles),
        .flags = HostHandlesEnableMonitor | HostHandlesSeparateDeliveredRequestLane,
        .request_write_fd = -1,
        .response_read_fd = -1,
        .deadletter_read_fd = -1,
        .control_write_fd = -1,
        .monitor_read_fd = -1,
        .delivered_request_read_fd = -1,
    };
}

fn closeHostHandles(handles: *HostHandles) void {
    const values = [_]c_int{
        handles.request_write_fd,
        handles.response_read_fd,
        handles.deadletter_read_fd,
        handles.control_write_fd,
        handles.monitor_read_fd,
        handles.delivered_request_read_fd,
    };
    for (values, 0..) |fd, index| {
        if (fd >= 0) {
            var duplicate = false;
            for (values[0..index]) |previous| {
                if (previous == fd) duplicate = true;
            }
            if (!duplicate) coakka_zig_fd_close(fd);
        }
    }
    handles.request_write_fd = -1;
    handles.response_read_fd = -1;
    handles.deadletter_read_fd = -1;
    handles.control_write_fd = -1;
    handles.monitor_read_fd = -1;
    handles.delivered_request_read_fd = -1;
}

fn cstr(value: ?[*:0]const u8) []const u8 {
    if (value) |ptr| return std.mem.span(ptr);
    return "";
}

fn lockProcessLibrary() void {
    while (!process_library_lock.tryLock()) std.atomic.spinLoopHint();
}

fn releaseActiveHost() void {
    lockProcessLibrary();
    process_host_active = false;
    process_library_lock.unlock();
}

fn lookupSymbol(
    library: *PlatformLibrary,
    comptime Symbol: type,
    name: [:0]const u8,
) !Symbol {
    const symbol = coakka_zig_library_symbol(library, name.ptr) orelse return error.MissingSymbol;
    return @ptrCast(@alignCast(symbol));
}
