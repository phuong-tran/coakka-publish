const std = @import("std");
const runtime = @import("runtime.zig");

fn require(condition: bool, message: []const u8) !void {
    if (!condition) {
        std.debug.print("zig transport smoke failed: {s}\n", .{message});
        return error.TransportSmokeFailed;
    }
}

fn takeStarted(result: runtime.StartHostResult) !runtime.RuntimeHost {
    return switch (result) {
        .started => |host| host,
        .connection_rejected => error.UnexpectedConnectionRejection,
        .security_rejected => error.UnexpectedSecurityRejection,
    };
}

fn verifyEmbeddedNul(native: *runtime.NativeRuntime) !void {
    var spec = runtime.smokeSpec();
    spec.security = .{ .credential_id = "truncated\x00credential" };
    const result = native.startHost(spec) catch |err| {
        if (err == error.EmbeddedNul) return;
        return err;
    };
    var host = try takeStarted(result);
    host.deinit();
    return error.EmbeddedNulWasAccepted;
}

fn pathZ(buffer: []u8, root: []const u8, name: []const u8) ![:0]u8 {
    return try std.fmt.bufPrintZ(buffer, "{s}/{s}", .{ root, name });
}

pub fn main(init: std.process.Init) !void {
    const lib_path = init.environ_map.get("COAKKA_RUNTIME_LIB") orelse {
        std.debug.print("set COAKKA_RUNTIME_LIB=/path/to/libcoakka_runtime_v2\n", .{});
        return error.MissingRuntimeLibraryPath;
    };

    const sizes = runtime.transport.abiSizes();
    try require(sizes.capabilities == 48, "capabilities ABI size");
    try require(sizes.connection_options == 48, "connection options ABI size");
    try require(sizes.connection_validation == 40, "connection validation ABI size");
    try require(sizes.connection_config == 72, "connection config ABI size");
    try require(sizes.connection_apply_result == 136, "connection result ABI size");
    try require(sizes.security_options == 72, "security options ABI size");
    try require(sizes.security_validation == 24, "security validation ABI size");
    try require(sizes.security_config == 40, "security config ABI size");
    try require(sizes.security_identity == 248, "security identity ABI size");
    try require(sizes.security_info == 296, "security info ABI size");
    try require(sizes.security_apply_result == 344, "security result ABI size");

    var native = try runtime.NativeRuntime.open(lib_path);
    defer native.close();
    const info = try native.readInfo();
    const capabilities = try native.readCapabilities();
    const mode: runtime.TcpConnectionMode = if (capabilities.effective.supports(.tcp_bounded_pool))
        .bounded_pool
    else
        .per_exchange;

    var invalid_mode_spec = runtime.smokeSpec();
    invalid_mode_spec.connection_strategy = .{ .mode = .{ .value = 999 } };
    switch (try native.startHost(invalid_mode_spec)) {
        .connection_rejected => |result| {
            try require(result.status.eql(.invalid_argument), "unknown mode status");
            try require(result.validation_code.value == 4, "unknown mode validation");
            try require(result.active_config.mode.eql(.per_exchange), "unknown mode changed config");
        },
        .started => |value| {
            var host = value;
            host.deinit();
            return error.UnknownModeWasAccepted;
        },
        .security_rejected => return error.UnexpectedSecurityRejection,
    }

    var plaintext_fields_spec = runtime.smokeSpec();
    plaintext_fields_spec.security = .{
        .credential_generation = 1,
        .credential_id = "must-not-be-ignored",
    };
    switch (try native.startHost(plaintext_fields_spec)) {
        .security_rejected => |result| {
            try require(result.status.eql(.invalid_argument), "plaintext field status");
            try require(result.validation_code.value == 7, "plaintext field validation");
            try require(result.active_security.credential_generation == 0, "plaintext rejection state");
        },
        .started => |value| {
            var host = value;
            host.deinit();
            return error.PlaintextFieldsWereAccepted;
        },
        .connection_rejected => return error.UnexpectedConnectionRejection,
    }

    try verifyEmbeddedNul(&native);

    {
        var configured_spec = runtime.smokeSpec();
        configured_spec.connection_strategy = .{ .mode = mode };
        configured_spec.security = .{};
        var host = try takeStarted(try native.startHost(configured_spec));
        defer host.deinit();

        const stats = try host.stats();
        try require(runtime.isStarted(stats, 1, 1), "runtime stats");
        try require((try host.capabilities()).effective.value == capabilities.effective.value, "capabilities");
        try require(host.startup_connection_result != null, "connection startup result");
        try require(host.startup_connection_result.?.applied(), "connection startup apply");
        try require(host.startup_security_result != null, "security startup result");
        try require(host.startup_security_result.?.applied(), "security startup apply");
        try require((try host.connectionConfig()).mode.eql(mode), "effective connection mode");

        const rejected = try host.applyConnectionStrategy(.{});
        try require(rejected.status.eql(.bad_state), "post-start connection status");
        try require(!rejected.changed, "post-start connection changed state");
        try require(rejected.active_config.mode.eql(mode), "post-start active mode");
        try host.smokeRawRoundTrip();
        try host.smokeRouteMissDeadletter();
    }

    var tls_executed = false;
    if (capabilities.effective.supports(.tcp_tls)) {
        if (init.environ_map.get("COAKKA_TLS_FIXTURE_ROOT")) |fixture_root| {
            var ca_buffer: [4096]u8 = undefined;
            var cert_buffer: [4096]u8 = undefined;
            var server_key_buffer: [4096]u8 = undefined;
            var client_key_buffer: [4096]u8 = undefined;
            const ca_file = try pathZ(&ca_buffer, fixture_root, "ca.pem");
            const cert_file = try pathZ(&cert_buffer, fixture_root, "server.pem");
            const server_key = try pathZ(&server_key_buffer, fixture_root, "server.key");
            const client_key = try pathZ(&client_key_buffer, fixture_root, "client.key");

            var tls_spec = runtime.smokeSpec();
            tls_spec.security = .{
                .mode = .tls,
                .credential_generation = 1,
                .credential_id = "zig-generation-1",
                .ca_certificate_file = ca_file,
                .identity_certificate_file = cert_file,
                .private_key_file = server_key,
            };
            var host = try takeStarted(try native.startHost(tls_spec));
            defer host.deinit();

            const startup = host.startup_security_result orelse return error.MissingTlsStartupResult;
            try require(startup.applied(), "TLS startup status");
            try require(startup.active_security.credential_generation == 1, "TLS startup generation");
            try require(startup.active_security.identity_fingerprint_sha256.slice().len == 64, "TLS fingerprint");

            const bad_reload = try host.applySecurity(.{
                .mode = .tls,
                .credential_generation = 2,
                .credential_id = "zig-generation-2-bad",
                .ca_certificate_file = ca_file,
                .identity_certificate_file = cert_file,
                .private_key_file = client_key,
            });
            try require(bad_reload.status.eql(.invalid_argument), "bad TLS reload status");
            try require(!bad_reload.changed, "bad TLS reload changed state");
            try require(bad_reload.active_security.credential_generation == 1, "bad TLS reload generation");
            try require((try host.securityInfo()).credential_generation == 1, "TLS getter after rejection");

            const applied = try host.applySecurity(.{
                .mode = .tls,
                .credential_generation = 2,
                .credential_id = "zig-generation-2",
                .ca_certificate_file = ca_file,
                .identity_certificate_file = cert_file,
                .private_key_file = server_key,
            });
            try require(applied.applied() and applied.changed, "valid TLS reload status");
            try require(applied.active_security.credential_generation == 2, "valid TLS generation");

            const stale = try host.applySecurity(.{
                .mode = .tls,
                .credential_generation = 1,
                .credential_id = "zig-generation-1-stale",
                .ca_certificate_file = ca_file,
                .identity_certificate_file = cert_file,
                .private_key_file = server_key,
            });
            try require(stale.status.eql(.invalid_argument), "stale TLS status");
            try require(!stale.changed, "stale TLS changed state");
            try require(stale.active_security.credential_generation == 2, "stale TLS generation");
            tls_executed = true;
        }
    }

    std.debug.print(
        "coakka_runtime_zig_smoke abi={d} runtime={s} git={s} capabilities={d} mode={d} tls_executed={} rawRoundTrip=ok routeMissDeadletter=ok\n",
        .{
            info.abi_version,
            cstr(info.runtime_version),
            cstr(info.git_commit),
            capabilities.effective.value,
            mode.value,
            tls_executed,
        },
    );
}

fn cstr(value: ?[*:0]const u8) []const u8 {
    if (value) |ptr| return std.mem.span(ptr);
    return "";
}
