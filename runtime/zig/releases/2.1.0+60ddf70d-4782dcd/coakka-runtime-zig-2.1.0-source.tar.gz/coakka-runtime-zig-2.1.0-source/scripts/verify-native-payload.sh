#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
zig_root="$(cd "${script_dir}/.." && pwd)"
native_root="${zig_root}/native"

sha256_file() {
  if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print $1}';
  else sha256sum "$1" | awk '{print $1}'; fi
}

verify() {
  local relative="$1" expected="$2" format="$3"
  local path="${native_root}/${relative}"
  [[ -f "${path}" ]] || { echo "[zig-verify-native] missing ${relative}" >&2; exit 1; }
  [[ "$(sha256_file "${path}")" == "${expected}" ]] || {
    echo "[zig-verify-native] digest mismatch ${relative}" >&2; exit 1;
  }
  file "${path}" | grep -Eq "${format}" || {
    echo "[zig-verify-native] format mismatch ${relative}" >&2; exit 1;
  }
}

verify "macos-aarch64/libcoakka_runtime_v2.dylib" \
  "e95cda46cd8e5d31633d005bb8af9093b2a93c9c2d0cefc90148e188f31da6d7" \
  "Mach-O 64-bit dynamically linked shared library arm64"
verify "linux-aarch64/libcoakka_runtime_v2.so" \
  "3c0cc47250e3c4ebb71633af85d205adb7bf2606d58abba0bf893a770dfde48c" \
  "ELF 64-bit LSB shared object, ARM aarch64"
verify "linux-x86_64/libcoakka_runtime_v2.so" \
  "7d8781b8eae6948eee968e422dd2097dfee43d788c4cb4a3fb3e8936bd214815" \
  "ELF 64-bit LSB shared object, x86-64"
verify "windows-aarch64/libcoakka_runtime_v2.dll" \
  "e932f870f6dd15fd36612f0ce404e4906faff47766f6ed40c328d4e12a69ebf0" \
  "PE32\\+ executable \\(DLL\\).*Aarch64"
verify "windows-x86_64/libcoakka_runtime_v2.dll" \
  "dc9d352144fefb2d6789bc3ea49dd6fe1b3bb627be4f1277944bc51d49e2f3f9" \
  "PE32\\+ executable \\(DLL\\).*x86-64"

count="$(find "${native_root}" -type f \( -name '*.dylib' -o -name '*.so' -o -name '*.dll' \) | wc -l | tr -d ' ')"
[[ "${count}" == "5" ]] || { echo "[zig-verify-native] expected 5 natives, got ${count}" >&2; exit 1; }
echo "[zig-verify-native] exact payload ok (macOS/Linux/Windows); publisher signing absent"
