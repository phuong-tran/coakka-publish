const std = @import("std");
pub const transport = @import("transport.zig");
pub const stream_lane = @import("stream_lane.zig");
pub const StreamLane = stream_lane.StreamLane;
pub const StreamLaneConfig = stream_lane.Config;
pub const StreamPublishSpec = stream_lane.PublishSpec;
pub const StreamSubscribeSpec = stream_lane.SubscribeSpec;
pub const StreamSessionSnapshot = stream_lane.SessionSnapshot;
pub const StreamPressureSnapshot = stream_lane.PressureSnapshot;
pub const StreamLaneStats = stream_lane.Stats;

/// Native runtime ABI version expected by this Zig connector source package.
pub const AbiVersion: u32 = 1;

const StatusOk: c_int = 0;
const StatusWouldBlock: c_int = -6;
const StateStarted: c_int = 1;
const RouteStrategySingleOwner: c_int = 1;
const EndpointFlagLocal: u32 = 1 << 0;
const HostHandlesEnableMonitor: u32 = 1 << 0;
const HostHandlesSeparateDeliveredRequestLane: u32 = 1 << 1;
const ClientResultResponse: u32 = 1;
const ClientResultDeadletter: u32 = 2;
const DeliveryHintRouterDefault: u32 = 1;

pub const Status = transport.Status;
pub const Capabilities = transport.Capabilities;
pub const TcpConnectionMode = transport.TcpConnectionMode;
pub const TcpSecurityMode = transport.TcpSecurityMode;
pub const TlsReloadMode = transport.TlsReloadMode;
pub const TcpConnectionStrategySpec = transport.TcpConnectionStrategySpec;
pub const TcpSecuritySpec = transport.TcpSecuritySpec;
pub const CapabilitySnapshot = transport.CapabilitySnapshot;
pub const ConnectionConfigSnapshot = transport.ConnectionConfigSnapshot;
pub const ConnectionApplyResult = transport.ConnectionApplyResult;
pub const SecurityInfoSnapshot = transport.SecurityInfoSnapshot;
pub const SecurityApplyResult = transport.SecurityApplyResult;

const PlatformLibrary = opaque {};
extern "c" fn coakka_zig_library_open(
    path: [*:0]const u8,
    error_buf: [*]u8,
    error_buf_len: usize,
) ?*PlatformLibrary;
extern "c" fn coakka_zig_library_close(library: ?*PlatformLibrary) void;
extern "c" fn coakka_zig_library_symbol(
    library: ?*PlatformLibrary,
    name: [*:0]const u8,
) ?*anyopaque;
extern "c" fn coakka_zig_fd_close(fd: c_int) void;
extern "c" fn coakka_zig_sleep_milliseconds(milliseconds: c_uint) void;

var process_library_lock: std.atomic.Mutex = .unlocked;
var process_library: ?*PlatformLibrary = null;
var process_library_path: [4096]u8 = undefined;
var process_library_path_len: usize = 0;
var process_host_active = false;

/// Opaque native runtime instance owned by RuntimeHost.
pub const Runtime = opaque {};
/// Opaque connector-side ask client used for request/reply matching.
pub const AskClient = opaque {};
/// Opaque ask ticket returned for one pending request.
pub const AskTicket = opaque {};
/// Opaque framed-pipe reader. It does not own the fd passed to native code.
pub const FrameReader = opaque {};
/// Opaque native file-lane instance owned by FileLane.
pub const FileLaneNative = opaque {};

/// TLS material read at lane startup. Never log key paths or transfer tokens.
pub const FileLaneSecurityConfig = extern struct {
    struct_size: usize = @sizeOf(FileLaneSecurityConfig),
    mode: u32 = 0,
    reserved: u32 = 0,
    credential_generation: u64 = 0,
    credential_id: ?[*:0]const u8 = null,
    ca_certificate_file: ?[*:0]const u8 = null,
    identity_certificate_file: ?[*:0]const u8 = null,
    private_key_file: ?[*:0]const u8 = null,
};
/// Bounded lane configuration. Size fields are bytes, time fields are
/// milliseconds, and zero tuning fields select core-runtime defaults.
pub const FileLaneConfig = extern struct {
    struct_size: usize = @sizeOf(FileLaneConfig),
    flags: u32 = 3,
    bind_host: [*:0]const u8 = "127.0.0.1",
    bind_port: u16 = 0,
    queue_capacity: usize = 0,
    max_file_size: u64 = 0,
    io_timeout_ms: u32 = 0,
    checkpoint_bytes: u64 = 0,
    progress_bytes: u64 = 0,
    progress_interval_ms: u32 = 0,
    sender_worker_count: u32 = 0,
    receiver_worker_count: u32 = 0,
    security: ?*const FileLaneSecurityConfig = null,
};
/// Receiver authorization and exact content identity for one transfer.
/// The destination path remains local to the receiver app-host.
pub const FileReceiveSpec = extern struct {
    struct_size: usize = @sizeOf(FileReceiveSpec),
    transfer_id: [*:0]const u8,
    authorization_token: [*:0]const u8,
    destination_path: [*:0]const u8,
    expected_size: u64,
    expected_sha256: [32]u8,
};
/// Source and receiver endpoint for one previously prepared transfer.
pub const FileSendSpec = extern struct {
    struct_size: usize = @sizeOf(FileSendSpec),
    transfer_id: [*:0]const u8,
    authorization_token: [*:0]const u8,
    remote_host: [*:0]const u8,
    remote_port: u16,
    source_path: [*:0]const u8,
    expected_size: u64,
    expected_sha256: [32]u8,
    timeout_ms: u32 = 0,
};
/// Immutable progress view with process-local monotonic timestamps.
/// progress_milli ranges from 0 to 100000 (100.000%); update_sequence advances on changes.
pub const FileTransferSnapshot = extern struct {
    struct_size: usize = @sizeOf(FileTransferSnapshot),
    direction: u32 = 0,
    state: u32 = 0,
    result: u32 = 0,
    expected_size: u64 = 0,
    transferred_bytes: u64 = 0,
    committed_offset: u64 = 0,
    progress_milli: u32 = 0,
    cancel_requested: u32 = 0,
    update_sequence: u64 = 0,
    submitted_mono_ns: u64 = 0,
    started_mono_ns: u64 = 0,
    updated_mono_ns: u64 = 0,
    terminal_mono_ns: u64 = 0,
    detail: [160]u8 = [_]u8{0} ** 160,
    pub fn terminal(self: FileTransferSnapshot) bool {
        return self.state >= 6;
    }
    pub fn succeeded(self: FileTransferSnapshot) bool {
        return self.state == 6 and self.result == 1;
    }
};
/// Bounded queue, active-work, terminal-count, and completed-byte counters.
pub const FileLaneStats = extern struct {
    struct_size: usize = @sizeOf(FileLaneStats),
    queue_capacity: usize = 0,
    queued_sends: usize = 0,
    prepared_receives: usize = 0,
    active_sends: usize = 0,
    active_receives: usize = 0,
    retained_records: usize = 0,
    submitted_sends: u64 = 0,
    prepared_receive_count: u64 = 0,
    completed_sends: u64 = 0,
    completed_receives: u64 = 0,
    failed_sends: u64 = 0,
    failed_receives: u64 = 0,
    canceled_transfers: u64 = 0,
    completed_send_bytes: u64 = 0,
    completed_receive_bytes: u64 = 0,
};
/// A file SHA-256 and exact byte count.
pub const FileDigest = struct { sha256: [32]u8, size: u64 };

/// Runtime creation config passed to the native C ABI.
pub const RuntimeConfig = extern struct {
    system_name: [*:0]const u8,
    node_id: [*:0]const u8,
    strict_no_drop: c_int,
    queue_capacity: c_int,
};

/// Whether the runtime owns an inbound TCP listener.
pub const NetworkMode = enum(u32) {
    embedded = 1,
    outbound_only = 2,
    network_node = 3,
};

/// Native-compatible startup policy; listener ownership is not inferred from routes.
pub const NetworkConfig = extern struct {
    struct_size: usize = @sizeOf(NetworkConfig),
    fields: u64,
    mode: NetworkMode,
    reserved: u32 = 0,
    bind_host: ?[*:0]const u8 = null,
    advertise_host: ?[*:0]const u8 = null,
    bind_port: u16 = 0,
    advertise_port: u16 = 0,
    reserved2: u32 = 0,

    pub fn embedded() NetworkConfig {
        return .{ .fields = 0x01, .mode = .embedded };
    }

    pub fn outboundOnly() NetworkConfig {
        return .{ .fields = 0x01, .mode = .outbound_only };
    }

    pub fn networkNode(
        bind_host: [*:0]const u8,
        bind_port: u16,
        advertise_host: [*:0]const u8,
        advertise_port: u16,
    ) NetworkConfig {
        return .{
            .fields = 0x1f,
            .mode = .network_node,
            .bind_host = bind_host,
            .advertise_host = advertise_host,
            .bind_port = bind_port,
            .advertise_port = if (advertise_port == 0) bind_port else advertise_port,
        };
    }

    pub fn validate(self: NetworkConfig) !void {
        switch (self.mode) {
            .embedded, .outbound_only => {
                if (self.fields != 0x01 or self.bind_host != null or self.bind_port != 0 or
                    self.advertise_host != null or self.advertise_port != 0)
                {
                    return error.InvalidNetworkConfig;
                }
            },
            .network_node => {
                if (self.fields != 0x1f or self.bind_host == null or self.bind_port == 0 or
                    self.advertise_host == null or self.advertise_port == 0)
                {
                    return error.InvalidNetworkConfig;
                }
                const advertised = std.mem.span(self.advertise_host.?);
                if (std.mem.eql(u8, advertised, "0.0.0.0") or
                    std.mem.eql(u8, advertised, "::") or
                    std.mem.eql(u8, advertised, "[::]") or
                    std.mem.eql(u8, advertised, "::0"))
                {
                    return error.InvalidNetworkConfig;
                }
            },
        }
    }
};

/// Immutable runtime build and feature information.
pub const RuntimeInfo = extern struct {
    struct_size: usize,
    abi_version: u32,
    feature_flags: u32,
    runtime_version: ?[*:0]const u8,
    git_commit: ?[*:0]const u8,
};

/// Host-owned fd lanes returned by the native runtime.
///
/// Every non-negative fd must be closed by the host. The native runtime does
/// not create a Zig event loop or hidden polling thread.
pub const HostHandles = extern struct {
    struct_size: usize,
    flags: u32,
    request_write_fd: c_int,
    response_read_fd: c_int,
    deadletter_read_fd: c_int,
    control_write_fd: c_int,
    monitor_read_fd: c_int,
    delivered_request_read_fd: c_int,
};

/// Endpoint metadata inside a runtime route snapshot.
///
/// For local endpoints, host/port are diagnostic metadata, not a socket
/// listener owned by this connector.
pub const Endpoint = extern struct {
    host: [*:0]const u8,
    port: u16,
    weight: u32,
    flags: u32,
};

/// Target-to-endpoints route-table entry.
pub const Route = extern struct {
    target: [*:0]const u8,
    strategy: c_int,
    route_key_hint: ?[*:0]const u8,
    flags: u32,
    endpoints: *const Endpoint,
    endpoint_count: usize,
};

/// Complete route snapshot applied under one generation.
pub const ControlSnapshot = extern struct {
    generation: u64,
    routes: *const Route,
    route_count: usize,
};

/// Small stats view used by the Zig source-first smoke lane.
pub const RuntimeStats = extern struct {
    struct_size: usize,
    applied_generation: u64,
    route_count: usize,
    runtime_state: c_int,
};

/// Raw request envelope builder input.
///
/// The native builder copies the provided strings/payload into a returned
/// frame. Release returned buffers with client_bytes_release.
pub const RawRequestSpec = extern struct {
    struct_size: usize,
    message_id: [*:0]const u8,
    source: [*:0]const u8,
    target: [*:0]const u8,
    reply_to: [*:0]const u8,
    payload: [*]const u8,
    payload_len: usize,
    timeout_ms: u32,
    delivery_hint: u32,
    one_way: u32,
};

/// Raw reply envelope builder input built from one delivered request frame.
pub const RawReplySpec = extern struct {
    struct_size: usize,
    request_buf: [*]const u8,
    request_len: usize,
    source: [*:0]const u8,
    payload: [*]const u8,
    payload_len: usize,
};

/// Same-process runtime start spec used by the Zig connector wrapper.
///
/// `host` and `port` are route metadata for diagnostics. A local route does
/// not bind or listen on that address.
pub const StartSpec = struct {
    system_name: [*:0]const u8,
    node_id: [*:0]const u8,
    target: [*:0]const u8,
    host: [*:0]const u8,
    port: u16,
    generation: u64 = 1,
    strict_no_drop: bool = true,
    queue_capacity: c_int = 32,
    connection_strategy: ?TcpConnectionStrategySpec = null,
    security: ?TcpSecuritySpec = null,
    network: NetworkConfig = NetworkConfig.embedded(),
};

/// Snapshot returned by createSnapshot() for smoke and package verification.
pub const RuntimeSnapshot = struct {
    abi_version: u32,
    runtime_version: []const u8,
    git_commit: []const u8,
    system_name: []const u8,
    node_id: []const u8,
    generation: u64,
    routes: usize,
    state: c_int,
};

/// Result of startup without erasing structured native transport rejection.
pub const StartHostResult = union(enum) {
    started: RuntimeHost,
    connection_rejected: ConnectionApplyResult,
    security_rejected: SecurityApplyResult,
};

const GetAbiVersionFn = *const fn () callconv(.c) u32;
const GetInfoFn = *const fn (*RuntimeInfo) callconv(.c) c_int;
const CreateFn = *const fn (*const RuntimeConfig) callconv(.c) ?*Runtime;
const DestroyFn = *const fn (?*Runtime) callconv(.c) void;
const ApplyNetworkFn = *const fn (?*Runtime, *const NetworkConfig) callconv(.c) c_int;
const GetHostHandlesFn = *const fn (?*Runtime, *HostHandles) callconv(.c) c_int;
const ApplyControlSnapshotFn = *const fn (?*Runtime, *const ControlSnapshot) callconv(.c) c_int;
const StartFn = *const fn (?*Runtime) callconv(.c) c_int;
const StopFn = *const fn (?*Runtime) callconv(.c) c_int;
const GetStatsFn = *const fn (?*Runtime, *RuntimeStats) callconv(.c) c_int;
const GetCapabilitiesFn = *const fn (*transport.NativeCapabilities) callconv(.c) c_int;
const ApplyConnectionFn = *const fn (
    ?*Runtime,
    *const transport.NativeConnectionOptions,
    *transport.NativeConnectionApplyResult,
) callconv(.c) c_int;
const GetConnectionConfigFn = *const fn (?*Runtime, *transport.NativeConnectionConfig) callconv(.c) c_int;
const ApplySecurityFn = *const fn (
    ?*Runtime,
    *const transport.NativeSecurityOptions,
    *transport.NativeSecurityApplyResult,
) callconv(.c) c_int;
const GetSecurityInfoFn = *const fn (?*Runtime, *transport.NativeSecurityInfo) callconv(.c) c_int;
const ApplyReasonNameFn = *const fn (u32) callconv(.c) ?[*:0]const u8;
const SubmitEnvelopeFn = *const fn (?*Runtime, [*]const u8, usize) callconv(.c) c_int;
const AskClientCreateFn = *const fn (?*Runtime, *const HostHandles) callconv(.c) ?*AskClient;
const AskClientDestroyFn = *const fn (?*AskClient) callconv(.c) void;
const AskClientBeginFn = *const fn (?*AskClient, [*]const u8, usize, *?*AskTicket) callconv(.c) c_int;
const AskTicketAwaitFn = *const fn (?*AskTicket, u32, *u32, *?[*]u8, *usize) callconv(.c) c_int;
const AskTicketDestroyFn = *const fn (?*AskTicket) callconv(.c) void;
const BuildRawRequestFn = *const fn (*const RawRequestSpec, *?[*]u8, *usize) callconv(.c) c_int;
const BuildRawReplyFn = *const fn (*const RawReplySpec, *?[*]u8, *usize) callconv(.c) c_int;
const ClientBytesReleaseFn = *const fn (?[*]u8) callconv(.c) void;
const FrameReaderCreateFn = *const fn (c_int, usize) callconv(.c) ?*FrameReader;
const FrameReaderDestroyFn = *const fn (?*FrameReader) callconv(.c) void;
const FrameReadTryFn = *const fn (?*FrameReader, *?[*]u8, *usize) callconv(.c) c_int;
const FrameReleaseFn = *const fn (?[*]u8) callconv(.c) void;
const FileLaneCreateFn = *const fn (*const FileLaneConfig, *?*FileLaneNative) callconv(.c) c_int;
const FileLaneDestroyFn = *const fn (?*FileLaneNative) callconv(.c) void;
const FileLaneSimpleFn = *const fn (?*FileLaneNative) callconv(.c) c_int;
const FileLanePortFn = *const fn (?*FileLaneNative, *u16) callconv(.c) c_int;
const FileLanePrepareFn = *const fn (?*FileLaneNative, *const FileReceiveSpec) callconv(.c) c_int;
const FileLaneSubmitFn = *const fn (?*FileLaneNative, *const FileSendSpec) callconv(.c) c_int;
const FileLaneGetFn = *const fn (?*FileLaneNative, [*:0]const u8, u32, *FileTransferSnapshot) callconv(.c) c_int;
const FileLaneWaitFn = *const fn (?*FileLaneNative, [*:0]const u8, u32, u64, u32, *FileTransferSnapshot) callconv(.c) c_int;
const FileLaneControlFn = *const fn (?*FileLaneNative, [*:0]const u8, u32) callconv(.c) c_int;
const FileLaneStatsFn = *const fn (?*FileLaneNative, *FileLaneStats) callconv(.c) c_int;
const FileShaFn = *const fn ([*:0]const u8, *[32]u8, *u64) callconv(.c) c_int;

/// Dynamically loaded native runtime symbol table.
pub const NativeRuntime = struct {
    lib: *PlatformLibrary,
    get_abi_version: GetAbiVersionFn,
    get_info: GetInfoFn,
    create: CreateFn,
    destroy: DestroyFn,
    apply_network: ApplyNetworkFn,
    get_host_handles: GetHostHandlesFn,
    apply_control_snapshot: ApplyControlSnapshotFn,
    start_runtime: StartFn,
    stop_runtime: StopFn,
    get_stats: GetStatsFn,
    get_capabilities: GetCapabilitiesFn,
    apply_connection: ApplyConnectionFn,
    get_connection_config: GetConnectionConfigFn,
    apply_security: ApplySecurityFn,
    get_security_info: GetSecurityInfoFn,
    apply_reason_name: ApplyReasonNameFn,
    submit_envelope: SubmitEnvelopeFn,
    ask_client_create: AskClientCreateFn,
    ask_client_destroy: AskClientDestroyFn,
    ask_client_begin: AskClientBeginFn,
    ask_ticket_await: AskTicketAwaitFn,
    ask_ticket_destroy: AskTicketDestroyFn,
    build_raw_request: BuildRawRequestFn,
    build_raw_reply: BuildRawReplyFn,
    client_bytes_release: ClientBytesReleaseFn,
    frame_reader_create: FrameReaderCreateFn,
    frame_reader_destroy: FrameReaderDestroyFn,
    frame_read_try: FrameReadTryFn,
    frame_release: FrameReleaseFn,
    file_lane_create: ?FileLaneCreateFn,
    file_lane_destroy: ?FileLaneDestroyFn,
    file_lane_start: ?FileLaneSimpleFn,
    file_lane_stop: ?FileLaneSimpleFn,
    file_lane_port: ?FileLanePortFn,
    file_lane_prepare: ?FileLanePrepareFn,
    file_lane_submit: ?FileLaneSubmitFn,
    file_lane_get: ?FileLaneGetFn,
    file_lane_wait: ?FileLaneWaitFn,
    file_lane_cancel: ?FileLaneControlFn,
    file_lane_forget: ?FileLaneControlFn,
    file_lane_stats: ?FileLaneStatsFn,
    file_sha: ?FileShaFn,
    stream_create: ?stream_lane.CreateFn,
    stream_destroy: ?stream_lane.DestroyFn,
    stream_start: ?stream_lane.SimpleFn,
    stream_stop: ?stream_lane.SimpleFn,
    stream_port: ?stream_lane.PortFn,
    stream_prepare: ?stream_lane.PublishFn,
    stream_subscribe: ?stream_lane.SubscribeFn,
    stream_get: ?stream_lane.GetFn,
    stream_wait: ?stream_lane.WaitFn,
    stream_pressure: ?stream_lane.PressureFn,
    stream_wait_pressure: ?stream_lane.WaitPressureFn,
    stream_cancel: ?stream_lane.ControlFn,
    stream_forget: ?stream_lane.ControlFn,
    stream_stats: ?stream_lane.StatsFn,

    /// Opens the native runtime library and resolves the symbols required by this lane.
    pub fn open(path: []const u8) !NativeRuntime {
        if (path.len == 0 or path.len >= process_library_path.len) {
            return error.InvalidRuntimeLibraryPath;
        }
        lockProcessLibrary();
        defer process_library_lock.unlock();

        if (process_library) |library| {
            if (!std.mem.eql(u8, process_library_path[0..process_library_path_len], path)) {
                return error.DifferentRuntimeLibraryAlreadyLoaded;
            }
            const out = try resolveSymbols(library);
            if (out.get_abi_version() != AbiVersion) return error.UnsupportedAbiVersion;
            return out;
        }

        var path_z: [4096:0]u8 = undefined;
        @memcpy(path_z[0..path.len], path);
        path_z[path.len] = 0;
        var error_buf = [_]u8{0} ** 512;
        const library = coakka_zig_library_open(&path_z, &error_buf, error_buf.len) orelse {
            return error.NativeLibraryLoadFailed;
        };
        errdefer coakka_zig_library_close(library);
        const out = try resolveSymbols(library);
        if (out.get_abi_version() != AbiVersion) return error.UnsupportedAbiVersion;
        @memcpy(process_library_path[0..path.len], path);
        process_library_path_len = path.len;
        process_library = library;
        return out;
    }

    fn resolveSymbols(lib: *PlatformLibrary) !NativeRuntime {
        return .{
            .lib = lib,
            .get_abi_version = try lookupSymbol(lib, GetAbiVersionFn, "coakka_v2_runtime_get_abi_version"),
            .get_info = try lookupSymbol(lib, GetInfoFn, "coakka_v2_runtime_get_info"),
            .create = try lookupSymbol(lib, CreateFn, "coakka_v2_runtime_create"),
            .destroy = try lookupSymbol(lib, DestroyFn, "coakka_v2_runtime_destroy"),
            .apply_network = try lookupSymbol(lib, ApplyNetworkFn, "coakka_v2_runtime_apply_network_options"),
            .get_host_handles = try lookupSymbol(lib, GetHostHandlesFn, "coakka_v2_runtime_get_host_handles"),
            .apply_control_snapshot = try lookupSymbol(lib, ApplyControlSnapshotFn, "coakka_v2_runtime_apply_control_snapshot"),
            .start_runtime = try lookupSymbol(lib, StartFn, "coakka_v2_runtime_start"),
            .stop_runtime = try lookupSymbol(lib, StopFn, "coakka_v2_runtime_stop"),
            .get_stats = try lookupSymbol(lib, GetStatsFn, "coakka_v2_runtime_get_stats"),
            .get_capabilities = try lookupSymbol(lib, GetCapabilitiesFn, "coakka_v2_runtime_get_capabilities"),
            .apply_connection = try lookupSymbol(lib, ApplyConnectionFn, "coakka_v2_runtime_apply_tcp_connection_options_ex"),
            .get_connection_config = try lookupSymbol(lib, GetConnectionConfigFn, "coakka_v2_runtime_get_tcp_connection_config"),
            .apply_security = try lookupSymbol(lib, ApplySecurityFn, "coakka_v2_runtime_apply_tcp_security_options_ex"),
            .get_security_info = try lookupSymbol(lib, GetSecurityInfoFn, "coakka_v2_runtime_get_tcp_security_info"),
            .apply_reason_name = try lookupSymbol(lib, ApplyReasonNameFn, "coakka_v2_transport_apply_reason_name"),
            .submit_envelope = try lookupSymbol(lib, SubmitEnvelopeFn, "coakka_v2_runtime_submit_envelope"),
            .ask_client_create = try lookupSymbol(lib, AskClientCreateFn, "coakka_v2_ask_client_create"),
            .ask_client_destroy = try lookupSymbol(lib, AskClientDestroyFn, "coakka_v2_ask_client_destroy"),
            .ask_client_begin = try lookupSymbol(lib, AskClientBeginFn, "coakka_v2_ask_client_begin"),
            .ask_ticket_await = try lookupSymbol(lib, AskTicketAwaitFn, "coakka_v2_ask_ticket_await"),
            .ask_ticket_destroy = try lookupSymbol(lib, AskTicketDestroyFn, "coakka_v2_ask_ticket_destroy"),
            .build_raw_request = try lookupSymbol(lib, BuildRawRequestFn, "coakka_v2_client_build_raw_request"),
            .build_raw_reply = try lookupSymbol(lib, BuildRawReplyFn, "coakka_v2_client_build_raw_reply"),
            .client_bytes_release = try lookupSymbol(lib, ClientBytesReleaseFn, "coakka_v2_client_bytes_release"),
            .frame_reader_create = try lookupSymbol(lib, FrameReaderCreateFn, "coakka_v2_frame_reader_create"),
            .frame_reader_destroy = try lookupSymbol(lib, FrameReaderDestroyFn, "coakka_v2_frame_reader_destroy"),
            .frame_read_try = try lookupSymbol(lib, FrameReadTryFn, "coakka_v2_frame_read_try"),
            .frame_release = try lookupSymbol(lib, FrameReleaseFn, "coakka_v2_frame_release"),
            .file_lane_create = lookupOptionalSymbol(lib, FileLaneCreateFn, "coakka_v2_file_lane_create_ex"),
            .file_lane_destroy = lookupOptionalSymbol(lib, FileLaneDestroyFn, "coakka_v2_file_lane_destroy"),
            .file_lane_start = lookupOptionalSymbol(lib, FileLaneSimpleFn, "coakka_v2_file_lane_start"),
            .file_lane_stop = lookupOptionalSymbol(lib, FileLaneSimpleFn, "coakka_v2_file_lane_stop"),
            .file_lane_port = lookupOptionalSymbol(lib, FileLanePortFn, "coakka_v2_file_lane_get_bound_port"),
            .file_lane_prepare = lookupOptionalSymbol(lib, FileLanePrepareFn, "coakka_v2_file_lane_prepare_receive"),
            .file_lane_submit = lookupOptionalSymbol(lib, FileLaneSubmitFn, "coakka_v2_file_lane_submit_send"),
            .file_lane_get = lookupOptionalSymbol(lib, FileLaneGetFn, "coakka_v2_file_lane_get_transfer"),
            .file_lane_wait = lookupOptionalSymbol(lib, FileLaneWaitFn, "coakka_v2_file_lane_wait_transfer"),
            .file_lane_cancel = lookupOptionalSymbol(lib, FileLaneControlFn, "coakka_v2_file_lane_cancel_transfer"),
            .file_lane_forget = lookupOptionalSymbol(lib, FileLaneControlFn, "coakka_v2_file_lane_forget_transfer"),
            .file_lane_stats = lookupOptionalSymbol(lib, FileLaneStatsFn, "coakka_v2_file_lane_get_stats"),
            .file_sha = lookupOptionalSymbol(lib, FileShaFn, "coakka_v2_file_sha256_path"),
            .stream_create = lookupOptionalSymbol(lib, stream_lane.CreateFn, "coakka_v2_stream_lane_create_ex"),
            .stream_destroy = lookupOptionalSymbol(lib, stream_lane.DestroyFn, "coakka_v2_stream_lane_destroy"),
            .stream_start = lookupOptionalSymbol(lib, stream_lane.SimpleFn, "coakka_v2_stream_lane_start"),
            .stream_stop = lookupOptionalSymbol(lib, stream_lane.SimpleFn, "coakka_v2_stream_lane_stop"),
            .stream_port = lookupOptionalSymbol(lib, stream_lane.PortFn, "coakka_v2_stream_lane_get_bound_port"),
            .stream_prepare = lookupOptionalSymbol(lib, stream_lane.PublishFn, "coakka_v2_stream_lane_prepare_publish"),
            .stream_subscribe = lookupOptionalSymbol(lib, stream_lane.SubscribeFn, "coakka_v2_stream_lane_subscribe"),
            .stream_get = lookupOptionalSymbol(lib, stream_lane.GetFn, "coakka_v2_stream_lane_get_session"),
            .stream_wait = lookupOptionalSymbol(lib, stream_lane.WaitFn, "coakka_v2_stream_lane_wait_session"),
            .stream_pressure = lookupOptionalSymbol(lib, stream_lane.PressureFn, "coakka_v2_stream_lane_get_pressure"),
            .stream_wait_pressure = lookupOptionalSymbol(lib, stream_lane.WaitPressureFn, "coakka_v2_stream_lane_wait_pressure"),
            .stream_cancel = lookupOptionalSymbol(lib, stream_lane.ControlFn, "coakka_v2_stream_lane_cancel_session"),
            .stream_forget = lookupOptionalSymbol(lib, stream_lane.ControlFn, "coakka_v2_stream_lane_forget_session"),
            .stream_stats = lookupOptionalSymbol(lib, stream_lane.StatsFn, "coakka_v2_stream_lane_get_stats"),
        };
    }

    /// Releases this value; the first native module stays loaded for process lifetime.
    pub fn close(self: *NativeRuntime) void {
        _ = self;
    }

    /// Opens and starts a lane, failing when the complete native ABI is absent.
    pub fn openFileLane(self: *NativeRuntime, config: FileLaneConfig) !FileLane {
        if (config.flags == 0 or config.flags & ~@as(u32, 3) != 0 or config.sender_worker_count > 4 or config.receiver_worker_count > 4) return error.InvalidFileLaneConfig;
        if (self.file_lane_create == null or
            self.file_lane_destroy == null or
            self.file_lane_start == null or
            self.file_lane_stop == null or
            self.file_lane_port == null or
            self.file_lane_prepare == null or
            self.file_lane_submit == null or
            self.file_lane_get == null or
            self.file_lane_wait == null or
            self.file_lane_cancel == null or
            self.file_lane_forget == null or
            self.file_lane_stats == null or
            self.file_sha == null) return error.FileLaneUnavailable;
        const create = self.file_lane_create orelse return error.FileLaneUnavailable;
        const destroy = self.file_lane_destroy.?;
        const start = self.file_lane_start.?;
        var lane: ?*FileLaneNative = null;
        if (create(&config, &lane) != StatusOk or lane == null) return error.NativeCallFailed;
        if (start(lane) != StatusOk) {
            destroy(lane);
            return error.NativeCallFailed;
        }
        return .{ .native = self, .lane = lane };
    }

    /// Opens and starts a Stream Lane after verifying its complete optional ABI.
    /// Callback contexts remain caller-owned until forget succeeds or close returns.
    pub fn openStreamLane(self: *NativeRuntime, config: StreamLaneConfig) !StreamLane {
        const bindings = stream_lane.Bindings{
            .create = self.stream_create orelse return error.StreamLaneUnavailable,
            .destroy = self.stream_destroy orelse return error.StreamLaneUnavailable,
            .start = self.stream_start orelse return error.StreamLaneUnavailable,
            .stop = self.stream_stop orelse return error.StreamLaneUnavailable,
            .port = self.stream_port orelse return error.StreamLaneUnavailable,
            .prepare = self.stream_prepare orelse return error.StreamLaneUnavailable,
            .subscribe = self.stream_subscribe orelse return error.StreamLaneUnavailable,
            .get = self.stream_get orelse return error.StreamLaneUnavailable,
            .wait = self.stream_wait orelse return error.StreamLaneUnavailable,
            .pressure = self.stream_pressure orelse return error.StreamLaneUnavailable,
            .wait_pressure = self.stream_wait_pressure orelse return error.StreamLaneUnavailable,
            .cancel = self.stream_cancel orelse return error.StreamLaneUnavailable,
            .forget = self.stream_forget orelse return error.StreamLaneUnavailable,
            .stats = self.stream_stats orelse return error.StreamLaneUnavailable,
        };
        return stream_lane.StreamLane.open(bindings, config);
    }

    /// Computes the exact source identity using the native implementation.
    pub fn fileSha256(self: *NativeRuntime, path: [*:0]const u8) !FileDigest {
        var out = FileDigest{ .sha256 = [_]u8{0} ** 32, .size = 0 };
        if ((self.file_sha orelse return error.FileLaneUnavailable)(path, &out.sha256, &out.size) != StatusOk) return error.NativeCallFailed;
        return out;
    }

    /// Reads runtime info and verifies the expected ABI version.
    pub fn readInfo(self: *NativeRuntime) !RuntimeInfo {
        var info = std.mem.zeroes(RuntimeInfo);
        info.struct_size = @sizeOf(RuntimeInfo);
        if (self.get_info(&info) != StatusOk) return error.NativeCallFailed;
        if (info.abi_version != AbiVersion) return error.UnsupportedAbiVersion;
        return info;
    }

    /// Copies capability and edition truth before or during host lifecycle.
    ///
    /// This synchronous call is available in every edition and does not infer
    /// support from package metadata.
    pub fn readCapabilities(self: *NativeRuntime) !CapabilitySnapshot {
        var native = std.mem.zeroes(transport.NativeCapabilities);
        native.struct_size = @sizeOf(transport.NativeCapabilities);
        if (self.get_capabilities(&native) != StatusOk) {
            return error.NativeCallFailed;
        }
        return transport.capabilitySnapshot(native);
    }

    /// Creates and atomically configures one host before exporting handles/start.
    ///
    /// The returned union retains a structured connection/security rejection.
    /// Credential loading is synchronous and may block on file I/O.
    pub fn startHost(self: *NativeRuntime, spec: StartSpec) !StartHostResult {
        _ = try self.readInfo();
        try spec.network.validate();
        lockProcessLibrary();
        if (process_host_active) {
            process_library_lock.unlock();
            return error.RuntimeHostAlreadyActive;
        }
        process_host_active = true;
        process_library_lock.unlock();
        const config = RuntimeConfig{
            .system_name = spec.system_name,
            .node_id = spec.node_id,
            .strict_no_drop = if (spec.strict_no_drop) 1 else 0,
            .queue_capacity = spec.queue_capacity,
        };
        const runtime = self.create(&config) orelse {
            releaseActiveHost();
            return error.NativeCallFailed;
        };
        var host = RuntimeHost{
            .native = self,
            .runtime = runtime,
            .handles = initHostHandles(),
            .start_attempted = false,
            .transport_lock = .unlocked,
            .startup_connection_result = null,
            .startup_security_result = null,
            .owns_active_slot = true,
        };
        errdefer host.deinit();

        if (self.apply_network(runtime, &spec.network) != StatusOk) {
            return error.NativeCallFailed;
        }

        if (spec.connection_strategy) |connection| {
            const result = try host.applyConnectionStrategy(connection);
            host.startup_connection_result = result;
            if (!result.applied()) {
                host.deinit();
                return .{ .connection_rejected = result };
            }
        }
        if (spec.security) |security| {
            const result = try host.applySecurity(security);
            host.startup_security_result = result;
            if (!result.applied()) {
                host.deinit();
                return .{ .security_rejected = result };
            }
        }
        try host.applySingleLocalRoute(spec);
        if (self.get_host_handles(runtime, &host.handles) != StatusOk) {
            return error.NativeCallFailed;
        }
        host.start_attempted = true;
        if (self.start_runtime(runtime) != StatusOk) {
            return error.NativeCallFailed;
        }
        return .{ .started = host };
    }

    /// Starts a smoke host, reads stats/info, and returns a compact snapshot.
    pub fn createSnapshot(self: *NativeRuntime) !RuntimeSnapshot {
        const info = try self.readInfo();
        var host = switch (try self.startHost(smokeSpec())) {
            .started => |started| started,
            else => return error.TransportConfigurationRejected,
        };
        defer host.deinit();
        const stats = try host.stats();

        return .{
            .abi_version = info.abi_version,
            .runtime_version = cstr(info.runtime_version),
            .git_commit = cstr(info.git_commit),
            .system_name = std.mem.span(smokeSpec().system_name),
            .node_id = std.mem.span(smokeSpec().node_id),
            .generation = stats.applied_generation,
            .routes = stats.route_count,
            .state = stats.runtime_state,
        };
    }
};

/// Independent file-transfer owner. Native waits do not hold the lifecycle lock.
///
/// Prepare the receiver before submitting the sender. Observe success on both
/// peers, then forget retained records. File bytes do not belong in runtime
/// Envelope payloads.
pub const FileLane = struct {
    native: *NativeRuntime,
    lane: ?*FileLaneNative,
    state_lock: std.atomic.Mutex = .unlocked,
    active_calls: usize = 0,
    closing: bool = false,

    fn begin(self: *FileLane) !*FileLaneNative {
        while (!self.state_lock.tryLock()) std.atomic.spinLoopHint();
        defer self.state_lock.unlock();
        if (self.closing or self.lane == null) return error.FileLaneClosed;
        self.active_calls += 1;
        return self.lane.?;
    }
    fn end(self: *FileLane) void {
        while (!self.state_lock.tryLock()) std.atomic.spinLoopHint();
        self.active_calls -= 1;
        self.state_lock.unlock();
    }
    /// Returns the receiver port selected when the lane started.
    pub fn boundPort(self: *FileLane) !u16 {
        const lane = try self.begin();
        defer self.end();
        var out: u16 = 0;
        if ((self.native.file_lane_port orelse return error.FileLaneUnavailable)(lane, &out) != StatusOk) return error.NativeCallFailed;
        return out;
    }
    /// Authorizes one destination and expected content identity.
    pub fn prepareReceive(self: *FileLane, spec: *const FileReceiveSpec) !void {
        const lane = try self.begin();
        defer self.end();
        if ((self.native.file_lane_prepare orelse return error.FileLaneUnavailable)(lane, spec) != StatusOk) return error.NativeCallFailed;
    }
    /// Queues a send after the remote application prepares the receive.
    pub fn submitSend(self: *FileLane, spec: *const FileSendSpec) !void {
        if (spec.remote_port == 0) return error.InvalidFileLaneConfig;
        const lane = try self.begin();
        defer self.end();
        if ((self.native.file_lane_submit orelse return error.FileLaneUnavailable)(lane, spec) != StatusOk) return error.NativeCallFailed;
    }
    /// Returns the current copied snapshot without waiting.
    pub fn transfer(self: *FileLane, transfer_id: [*:0]const u8, direction: u32) !FileTransferSnapshot {
        const lane = try self.begin();
        defer self.end();
        var out = FileTransferSnapshot{};
        if ((self.native.file_lane_get orelse return error.FileLaneUnavailable)(lane, transfer_id, direction, &out) != StatusOk) return error.NativeCallFailed;
        return out;
    }
    /// Blocks until the sequence advances, the timeout expires, or the lane stops.
    /// after_sequence is the last update already handled; zero requests current state.
    pub fn waitTransfer(self: *FileLane, transfer_id: [*:0]const u8, direction: u32, after_sequence: u64, timeout_ms: u32) !FileTransferSnapshot {
        const lane = try self.begin();
        defer self.end();
        var out = FileTransferSnapshot{};
        if ((self.native.file_lane_wait orelse return error.FileLaneUnavailable)(lane, transfer_id, direction, after_sequence, timeout_ms, &out) != StatusOk) return error.NativeCallFailed;
        return out;
    }
    /// Requests cooperative cancellation; observe terminal state before forget.
    pub fn cancel(self: *FileLane, transfer_id: [*:0]const u8, direction: u32) !void {
        const lane = try self.begin();
        defer self.end();
        if ((self.native.file_lane_cancel orelse return error.FileLaneUnavailable)(lane, transfer_id, direction) != StatusOk) return error.NativeCallFailed;
    }
    /// Releases one retained terminal record after recording its outcome.
    pub fn forget(self: *FileLane, transfer_id: [*:0]const u8, direction: u32) !void {
        const lane = try self.begin();
        defer self.end();
        if ((self.native.file_lane_forget orelse return error.FileLaneUnavailable)(lane, transfer_id, direction) != StatusOk) return error.NativeCallFailed;
    }
    /// Returns a copied lane-level observability snapshot.
    pub fn stats(self: *FileLane) !FileLaneStats {
        const lane = try self.begin();
        defer self.end();
        var out = FileLaneStats{};
        if ((self.native.file_lane_stats orelse return error.FileLaneUnavailable)(lane, &out) != StatusOk) return error.NativeCallFailed;
        return out;
    }
    /// Stops the lane, wakes blocked waits, drains calls, and releases native state.
    pub fn close(self: *FileLane) !void {
        while (!self.state_lock.tryLock()) std.atomic.spinLoopHint();
        if (self.lane == null) {
            self.state_lock.unlock();
            return;
        }
        if (self.closing) {
            self.state_lock.unlock();
            while (true) {
                while (!self.state_lock.tryLock()) std.atomic.spinLoopHint();
                const closed = self.lane == null;
                self.state_lock.unlock();
                if (closed) return;
                // Close is a cold lifecycle path and another caller may be in
                // a blocking wait. Sleep instead of occupying one CPU.
                coakka_zig_sleep_milliseconds(1);
            }
        }
        self.closing = true;
        const lane = self.lane.?;
        self.state_lock.unlock();
        const status = (self.native.file_lane_stop orelse return error.FileLaneUnavailable)(lane);
        while (true) {
            while (!self.state_lock.tryLock()) std.atomic.spinLoopHint();
            if (self.active_calls == 0) break;
            self.state_lock.unlock();
            // Stop wakes blocked calls; bounded sleep avoids a close-time
            // busy loop while those calls return and release their borrow.
            coakka_zig_sleep_milliseconds(1);
        }
        (self.native.file_lane_destroy orelse return error.FileLaneUnavailable)(lane);
        self.lane = null;
        self.state_lock.unlock();
        if (status != StatusOk and status != -7) return error.NativeCallFailed;
    }
};

/// Owner of one native runtime instance and its host fd lanes.
pub const RuntimeHost = struct {
    native: *NativeRuntime,
    runtime: ?*Runtime,
    handles: HostHandles,
    start_attempted: bool,
    transport_lock: std.atomic.Mutex,
    startup_connection_result: ?ConnectionApplyResult,
    startup_security_result: ?SecurityApplyResult,
    owns_active_slot: bool,

    /// Stops the runtime, destroys the native instance, and closes host-owned fds.
    pub fn deinit(self: *RuntimeHost) void {
        self.lockTransport();
        defer self.transport_lock.unlock();
        if (self.runtime) |runtime| {
            if (self.start_attempted) {
                _ = self.native.stop_runtime(runtime);
                self.start_attempted = false;
            }
            closeHostHandles(&self.handles);
            self.native.destroy(runtime);
            self.runtime = null;
        }
        closeHostHandles(&self.handles);
        if (self.owns_active_slot) {
            self.owns_active_slot = false;
            releaseActiveHost();
        }
    }

    /// Copies compiled, entitled, and effective capabilities for this module.
    ///
    /// The call is synchronous, serialized with apply/teardown, available in
    /// every edition, and returns owned numeric data only.
    pub fn capabilities(self: *RuntimeHost) !CapabilitySnapshot {
        self.lockTransport();
        defer self.transport_lock.unlock();
        if (self.runtime == null) return error.RuntimeClosed;
        return try self.native.readCapabilities();
    }

    /// Copies the effective connection policy and default provenance.
    pub fn connectionConfig(self: *RuntimeHost) !ConnectionConfigSnapshot {
        self.lockTransport();
        defer self.transport_lock.unlock();
        const runtime = self.runtime orelse return error.RuntimeClosed;
        var native = std.mem.zeroes(transport.NativeConnectionConfig);
        native.struct_size = @sizeOf(transport.NativeConnectionConfig);
        if (self.native.get_connection_config(runtime, &native) != StatusOk) {
            return error.NativeCallFailed;
        }
        return transport.connectionConfig(native);
    }

    /// Copies active non-secret TLS/mTLS identity and generation metadata.
    pub fn securityInfo(self: *RuntimeHost) !SecurityInfoSnapshot {
        self.lockTransport();
        defer self.transport_lock.unlock();
        const runtime = self.runtime orelse return error.RuntimeClosed;
        var native = std.mem.zeroes(transport.NativeSecurityInfo);
        native.struct_size = @sizeOf(transport.NativeSecurityInfo);
        if (self.native.get_security_info(runtime, &native) != StatusOk) {
            return error.NativeCallFailed;
        }
        return transport.securityInfo(native);
    }

    /// Attempts an atomic startup-shaped connection apply.
    ///
    /// Nil tuning fields preserve core defaults. The call is synchronous and
    /// serialized with transport getters/teardown. After start, core normally
    /// returns `bad_state` with the unchanged active config.
    pub fn applyConnectionStrategy(
        self: *RuntimeHost,
        spec: TcpConnectionStrategySpec,
    ) !ConnectionApplyResult {
        self.lockTransport();
        defer self.transport_lock.unlock();
        const runtime = self.runtime orelse return error.RuntimeClosed;
        var options = transport.connectionOptions(spec);
        var native = std.mem.zeroes(transport.NativeConnectionApplyResult);
        native.struct_size = @sizeOf(transport.NativeConnectionApplyResult);
        const status = self.native.apply_connection(runtime, &options, &native);
        if (status != native.apply_status) return error.ApplyStatusMismatch;
        return transport.connectionResult(native, self.native.apply_reason_name(native.reason));
    }

    /// Applies startup security or reloads newer same-mode TLS credentials.
    ///
    /// Sentinel strings are borrowed only during this synchronous call; file
    /// loading may block. Invalid/stale material leaves active state unchanged.
    pub fn applySecurity(self: *RuntimeHost, spec: TcpSecuritySpec) !SecurityApplyResult {
        self.lockTransport();
        defer self.transport_lock.unlock();
        const runtime = self.runtime orelse return error.RuntimeClosed;
        var options = try transport.securityOptions(spec);
        var native = std.mem.zeroes(transport.NativeSecurityApplyResult);
        native.struct_size = @sizeOf(transport.NativeSecurityApplyResult);
        const status = self.native.apply_security(runtime, &options, &native);
        if (status != native.apply_status) return error.ApplyStatusMismatch;
        return transport.securityResult(native, self.native.apply_reason_name(native.reason));
    }

    fn lockTransport(self: *RuntimeHost) void {
        while (!self.transport_lock.tryLock()) std.atomic.spinLoopHint();
    }

    /// Reads the runtime stats view used by this connector lane.
    pub fn stats(self: *RuntimeHost) !RuntimeStats {
        var out = std.mem.zeroes(RuntimeStats);
        out.struct_size = @sizeOf(RuntimeStats);
        if (self.native.get_stats(self.runtime, &out) != StatusOk) {
            return error.NativeCallFailed;
        }
        return out;
    }

    /// Proves one local raw request/reply through the delivered-request lane.
    pub fn smokeRawRoundTrip(self: *RuntimeHost) !void {
        if (self.runtime == null or self.handles.delivered_request_read_fd < 0) {
            return error.NativeCallFailed;
        }

        const client = self.native.ask_client_create(self.runtime, &self.handles) orelse return error.NativeCallFailed;
        defer self.native.ask_client_destroy(client);

        const request_payload = "hello";
        var request_spec = RawRequestSpec{
            .struct_size = @sizeOf(RawRequestSpec),
            .message_id = "req-zig-raw-1",
            .source = "zig-client",
            .target = smokeSpec().target,
            .reply_to = "zig-client/replies",
            .payload = request_payload.ptr,
            .payload_len = request_payload.len,
            .timeout_ms = 1000,
            .delivery_hint = DeliveryHintRouterDefault,
            .one_way = 0,
        };
        var request_buf: ?[*]u8 = null;
        var request_len: usize = 0;
        if (self.native.build_raw_request(&request_spec, &request_buf, &request_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(request_buf);
        if (request_buf == null or request_len == 0) return error.NativeCallFailed;

        var ticket: ?*AskTicket = null;
        if (self.native.ask_client_begin(client, request_buf.?, request_len, &ticket) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.ask_ticket_destroy(ticket);

        const reader = self.native.frame_reader_create(self.handles.delivered_request_read_fd, 64 * 1024) orelse return error.NativeCallFailed;
        defer self.native.frame_reader_destroy(reader);

        const delivered_buf = try self.readDeliveredFrame(reader);
        defer self.native.frame_release(delivered_buf.ptr);

        const reply_payload = "reply";
        var reply_spec = RawReplySpec{
            .struct_size = @sizeOf(RawReplySpec),
            .request_buf = delivered_buf.ptr.?,
            .request_len = delivered_buf.len,
            .source = smokeSpec().target,
            .payload = reply_payload.ptr,
            .payload_len = reply_payload.len,
        };
        var reply_buf: ?[*]u8 = null;
        var reply_len: usize = 0;
        if (self.native.build_raw_reply(&reply_spec, &reply_buf, &reply_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(reply_buf);
        if (reply_buf == null or reply_len == 0) return error.NativeCallFailed;

        if (self.native.submit_envelope(self.runtime, reply_buf.?, reply_len) != StatusOk) {
            return error.NativeCallFailed;
        }

        var result_kind: u32 = 0;
        var result_buf: ?[*]u8 = null;
        var result_len: usize = 0;
        if (self.native.ask_ticket_await(ticket, 1000, &result_kind, &result_buf, &result_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(result_buf);
        if (result_kind != ClientResultResponse or result_buf == null or result_len == 0) {
            return error.NativeCallFailed;
        }
    }

    /// Proves a route miss returns a matched deadletter through the ask path.
    pub fn smokeRouteMissDeadletter(self: *RuntimeHost) !void {
        if (self.runtime == null) {
            return error.NativeCallFailed;
        }

        const client = self.native.ask_client_create(self.runtime, &self.handles) orelse return error.NativeCallFailed;
        defer self.native.ask_client_destroy(client);

        const request_payload = "missing";
        var request_spec = RawRequestSpec{
            .struct_size = @sizeOf(RawRequestSpec),
            .message_id = "req-zig-missing-1",
            .source = "zig-client",
            .target = "svc.missing",
            .reply_to = "zig-client/replies",
            .payload = request_payload.ptr,
            .payload_len = request_payload.len,
            .timeout_ms = 1000,
            .delivery_hint = DeliveryHintRouterDefault,
            .one_way = 0,
        };
        var request_buf: ?[*]u8 = null;
        var request_len: usize = 0;
        if (self.native.build_raw_request(&request_spec, &request_buf, &request_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(request_buf);
        if (request_buf == null or request_len == 0) return error.NativeCallFailed;

        var ticket: ?*AskTicket = null;
        if (self.native.ask_client_begin(client, request_buf.?, request_len, &ticket) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.ask_ticket_destroy(ticket);

        var result_kind: u32 = 0;
        var result_buf: ?[*]u8 = null;
        var result_len: usize = 0;
        if (self.native.ask_ticket_await(ticket, 1000, &result_kind, &result_buf, &result_len) != StatusOk) {
            return error.NativeCallFailed;
        }
        defer self.native.client_bytes_release(result_buf);
        if (result_kind != ClientResultDeadletter or result_buf == null or result_len == 0) {
            return error.NativeCallFailed;
        }
    }

    fn applySingleLocalRoute(self: *RuntimeHost, spec: StartSpec) !void {
        const endpoint = Endpoint{
            .host = spec.host,
            .port = spec.port,
            .weight = 1,
            .flags = EndpointFlagLocal,
        };
        const route = Route{
            .target = spec.target,
            .strategy = RouteStrategySingleOwner,
            .route_key_hint = null,
            .flags = 0,
            .endpoints = &endpoint,
            .endpoint_count = 1,
        };
        const snapshot = ControlSnapshot{
            .generation = spec.generation,
            .routes = &route,
            .route_count = 1,
        };
        if (self.native.apply_control_snapshot(self.runtime, &snapshot) != StatusOk) {
            return error.NativeCallFailed;
        }
    }

    fn readDeliveredFrame(self: *RuntimeHost, reader: *FrameReader) !struct { ptr: ?[*]u8, len: usize } {
        var attempts: usize = 0;
        while (attempts < 1000) : (attempts += 1) {
            var buf: ?[*]u8 = null;
            var len: usize = 0;
            const rc = self.native.frame_read_try(reader, &buf, &len);
            if (rc == StatusOk) {
                if (buf == null or len == 0) return error.NativeCallFailed;
                return .{ .ptr = buf, .len = len };
            }
            if (rc != StatusWouldBlock) {
                return error.NativeCallFailed;
            }
            coakka_zig_sleep_milliseconds(1);
        }
        return error.Timeout;
    }
};

/// Returns the default same-process smoke spec.
pub fn smokeSpec() StartSpec {
    return .{
        .system_name = "zig-runtime-smoke",
        .node_id = "zig-runtime-smoke-node",
        .target = "svc.echo",
        .host = "127.0.0.1",
        .port = 0,
        .generation = 1,
        .strict_no_drop = true,
        .queue_capacity = 32,
    };
}

/// Creates a same-process local start spec for a single target.
pub fn localStartSpec(system_name: [*:0]const u8, node_id: [*:0]const u8, target: [*:0]const u8) StartSpec {
    return .{
        .system_name = system_name,
        .node_id = node_id,
        .target = target,
        .host = "127.0.0.1",
        .port = 0,
    };
}

/// Returns true when stats show a started runtime with the expected route snapshot.
pub fn isStarted(stats: RuntimeStats, generation: u64, route_count: usize) bool {
    return stats.runtime_state == StateStarted and
        stats.applied_generation == generation and
        stats.route_count == route_count;
}

fn initHostHandles() HostHandles {
    return .{
        .struct_size = @sizeOf(HostHandles),
        .flags = HostHandlesEnableMonitor | HostHandlesSeparateDeliveredRequestLane,
        .request_write_fd = -1,
        .response_read_fd = -1,
        .deadletter_read_fd = -1,
        .control_write_fd = -1,
        .monitor_read_fd = -1,
        .delivered_request_read_fd = -1,
    };
}

fn closeHostHandles(handles: *HostHandles) void {
    const values = [_]c_int{
        handles.request_write_fd,
        handles.response_read_fd,
        handles.deadletter_read_fd,
        handles.control_write_fd,
        handles.monitor_read_fd,
        handles.delivered_request_read_fd,
    };
    for (values, 0..) |fd, index| {
        if (fd >= 0) {
            var duplicate = false;
            for (values[0..index]) |previous| {
                if (previous == fd) duplicate = true;
            }
            if (!duplicate) coakka_zig_fd_close(fd);
        }
    }
    handles.request_write_fd = -1;
    handles.response_read_fd = -1;
    handles.deadletter_read_fd = -1;
    handles.control_write_fd = -1;
    handles.monitor_read_fd = -1;
    handles.delivered_request_read_fd = -1;
}

fn cstr(value: ?[*:0]const u8) []const u8 {
    if (value) |ptr| return std.mem.span(ptr);
    return "";
}

fn lockProcessLibrary() void {
    while (!process_library_lock.tryLock()) std.atomic.spinLoopHint();
}

fn releaseActiveHost() void {
    lockProcessLibrary();
    process_host_active = false;
    process_library_lock.unlock();
}

fn lookupSymbol(
    library: *PlatformLibrary,
    comptime Symbol: type,
    name: [:0]const u8,
) !Symbol {
    const symbol = coakka_zig_library_symbol(library, name.ptr) orelse return error.MissingSymbol;
    return @ptrCast(@alignCast(symbol));
}

fn lookupOptionalSymbol(library: *PlatformLibrary, comptime Symbol: type, name: [:0]const u8) ?Symbol {
    const symbol = coakka_zig_library_symbol(library, name.ptr) orelse return null;
    return @ptrCast(@alignCast(symbol));
}

comptime {
    if (@sizeOf(NetworkConfig) != 48 or
        @sizeOf(FileLaneSecurityConfig) != 56 or @sizeOf(FileLaneConfig) != 96 or
        @sizeOf(FileReceiveSpec) != 72 or @sizeOf(FileSendSpec) != 96 or
        @sizeOf(FileTransferSnapshot) != 256 or @sizeOf(FileLaneStats) != 128)
        @compileError("file-lane ABI layout drift");
}
