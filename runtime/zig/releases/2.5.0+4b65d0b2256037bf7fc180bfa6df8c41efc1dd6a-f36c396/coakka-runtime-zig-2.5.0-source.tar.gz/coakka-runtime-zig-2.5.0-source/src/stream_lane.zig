const std = @import("std");

extern "c" fn coakka_zig_sleep_milliseconds(milliseconds: c_uint) void;

pub const StatusOk: c_int = 0;
pub const StatusClosed: c_int = -7;
pub const Publisher: u32 = 1;
pub const Subscriber: u32 = 1 << 1;
pub const DirectionPublish: u32 = 1;
pub const DirectionSubscribe: u32 = 2;
pub const FrameKeyframe: u32 = 1;
pub const FrameDiscontinuity: u32 = 1 << 1;
pub const FrameEndOfSegment: u32 = 1 << 2;
pub const PressureCreditWait: u32 = 1;
pub const PressureTransportWrite: u32 = 1 << 1;
pub const PressureConsumerBusy: u32 = 1 << 2;
pub const PressureTransportRead: u32 = 1 << 3;

/// Opaque native stream-lane instance owned by StreamLane.
pub const Native = opaque {};

/// Frame metadata returned by a source and delivered to a consumer.
pub const Frame = extern struct {
    struct_size: usize = @sizeOf(Frame),
    sequence: u64 = 0,
    captured_mono_ns: u64 = 0,
    dropped_before: u64 = 0,
    flags: u32 = 0,
    size: usize = 0,
};

/// Bounded publisher callback. destination is borrowed for this call only.
/// Return 0 with a non-empty frame, -6 when no frame is ready, or -7 at end.
pub const SourceFn = *const fn (?*anyopaque, [*]u8, usize, *Frame) callconv(.c) c_int;
/// Bounded subscriber callback. data is borrowed for this call only.
/// Return 0 after consumption or -7 to request clean cancellation.
pub const ConsumerFn = *const fn (?*anyopaque, [*]const u8, *const Frame) callconv(.c) c_int;

/// TLS material read at startup. Never log key paths or session tokens.
pub const SecurityConfig = extern struct {
    struct_size: usize = @sizeOf(SecurityConfig),
    mode: u32 = 0,
    reserved: u32 = 0,
    credential_generation: u64 = 0,
    credential_id: ?[*:0]const u8 = null,
    ca_certificate_file: ?[*:0]const u8 = null,
    identity_certificate_file: ?[*:0]const u8 = null,
    private_key_file: ?[*:0]const u8 = null,
};

/// Bounded workers, frames, flow control, and pressure timing.
/// Size fields are bytes, time fields are milliseconds, and zero tuning values
/// select conservative core-runtime defaults.
pub const Config = extern struct {
    struct_size: usize = @sizeOf(Config),
    flags: u32 = Publisher | Subscriber,
    bind_host: [*:0]const u8 = "127.0.0.1",
    bind_port: u16 = 0,
    capacity: usize = 0,
    max_frame_bytes: u32 = 0,
    max_window_bytes: u32 = 0,
    io_timeout_ms: u32 = 0,
    source_retry_ms: u32 = 0,
    progress_frames: u32 = 0,
    progress_interval_ms: u32 = 0,
    publisher_worker_count: u32 = 0,
    subscriber_worker_count: u32 = 0,
    security: ?*const SecurityConfig = null,
    pressure_after_ms: u32 = 0,
    stalled_after_ms: u32 = 0,
    recovery_after_ms: u32 = 0,
    pressure_observation_ms: u32 = 0,
};

/// Publisher authorization and borrowed callback context.
/// source_context must remain valid until forget succeeds or close returns.
pub const PublishSpec = extern struct {
    struct_size: usize = @sizeOf(PublishSpec),
    session_id: [*:0]const u8,
    authorization_token: [*:0]const u8,
    format_id: u64,
    max_frame_bytes: u32,
    source_next: SourceFn,
    source_context: ?*anyopaque,
};

/// Subscriber endpoint, flow-control window, and borrowed callback context.
/// consumer_context must remain valid until forget succeeds or close returns.
pub const SubscribeSpec = extern struct {
    struct_size: usize = @sizeOf(SubscribeSpec),
    session_id: [*:0]const u8,
    authorization_token: [*:0]const u8,
    remote_host: [*:0]const u8,
    remote_port: u16,
    format_id: u64,
    max_frame_bytes: u32,
    initial_window_bytes: u32,
    timeout_ms: u32 = 0,
    consume: ConsumerFn,
    consumer_context: ?*anyopaque,
};

/// Copied session progress with process-local monotonic timestamps.
/// Frame/byte counters are cumulative and update_sequence advances on changes.
pub const SessionSnapshot = extern struct {
    struct_size: usize = @sizeOf(SessionSnapshot),
    direction: u32 = 0,
    state: u32 = 0,
    result: u32 = 0,
    format_id: u64 = 0,
    frames: u64 = 0,
    bytes: u64 = 0,
    dropped_frames: u64 = 0,
    last_sequence: u64 = 0,
    negotiated_max_frame_bytes: u32 = 0,
    window_bytes: u32 = 0,
    cancel_requested: u32 = 0,
    update_sequence: u64 = 0,
    submitted_mono_ns: u64 = 0,
    started_mono_ns: u64 = 0,
    updated_mono_ns: u64 = 0,
    terminal_mono_ns: u64 = 0,
    detail: [160]u8 = [_]u8{0} ** 160,
    pub fn terminal(self: SessionSnapshot) bool {
        return self.state >= 6;
    }
    pub fn succeeded(self: SessionSnapshot) bool {
        return self.state == 6 and self.result == 1;
    }
};

/// Copied, policy-neutral transport-pressure observation.
/// Durations/timestamps are nanoseconds; observed_delivery_bps is bytes per second.
pub const PressureSnapshot = extern struct {
    struct_size: usize = @sizeOf(PressureSnapshot),
    direction: u32 = 0,
    state: u32 = 0,
    reason_bits: u32 = 0,
    available_credit_bytes: u32 = 0,
    window_capacity_bytes: u32 = 0,
    update_sequence: u64 = 0,
    transition_count: u64 = 0,
    observed_mono_ns: u64 = 0,
    state_started_mono_ns: u64 = 0,
    pressure_started_mono_ns: u64 = 0,
    last_progress_mono_ns: u64 = 0,
    observed_delivery_bps: u64 = 0,
    current_operation_ns: u64 = 0,
    last_operation_ns: u64 = 0,
    total_pressured_ns: u64 = 0,
    max_pressured_ns: u64 = 0,
};

/// Bounded queue, active-session, terminal, frame, byte, and drop counters.
pub const Stats = extern struct {
    struct_size: usize = @sizeOf(Stats),
    capacity: usize = 0,
    queued_subscribers: usize = 0,
    prepared_publishers: usize = 0,
    active_publishers: usize = 0,
    active_subscribers: usize = 0,
    retained_records: usize = 0,
    submitted_subscribers: u64 = 0,
    prepared_publisher_count: u64 = 0,
    ended_publishers: u64 = 0,
    ended_subscribers: u64 = 0,
    failed_publishers: u64 = 0,
    failed_subscribers: u64 = 0,
    canceled_sessions: u64 = 0,
    published_frames: u64 = 0,
    published_bytes: u64 = 0,
    consumed_frames: u64 = 0,
    consumed_bytes: u64 = 0,
    source_reported_drops: u64 = 0,
};

pub const CreateFn = *const fn (*const Config, *?*Native) callconv(.c) c_int;
pub const DestroyFn = *const fn (?*Native) callconv(.c) void;
pub const SimpleFn = *const fn (?*Native) callconv(.c) c_int;
pub const PortFn = *const fn (?*Native, *u16) callconv(.c) c_int;
pub const PublishFn = *const fn (?*Native, *const PublishSpec) callconv(.c) c_int;
pub const SubscribeFn = *const fn (?*Native, *const SubscribeSpec) callconv(.c) c_int;
pub const GetFn = *const fn (?*Native, [*:0]const u8, u32, *SessionSnapshot) callconv(.c) c_int;
pub const WaitFn = *const fn (?*Native, [*:0]const u8, u32, u64, u32, *SessionSnapshot) callconv(.c) c_int;
pub const PressureFn = *const fn (?*Native, [*:0]const u8, u32, *PressureSnapshot) callconv(.c) c_int;
pub const WaitPressureFn = *const fn (?*Native, [*:0]const u8, u32, u64, u32, *PressureSnapshot) callconv(.c) c_int;
pub const ControlFn = *const fn (?*Native, [*:0]const u8, u32) callconv(.c) c_int;
pub const StatsFn = *const fn (?*Native, *Stats) callconv(.c) c_int;

/// Complete concrete native function table. No virtual dispatch or heap allocation.
pub const Bindings = struct {
    create: CreateFn,
    destroy: DestroyFn,
    start: SimpleFn,
    stop: SimpleFn,
    port: PortFn,
    prepare: PublishFn,
    subscribe: SubscribeFn,
    get: GetFn,
    wait: WaitFn,
    pressure: PressureFn,
    wait_pressure: WaitPressureFn,
    cancel: ControlFn,
    forget: ControlFn,
    stats: StatsFn,
};

/// Independent stream owner. Native waits never hold the lifecycle lock.
pub const StreamLane = struct {
    bindings: Bindings,
    lane: ?*Native,
    state_lock: std.atomic.Mutex = .unlocked,
    active_calls: usize = 0,
    closing: bool = false,

    /// Creates and starts a lane with the concrete symbol table.
    pub fn open(bindings: Bindings, config: Config) !StreamLane {
        if (config.flags == 0 or config.flags & ~@as(u32, 3) != 0 or config.capacity > 64 or
            config.max_frame_bytes > 4 * 1024 * 1024 or config.max_window_bytes > 16 * 1024 * 1024 or
            config.source_retry_ms > 1000 or config.publisher_worker_count > 4 or
            config.subscriber_worker_count > 4 or config.pressure_after_ms > 60000 or
            config.stalled_after_ms > 60000 or config.recovery_after_ms > 60000 or
            config.pressure_observation_ms > 60000 or
            (config.max_frame_bytes != 0 and config.max_window_bytes != 0 and config.max_window_bytes < config.max_frame_bytes))
            return error.InvalidStreamLaneConfig;
        var lane: ?*Native = null;
        if (bindings.create(&config, &lane) != StatusOk or lane == null) return error.NativeCallFailed;
        errdefer bindings.destroy(lane);
        if (bindings.start(lane) != StatusOk) return error.NativeCallFailed;
        return .{ .bindings = bindings, .lane = lane };
    }
    fn begin(self: *StreamLane) !*Native {
        while (!self.state_lock.tryLock()) std.atomic.spinLoopHint();
        defer self.state_lock.unlock();
        if (self.closing or self.lane == null) return error.StreamLaneClosed;
        self.active_calls += 1;
        return self.lane.?;
    }
    fn end(self: *StreamLane) void {
        while (!self.state_lock.tryLock()) std.atomic.spinLoopHint();
        self.active_calls -= 1;
        self.state_lock.unlock();
    }
    /// Returns the publisher port selected at startup.
    pub fn boundPort(self: *StreamLane) !u16 {
        const lane = try self.begin();
        defer self.end();
        var out: u16 = 0;
        if (self.bindings.port(lane, &out) != 0) return error.NativeCallFailed;
        return out;
    }
    /// Prepares a publisher. Callback context remains caller-owned through forget or close.
    pub fn preparePublish(self: *StreamLane, spec: *const PublishSpec) !void {
        const lane = try self.begin();
        defer self.end();
        if (self.bindings.prepare(lane, spec) != 0) return error.NativeCallFailed;
    }
    /// Queues a subscriber. Callback context remains caller-owned through forget or close.
    pub fn subscribe(self: *StreamLane, spec: *const SubscribeSpec) !void {
        if (spec.remote_port == 0) return error.InvalidStreamLaneConfig;
        const lane = try self.begin();
        defer self.end();
        if (self.bindings.subscribe(lane, spec) != 0) return error.NativeCallFailed;
    }
    /// Returns the current copied session snapshot.
    pub fn session(self: *StreamLane, session_id: [*:0]const u8, direction: u32) !SessionSnapshot {
        const lane = try self.begin();
        defer self.end();
        var out = SessionSnapshot{};
        if (self.bindings.get(lane, session_id, direction, &out) != 0) return error.NativeCallFailed;
        return out;
    }
    /// Waits for a session update newer than sequence or until timeout_ms.
    /// after_sequence is the last update already handled; zero requests current state.
    pub fn waitSession(self: *StreamLane, session_id: [*:0]const u8, direction: u32, after_sequence: u64, timeout_ms: u32) !SessionSnapshot {
        const lane = try self.begin();
        defer self.end();
        var out = SessionSnapshot{};
        if (self.bindings.wait(lane, session_id, direction, after_sequence, timeout_ms, &out) != 0) return error.NativeCallFailed;
        return out;
    }
    /// Returns the current policy-neutral pressure observation.
    pub fn getPressure(self: *StreamLane, session_id: [*:0]const u8, direction: u32) !PressureSnapshot {
        const lane = try self.begin();
        defer self.end();
        var out = PressureSnapshot{};
        if (self.bindings.pressure(lane, session_id, direction, &out) != 0) return error.NativeCallFailed;
        return out;
    }
    /// Waits for pressure newer than sequence or until timeout_ms.
    /// after_sequence is the last pressure update handled by app-host policy.
    pub fn waitPressure(self: *StreamLane, session_id: [*:0]const u8, direction: u32, after_sequence: u64, timeout_ms: u32) !PressureSnapshot {
        const lane = try self.begin();
        defer self.end();
        var out = PressureSnapshot{};
        if (self.bindings.wait_pressure(lane, session_id, direction, after_sequence, timeout_ms, &out) != 0) return error.NativeCallFailed;
        return out;
    }
    /// Requests cooperative cancellation; observe terminal state before forget.
    pub fn cancel(self: *StreamLane, session_id: [*:0]const u8, direction: u32) !void {
        const lane = try self.begin();
        defer self.end();
        if (self.bindings.cancel(lane, session_id, direction) != 0) return error.NativeCallFailed;
    }
    /// Releases one terminal record. Caller may release its callback context after return.
    pub fn forget(self: *StreamLane, session_id: [*:0]const u8, direction: u32) !void {
        const lane = try self.begin();
        defer self.end();
        if (self.bindings.forget(lane, session_id, direction) != 0) return error.NativeCallFailed;
    }
    /// Returns copied lane-level counters.
    pub fn getStats(self: *StreamLane) !Stats {
        const lane = try self.begin();
        defer self.end();
        var out = Stats{};
        if (self.bindings.stats(lane, &out) != 0) return error.NativeCallFailed;
        return out;
    }
    /// Stops and joins native workers, then drains host calls and destroys the lane.
    pub fn close(self: *StreamLane) !void {
        while (!self.state_lock.tryLock()) std.atomic.spinLoopHint();
        if (self.lane == null) {
            self.state_lock.unlock();
            return;
        }
        if (self.closing) {
            self.state_lock.unlock();
            while (true) {
                while (!self.state_lock.tryLock()) std.atomic.spinLoopHint();
                const closed = self.lane == null;
                self.state_lock.unlock();
                if (closed) return;
                // Close is a cold lifecycle path and another caller may be in
                // a blocking wait. Sleep instead of occupying one CPU.
                coakka_zig_sleep_milliseconds(1);
            }
        }
        self.closing = true;
        const lane = self.lane.?;
        self.state_lock.unlock();
        const status = self.bindings.stop(lane);
        while (true) {
            while (!self.state_lock.tryLock()) std.atomic.spinLoopHint();
            if (self.active_calls == 0) break;
            self.state_lock.unlock();
            // Stop wakes blocked calls; bounded sleep avoids a close-time
            // busy loop while those calls return and release their borrow.
            coakka_zig_sleep_milliseconds(1);
        }
        self.bindings.destroy(lane);
        self.lane = null;
        self.state_lock.unlock();
        if (status != StatusOk and status != StatusClosed) return error.NativeCallFailed;
    }
};

comptime {
    if (@sizeOf(Frame) != 48 or @sizeOf(Config) != 96 or @sizeOf(PublishSpec) != 56 or
        @sizeOf(SubscribeSpec) != 80 or @sizeOf(SessionSnapshot) != 280 or
        @sizeOf(PressureSnapshot) != 120 or @sizeOf(Stats) != 152)
        @compileError("stream-lane ABI layout changed");
}
