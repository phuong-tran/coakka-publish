# CoAkka Runtime Zig Connector

<p align="center">
  <img src="https://raw.githubusercontent.com/phuong-tran/coakka-samples/main/docs/assets/brand/coakka-logo.png" alt="CoAkka" width="480">
</p>

This is the Zig connector in the polyglot, multi-language, multi-platform CoAkka
runtime ecosystem. CoAkka is not Zig-only: Zig applications can share the same
runtime semantics with native C/C++, JVM, Node/Bun, Python, Go, C#, Rust, Swift,
and Mojo services. It exposes lifecycle, request/reply, diagnostics, capability
discovery, startup connection strategy, structured atomic apply results, and
same-mode TLS/mTLS credential reload over the public C ABI.

Connector version: `2.5.3-source`<br>
Native generation: `2.5.1+26f7944de4a4e0598845a54e4775f9463a9e33be`<br>
Publisher signing: absent

## Compatibility

| Target | Native in source tarball | Current evidence |
| --- | --- | --- |
| macOS ARM64 | dylib | Zig request/reply, transport, and TLS/mTLS reload pass |
| Linux ARM64 | ELF shared object | exact payload plus Zig compile/link pass; native execution pending |
| Windows x86-64 | DLL | exact payload plus Zig compile/link pass; native execution pending |

Linux remains the primary runtime deployment target. The distribution includes
Linux, Windows, and macOS even when one connector test run executes on fewer
targets.

## Smoke

```sh
COAKKA_RUNTIME_LIB=/path/to/libcoakka_runtime_v2.dylib \
  bash scripts/smoke.sh
```

`COAKKA_TLS_FIXTURE_ROOT` enables the TLS reload portion and must contain
`ca.pem`, `server.pem`, `server.key`, and a mismatching `client.key`.

The Zig API keeps unknown numeric ABI values representable, sends optional
tuning only when present, and returns `StartHostResult` so startup rejection
does not lose its structured active-state snapshot. See
[transport configuration](TRANSPORT_CONFIGURATION.md).

## Dry-Run Gates

```sh
zig build
bash scripts/check-platform-source.sh
bash scripts/package-release.sh
bash scripts/check-package-readiness.sh
```

These checks build and consume a local source archive without changing any
registry or public release state.

## Common Guidance

- [CoAkka documentation and samples](https://github.com/phuong-tran/coakka-samples/blob/main/docs/README.md)
- [Connection strategies](https://github.com/phuong-tran/coakka-samples/blob/main/docs/connection-strategies.md)
- [TLS/mTLS](https://github.com/phuong-tran/coakka-samples/blob/main/docs/tls-and-mtls.md)
- [Troubleshooting](https://github.com/phuong-tran/coakka-samples/blob/main/docs/troubleshooting.md), including Linux loader, Gatekeeper, Windows publisher warnings, checksums, and absent signing
- [Contact/support](https://github.com/phuong-tran/coakka-samples/blob/main/docs/contact-and-support.md)
- Contact: `gabrielgun1983@gmail.com`

## File Lane

`NativeRuntime.openFileLane(...)` exposes exact file-lane ABI layouts and
explicit shutdown ownership. See the shared [file-lane contract](https://github.com/phuong-tran/coakka-samples/blob/main/docs/runtime-file-transfer.md)
and use a native runtime that exports the complete file-lane symbol set.

## Stream Lane

Version `2.5.3` contains the Stream Lane connector surface over exact native
generation `2.5.1+26f7944de4a4e0598845a54e4775f9463a9e33be`. Keep that pairing intact and follow the public
[streaming contract](https://github.com/phuong-tran/coakka-samples/blob/main/docs/runtime-streaming.md).
Replica owners use `openOwnedFileLane`/`openOwnedStreamLane` and
`prepareReceiveGrant`/`preparePublishGrant`; fixed-size grants derive exact
remote specs with `toSendSpec`/`toSubscribeSpec`. Copy the capability through
the authenticated control plane and follow the
[owner-grant ONE/ALL sample](https://github.com/phuong-tran/coakka-samples/blob/main/docs/runtime-lane-owner-grants.md).

## AI-Assisted Integration

Before generating application code, use the selected connector README together
with the public [AI-assisted integration guide](https://github.com/phuong-tran/coakka-samples/blob/main/docs/ai-assisted-integration.md).
It requires an exact package coordinate, platform evidence, the runnable
language sample, and the feature-specific lifecycle contract. Do not translate
API identifiers from another language by analogy.


## License

**Free for application use, including commercial and production use.**

Connector source, generated bindings, type declarations, examples, and package
documentation use the [Apache License, Version 2.0](https://github.com/phuong-tran/coakka-samples/blob/main/LICENSE).
Bundled Native Core files use the [CoAkka Native Artifact License 1.2](https://github.com/phuong-tran/coakka-samples/blob/main/NATIVE-LICENSE.md).
Those native terms permit ordinary application and SaaS use but require a
separate agreement to sell or offer CoAkka itself as managed runtime or
infrastructure.

See [CoAkka Package Licensing](https://github.com/phuong-tran/coakka-samples/blob/main/docs/package-licensing.md)
for the file-scope map. The package also carries offline `LICENSE`,
`NATIVE-LICENSE.md`, `PACKAGE-LICENSE.md`, and `NOTICE` copies.
