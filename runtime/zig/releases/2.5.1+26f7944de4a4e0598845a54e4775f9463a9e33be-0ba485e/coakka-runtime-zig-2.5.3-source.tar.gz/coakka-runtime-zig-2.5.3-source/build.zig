const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const root_module = b.createModule(.{
        .root_source_file = b.path("src/smoke.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    root_module.addCSourceFile(.{
        .file = b.path("src/platform_bridge.c"),
        .flags = &.{ "-std=c11", "-Wall", "-Wextra", "-Werror" },
    });

    const smoke = b.addExecutable(.{
        .name = "coakka-runtime-zig-smoke",
        .root_module = root_module,
    });
    b.installArtifact(smoke);

    const run_smoke = b.addRunArtifact(smoke);
    if (b.args) |args| {
        run_smoke.addArgs(args);
    }

    const smoke_step = b.step("smoke", "Run the runtime Zig smoke");
    smoke_step.dependOn(&run_smoke.step);
}
