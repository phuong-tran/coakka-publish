#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
zig_root="$(cd "${script_dir}/.." && pwd)"
work_root="$(mktemp -d "${TMPDIR:-/tmp}/coakka-zig-cross.XXXXXX")"
trap 'rm -rf "${work_root}"' EXIT

zig build --build-file "${zig_root}/build.zig" -Dtarget=aarch64-linux-gnu \
  -Doptimize=ReleaseSafe --prefix "${work_root}/linux"
zig build --build-file "${zig_root}/build.zig" -Dtarget=x86_64-windows-gnu \
  -Doptimize=ReleaseSafe --prefix "${work_root}/windows"
file "${work_root}/linux/bin/coakka-runtime-zig-smoke" | grep -q 'ELF 64-bit.*ARM aarch64'
file "${work_root}/windows/bin/coakka-runtime-zig-smoke.exe" | grep -q 'PE32+ executable.*x86-64'
echo "[zig-platform-source] Linux ARM64 and Windows x86-64 compile/link ok"
