#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
zig_root="$(cd "${script_dir}/.." && pwd)"
command -v zig >/dev/null 2>&1 || {
  echo "[zig-runtime-smoke] zig toolchain is required" >&2
  exit 1
}

runtime_lib="${COAKKA_RUNTIME_LIB:-}"
if [[ -z "${runtime_lib}" ]]; then
  case "$(uname -s)" in
    Darwin)
      platform="macos-aarch64"
      filename="libcoakka_runtime_v2.dylib"
      ;;
    Linux)
      case "$(uname -m)" in
        aarch64|arm64) platform="linux-aarch64" ;;
        *) echo "[zig-runtime-smoke] no bundled Linux native for $(uname -m)" >&2; exit 64 ;;
      esac
      filename="libcoakka_runtime_v2.so"
      ;;
    MINGW*|MSYS*|CYGWIN*)
      platform="windows-x86_64"
      filename="libcoakka_runtime_v2.dll"
      ;;
    *) echo "[zig-runtime-smoke] unsupported OS: $(uname -s)" >&2; exit 64 ;;
  esac
  packaged="${zig_root}/native/${platform}/${filename}"
  if [[ -f "${packaged}" ]]; then
    runtime_lib="${packaged}"
  else
    echo "[zig-runtime-smoke] bundled runtime not found; set COAKKA_RUNTIME_LIB" >&2
    exit 1
  fi
fi

[[ -f "${runtime_lib}" ]] || {
  echo "[zig-runtime-smoke] runtime library not found: ${runtime_lib}" >&2
  exit 1
}

COAKKA_RUNTIME_LIB="${runtime_lib}" zig build --build-file "${zig_root}/build.zig" smoke
