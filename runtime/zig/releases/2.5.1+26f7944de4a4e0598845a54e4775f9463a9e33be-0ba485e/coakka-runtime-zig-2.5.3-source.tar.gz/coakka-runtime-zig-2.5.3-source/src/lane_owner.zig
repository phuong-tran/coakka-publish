const std = @import("std");

pub const Feature: u32 = 1 << 25;

/// Stable identity and directly reachable host for one exact lane replica.
pub const Config = extern struct {
    struct_size: usize = @sizeOf(Config),
    owner_instance_id: [*:0]const u8,
    advertised_host: [*:0]const u8,

    pub fn validate(self: Config) !void {
        try visibleAscii(std.mem.span(self.owner_instance_id), 127);
        try visibleAscii(std.mem.span(self.advertised_host), 255);
    }
};

/// Direct endpoint of the owner retaining prepared lane state.
pub const Endpoint = extern struct {
    struct_size: usize = @sizeOf(Endpoint),
    port: u16 = 0,
    reserved: u16 = 0,
    owner_instance_id: [128]u8 = [_]u8{0} ** 128,
    advertised_host: [256]u8 = [_]u8{0} ** 256,

    pub fn ownerInstanceId(self: *const Endpoint) []const u8 {
        return fixed(&self.owner_instance_id);
    }
    pub fn advertisedHost(self: *const Endpoint) []const u8 {
        return fixed(&self.advertised_host);
    }
    pub fn advertisedHostZ(self: *const Endpoint) [*:0]const u8 {
        return @ptrCast(&self.advertised_host);
    }
};

pub fn fixed(value: []const u8) []const u8 {
    return value[0..(std.mem.indexOfScalar(u8, value, 0) orelse value.len)];
}

fn visibleAscii(value: []const u8, maximum: usize) !void {
    if (value.len == 0 or value.len > maximum) return error.InvalidLaneOwner;
    for (value) |byte| if (byte < 0x21 or byte > 0x7e) return error.InvalidLaneOwner;
}

comptime {
    if (@sizeOf(Config) != 24 or @sizeOf(Endpoint) != 400)
        @compileError("lane-owner ABI layout changed");
}
