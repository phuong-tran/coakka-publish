#if !defined(_WIN32) && !defined(_POSIX_C_SOURCE)
#define _POSIX_C_SOURCE 200809L
#endif

#include "platform_bridge.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX 1
#endif
#include <io.h>
#include <windows.h>
#else
#include <dlfcn.h>
#include <time.h>
#include <unistd.h>
#endif

struct coakka_zig_library_t {
  void *handle;
};

static void set_error(char *buf, size_t len, const char *message) {
  if (buf != NULL && len > 0) {
    snprintf(buf, len, "%s", message == NULL ? "unknown loader error" : message);
  }
}

coakka_zig_library_t *coakka_zig_library_open(const char *path,
                                               char *error_buf,
                                               size_t error_buf_len) {
  if (path == NULL) {
    set_error(error_buf, error_buf_len, "runtime library path is null");
    return NULL;
  }
  coakka_zig_library_t *library = calloc(1, sizeof(*library));
  if (library == NULL) {
    set_error(error_buf, error_buf_len, "out of memory");
    return NULL;
  }
#if defined(_WIN32)
  int length = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, path, -1, NULL, 0);
  if (length <= 0) {
    set_error(error_buf, error_buf_len, "runtime path is not valid UTF-8");
    free(library);
    return NULL;
  }
  wchar_t *wide_path = calloc((size_t)length, sizeof(*wide_path));
  if (wide_path == NULL ||
      MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, path, -1, wide_path, length) <= 0) {
    set_error(error_buf, error_buf_len, "failed to convert runtime path");
    free(wide_path);
    free(library);
    return NULL;
  }
  library->handle = (void *)LoadLibraryW(wide_path);
  free(wide_path);
  if (library->handle == NULL) {
    set_error(error_buf, error_buf_len, "LoadLibraryW rejected the runtime library");
    free(library);
    return NULL;
  }
#else
  library->handle = dlopen(path, RTLD_NOW | RTLD_LOCAL);
  if (library->handle == NULL) {
    set_error(error_buf, error_buf_len, dlerror());
    free(library);
    return NULL;
  }
#endif
  return library;
}

void coakka_zig_library_close(coakka_zig_library_t *library) {
  if (library == NULL) {
    return;
  }
#if defined(_WIN32)
  if (library->handle != NULL) {
    FreeLibrary((HMODULE)library->handle);
  }
#else
  if (library->handle != NULL) {
    dlclose(library->handle);
  }
#endif
  free(library);
}

void *coakka_zig_library_symbol(coakka_zig_library_t *library,
                                const char *name) {
  if (library == NULL || library->handle == NULL || name == NULL) {
    return NULL;
  }
#if defined(_WIN32)
  return (void *)GetProcAddress((HMODULE)library->handle, name);
#else
  return dlsym(library->handle, name);
#endif
}

void coakka_zig_fd_close(int fd) {
  if (fd < 0) {
    return;
  }
#if defined(_WIN32)
  (void)_close(fd);
#else
  (void)close(fd);
#endif
}

void coakka_zig_sleep_milliseconds(unsigned int milliseconds) {
#if defined(_WIN32)
  Sleep(milliseconds);
#else
  struct timespec duration = {
      .tv_sec = (time_t)(milliseconds / 1000u),
      .tv_nsec = (long)(milliseconds % 1000u) * 1000000L,
  };
  while (nanosleep(&duration, &duration) != 0 && errno == EINTR) {
  }
#endif
}
