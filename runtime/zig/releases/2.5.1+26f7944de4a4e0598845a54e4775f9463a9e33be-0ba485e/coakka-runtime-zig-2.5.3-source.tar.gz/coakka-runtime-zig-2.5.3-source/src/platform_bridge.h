#ifndef COAKKA_ZIG_PLATFORM_BRIDGE_H
#define COAKKA_ZIG_PLATFORM_BRIDGE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct coakka_zig_library_t coakka_zig_library_t;

/**
 * Opens one native runtime module at `path`. The path is borrowed for the
 * synchronous loader call. The caller owns the returned handle; NULL indicates
 * invalid input, allocation failure, or loader rejection. `error_buf`, when
 * non-NULL and non-empty, receives a truncated NUL-terminated diagnostic.
 * Serialize process-level open/close; symbol calls must not race close.
 */
coakka_zig_library_t *coakka_zig_library_open(const char *path,
                                               char *error_buf,
                                               size_t error_buf_len);

/**
 * Closes a loader handle and releases its storage. NULL is ignored. All symbols
 * and native objects obtained from the module must be quiescent first.
 */
void coakka_zig_library_close(coakka_zig_library_t *library);

/**
 * Resolves `name` in an open module. Inputs are borrowed and the returned code
 * pointer remains valid only while `library` is open. NULL means invalid input
 * or a missing symbol; the call performs no bridge-side synchronization.
 */
void *coakka_zig_library_symbol(coakka_zig_library_t *library,
                                const char *name);

/**
 * Closes one host-owned runtime descriptor. Negative descriptors are ignored;
 * callers must prevent duplicate close and concurrent I/O on the same lane.
 */
void coakka_zig_fd_close(int fd);

/**
 * Suspends the calling thread for at least the requested duration, retrying an
 * interrupted POSIX sleep. This bounded smoke-helper wait is not a runtime
 * readiness primitive and must not be used on a production hot path.
 */
void coakka_zig_sleep_milliseconds(unsigned int milliseconds);

#ifdef __cplusplus
}
#endif

#endif
