const std = @import("std");

const ConnectionFieldMode: u64 = 1 << 0;
const ConnectionFieldMaxConnections: u64 = 1 << 1;
const ConnectionFieldMaxRequests: u64 = 1 << 2;
const ConnectionFieldIdleTimeout: u64 = 1 << 3;
const SecurityFieldMode: u64 = 1 << 0;
const SecurityFieldSource: u64 = 1 << 1;
const SecurityFieldReloadMode: u64 = 1 << 2;
const SecurityFieldGeneration: u64 = 1 << 3;
const SecurityFieldCredentialId: u64 = 1 << 4;
const SecurityFieldCaFile: u64 = 1 << 5;
const SecurityFieldIdentityFile: u64 = 1 << 6;
const SecurityFieldKeyFile: u64 = 1 << 7;
const SecurityAllFields: u64 = (1 << 8) - 1;
const CredentialSourceFile: u32 = 1;

/// Stable numeric status returned by the runtime C ABI.
pub const Status = struct {
    value: c_int,

    pub const ok = Status{ .value = 0 };
    pub const invalid_argument = Status{ .value = -1 };
    pub const no_memory = Status{ .value = -2 };
    pub const bad_state = Status{ .value = -3 };
    pub const stale_generation = Status{ .value = -4 };
    pub const io = Status{ .value = -5 };
    pub const would_block = Status{ .value = -6 };
    pub const closed = Status{ .value = -7 };
    pub const feature_unavailable = Status{ .value = -8 };
    pub const feature_not_entitled = Status{ .value = -9 };

    pub fn eql(self: Status, other: Status) bool {
        return self.value == other.value;
    }
};

/// Capability bits copied from the loaded runtime.
pub const Capabilities = struct {
    value: u64,

    pub const none = Capabilities{ .value = 0 };
    pub const tcp_bounded_pool = Capabilities{ .value = 1 << 0 };
    pub const tcp_pool_tuning = Capabilities{ .value = 1 << 1 };
    pub const tcp_tls = Capabilities{ .value = 1 << 2 };
    pub const tcp_mutual_tls = Capabilities{ .value = 1 << 3 };
    pub const tls_credential_reload = Capabilities{ .value = 1 << 4 };
    pub const tls_external_provider = Capabilities{ .value = 1 << 5 };
    pub const tcp_persistent_single_flight = Capabilities{ .value = 1 << 6 };
    pub const tcp_multiplexing = Capabilities{ .value = 1 << 7 };

    pub fn supports(self: Capabilities, requested: Capabilities) bool {
        return self.value & requested.value == requested.value;
    }
};

/// Startup-only TCP connection ownership strategy.
pub const TcpConnectionMode = struct {
    value: u32,

    pub const per_exchange = TcpConnectionMode{ .value = 0 };
    pub const bounded_pool = TcpConnectionMode{ .value = 1 };
    pub const persistent_single_flight = TcpConnectionMode{ .value = 2 };
    pub const multiplexing = TcpConnectionMode{ .value = 3 };

    pub fn eql(self: TcpConnectionMode, other: TcpConnectionMode) bool {
        return self.value == other.value;
    }
};

/// Security policy independent from connection reuse.
pub const TcpSecurityMode = struct {
    value: u32,

    pub const plaintext = TcpSecurityMode{ .value = 0 };
    pub const tls = TcpSecurityMode{ .value = 1 };
    pub const mutual_tls = TcpSecurityMode{ .value = 2 };

    pub fn eql(self: TcpSecurityMode, other: TcpSecurityMode) bool {
        return self.value == other.value;
    }
};

/// Retirement policy for retained connections after TLS reload.
pub const TlsReloadMode = struct {
    value: u32,

    pub const graceful = TlsReloadMode{ .value = 0 };
    pub const drain_existing_connections = TlsReloadMode{ .value = 1 };

    pub fn eql(self: TlsReloadMode, other: TlsReloadMode) bool {
        return self.value == other.value;
    }
};

/// Stable high-level reason for one transport apply result.
pub const ApplyReason = struct {
    value: u32,

    pub const none = ApplyReason{ .value = 0 };
    pub const invalid_argument = ApplyReason{ .value = 1 };
    pub const feature_unavailable = ApplyReason{ .value = 2 };
    pub const feature_not_entitled = ApplyReason{ .value = 3 };
    pub const runtime_not_configurable = ApplyReason{ .value = 4 };
    pub const security_mode_change_requires_recreate = ApplyReason{ .value = 5 };
    pub const stale_credential_generation = ApplyReason{ .value = 6 };
    pub const credential_rejected = ApplyReason{ .value = 7 };
    pub const resource_failure = ApplyReason{ .value = 8 };
    pub const adapter_rejected = ApplyReason{ .value = 9 };
};

pub const ConnectionValidationCode = struct {
    value: u32,

    pub const valid = ConnectionValidationCode{ .value = 0 };
    pub const unknown_mode = ConnectionValidationCode{ .value = 4 };
};

pub const SecurityValidationCode = struct {
    value: u32,

    pub const valid = SecurityValidationCode{ .value = 0 };
    pub const field_not_applicable = SecurityValidationCode{ .value = 7 };
};

/// Startup connection mode; null tuning fields preserve core defaults.
pub const TcpConnectionStrategySpec = struct {
    mode: TcpConnectionMode = .per_exchange,
    max_connections: ?u32 = null,
    max_requests_per_connection: ?u64 = null,
    idle_timeout_ms: ?u64 = null,
};

/// Startup security policy or same-mode TLS/mTLS credential reload.
pub const TcpSecuritySpec = struct {
    mode: TcpSecurityMode = .plaintext,
    reload_mode: TlsReloadMode = .graceful,
    credential_generation: u64 = 0,
    credential_id: [:0]const u8 = "",
    ca_certificate_file: [:0]const u8 = "",
    identity_certificate_file: [:0]const u8 = "",
    private_key_file: [:0]const u8 = "",
};

pub const CapabilitySnapshot = struct {
    edition: u32,
    license_status: u32,
    compiled: Capabilities,
    entitled: Capabilities,
    effective: Capabilities,
    tcp_connection_defaults_revision: u32,
};

pub const ConnectionConfigSnapshot = struct {
    defaults_revision: u32,
    mode: TcpConnectionMode,
    applicable_fields: u64,
    explicitly_configured_fields: u64,
    defaulted_fields: u64,
    configurable_fields: u64,
    max_connections: u32,
    max_requests_per_connection: u64,
    idle_timeout_ms: u64,
};

pub const FixedString = struct {
    bytes: [128]u8 = [_]u8{0} ** 128,
    len: usize = 0,

    pub fn slice(self: *const FixedString) []const u8 {
        return self.bytes[0..self.len];
    }
};

pub const ConnectionApplyResult = struct {
    status: Status,
    changed: bool,
    reason: ApplyReason,
    reason_name: FixedString,
    runtime_state: u32,
    validation_code: ConnectionValidationCode,
    validation_field: u64,
    minimum_value: u64,
    maximum_value: u64,
    active_config: ConnectionConfigSnapshot,

    pub fn applied(self: ConnectionApplyResult) bool {
        return self.status.eql(.ok);
    }
};

pub const SecurityInfoSnapshot = struct {
    mode: TcpSecurityMode,
    credential_source_kind: u32,
    reload_mode: TlsReloadMode,
    reload_status: u32,
    credential_generation: u64,
    credential_id: FixedString,
    minimum_protocol_version: u32,
    maximum_protocol_version: u32,
    inbound_verification_flags: u64,
    outbound_verification_flags: u64,
    identity_not_before_unix_seconds: i64,
    identity_not_after_unix_seconds: i64,
    identity_fingerprint_sha256: FixedString,
};

pub const SecurityApplyResult = struct {
    status: Status,
    changed: bool,
    reason: ApplyReason,
    reason_name: FixedString,
    runtime_state: u32,
    validation_code: SecurityValidationCode,
    validation_field: u64,
    active_security: SecurityInfoSnapshot,

    pub fn applied(self: SecurityApplyResult) bool {
        return self.status.eql(.ok);
    }
};

pub const AbiSizes = struct {
    capabilities: usize,
    connection_options: usize,
    connection_validation: usize,
    connection_config: usize,
    connection_apply_result: usize,
    security_options: usize,
    security_validation: usize,
    security_config: usize,
    security_identity: usize,
    security_info: usize,
    security_apply_result: usize,
};

pub fn abiSizes() AbiSizes {
    return .{
        .capabilities = @sizeOf(NativeCapabilities),
        .connection_options = @sizeOf(NativeConnectionOptions),
        .connection_validation = @sizeOf(NativeConnectionValidation),
        .connection_config = @sizeOf(NativeConnectionConfig),
        .connection_apply_result = @sizeOf(NativeConnectionApplyResult),
        .security_options = @sizeOf(NativeSecurityOptions),
        .security_validation = @sizeOf(NativeSecurityValidation),
        .security_config = @sizeOf(NativeSecurityConfig),
        .security_identity = @sizeOf(NativeSecurityIdentity),
        .security_info = @sizeOf(NativeSecurityInfo),
        .security_apply_result = @sizeOf(NativeSecurityApplyResult),
    };
}

pub const NativeCapabilities = extern struct {
    struct_size: usize,
    edition: u32,
    license_status: u32,
    compiled_capabilities: u64,
    entitled_capabilities: u64,
    effective_capabilities: u64,
    tcp_connection_defaults_revision: u32,
    reserved: u32,
};

pub const NativeConnectionOptions = extern struct {
    struct_size: usize,
    fields: u64,
    mode: u32,
    reserved: u32,
    max_connections: u32,
    reserved2: u32,
    max_requests_per_connection: u64,
    idle_timeout_ms: u64,
};

pub const NativeConnectionValidation = extern struct {
    struct_size: usize,
    code: u32,
    reserved: u32,
    field: u64,
    minimum_value: u64,
    maximum_value: u64,
};

pub const NativeConnectionConfig = extern struct {
    struct_size: usize,
    defaults_revision: u32,
    mode: u32,
    applicable_fields: u64,
    explicitly_configured_fields: u64,
    defaulted_fields: u64,
    configurable_fields: u64,
    max_connections: u32,
    reserved: u32,
    max_requests_per_connection: u64,
    idle_timeout_ms: u64,
};

pub const NativeConnectionApplyResult = extern struct {
    struct_size: usize,
    apply_status: c_int,
    changed: u32,
    reason: u32,
    runtime_state: u32,
    validation: NativeConnectionValidation,
    effective_config: NativeConnectionConfig,
};

pub const NativeSecurityOptions = extern struct {
    struct_size: usize,
    fields: u64,
    mode: u32,
    credential_source_kind: u32,
    reload_mode: u32,
    reserved: u32,
    credential_generation: u64,
    credential_id: ?[*:0]const u8,
    ca_certificate_file: ?[*:0]const u8,
    identity_certificate_file: ?[*:0]const u8,
    private_key_file: ?[*:0]const u8,
};

pub const NativeSecurityValidation = extern struct {
    struct_size: usize,
    code: u32,
    reserved: u32,
    field: u64,
};

pub const NativeSecurityConfig = extern struct {
    struct_size: usize,
    mode: u32,
    credential_source_kind: u32,
    reload_mode: u32,
    reload_status: u32,
    credential_generation: u64,
    credential_id: ?[*:0]const u8,
};

pub const NativeSecurityIdentity = extern struct {
    struct_size: usize,
    minimum_protocol_version: u32,
    maximum_protocol_version: u32,
    inbound_verification_flags: u64,
    outbound_verification_flags: u64,
    identity_not_before_unix_seconds: i64,
    identity_not_after_unix_seconds: i64,
    credential_id_value: [128]u8,
    identity_fingerprint_sha256: [65]u8,
};

pub const NativeSecurityInfo = extern struct {
    struct_size: usize,
    config: NativeSecurityConfig,
    identity: NativeSecurityIdentity,
};

pub const NativeSecurityApplyResult = extern struct {
    struct_size: usize,
    apply_status: c_int,
    changed: u32,
    reason: u32,
    runtime_state: u32,
    validation: NativeSecurityValidation,
    active_security: NativeSecurityInfo,
};

pub fn connectionOptions(spec: TcpConnectionStrategySpec) NativeConnectionOptions {
    var out = std.mem.zeroes(NativeConnectionOptions);
    out.struct_size = @sizeOf(NativeConnectionOptions);
    out.fields = ConnectionFieldMode;
    out.mode = spec.mode.value;
    if (spec.max_connections) |value| {
        out.fields |= ConnectionFieldMaxConnections;
        out.max_connections = value;
    }
    if (spec.max_requests_per_connection) |value| {
        out.fields |= ConnectionFieldMaxRequests;
        out.max_requests_per_connection = value;
    }
    if (spec.idle_timeout_ms) |value| {
        out.fields |= ConnectionFieldIdleTimeout;
        out.idle_timeout_ms = value;
    }
    return out;
}

pub fn securityOptions(spec: TcpSecuritySpec) !NativeSecurityOptions {
    try rejectEmbeddedNul(spec.credential_id);
    try rejectEmbeddedNul(spec.ca_certificate_file);
    try rejectEmbeddedNul(spec.identity_certificate_file);
    try rejectEmbeddedNul(spec.private_key_file);

    var out = std.mem.zeroes(NativeSecurityOptions);
    out.struct_size = @sizeOf(NativeSecurityOptions);
    out.fields = SecurityFieldMode;
    out.mode = spec.mode.value;
    if (!spec.mode.eql(.plaintext)) {
        out.fields = SecurityAllFields;
        out.credential_source_kind = CredentialSourceFile;
        out.reload_mode = spec.reload_mode.value;
        out.credential_generation = spec.credential_generation;
        out.credential_id = spec.credential_id.ptr;
        out.ca_certificate_file = spec.ca_certificate_file.ptr;
        out.identity_certificate_file = spec.identity_certificate_file.ptr;
        out.private_key_file = spec.private_key_file.ptr;
        return out;
    }

    if (!spec.reload_mode.eql(.graceful)) {
        out.fields |= SecurityFieldReloadMode;
        out.reload_mode = spec.reload_mode.value;
    }
    if (spec.credential_generation != 0) {
        out.fields |= SecurityFieldGeneration;
        out.credential_generation = spec.credential_generation;
    }
    if (spec.credential_id.len != 0) {
        out.fields |= SecurityFieldCredentialId;
        out.credential_id = spec.credential_id.ptr;
    }
    if (spec.ca_certificate_file.len != 0 or
        spec.identity_certificate_file.len != 0 or
        spec.private_key_file.len != 0)
    {
        out.fields |= SecurityFieldSource;
        out.credential_source_kind = CredentialSourceFile;
    }
    if (spec.ca_certificate_file.len != 0) {
        out.fields |= SecurityFieldCaFile;
        out.ca_certificate_file = spec.ca_certificate_file.ptr;
    }
    if (spec.identity_certificate_file.len != 0) {
        out.fields |= SecurityFieldIdentityFile;
        out.identity_certificate_file = spec.identity_certificate_file.ptr;
    }
    if (spec.private_key_file.len != 0) {
        out.fields |= SecurityFieldKeyFile;
        out.private_key_file = spec.private_key_file.ptr;
    }
    return out;
}

pub fn capabilitySnapshot(native: NativeCapabilities) CapabilitySnapshot {
    return .{
        .edition = native.edition,
        .license_status = native.license_status,
        .compiled = .{ .value = native.compiled_capabilities },
        .entitled = .{ .value = native.entitled_capabilities },
        .effective = .{ .value = native.effective_capabilities },
        .tcp_connection_defaults_revision = native.tcp_connection_defaults_revision,
    };
}

pub fn connectionConfig(native: NativeConnectionConfig) ConnectionConfigSnapshot {
    return .{
        .defaults_revision = native.defaults_revision,
        .mode = .{ .value = native.mode },
        .applicable_fields = native.applicable_fields,
        .explicitly_configured_fields = native.explicitly_configured_fields,
        .defaulted_fields = native.defaulted_fields,
        .configurable_fields = native.configurable_fields,
        .max_connections = native.max_connections,
        .max_requests_per_connection = native.max_requests_per_connection,
        .idle_timeout_ms = native.idle_timeout_ms,
    };
}

pub fn connectionResult(native: NativeConnectionApplyResult, reason: ?[*:0]const u8) ConnectionApplyResult {
    return .{
        .status = .{ .value = native.apply_status },
        .changed = native.changed != 0,
        .reason = .{ .value = native.reason },
        .reason_name = copyCString(reason),
        .runtime_state = native.runtime_state,
        .validation_code = .{ .value = native.validation.code },
        .validation_field = native.validation.field,
        .minimum_value = native.validation.minimum_value,
        .maximum_value = native.validation.maximum_value,
        .active_config = connectionConfig(native.effective_config),
    };
}

pub fn securityInfo(native: NativeSecurityInfo) SecurityInfoSnapshot {
    return .{
        .mode = .{ .value = native.config.mode },
        .credential_source_kind = native.config.credential_source_kind,
        .reload_mode = .{ .value = native.config.reload_mode },
        .reload_status = native.config.reload_status,
        .credential_generation = native.config.credential_generation,
        .credential_id = copyFixed(&native.identity.credential_id_value),
        .minimum_protocol_version = native.identity.minimum_protocol_version,
        .maximum_protocol_version = native.identity.maximum_protocol_version,
        .inbound_verification_flags = native.identity.inbound_verification_flags,
        .outbound_verification_flags = native.identity.outbound_verification_flags,
        .identity_not_before_unix_seconds = native.identity.identity_not_before_unix_seconds,
        .identity_not_after_unix_seconds = native.identity.identity_not_after_unix_seconds,
        .identity_fingerprint_sha256 = copyFixed(&native.identity.identity_fingerprint_sha256),
    };
}

pub fn securityResult(native: NativeSecurityApplyResult, reason: ?[*:0]const u8) SecurityApplyResult {
    return .{
        .status = .{ .value = native.apply_status },
        .changed = native.changed != 0,
        .reason = .{ .value = native.reason },
        .reason_name = copyCString(reason),
        .runtime_state = native.runtime_state,
        .validation_code = .{ .value = native.validation.code },
        .validation_field = native.validation.field,
        .active_security = securityInfo(native.active_security),
    };
}

fn rejectEmbeddedNul(value: [:0]const u8) !void {
    if (std.mem.indexOfScalar(u8, value, 0) != null) {
        return error.EmbeddedNul;
    }
}

fn copyCString(value: ?[*:0]const u8) FixedString {
    if (value) |pointer| return copySlice(std.mem.span(pointer));
    return .{};
}

fn copyFixed(value: anytype) FixedString {
    var length: usize = 0;
    while (length < value.len and value[length] != 0) : (length += 1) {}
    return copySlice(value[0..length]);
}

fn copySlice(value: []const u8) FixedString {
    var out = FixedString{};
    out.len = @min(value.len, out.bytes.len);
    @memcpy(out.bytes[0..out.len], value[0..out.len]);
    return out;
}
