# CoAkka Raspberry Pi Camera 1.1.2 candidate

Extract this archive and run `./coakka_camera_pi --help` from its directory.
See the [camera guide](https://github.com/phuong-tran/coakka-samples/tree/main/coakka-runtime/demos/rpi-camera) for device setup, the shared token, and run commands.
